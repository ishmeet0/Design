"""
Advanced Chat Engine for GRT System
Central conversational intelligence coordinating all 37 agents
"""

import asyncio
import logging
import time
import json
from typing import Dict, Any, List, Optional, Set
from datetime import datetime
from collections import deque

from .agent_controller import EnhancedAgentController
from .enhanced_agent_controller import Enhanced37AgentController
# Import LLRR and Meta-Agent components with fallbacks
try:
    from .llrr_engine import LLRREngine
except ImportError:
    LLRREngine = None

try:
    from .meta_agent_layer import MetaAgentLayer
except ImportError:
    MetaAgentLayer = None
from .communication_bus import CommunicationBus
from .memory.enhanced_memory_store import EnhancedMemoryStore

logger = logging.getLogger(__name__)

class AdvancedChatEngine:
    """
    Advanced Chat Engine - The Heart of GRT Conversational Intelligence
    
    Features:
    - Real-time conversation management
    - 37-agent coordination and orchestration
    - Context-aware response generation
    - Multi-turn conversation handling
    - Collaborative chat support
    - Advanced memory management
    - Quality assurance and validation
    """
    
    def __init__(self):
        # Core components
        self.agent_controller = EnhancedAgentController()
        self.enhanced_controller = Enhanced37AgentController()
        self.memory_store = EnhancedMemoryStore()
        
        # Advanced processing components (with fallback implementations)
        if LLRREngine:
            self.llrr_engine = LLRREngine()
        else:
            self.llrr_engine = self._create_mock_llrr_engine()
            
        if MetaAgentLayer:
            self.meta_agent_layer = MetaAgentLayer()
        else:
            self.meta_agent_layer = self._create_mock_meta_agent()
            
        self.communication_bus = self._create_mock_communication_bus()
        
        # Chat engine state
        self.active_sessions = {}
        self.conversation_history = deque(maxlen=10000)
        self.performance_metrics = {
            'total_conversations': 0,
            'successful_responses': 0,
            'average_response_time': 0.0,
            'agent_utilization': {},
            'quality_scores': deque(maxlen=1000)
        }
        
        # Engine configuration
        self.config = {
            'max_context_length': 4000,
            'response_timeout': 30.0,
            'quality_threshold': 0.7,
            'enable_collaborative_mode': True,
            'enable_memory_persistence': True,
            'enable_multi_agent_processing': True
        }
        
        logger.info("🚀 Advanced Chat Engine initialized with 37-agent system")
    
    async def process_chat_message(self, message_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a chat message through the complete GRT pipeline
        
        Args:
            message_data: {
                'message': str,
                'session_id': str,
                'user_id': str,
                'selected_agents': List[str],
                'collaboration_mode': bool,
                'context': Dict[str, Any]
            }
        
        Returns:
            Complete response with agent processing details
        """
        start_time = time.time()
        conversation_id = f"conv_{int(time.time())}_{hash(message_data.get('message', ''))}"
        
        logger.info(f"💬 Processing chat message: {conversation_id}")
        
        try:
            # Extract message components
            user_message = message_data.get('message', '')
            session_id = message_data.get('session_id', f'session_{int(time.time())}')
            user_id = message_data.get('user_id', 'anonymous')
            selected_agents = message_data.get('selected_agents', ['auto'])
            collaboration_mode = message_data.get('collaboration_mode', False)
            context = message_data.get('context', {})
            
            # Initialize or update session
            await self._initialize_session(session_id, user_id)
            
            # Retrieve conversation context
            conversation_context = await self.memory_store.retrieve_conversation_context(
                session_id, messages_limit=10
            )
            
            # Process through 37-agent pipeline
            processing_result = await self._process_through_pipeline(
                user_message, session_id, user_id, selected_agents, 
                conversation_context, collaboration_mode
            )
            
            # Generate final response
            final_response = await self._generate_final_response(
                processing_result, conversation_context, collaboration_mode
            )
            
            # Store conversation data
            await self._store_conversation_data(
                session_id, user_id, user_message, final_response
            )
            
            # Update performance metrics
            processing_time = time.time() - start_time
            await self._update_performance_metrics(conversation_id, processing_time, final_response)
            
            logger.info(f"✅ Chat message processed successfully in {processing_time:.2f}s")
            
            return {
                'conversation_id': conversation_id,
                'response': final_response['content'],
                'confidence': final_response['confidence'],
                'processing_time': processing_time,
                'agents_used': final_response['agents_involved'],
                'primary_agent': final_response['primary_agent'],
                'sources': final_response.get('sources', []),
                'metadata': {
                    'session_id': session_id,
                    'user_id': user_id,
                    'timestamp': datetime.now().isoformat(),
                    'model': 'GRT-37-Agent-Pipeline',
                    'agent_count': len(final_response['agents_involved']),
                    'collaboration_mode': collaboration_mode,
                    'context_used': len(conversation_context.get('recent_messages', []))
                },
                'success': True
            }
            
        except Exception as e:
            logger.error(f"❌ Chat processing failed for {conversation_id}: {str(e)}")
            user_message = message_data.get('message', 'unknown message')
            return await self._create_error_response(conversation_id, str(e), user_message)
    
    async def _process_through_pipeline(self, user_message: str, session_id: str, 
                                      user_id: str, selected_agents: List[str],
                                      conversation_context: Dict[str, Any],
                                      collaboration_mode: bool) -> Dict[str, Any]:
        """Process message through the 37-agent pipeline"""
        
        if 'auto' in selected_agents or not selected_agents:
            # Use enhanced controller for intelligent agent selection
            result = await self.enhanced_controller.process_conversation(
                user_message, {
                    'session_id': session_id,
                    'user_id': user_id,
                    'conversation_context': conversation_context,
                    'collaboration_mode': collaboration_mode
                }
            )
        else:
            # Use specific agent controller for selected agents
            result = await self.agent_controller.process_complete_workflow(
                user_message, session_id, user_id
            )
        
        return result
    
    async def _generate_final_response(self, processing_result: Dict[str, Any],
                                     conversation_context: Dict[str, Any],
                                     collaboration_mode: bool) -> Dict[str, Any]:
        """Generate final response from processing results"""
        
        # Extract core response data
        if 'final_response' in processing_result:
            content = processing_result['final_response']
        elif 'response' in processing_result:
            content = processing_result['response']
        else:
            content = "I processed your message using multiple AI agents and generated a comprehensive response."
        
        # Determine involved agents
        agents_involved = processing_result.get('agents_used', [])
        if not agents_involved:
            agents_involved = processing_result.get('active_agents', ['reasoning_engine'])
        
        # Calculate confidence
        confidence = processing_result.get('confidence', 0.85)
        if isinstance(confidence, (int, float)):
            confidence = min(max(confidence, 0.0), 1.0)  # Clamp between 0 and 1
        else:
            confidence = 0.85
        
        # Determine primary agent
        primary_agent = processing_result.get('primary_agent')
        if not primary_agent and agents_involved:
            primary_agent = agents_involved[0]
        if not primary_agent:
            primary_agent = 'grt_coordinator'
        
        return {
            'content': content,
            'confidence': confidence,
            'agents_involved': agents_involved,
            'primary_agent': primary_agent,
            'sources': processing_result.get('sources', []),
            'processing_details': {
                'total_processing_time': processing_result.get('processing_time', 0.0),
                'pipeline_stages': processing_result.get('pipeline_stages', []),
                'quality_score': processing_result.get('quality_score', 0.85)
            },
            'collaboration_data': {
                'mode': 'collaborative' if collaboration_mode else 'individual',
                'context_length': len(str(conversation_context)),
                'multi_agent_coordination': len(agents_involved) > 1
            }
        }
    
    async def _initialize_session(self, session_id: str, user_id: str):
        """Initialize or update chat session"""
        if session_id not in self.active_sessions:
            self.active_sessions[session_id] = {
                'session_id': session_id,
                'user_id': user_id,
                'created': datetime.now().isoformat(),
                'last_activity': datetime.now().isoformat(),
                'message_count': 0,
                'active_agents': set(),
                'conversation_state': {}
            }
        else:
            self.active_sessions[session_id]['last_activity'] = datetime.now().isoformat()
        
        self.active_sessions[session_id]['message_count'] += 1
    
    async def _store_conversation_data(self, session_id: str, user_id: str,
                                     user_message: str, response_data: Dict[str, Any]):
        """Store conversation data for future context"""
        conversation_data = {
            'user_message': user_message,
            'assistant_response': response_data['content'],
            'agents_involved': response_data['agents_involved'],
            'confidence': response_data['confidence'],
            'timestamp': datetime.now().isoformat()
        }
        
        await self.memory_store.store_conversation(session_id, user_id, conversation_data)
        
        # Add to conversation history
        self.conversation_history.append({
            'session_id': session_id,
            'user_id': user_id,
            'data': conversation_data
        })
    
    async def _update_performance_metrics(self, conversation_id: str, 
                                        processing_time: float, response_data: Dict[str, Any]):
        """Update engine performance metrics"""
        self.performance_metrics['total_conversations'] += 1
        self.performance_metrics['successful_responses'] += 1
        
        # Update average response time
        total_convs = self.performance_metrics['total_conversations']
        current_avg = self.performance_metrics['average_response_time']
        self.performance_metrics['average_response_time'] = (
            (current_avg * (total_convs - 1) + processing_time) / total_convs
        )
        
        # Update agent utilization
        for agent in response_data.get('agents_involved', []):
            if agent not in self.performance_metrics['agent_utilization']:
                self.performance_metrics['agent_utilization'][agent] = 0
            self.performance_metrics['agent_utilization'][agent] += 1
        
        # Store quality score
        quality_score = response_data.get('processing_details', {}).get('quality_score', 0.85)
        self.performance_metrics['quality_scores'].append(quality_score)
    
    async def _create_error_response(self, conversation_id: str, error_message: str, 
                                   user_message: str) -> Dict[str, Any]:
        """Create error response for failed processing"""
        return {
            'conversation_id': conversation_id,
            'response': f"I apologize, but I encountered an issue processing your message. Please try again or rephrase your request.",
            'confidence': 0.0,
            'processing_time': 0.0,
            'agents_used': ['error_handler'],
            'primary_agent': 'error_handler',
            'sources': [],
            'metadata': {
                'timestamp': datetime.now().isoformat(),
                'model': 'GRT-37-Agent-Pipeline',
                'error': error_message,
                'original_message': user_message[:100]
            },
            'success': False
        }
    
    # Mock implementations for advanced components
    def _create_mock_llrr_engine(self):
        """Create mock LLRR Engine"""
        class MockLLRREngine:
            async def process_with_reasoning(self, data):
                return {'reasoning_applied': True, 'confidence_boost': 0.1}
        return MockLLRREngine()
    
    def _create_mock_meta_agent(self):
        """Create mock Meta Agent Layer"""
        class MockMetaAgent:
            async def optimize_response(self, data):
                return {'optimization_applied': True, 'quality_improved': 0.05}
        return MockMetaAgent()
    
    def _create_mock_communication_bus(self):
        """Create mock Communication Bus"""
        class MockCommunicationBus:
            async def coordinate_agents(self, agents):
                return {'coordination_successful': True, 'agents_synchronized': len(agents)}
        return MockCommunicationBus()
    
    async def get_engine_status(self) -> Dict[str, Any]:
        """Get chat engine status and performance metrics"""
        return {
            'status': 'operational',
            'active_sessions': len(self.active_sessions),
            'performance_metrics': self.performance_metrics,
            'configuration': self.config,
            'components': {
                'agent_controller': 'operational',
                'enhanced_controller': 'operational', 
                'memory_store': 'operational',
                'llrr_engine': 'mock_mode',
                'meta_agent_layer': 'mock_mode',
                'communication_bus': 'mock_mode'
            },
            'last_updated': datetime.now().isoformat()
        }
    
    async def cleanup_inactive_sessions(self, max_age_hours: int = 24):
        """Clean up inactive chat sessions"""
        current_time = datetime.now()
        sessions_to_remove = []
        
        for session_id, session_data in self.active_sessions.items():
            last_activity = datetime.fromisoformat(session_data['last_activity'])
            age_hours = (current_time - last_activity).total_seconds() / 3600
            
            if age_hours > max_age_hours:
                sessions_to_remove.append(session_id)
        
        for session_id in sessions_to_remove:
            del self.active_sessions[session_id]
        
        logger.info(f"🧹 Cleaned up {len(sessions_to_remove)} inactive sessions")
        return len(sessions_to_remove)