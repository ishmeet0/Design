# 🎯 Advanced intent classification and context setup with multi-dimensional analysis

from .base_agent import BaseAgent
from typing import Dict, Any, List, Tuple, Optional
import re
import json
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict

@dataclass
class IntentProfile:
    """Comprehensive intent profile"""
    primary_intent: str = "unknown"
    secondary_intents: List[str] = field(default_factory=list)
    confidence_score: float = 0.0
    complexity_level: str = "medium"
    domain_specific: bool = False
    requires_context: bool = True
    expected_response_type: str = "text"
    urgency_level: str = "normal"

@dataclass
class ContextConfiguration:
    """Advanced context configuration"""
    processing_mode: str = "balanced"
    required_capabilities: List[str] = field(default_factory=list)
    knowledge_domains: List[str] = field(default_factory=list)
    response_constraints: Dict[str, Any] = field(default_factory=dict)
    quality_requirements: Dict[str, float] = field(default_factory=dict)
    interaction_patterns: List[str] = field(default_factory=list)

class IntentContextAgent(BaseAgent):
    """Agent 3: Advanced intent classification and intelligent context setup"""
    
    def __init__(self):
        super().__init__(
            name="IntentContextAgent",
            description="Advanced intent classification with multi-dimensional context analysis",
            priority=9
        )
        
        # Comprehensive intent patterns
        self.intent_taxonomy = {
            'information_seeking': {
                'question': [r'\?', r'\b(what|why|how|when|where|who|which)\b'],
                'explanation': [r'\b(explain|describe|tell me|elaborate|clarify)\b'],
                'definition': [r'\b(define|meaning|definition|what is|what are)\b'],
                'comparison': [r'\b(compare|difference|versus|vs|better|worse)\b'],
                'research': [r'\b(research|investigate|study|analyze|examine)\b']
            },
            'task_oriented': {
                'creation': [r'\b(create|make|build|generate|design|develop)\b'],
                'modification': [r'\b(edit|change|modify|update|improve|fix)\b'],
                'analysis': [r'\b(analyze|evaluate|assess|review|examine)\b'],
                'problem_solving': [r'\b(solve|fix|resolve|troubleshoot|debug|help)\b'],
                'planning': [r'\b(plan|organize|schedule|prepare|arrange)\b']
            },
            'conversational': {
                'greeting': [r'\b(hello|hi|hey|good morning|good afternoon|greetings)\b'],
                'gratitude': [r'\b(thank|thanks|appreciate|grateful)\b'],
                'apology': [r'\b(sorry|apologize|excuse me|pardon)\b'],
                'farewell': [r'\b(goodbye|bye|see you|farewell)\b'],
                'acknowledgment': [r'\b(ok|okay|yes|no|understood|got it)\b']
            },
            'creative': {
                'storytelling': [r'\b(story|tale|narrative|write|creative)\b'],
                'brainstorming': [r'\b(brainstorm|ideas|creative|imagine|think)\b'],
                'artistic': [r'\b(art|design|creative|aesthetic|visual)\b'],
                'entertainment': [r'\b(fun|game|joke|humor|entertainment)\b']
            },
            'analytical': {
                'reasoning': [r'\b(reason|logic|think|consider|deduce)\b'],
                'calculation': [r'\b(calculate|compute|math|equation|formula)\b'],
                'prediction': [r'\b(predict|forecast|estimate|project)\b'],
                'optimization': [r'\b(optimize|improve|enhance|maximize|minimize)\b']
            }
        }
        
        # Context complexity indicators
        self.complexity_indicators = {
            'simple': [r'\b(simple|basic|easy|straightforward|quick)\b'],
            'moderate': [r'\b(moderate|medium|regular|standard)\b'],
            'complex': [r'\b(complex|complicated|detailed|comprehensive|advanced)\b'],
            'expert': [r'\b(expert|professional|technical|specialized|advanced)\b']
        }
        
        # Domain classification patterns
        self.domain_patterns = {
            'technology': [r'\b(tech|software|computer|code|program|algorithm|AI|digital)\b'],
            'science': [r'\b(science|research|experiment|hypothesis|theory|data|analysis)\b'],
            'business': [r'\b(business|company|market|sales|profit|strategy|management)\b'],
            'education': [r'\b(education|learn|teach|study|school|university|student)\b'],
            'healthcare': [r'\b(health|medical|doctor|patient|treatment|medicine|therapy)\b'],
            'finance': [r'\b(finance|money|budget|investment|bank|loan|credit)\b'],
            'legal': [r'\b(legal|law|court|judge|attorney|contract|rights)\b'],
            'creative': [r'\b(art|design|music|creative|aesthetic|visual|artistic)\b'],
            'personal': [r'\b(personal|life|family|relationship|home|daily)\b'],
            'academic': [r'\b(academic|research|paper|study|thesis|journal|scholarly)\b']
        }
        
        # Urgency and priority patterns
        self.urgency_patterns = {
            'critical': [r'\b(critical|emergency|urgent|asap|immediately|crisis)\b'],
            'high': [r'\b(important|priority|soon|quickly|rush|deadline)\b'],
            'medium': [r'\b(moderate|normal|when possible|reasonable time)\b'],
            'low': [r'\b(whenever|no rush|when convenient|low priority)\b']
        }
        
        # Quality requirement patterns
        self.quality_patterns = {
            'accuracy': [r'\b(accurate|precise|exact|correct|error-free)\b'],
            'completeness': [r'\b(complete|comprehensive|thorough|detailed|full)\b'],
            'creativity': [r'\b(creative|innovative|original|unique|imaginative)\b'],
            'clarity': [r'\b(clear|simple|understandable|plain|straightforward)\b'],
            'efficiency': [r'\b(efficient|fast|quick|optimized|streamlined)\b']
        }
    
    def _define_capabilities(self) -> List[str]:
        """Define advanced intent and context capabilities"""
        return [
            'intent_classification', 'context_analysis', 'multi_intent_detection',
            'domain_classification', 'complexity_assessment', 'urgency_detection',
            'quality_requirement_analysis', 'interaction_pattern_recognition',
            'context_configuration', 'processing_mode_selection'
        ]
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Advanced intent classification and context setup"""
        current_input = pipeline_data.get('current_response', '')
        user_input = pipeline_data.get('user_input', '')
        
        self._log_processing(current_input)
        
        # Stage 1: Multi-dimensional intent classification
        intent_profile = self._classify_intent_comprehensive(current_input)
        
        # Stage 2: Domain and complexity analysis
        domain_analysis = self._analyze_domains(current_input)
        complexity_assessment = self._assess_complexity(current_input)
        
        # Stage 3: Context requirement analysis
        context_requirements = self._analyze_context_requirements(current_input, intent_profile)
        
        # Stage 4: Quality and constraint analysis
        quality_analysis = self._analyze_quality_requirements(current_input)
        constraint_analysis = self._analyze_constraints(current_input)
        
        # Stage 5: Urgency and priority assessment
        urgency_assessment = self._assess_urgency_priority(current_input)
        
        # Stage 6: Interaction pattern recognition
        interaction_patterns = self._recognize_interaction_patterns(current_input, pipeline_data)
        
        # Stage 7: Generate comprehensive context configuration
        context_config = self._generate_context_configuration(
            intent_profile, domain_analysis, complexity_assessment,
            context_requirements, quality_analysis, urgency_assessment
        )
        
        # Stage 8: Enhanced output generation
        enhanced_output = self._generate_enhanced_output(
            current_input, intent_profile, context_config
        )
        
        comprehensive_metadata = {
            'processing_stage': 'intent_and_context',
            'analysis_timestamp': datetime.now().isoformat(),
            'intent_analysis': {
                'intent_profile': intent_profile.__dict__,
                'domain_analysis': domain_analysis,
                'complexity_assessment': complexity_assessment,
                'context_requirements': context_requirements
            },
            'quality_analysis': quality_analysis,
            'constraint_analysis': constraint_analysis,
            'urgency_assessment': urgency_assessment,
            'interaction_patterns': interaction_patterns,
            'context_configuration': context_config.__dict__,
            'processing_recommendations': self._generate_processing_recommendations(
                intent_profile, context_config, quality_analysis
            )
        }
        
        return self._create_result(
            output=enhanced_output,
            metadata=comprehensive_metadata
        )
    
    def _classify_intent_comprehensive(self, text: str) -> IntentProfile:
        """Comprehensive multi-dimensional intent classification"""
        text_lower = text.lower()
        intent_scores = defaultdict(float)
        category_scores = defaultdict(float)
        
        # Analyze all intent categories and subcategories
        for category, subcategories in self.intent_taxonomy.items():
            category_total = 0
            for intent_type, patterns in subcategories.items():
                score = 0
                for pattern in patterns:
                    matches = len(re.findall(pattern, text_lower, re.IGNORECASE))
                    score += matches
                
                intent_scores[intent_type] = score
                category_total += score
            category_scores[category] = category_total
        
        # Determine primary and secondary intents
        sorted_intents = sorted(intent_scores.items(), key=lambda x: x[1], reverse=True)
        primary_intent = sorted_intents[0][0] if sorted_intents and sorted_intents[0][1] > 0 else "general"
        secondary_intents = [intent for intent, score in sorted_intents[1:4] if score > 0]
        
        # Calculate confidence score
        total_score = sum(intent_scores.values())
        primary_score = intent_scores[primary_intent]
        confidence = (primary_score / max(1, total_score)) if total_score > 0 else 0.0
        
        # Determine dominant category
        dominant_category = max(category_scores, key=category_scores.get) if category_scores else "general"
        
        # Assess if domain-specific
        domain_specific = any(score > 2 for score in intent_scores.values())
        
        # Determine expected response type
        response_type = self._determine_response_type(primary_intent, dominant_category)
        
        return IntentProfile(
            primary_intent=primary_intent,
            secondary_intents=secondary_intents,
            confidence_score=confidence,
            complexity_level=self._assess_intent_complexity(text, primary_intent),
            domain_specific=domain_specific,
            requires_context=primary_intent not in ['greeting', 'farewell', 'acknowledgment'],
            expected_response_type=response_type,
            urgency_level=self._assess_intent_urgency(text)
        )
    
    def _analyze_domains(self, text: str) -> Dict[str, Any]:
        """Analyze knowledge domains referenced in the text"""
        text_lower = text.lower()
        domain_scores = {}
        
        for domain, patterns in self.domain_patterns.items():
            score = 0
            matches = []
            for pattern in patterns:
                pattern_matches = re.findall(pattern, text_lower, re.IGNORECASE)
                matches.extend(pattern_matches)
                score += len(pattern_matches)
            
            domain_scores[domain] = {
                'relevance_score': score,
                'matches': matches,
                'is_relevant': score > 0,
                'confidence': min(1.0, score / max(1, len(text.split()) * 0.1))
            }
        
        relevant_domains = [domain for domain, data in domain_scores.items() if data['is_relevant']]
        primary_domain = max(domain_scores, key=lambda x: domain_scores[x]['relevance_score']) if relevant_domains else None
        
        return {
            'all_domains': domain_scores,
            'relevant_domains': relevant_domains,
            'primary_domain': primary_domain,
            'is_interdisciplinary': len(relevant_domains) > 2,
            'domain_complexity': len(relevant_domains)
        }
    
    def _assess_complexity(self, text: str) -> Dict[str, Any]:
        """Assess the complexity level of the request"""
        text_lower = text.lower()
        complexity_scores = {}
        
        for level, patterns in self.complexity_indicators.items():
            score = 0
            for pattern in patterns:
                score += len(re.findall(pattern, text_lower, re.IGNORECASE))
            complexity_scores[level] = score
        
        # Additional complexity factors
        word_count = len(text.split())
        sentence_count = len(re.split(r'[.!?]+', text))
        avg_sentence_length = word_count / max(1, sentence_count)
        technical_terms = len(re.findall(r'\b[A-Z]{2,}|\b\w+[._-]\w+|\b\w{10,}\b', text))
        
        # Calculate overall complexity
        explicit_complexity = max(complexity_scores, key=complexity_scores.get) if any(complexity_scores.values()) else None
        
        # Infer complexity from structure
        structural_complexity = (
            "simple" if word_count < 20 and avg_sentence_length < 15 else
            "moderate" if word_count < 100 and avg_sentence_length < 25 else
            "complex" if word_count < 300 else
            "expert"
        )
        
        final_complexity = explicit_complexity or structural_complexity
        
        return {
            'explicit_complexity': explicit_complexity,
            'structural_complexity': structural_complexity, 
            'final_complexity': final_complexity,
            'word_count': word_count,
            'sentence_count': sentence_count,
            'avg_sentence_length': avg_sentence_length,
            'technical_terms': technical_terms,
            'complexity_factors': {
                'length': word_count > 100,
                'technical': technical_terms > 3,
                'multi_part': sentence_count > 5,
                'abstract': bool(re.search(r'\b(concept|theory|abstract|philosophical)\b', text_lower))
            }
        }
    
    def _analyze_context_requirements(self, text: str, intent_profile: IntentProfile) -> Dict[str, Any]:
        """Analyze what context is required for processing"""
        requirements = {
            'external_knowledge': intent_profile.primary_intent in ['question', 'research', 'explanation'],
            'personal_context': bool(re.search(r'\b(my|me|I|personal|mine)\b', text)),
            'temporal_context': bool(re.search(r'\b(today|yesterday|tomorrow|now|recently|soon)\b', text)),
            'situational_context': bool(re.search(r'\b(here|there|this|that|current|situation)\b', text)),
            'historical_context': bool(re.search(r'\b(before|previously|last time|history|past)\b', text)),
            'comparative_context': bool(re.search(r'\b(compare|versus|better|worse|different)\b', text))
        }
        
        context_complexity = sum(requirements.values())
        
        return {
            'requirements': requirements,
            'context_complexity': context_complexity,
            'high_context_dependency': context_complexity > 3,
            'context_sources_needed': [key for key, value in requirements.items() if value]
        }
    
    def _analyze_quality_requirements(self, text: str) -> Dict[str, Any]:
        """Analyze quality requirements from the text"""
        text_lower = text.lower()
        quality_scores = {}
        
        for quality_type, patterns in self.quality_patterns.items():
            score = 0
            matches = []
            for pattern in patterns:
                pattern_matches = re.findall(pattern, text_lower, re.IGNORECASE)
                matches.extend(pattern_matches)
                score += len(pattern_matches)
            
            quality_scores[quality_type] = {
                'importance': min(1.0, score / max(1, len(text.split()) * 0.05)),
                'matches': matches,
                'explicitly_requested': score > 0
            }
        
        # Set default quality requirements
        default_requirements = {
            'accuracy': 0.8,
            'completeness': 0.7,
            'creativity': 0.5,
            'clarity': 0.8,
            'efficiency': 0.6
        }
        
        # Adjust based on explicit requirements
        final_requirements = {}
        for quality_type, default_score in default_requirements.items():
            explicit_score = quality_scores[quality_type]['importance']
            final_requirements[quality_type] = max(default_score, explicit_score)
        
        return {
            'explicit_quality_mentions': quality_scores,
            'quality_requirements': final_requirements,
            'prioritized_qualities': sorted(final_requirements.items(), key=lambda x: x[1], reverse=True)
        }
    
    def _analyze_constraints(self, text: str) -> Dict[str, Any]:
        """Analyze constraints and limitations mentioned"""
        text_lower = text.lower()
        
        constraints = {
            'length_constraints': {
                'short': bool(re.search(r'\b(brief|short|concise|summary)\b', text_lower)),
                'long': bool(re.search(r'\b(detailed|comprehensive|thorough|extensive)\b', text_lower)),
                'specific_length': re.findall(r'\b(\d+)\s*(words?|characters?|pages?)\b', text_lower)
            },
            'format_constraints': {
                'list': bool(re.search(r'\b(list|bullet|points|numbered)\b', text_lower)),
                'paragraph': bool(re.search(r'\b(paragraph|essay|prose)\b', text_lower)),
                'table': bool(re.search(r'\b(table|chart|grid)\b', text_lower)),
                'code': bool(re.search(r'\b(code|script|program)\b', text_lower))
            },
            'style_constraints': {
                'formal': bool(re.search(r'\b(formal|professional|academic)\b', text_lower)),
                'casual': bool(re.search(r'\b(casual|informal|friendly)\b', text_lower)),
                'technical': bool(re.search(r'\b(technical|detailed|specific)\b', text_lower)),
                'simple': bool(re.search(r'\b(simple|easy|basic|layman)\b', text_lower))
            },
            'time_constraints': {
                'urgent': bool(re.search(r'\b(urgent|asap|quickly|immediately)\b', text_lower)),
                'flexible': bool(re.search(r'\b(when possible|no rush|flexible)\b', text_lower))
            }
        }
        
        return constraints
    
    def _assess_urgency_priority(self, text: str) -> Dict[str, Any]:
        """Assess urgency and priority levels"""
        text_lower = text.lower()
        urgency_scores = {}
        
        for level, patterns in self.urgency_patterns.items():
            score = 0
            matches = []
            for pattern in patterns:
                pattern_matches = re.findall(pattern, text_lower, re.IGNORECASE)
                matches.extend(pattern_matches)
                score += len(pattern_matches)
            
            urgency_scores[level] = {
                'score': score,
                'matches': matches
            }
        
        # Determine urgency level
        urgency_level = max(urgency_scores, key=lambda x: urgency_scores[x]['score']) if any(urgency_scores[x]['score'] > 0 for x in urgency_scores) else 'medium'
        
        return {
            'urgency_level': urgency_level,
            'urgency_scores': urgency_scores,
            'requires_immediate_attention': urgency_level in ['critical', 'high'],
            'can_be_deferred': urgency_level in ['low', 'medium']
        }
    
    def _recognize_interaction_patterns(self, text: str, pipeline_data: Dict[str, Any]) -> List[str]:
        """Recognize interaction patterns and conversation context"""
        patterns = []
        text_lower = text.lower()
        
        # Conversational patterns
        if re.search(r'\b(please|thank you|sorry)\b', text_lower):
            patterns.append('polite_interaction')
        
        if re.search(r'\?', text):
            patterns.append('questioning')
        
        if re.search(r'\b(help|assist|support)\b', text_lower):
            patterns.append('help_seeking')
        
        # Sequential patterns (if previous messages exist)
        if pipeline_data.get('session_history'):
            patterns.append('continuing_conversation')
        
        # Task-oriented patterns
        if re.search(r'\b(step|first|then|next|finally)\b', text_lower):
            patterns.append('sequential_task')
        
        if re.search(r'\b(compare|versus|difference)\b', text_lower):
            patterns.append('comparative_analysis')
        
        return patterns
    
    def _generate_context_configuration(self, intent_profile: IntentProfile, domain_analysis: Dict[str, Any],
                                      complexity_assessment: Dict[str, Any], context_requirements: Dict[str, Any],
                                      quality_analysis: Dict[str, Any], urgency_assessment: Dict[str, Any]) -> ContextConfiguration:
        """Generate comprehensive context configuration"""
        
        # Determine processing mode
        processing_mode = self._determine_processing_mode(intent_profile, complexity_assessment)
        
        # Determine required capabilities
        required_capabilities = self._determine_required_capabilities(
            intent_profile, domain_analysis, complexity_assessment
        )
        
        # Set quality requirements
        quality_requirements = quality_analysis['quality_requirements']
        
        # Configure response constraints
        response_constraints = {
            'max_length': self._determine_max_length(complexity_assessment, intent_profile),
            'formality_level': self._determine_formality_level(intent_profile, domain_analysis),
            'technical_level': self._determine_technical_level(domain_analysis, complexity_assessment),
            'urgency_level': urgency_assessment['urgency_level']
        }
        
        return ContextConfiguration(
            processing_mode=processing_mode,
            required_capabilities=required_capabilities,
            knowledge_domains=domain_analysis['relevant_domains'],
            response_constraints=response_constraints,
            quality_requirements=quality_requirements,
            interaction_patterns=[]  # Would be filled by interaction pattern analysis
        )
    
    def _generate_enhanced_output(self, original_input: str, intent_profile: IntentProfile, 
                                context_config: ContextConfiguration) -> str:
        """Generate enhanced output with context awareness"""
        # For now, return original input with context annotations
        # In full implementation, this would apply context transformations
        
        enhancements = []
        
        if intent_profile.confidence_score < 0.5:
            enhancements.append(f"Intent clarification needed (confidence: {intent_profile.confidence_score:.2f})")
        
        if context_config.processing_mode != 'balanced':
            enhancements.append(f"Processing mode: {context_config.processing_mode}")
        
        if len(context_config.knowledge_domains) > 0:
            enhancements.append(f"Domains: {', '.join(context_config.knowledge_domains[:3])}")
        
        if enhancements:
            return original_input + "\n\n[Context Analysis: " + " | ".join(enhancements) + "]"
        else:
            return original_input
    
    def _generate_processing_recommendations(self, intent_profile: IntentProfile, 
                                           context_config: ContextConfiguration,
                                           quality_analysis: Dict[str, Any]) -> List[str]:
        """Generate recommendations for downstream processing"""
        recommendations = []
        
        if intent_profile.confidence_score < 0.6:
            recommendations.append("Request intent clarification from user")
        
        if context_config.processing_mode == 'analytical':
            recommendations.append("Apply enhanced logical reasoning")
        
        if context_config.processing_mode == 'creative':
            recommendations.append("Emphasize creative and divergent thinking")
        
        if 'accuracy' in quality_analysis['quality_requirements'] and quality_analysis['quality_requirements']['accuracy'] > 0.8:
            recommendations.append("Apply extra fact-checking and validation")
        
        if len(context_config.knowledge_domains) > 3:
            recommendations.append("Consider interdisciplinary approach")
        
        return recommendations
    
    # Helper methods
    def _determine_response_type(self, intent: str, category: str) -> str:
        """Determine expected response type"""
        response_mapping = {
            'question': 'answer',
            'explanation': 'detailed_explanation',
            'creation': 'generated_content',
            'problem_solving': 'solution_steps',
            'analysis': 'analytical_report',
            'greeting': 'acknowledgment',
            'brainstorming': 'idea_list'
        }
        return response_mapping.get(intent, 'comprehensive_response')
    
    def _assess_intent_complexity(self, text: str, intent: str) -> str:
        """Assess complexity level of the intent"""
        if intent in ['greeting', 'farewell', 'acknowledgment']:
            return 'simple'
        elif intent in ['question', 'explanation'] and len(text.split()) < 20:
            return 'simple'
        elif intent in ['creation', 'analysis', 'problem_solving']:
            return 'complex'
        else:
            return 'moderate'
    
    def _assess_intent_urgency(self, text: str) -> str:
        """Assess urgency level from intent"""
        text_lower = text.lower()
        if re.search(r'\b(emergency|critical|urgent|asap)\b', text_lower):
            return 'high'
        elif re.search(r'\b(soon|quickly|priority)\b', text_lower):
            return 'medium'
        else:
            return 'normal'
    
    def _determine_processing_mode(self, intent_profile: IntentProfile, complexity_assessment: Dict[str, Any]) -> str:
        """Determine appropriate processing mode"""
        if intent_profile.primary_intent in ['analysis', 'reasoning', 'calculation']:
            return 'analytical'
        elif intent_profile.primary_intent in ['creation', 'brainstorming', 'storytelling']:
            return 'creative'
        elif intent_profile.primary_intent in ['problem_solving', 'troubleshoot']:
            return 'solution_focused'
        elif complexity_assessment['final_complexity'] == 'expert':
            return 'comprehensive'
        else:
            return 'balanced'
    
    def _determine_required_capabilities(self, intent_profile: IntentProfile, domain_analysis: Dict[str, Any],
                                       complexity_assessment: Dict[str, Any]) -> List[str]:
        """Determine required processing capabilities"""
        capabilities = ['basic_processing']
        
        # Intent-based capabilities
        if intent_profile.primary_intent == 'question':
            capabilities.extend(['knowledge_retrieval', 'reasoning'])
        elif intent_profile.primary_intent == 'creation':
            capabilities.extend(['generation', 'creativity'])
        elif intent_profile.primary_intent == 'analysis':
            capabilities.extend(['analytical_reasoning', 'critical_thinking'])
        elif intent_profile.primary_intent == 'problem_solving':
            capabilities.extend(['problem_decomposition', 'solution_generation'])
        
        # Domain-based capabilities
        if 'technology' in domain_analysis['relevant_domains']:
            capabilities.append('technical_knowledge')
        if 'science' in domain_analysis['relevant_domains']:
            capabilities.append('scientific_reasoning')
        if 'creative' in domain_analysis['relevant_domains']:
            capabilities.append('creative_thinking')
        
        # Complexity-based capabilities
        if complexity_assessment['final_complexity'] in ['complex', 'expert']:
            capabilities.extend(['deep_reasoning', 'comprehensive_analysis'])
        
        return list(set(capabilities))  # Remove duplicates
    
    def _determine_max_length(self, complexity_assessment: Dict[str, Any], intent_profile: IntentProfile) -> int:
        """Determine maximum response length"""
        base_length = 500
        
        if complexity_assessment['final_complexity'] == 'expert':
            base_length = 2000
        elif complexity_assessment['final_complexity'] == 'complex':
            base_length = 1200
        elif complexity_assessment['final_complexity'] == 'simple':
            base_length = 200
        
        if intent_profile.primary_intent in ['explanation', 'analysis']:
            base_length *= 1.5
        elif intent_profile.primary_intent in ['greeting', 'acknowledgment']:
            base_length = 100
        
        return int(base_length)
    
    def _determine_formality_level(self, intent_profile: IntentProfile, domain_analysis: Dict[str, Any]) -> str:
        """Determine appropriate formality level"""
        if intent_profile.primary_intent in ['greeting', 'farewell']:
            return 'casual'
        elif 'business' in domain_analysis['relevant_domains'] or 'legal' in domain_analysis['relevant_domains']:
            return 'formal'
        elif 'academic' in domain_analysis['relevant_domains']:
            return 'academic'
        else:
            return 'professional'
    
    def _determine_technical_level(self, domain_analysis: Dict[str, Any], complexity_assessment: Dict[str, Any]) -> str:
        """Determine appropriate technical level"""
        if domain_analysis['primary_domain'] in ['technology', 'science']:
            if complexity_assessment['final_complexity'] == 'expert':
                return 'highly_technical'
            else:
                return 'moderately_technical'
        elif complexity_assessment['complexity_factors']['technical']:
            return 'moderately_technical'
        else:
            return 'accessible'