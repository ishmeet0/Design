# 🖊️ Creative writing, blogs, stories, etc.
from .base_agent import BaseAgent
from typing import Dict, Any

class ContentCreationAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="ContentCreationAgent", description="Creative writing, blogs, stories, etc.")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        intent_data = pipeline_data.get('stage_results', {}).get(3, {}).get('metadata', {})
        
        self._log_processing(current_response)
        
        # Enhance creative aspects if creation intent detected
        if intent_data.get('user_intent') == 'creation':
            enhanced_response = self._enhance_creative_content(current_response)
        else:
            enhanced_response = current_response
        
        return self._create_result(
            output=enhanced_response,
            metadata={'content_creation_applied': intent_data.get('user_intent') == 'creation'}
        )
    
    def _enhance_creative_content(self, response: str) -> str:
        # Add creative enhancement for content creation requests
        return response + " I'm ready to help bring your creative vision to life with detailed, engaging content."
"""
🎨 Agent 37: Content Creation Agent - Advanced content generation and creative production system
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List
import json
import re
from datetime import datetime

class Agent37ContentCreationAgent(BaseAgent):
    """Agent 37: Advanced content creation, generation, and creative production"""
    
    def __init__(self):
        super().__init__(
            name="Agent37ContentCreationAgent",
            description="Advanced content creation, generation, and creative production system",
            priority=9
        )
        
        # Content types and their characteristics
        self.content_types = {
            'article': {
                'structure': ['introduction', 'body_sections', 'conclusion'],
                'length': 'long_form',
                'style': 'informative',
                'elements': ['headlines', 'subheadings', 'paragraphs', 'transitions']
            },
            'blog_post': {
                'structure': ['hook', 'main_content', 'call_to_action'],
                'length': 'medium_form',
                'style': 'conversational',
                'elements': ['engaging_title', 'personal_voice', 'examples', 'conclusion']
            },
            'technical_documentation': {
                'structure': ['overview', 'detailed_sections', 'examples', 'references'],
                'length': 'comprehensive',
                'style': 'precise',
                'elements': ['code_blocks', 'step_by_step', 'diagrams', 'troubleshooting']
            },
            'creative_writing': {
                'structure': ['setting', 'development', 'climax', 'resolution'],
                'length': 'variable',
                'style': 'narrative',
                'elements': ['characters', 'dialogue', 'description', 'plot']
            },
            'marketing_copy': {
                'structure': ['attention', 'interest', 'desire', 'action'],
                'length': 'concise',
                'style': 'persuasive',
                'elements': ['headlines', 'benefits', 'social_proof', 'cta']
            },
            'educational_content': {
                'structure': ['learning_objectives', 'content_delivery', 'practice', 'assessment'],
                'length': 'structured',
                'style': 'instructional',
                'elements': ['examples', 'exercises', 'summaries', 'resources']
            }
        }
        
        # Creative enhancement strategies
        self.creative_strategies = {
            'engagement': {
                'techniques': ['storytelling', 'analogies', 'questions', 'scenarios'],
                'tone_variations': ['enthusiastic', 'curious', 'supportive', 'inspiring'],
                'interaction_elements': ['direct_address', 'inclusive_language', 'calls_to_action']
            },
            'clarity': {
                'techniques': ['simple_language', 'clear_structure', 'logical_flow', 'summaries'],
                'formatting': ['headers', 'bullet_points', 'numbered_lists', 'emphasis'],
                'explanatory_elements': ['definitions', 'examples', 'comparisons', 'visuals']
            },
            'creativity': {
                'techniques': ['unique_perspectives', 'creative_metaphors', 'innovative_examples', 'original_insights'],
                'style_elements': ['varied_sentence_structure', 'rich_vocabulary', 'dynamic_pacing', 'memorable_phrases'],
                'creative_formats': ['storytelling', 'dialogue', 'scenarios', 'case_studies']
            },
            'authority': {
                'techniques': ['expert_insights', 'data_references', 'case_studies', 'best_practices'],
                'credibility_elements': ['citations', 'examples', 'proven_methods', 'industry_standards'],
                'professional_tone': ['confident', 'knowledgeable', 'balanced', 'objective']
            }
        }
        
        # Quality enhancement factors
        self.quality_factors = {
            'readability': ['sentence_variety', 'paragraph_flow', 'transition_quality', 'clarity'],
            'engagement': ['hook_strength', 'interest_maintenance', 'emotional_connection', 'reader_involvement'],
            'value': ['practical_insights', 'actionable_advice', 'comprehensive_coverage', 'unique_perspective'],
            'professionalism': ['accuracy', 'consistency', 'appropriate_tone', 'error_free']
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process content through creation and enhancement system"""
        try:
            current_response = pipeline_data.get('current_response', '')
            user_input = pipeline_data.get('user_input', '')
            context = pipeline_data.get('context', {})
            
            self._log_processing(f"Content Creation: {len(current_response)} characters")
            
            # Analyze content requirements
            content_requirements = self._analyze_content_requirements(user_input, context)
            
            # Determine content type and strategy
            content_strategy = self._determine_content_strategy(current_response, content_requirements)
            
            # Apply creative enhancements
            creative_enhancements = self._apply_creative_enhancements(
                current_response, content_strategy, content_requirements
            )
            
            # Optimize content structure
            structure_optimization = self._optimize_content_structure(
                creative_enhancements['enhanced_content'], content_strategy
            )
            
            # Apply quality improvements
            quality_improvements = self._apply_quality_improvements(
                structure_optimization['structured_content'], content_requirements
            )
            
            # Generate final creative content
            final_content = self._generate_final_content(
                quality_improvements['improved_content'], content_strategy, content_requirements
            )
            
            # Create content metadata
            content_metadata = self._create_content_metadata(
                content_requirements, content_strategy, creative_enhancements, 
                structure_optimization, quality_improvements
            )
            
            return self._create_result(
                final_content,
                {
                    'content_analysis': {
                        'content_requirements': content_requirements,
                        'content_strategy': content_strategy,
                        'creative_enhancements': creative_enhancements,
                        'structure_optimization': structure_optimization,
                        'quality_improvements': quality_improvements
                    },
                    'content_metadata': content_metadata,
                    'content_type': content_strategy['content_type'],
                    'creativity_score': self._calculate_creativity_score(creative_enhancements, quality_improvements)
                }
            )
            
        except Exception as e:
            return self._create_result(
                current_response,
                {'error': f'Content creation failed: {str(e)}', 'fallback_applied': True}
            )
    
    def _analyze_content_requirements(self, user_input: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze requirements for content creation"""
        
        # Identify content purpose
        purpose_analysis = self._identify_content_purpose(user_input)
        
        # Determine target audience
        audience_analysis = self._analyze_target_audience(user_input, context)
        
        # Assess content scope and depth
        scope_analysis = self._assess_content_scope(user_input)
        
        # Identify tone and style requirements
        tone_style_requirements = self._identify_tone_and_style(user_input)
        
        # Determine output format preferences
        format_preferences = self._determine_format_preferences(user_input)
        
        # Assess creativity level needed
        creativity_level = self._assess_creativity_requirements(user_input)
        
        return {
            'purpose_analysis': purpose_analysis,
            'audience_analysis': audience_analysis,
            'scope_analysis': scope_analysis,
            'tone_style_requirements': tone_style_requirements,
            'format_preferences': format_preferences,
            'creativity_level': creativity_level,
            'content_goals': self._extract_content_goals(user_input),
            'constraints': self._identify_constraints(user_input)
        }
    
    def _determine_content_strategy(self, current_response: str, 
                                  requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Determine optimal content creation strategy"""
        
        # Determine primary content type
        content_type = self._classify_content_type(current_response, requirements)
        
        # Select enhancement strategies
        enhancement_strategies = self._select_enhancement_strategies(requirements, content_type)
        
        # Plan content structure
        structure_plan = self._plan_content_structure(content_type, requirements)
        
        # Determine creative approach
        creative_approach = self._determine_creative_approach(requirements, content_type)
        
        return {
            'content_type': content_type,
            'enhancement_strategies': enhancement_strategies,
            'structure_plan': structure_plan,
            'creative_approach': creative_approach,
            'content_config': self.content_types.get(content_type, self.content_types['article']),
            'priority_focus': self._determine_priority_focus(requirements)
        }
    
    def _apply_creative_enhancements(self, content: str, strategy: Dict[str, Any], 
                                   requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Apply creative enhancements to content"""
        
        enhanced_content = content
        applied_enhancements = []
        
        # Apply engagement enhancements
        if 'engagement' in strategy['enhancement_strategies']:
            enhanced_content = self._apply_engagement_enhancements(
                enhanced_content, requirements['audience_analysis']
            )
            applied_enhancements.append('engagement')
        
        # Apply clarity enhancements
        if 'clarity' in strategy['enhancement_strategies']:
            enhanced_content = self._apply_clarity_enhancements(
                enhanced_content, requirements['scope_analysis']
            )
            applied_enhancements.append('clarity')
        
        # Apply creativity enhancements
        if 'creativity' in strategy['enhancement_strategies']:
            enhanced_content = self._apply_creativity_enhancements(
                enhanced_content, requirements['creativity_level']
            )
            applied_enhancements.append('creativity')
        
        # Apply authority enhancements
        if 'authority' in strategy['enhancement_strategies']:
            enhanced_content = self._apply_authority_enhancements(enhanced_content)
            applied_enhancements.append('authority')
        
        return {
            'enhanced_content': enhanced_content,
            'applied_enhancements': applied_enhancements,
            'enhancement_effectiveness': self._measure_enhancement_effectiveness(content, enhanced_content)
        }
    
    def _optimize_content_structure(self, content: str, strategy: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize content structure based on strategy"""
        
        content_config = strategy['content_config']
        structure_plan = strategy['structure_plan']
        
        # Apply structural elements
        structured_content = self._apply_structural_elements(content, content_config['structure'])
        
        # Optimize flow and transitions
        flow_optimized = self._optimize_content_flow(structured_content)
        
        # Add formatting elements
        formatted_content = self._add_content_formatting(flow_optimized, content_config['elements'])
        
        # Ensure logical organization
        organized_content = self._ensure_logical_organization(formatted_content, structure_plan)
        
        return {
            'structured_content': organized_content,
            'applied_structure': content_config['structure'],
            'formatting_elements': content_config['elements'],
            'structural_improvements': self._assess_structural_improvements(content, organized_content)
        }
    
    def _apply_quality_improvements(self, content: str, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Apply quality improvements to content"""
        
        improved_content = content
        quality_enhancements = []
        
        # Improve readability
        readability_improved = self._improve_readability(improved_content, requirements)
        if readability_improved != improved_content:
            improved_content = readability_improved
            quality_enhancements.append('readability')
        
        # Enhance engagement
        engagement_enhanced = self._enhance_engagement(improved_content, requirements)
        if engagement_enhanced != improved_content:
            improved_content = engagement_enhanced
            quality_enhancements.append('engagement')
        
        # Add value elements
        value_enhanced = self._add_value_elements(improved_content, requirements)
        if value_enhanced != improved_content:
            improved_content = value_enhanced
            quality_enhancements.append('value')
        
        # Polish professionalism
        professional_polished = self._polish_professionalism(improved_content)
        if professional_polished != improved_content:
            improved_content = professional_polished
            quality_enhancements.append('professionalism')
        
        return {
            'improved_content': improved_content,
            'quality_enhancements': quality_enhancements,
            'quality_metrics': self._calculate_quality_metrics(content, improved_content)
        }
    
    def _generate_final_content(self, content: str, strategy: Dict[str, Any], 
                               requirements: Dict[str, Any]) -> str:
        """Generate final polished content"""
        
        final_content = content
        
        # Add creative flourishes if appropriate
        if requirements['creativity_level'] in ['high', 'very_high']:
            final_content = self._add_creative_flourishes(final_content, strategy)
        
        # Ensure brand consistency if specified
        if 'brand_voice' in requirements.get('constraints', {}):
            final_content = self._apply_brand_consistency(final_content, requirements['constraints'])
        
        # Add call-to-action if needed
        if strategy['creative_approach']['needs_cta']:
            final_content = self._add_appropriate_cta(final_content, requirements)
        
        # Final polish and refinement
        final_content = self._apply_final_polish(final_content, strategy['content_type'])
        
        return final_content
    
    def _create_content_metadata(self, requirements: Dict[str, Any], strategy: Dict[str, Any],
                               enhancements: Dict[str, Any], structure: Dict[str, Any], 
                               quality: Dict[str, Any]) -> Dict[str, Any]:
        """Create comprehensive content metadata"""
        
        return {
            'creation_timestamp': datetime.now().isoformat(),
            'content_type': strategy['content_type'],
            'target_audience': requirements['audience_analysis']['primary_audience'],
            'content_purpose': requirements['purpose_analysis']['primary_purpose'],
            'creative_level': requirements['creativity_level'],
            'enhancement_summary': {
                'applied_strategies': strategy['enhancement_strategies'],
                'creative_enhancements': enhancements['applied_enhancements'],
                'quality_improvements': quality['quality_enhancements']
            },
            'structural_elements': structure['applied_structure'],
            'quality_metrics': quality['quality_metrics'],
            'content_characteristics': {
                'estimated_reading_time': self._estimate_reading_time(quality['improved_content']),
                'complexity_level': self._assess_content_complexity(quality['improved_content']),
                'engagement_potential': self._assess_engagement_potential(quality['improved_content'])
            }
        }
    
    def _identify_content_purpose(self, user_input: str) -> Dict[str, Any]:
        """Identify the primary purpose of the requested content"""
        
        purpose_patterns = {
            'inform': [r'(?i)\b(?:explain|describe|tell|information|facts|details)\b'],
            'educate': [r'(?i)\b(?:teach|learn|tutorial|guide|how.?to|instruction)\b'],
            'persuade': [r'(?i)\b(?:convince|persuade|argue|sell|promote|marketing)\b'],
            'entertain': [r'(?i)\b(?:story|narrative|creative|fun|entertaining|engaging)\b'],
            'inspire': [r'(?i)\b(?:inspire|motivate|encourage|uplift|passionate)\b'],
            'solve': [r'(?i)\b(?:solve|fix|resolve|solution|answer|help)\b']
        }
        
        purpose_scores = {}
        for purpose, patterns in purpose_patterns.items():
            score = sum(len(re.findall(pattern, user_input)) for pattern in patterns)
            purpose_scores[purpose] = score
        
        primary_purpose = max(purpose_scores, key=purpose_scores.get) if any(purpose_scores.values()) else 'inform'
        
        return {
            'primary_purpose': primary_purpose,
            'purpose_scores': purpose_scores,
            'purpose_clarity': max(purpose_scores.values()) / max(1, len(user_input.split()) * 0.1),
            'secondary_purposes': [p for p, s in purpose_scores.items() if s > 0 and p != primary_purpose]
        }
    
    def _analyze_target_audience(self, user_input: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze target audience characteristics"""
        
        audience_indicators = {
            'general_public': [r'(?i)\b(?:everyone|people|public|general|audience)\b'],
            'professionals': [r'(?i)\b(?:professional|business|corporate|industry|expert)\b'],
            'students': [r'(?i)\b(?:student|learner|beginner|education|academic)\b'],
            'technical': [r'(?i)\b(?:developer|engineer|technical|programmer|specialist)\b'],
            'creative': [r'(?i)\b(?:artist|designer|creative|writer|creator)\b']
        }
        
        audience_scores = {}
        for audience, patterns in audience_indicators.items():
            score = sum(len(re.findall(pattern, user_input)) for pattern in patterns)
            audience_scores[audience] = score
        
        primary_audience = max(audience_scores, key=audience_scores.get) if any(audience_scores.values()) else 'general_public'
        
        return {
            'primary_audience': primary_audience,
            'audience_scores': audience_scores,
            'expertise_level': self._infer_audience_expertise(primary_audience, user_input),
            'communication_preferences': self._infer_communication_preferences(primary_audience)
        }
    
    def _assess_content_scope(self, user_input: str) -> Dict[str, Any]:
        """Assess the scope and depth requirements"""
        
        scope_indicators = {
            'brief': [r'(?i)\b(?:brief|short|quick|summary|overview)\b'],
            'comprehensive': [r'(?i)\b(?:comprehensive|detailed|thorough|complete|in.?depth)\b'],
            'focused': [r'(?i)\b(?:specific|particular|focused|narrow|targeted)\b'],
            'broad': [r'(?i)\b(?:broad|wide|general|extensive|covering)\b']
        }
        
        scope_scores = {}
        for scope, patterns in scope_indicators.items():
            score = sum(len(re.findall(pattern, user_input)) for pattern in patterns)
            scope_scores[scope] = score
        
        primary_scope = max(scope_scores, key=scope_scores.get) if any(scope_scores.values()) else 'focused'
        
        # Estimate content length based on scope and input complexity
        input_complexity = len(user_input.split())
        length_estimate = self._estimate_content_length(primary_scope, input_complexity)
        
        return {
            'primary_scope': primary_scope,
            'scope_scores': scope_scores,
            'estimated_length': length_estimate,
            'depth_level': self._determine_depth_level(primary_scope, scope_scores)
        }
    
    def _identify_tone_and_style(self, user_input: str) -> Dict[str, Any]:
        """Identify required tone and style"""
        
        tone_indicators = {
            'professional': [r'(?i)\b(?:professional|formal|business|official)\b'],
            'casual': [r'(?i)\b(?:casual|informal|friendly|relaxed|conversational)\b'],
            'academic': [r'(?i)\b(?:academic|scholarly|research|scientific|analytical)\b'],
            'creative': [r'(?i)\b(?:creative|artistic|expressive|imaginative)\b'],
            'authoritative': [r'(?i)\b(?:authoritative|expert|definitive|comprehensive)\b']
        }
        
        tone_scores = {}
        for tone, patterns in tone_indicators.items():
            score = sum(len(re.findall(pattern, user_input)) for pattern in patterns)
            tone_scores[tone] = score
        
        primary_tone = max(tone_scores, key=tone_scores.get) if any(tone_scores.values()) else 'professional'
        
        return {
            'primary_tone': primary_tone,
            'tone_scores': tone_scores,
            'formality_level': self._determine_formality_level(primary_tone),
            'style_preferences': self._determine_style_preferences(primary_tone, tone_scores)
        }
    
    def _calculate_creativity_score(self, enhancements: Dict[str, Any], 
                                   quality: Dict[str, Any]) -> float:
        """Calculate overall creativity score"""
        
        base_score = 0.5
        
        # Enhancement contributions
        if 'creativity' in enhancements['applied_enhancements']:
            base_score += 0.2
        if 'engagement' in enhancements['applied_enhancements']:
            base_score += 0.1
        
        # Quality contributions
        quality_boost = quality['quality_metrics'].get('creativity_improvement', 0) * 0.2
        base_score += quality_boost
        
        # Enhancement effectiveness
        effectiveness = enhancements.get('enhancement_effectiveness', {}).get('overall_improvement', 0)
        base_score += effectiveness * 0.1
        
        return min(1.0, base_score)
    
    def _classify_content_type(self, content: str, requirements: Dict[str, Any]) -> str:
        """Classify the type of content to be created"""
        
        purpose = requirements['purpose_analysis']['primary_purpose']
        audience = requirements['audience_analysis']['primary_audience']
        scope = requirements['scope_analysis']['primary_scope']
        
        # Decision logic based on purpose and audience
        if purpose == 'educate' and scope == 'comprehensive':
            return 'educational_content'
        elif purpose == 'persuade' or audience == 'professionals':
            return 'marketing_copy'
        elif audience == 'technical' or 'code' in content.lower():
            return 'technical_documentation'
        elif purpose == 'entertain' or requirements['creativity_level'] == 'high':
            return 'creative_writing'
        elif scope == 'brief' and purpose == 'inform':
            return 'blog_post'
        else:
            return 'article'
    
    def _select_enhancement_strategies(self, requirements: Dict[str, Any], content_type: str) -> List[str]:
        """Select appropriate enhancement strategies"""
        
        strategies = []
        
        # Always apply clarity
        strategies.append('clarity')
        
        # Add engagement for most content types
        if content_type in ['blog_post', 'creative_writing', 'educational_content']:
            strategies.append('engagement')
        
        # Add creativity for creative content
        if requirements['creativity_level'] in ['high', 'very_high']:
            strategies.append('creativity')
        
        # Add authority for professional/technical content
        if content_type in ['technical_documentation', 'article'] or requirements['audience_analysis']['primary_audience'] == 'professionals':
            strategies.append('authority')
        
        return strategies
    
    def _estimate_reading_time(self, content: str) -> str:
        """Estimate reading time for content"""
        words = len(content.split())
        minutes = words / 200  # Average reading speed
        
        if minutes < 1:
            return "< 1 minute"
        elif minutes < 2:
            return "1-2 minutes"
        elif minutes < 5:
            return f"{int(minutes)} minutes"
        else:
            return f"{int(minutes)} minutes"
    
    def _assess_content_complexity(self, content: str) -> str:
        """Assess content complexity level"""
        
        # Simple metrics for complexity
        avg_sentence_length = len(content.split()) / max(1, content.count('.'))
        technical_terms = len(re.findall(r'\b[A-Z]{2,}\b|\b\w*[A-Z]\w*[A-Z]\w*\b', content))
        
        if avg_sentence_length > 20 or technical_terms > 10:
            return 'high'
        elif avg_sentence_length > 15 or technical_terms > 5:
            return 'medium'
        else:
            return 'low'
    
    def _assess_engagement_potential(self, content: str) -> str:
        """Assess engagement potential of content"""
        
        engagement_indicators = [
            r'\?',  # Questions
            r'(?i)\b(?:you|your)\b',  # Direct address
            r'(?i)\b(?:imagine|consider|think about)\b',  # Engaging language
            r'(?i)\b(?:example|instance|story)\b'  # Examples and stories
        ]
        
        engagement_score = sum(len(re.findall(pattern, content)) for pattern in engagement_indicators)
        content_length = len(content.split())
        
        engagement_ratio = engagement_score / max(1, content_length / 100)
        
        if engagement_ratio > 5:
            return 'high'
        elif engagement_ratio > 2:
            return 'medium'
        else:
            return 'low'
