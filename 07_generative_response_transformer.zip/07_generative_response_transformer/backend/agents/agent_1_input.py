# 📥 Advanced input processing with language detection, noise filtering, and semantic preprocessing

import re
import hashlib
import time
from typing import Dict, Any, List, Optional
from datetime import datetime
from .base_agent import BaseAgent

class InputAgent(BaseAgent):
    """
    Enhanced Input Agent for advanced user input processing
    - Multi-language detection
    - Intent preprocessing
    - Context extraction
    - Emotional tone detection
    - Input validation and sanitization
    """

    def __init__(self):
        super().__init__(
            name="Input Processing Agent",
            description="Advanced input processing with NLP capabilities",
            priority=10,  # Highest priority as entry point
            max_retries=3,
            timeout_seconds=15
        )

        # Enhanced capabilities
        self.capabilities = [
            'multilingual_detection',
            'intent_preprocessing',
            'context_extraction',
            'emotional_analysis',
            'input_sanitization',
            'spam_detection',
            'urgency_assessment'
        ]

        # Language patterns
        self.language_patterns = {
            'english': r'[a-zA-Z\s]+',
            'spanish': r'[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ\s]+',
            'french': r'[a-zA-ZàâäéèêëïîôöùûüÿÀÂÄÉÈÊËÏÎÔÖÙÛÜŸ\s]+',
            'german': r'[a-zA-ZäöüßÄÖÜ\s]+',
            'chinese': r'[\u4e00-\u9fff]+',
            'arabic': r'[\u0600-\u06ff]+',
            'russian': r'[\u0400-\u04ff]+',
            'japanese': r'[\u3040-\u309f\u30a0-\u30ff\u4e00-\u9fff]+',
            'korean': r'[\uac00-\ud7af]+'
        }

        # Emotional indicators
        self.emotion_patterns = {
            'excitement': r'[!]{2,}|wow|amazing|awesome|fantastic',
            'frustration': r'argh|ugh|frustrated|annoying|hate',
            'confusion': r'\?{2,}|confused|don\'t understand|what',
            'urgency': r'urgent|asap|quickly|immediate|emergency',
            'politeness': r'please|thank you|thanks|excuse me|sorry'
        }

        # Intent patterns
        self.intent_patterns = {
            'question': r'\?|what|how|when|where|why|who|which',
            'request': r'can you|could you|would you|please',
            'command': r'^(create|make|build|generate|write|design)',
            'greeting': r'^(hi|hello|hey|good morning|good afternoon)',
            'goodbye': r'bye|goodbye|see you|farewell|exit',
            'help': r'help|assist|support|guide|tutorial'
        }

    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Enhanced input processing with comprehensive analysis"""

        # Extract input text
        user_input = pipeline_data.get('user_input', '')
        if not user_input:
            user_input = pipeline_data.get('current_response', '')

        # Log processing
        self._log_processing(f"Processing input: {user_input[:100]}...")

        # Comprehensive input analysis
        analysis_result = self._analyze_input_comprehensive(user_input)

        # Enhanced metadata
        enhanced_metadata = {
            'input_analysis': analysis_result,
            'processing_timestamp': datetime.now().isoformat(),
            'input_hash': hashlib.md5(user_input.encode()).hexdigest(),
            'processing_confidence': self._calculate_confidence(analysis_result),
            'recommended_agents': self._recommend_next_agents(analysis_result),
            'priority_level': self._assess_priority(analysis_result)
        }

        # Create enhanced output
        enhanced_output = self._create_enhanced_output(user_input, analysis_result)

        return self._create_result(
            output=enhanced_output,
            metadata=enhanced_metadata
        )

    def _analyze_input_comprehensive(self, user_input: str) -> Dict[str, Any]:
        """Comprehensive input analysis"""
        return {
            'original_input': user_input,
            'cleaned_input': self._sanitize_input(user_input),
            'language_detected': self._detect_language(user_input),
            'emotional_tone': self._analyze_emotional_tone(user_input),
            'intent_classification': self._classify_intent(user_input),
            'complexity_score': self._assess_complexity(user_input),
            'context_hints': self._extract_context_hints(user_input),
            'urgency_level': self._assess_urgency(user_input),
            'spam_probability': self._detect_spam(user_input),
            'input_length': len(user_input),
            'word_count': len(user_input.split()),
            'sentence_count': len(re.split(r'[.!?]+', user_input))
        }

    def _sanitize_input(self, text: str) -> str:
        """Advanced input sanitization"""
        # Remove potentially harmful content
        cleaned = re.sub(r'<script.*?</script>', '', text, flags=re.IGNORECASE)
        cleaned = re.sub(r'javascript:', '', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r'on\w+\s*=', '', cleaned, flags=re.IGNORECASE)

        # Normalize whitespace
        cleaned = ' '.join(cleaned.split())

        # Remove excessive punctuation
        cleaned = re.sub(r'([.!?]){3,}', r'\1\1', cleaned)

        return cleaned.strip()

    def _detect_language(self, text: str) -> Dict[str, Any]:
        """Enhanced language detection"""
        detected_languages = []
        confidence_scores = {}

        for lang, pattern in self.language_patterns.items():
            matches = len(re.findall(pattern, text, re.IGNORECASE))
            if matches > 0:
                confidence = min(matches / len(text.split()), 1.0)
                confidence_scores[lang] = confidence
                if confidence > 0.3:
                    detected_languages.append(lang)

        primary_language = max(confidence_scores, key=confidence_scores.get) if confidence_scores else 'english'

        return {
            'primary_language': primary_language,
            'detected_languages': detected_languages,
            'confidence_scores': confidence_scores,
            'is_multilingual': len(detected_languages) > 1
        }

    def _analyze_emotional_tone(self, text: str) -> Dict[str, Any]:
        """Advanced emotional tone analysis"""
        emotions_detected = {}

        for emotion, pattern in self.emotion_patterns.items():
            matches = len(re.findall(pattern, text, re.IGNORECASE))
            if matches > 0:
                emotions_detected[emotion] = matches

        # Calculate overall emotional sentiment
        positive_indicators = emotions_detected.get('excitement', 0) + emotions_detected.get('politeness', 0)
        negative_indicators = emotions_detected.get('frustration', 0) + emotions_detected.get('confusion', 0)

        sentiment_score = (positive_indicators - negative_indicators) / max(len(text.split()), 1)

        dominant_emotion = max(emotions_detected, key=emotions_detected.get) if emotions_detected else 'neutral'

        return {
            'emotions_detected': emotions_detected,
            'dominant_emotion': dominant_emotion,
            'sentiment_score': sentiment_score,
            'emotional_intensity': sum(emotions_detected.values()),
            'requires_empathy': any(emotion in emotions_detected for emotion in ['frustration', 'confusion'])
        }

    def _classify_intent(self, text: str) -> Dict[str, Any]:
        """Advanced intent classification"""
        intents_detected = {}

        for intent, pattern in self.intent_patterns.items():
            if re.search(pattern, text, re.IGNORECASE):
                intents_detected[intent] = True

        primary_intent = list(intents_detected.keys())[0] if intents_detected else 'general'

        return {
            'primary_intent': primary_intent,
            'all_intents': list(intents_detected.keys()),
            'is_question': 'question' in intents_detected,
            'is_request': 'request' in intents_detected,
            'is_command': 'command' in intents_detected,
            'requires_action': any(intent in intents_detected for intent in ['command', 'request'])
        }

    def _assess_complexity(self, text: str) -> float:
        """Assess input complexity for routing"""
        words = text.split()
        sentences = re.split(r'[.!?]+', text)

        complexity_factors = {
            'length': min(len(words) / 50, 1.0),
            'sentence_variety': min(len(sentences) / 5, 1.0),
            'technical_terms': len(re.findall(r'\b(API|algorithm|function|database|server|code|programming)\b', text, re.IGNORECASE)) * 0.2,
            'question_marks': text.count('?') * 0.1,
            'special_requests': len(re.findall(r'\b(create|build|design|analyze|generate)\b', text, re.IGNORECASE)) * 0.2
        }

        return min(sum(complexity_factors.values()) / len(complexity_factors), 1.0)

    def _extract_context_hints(self, text: str) -> List[str]:
        """Extract context hints for better understanding"""
        context_hints = []

        # Domain-specific contexts
        domains = {
            'coding': r'\b(code|programming|function|variable|class|python|javascript)\b',
            'design': r'\b(design|UI|UX|interface|layout|color|font)\b',
            'cad': r'\b(CAD|3D|model|drawing|engineering|mechanical)\b',
            'general': r'\b(help|question|how|what|explain)\b'
        }

        for domain, pattern in domains.items():
            if re.search(pattern, text, re.IGNORECASE):
                context_hints.append(domain)

        return context_hints

    def _assess_urgency(self, text: str) -> Dict[str, Any]:
        """Assess urgency level"""
        urgency_indicators = len(re.findall(r'\b(urgent|asap|quickly|immediate|emergency|now)\b', text, re.IGNORECASE))
        exclamation_marks = text.count('!')

        urgency_score = min((urgency_indicators * 0.4 + exclamation_marks * 0.1), 1.0)

        if urgency_score > 0.7:
            level = 'high'
        elif urgency_score > 0.3:
            level = 'medium'
        else:
            level = 'low'

        return {
            'urgency_level': level,
            'urgency_score': urgency_score,
            'requires_immediate_attention': urgency_score > 0.7
        }

    def _detect_spam(self, text: str) -> float:
        """Detect spam probability"""
        spam_indicators = [
            len(re.findall(r'[A-Z]{3,}', text)) * 0.1,  # Excessive caps
            text.count('!') * 0.05,  # Excessive exclamation
            len(re.findall(r'\$\d+', text)) * 0.1,  # Money mentions
            len(re.findall(r'(click here|visit|buy now)', text, re.IGNORECASE)) * 0.2
        ]

        return min(sum(spam_indicators), 1.0)

    def _calculate_confidence(self, analysis: Dict[str, Any]) -> float:
        """Calculate processing confidence"""
        confidence_factors = [
            0.2 if analysis['language_detected']['primary_language'] != 'unknown' else 0.0,
            0.2 if analysis['intent_classification']['primary_intent'] != 'general' else 0.1,
            0.2 if analysis['emotional_tone']['dominant_emotion'] != 'neutral' else 0.1,
            0.2 if analysis['context_hints'] else 0.0,
            0.2  # Base confidence
        ]

        return sum(confidence_factors)

    def _recommend_next_agents(self, analysis: Dict[str, Any]) -> List[int]:
        """Recommend next agents based on analysis"""
        recommendations = [2, 3]  # Always include thinking and intent agents

        # Add specialized agents based on context
        if 'coding' in analysis['context_hints']:
            recommendations.extend([13, 24])  # Code interpreter, inference optimizer

        if 'design' in analysis['context_hints']:
            recommendations.extend([16, 20])  # Visualizer, UI/UX designer

        if 'cad' in analysis['context_hints']:
            recommendations.extend([15])  # CAD generator

        if analysis['emotional_tone']['requires_empathy']:
            recommendations.extend([9, 18])  # Personality engine, emotion detector

        if analysis['intent_classification']['is_question']:
            recommendations.extend([12, 23])  # Fact checker, QA agent

        return list(set(recommendations))  # Remove duplicates

    def _assess_priority(self, analysis: Dict[str, Any]) -> int:
        """Assess processing priority (1-10, higher = more urgent)"""
        base_priority = 5

        if analysis['urgency_level']['urgency_level'] == 'high':
            base_priority += 3
        elif analysis['urgency_level']['urgency_level'] == 'medium':
            base_priority += 1

        if analysis['complexity_score'] > 0.7:
            base_priority += 2

        if analysis['emotional_tone']['requires_empathy']:
            base_priority += 1

        return min(base_priority, 10)

    def _create_enhanced_output(self, original_input: str, analysis: Dict[str, Any]) -> str:
        """Create enhanced output for next agents"""
        return f"""ENHANCED INPUT ANALYSIS:
Original: {original_input}
Language: {analysis['language_detected']['primary_language']}
Intent: {analysis['intent_classification']['primary_intent']}
Emotion: {analysis['emotional_tone']['dominant_emotion']}
Complexity: {analysis['complexity_score']:.2f}
Context: {', '.join(analysis['context_hints']) if analysis['context_hints'] else 'General'}
Urgency: {analysis['urgency_level']['urgency_level']}

PROCESSED INPUT: {analysis['cleaned_input']}"""

    def _define_capabilities(self) -> List[str]:
        """Override base method with enhanced capabilities"""
        return [
            'advanced_input_processing',
            'multilingual_support',
            'emotional_intelligence',
            'intent_classification',
            'spam_detection',
            'urgency_assessment',
            'context_extraction',
            'complexity_analysis'
        ]

    def _define_dependencies(self) -> List[str]:
        """No dependencies for input agent"""
        return []