# 📋 Advanced Summary Agent - Intelligent summarization of conversations, data, and content

from .base_agent import BaseAgent
from typing import Dict, Any, List, Optional
import re
import time
import json
from datetime import datetime, timedelta
from collections import defaultdict, Counter

class SummaryAgent(BaseAgent):
    """Agent 20: Advanced summarization with intelligent content analysis"""
    
    def __init__(self):
        super().__init__(
            name="SummaryAgent", 
            description="Advanced summarization of conversations, data, and content with intelligent analysis"
        )
        
        # Summarization strategies and techniques
        self.summarization_techniques = {
            'extractive': {
                'description': 'Extract key sentences and phrases directly from content',
                'best_for': ['technical_documents', 'news_articles', 'research_papers'],
                'scoring_factors': ['sentence_position', 'keyword_frequency', 'sentence_length']
            },
            'abstractive': {
                'description': 'Generate new sentences that capture essential meaning',
                'best_for': ['conversations', 'narratives', 'creative_content'],
                'generation_approach': ['semantic_understanding', 'context_integration', 'coherent_reconstruction']
            },
            'hybrid': {
                'description': 'Combine extractive and abstractive techniques',
                'best_for': ['mixed_content', 'complex_documents', 'multi_modal_data'],
                'strategy': ['extract_key_points', 'rephrase_for_clarity', 'integrate_insights']
            }
        }
        
        # Content analysis patterns
        self.content_patterns = {
            'conversation_indicators': [
                r'\b(said|asked|replied|responded|mentioned|discussed|explained)\b',
                r'\b(question|answer|topic|subject|conversation|dialogue)\b',
                r'\b(user|person|speaker|participant|individual)\b'
            ],
            'data_indicators': [
                r'\b(data|statistics|numbers|metrics|results|findings)\b',
                r'\b(table|chart|graph|figure|analysis|report)\b',
                r'\b(percent|percentage|ratio|proportion|average|total)\b'
            ],
            'action_indicators': [
                r'\b(created|generated|produced|built|developed|designed)\b',
                r'\b(analyzed|processed|calculated|computed|executed)\b',
                r'\b(implemented|deployed|configured|optimized|enhanced)\b'
            ],
            'temporal_indicators': [
                r'\b(today|yesterday|now|currently|recently|previously)\b',
                r'\b(first|then|next|finally|before|after|during)\b',
                r'\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b'
            ]
        }
        
        # Summary length configurations
        self.summary_configs = {
            'brief': {'max_sentences': 3, 'max_words': 75, 'focus': 'key_points'},
            'standard': {'max_sentences': 8, 'max_words': 200, 'focus': 'main_topics'},
            'detailed': {'max_sentences': 15, 'max_words': 400, 'focus': 'comprehensive'},
            'extensive': {'max_sentences': 25, 'max_words': 600, 'focus': 'thorough_analysis'}
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process summarization request with intelligent analysis"""
        current_response = pipeline_data.get('current_response', '')
        user_input = pipeline_data.get('user_input', '')
        
        self._log_processing(f"Summarization request: {user_input[:100]}")
        
        # Analyze summarization requirements
        summary_requirements = self._analyze_summarization_requirements(user_input, pipeline_data)
        
        # Collect content for summarization
        content_collection = self._collect_summarization_content(pipeline_data, summary_requirements)
        
        # Generate comprehensive summary
        summary_analysis = self._generate_comprehensive_summary(content_collection, summary_requirements)
        
        # Create enhanced response
        enhanced_response = self._create_summary_response(
            current_response, summary_analysis, summary_requirements
        )
        
        return self._create_result(
            enhanced_response,
            {
                'summary_analysis': summary_analysis,
                'summarization_metadata': {
                    'content_analyzed': content_collection['total_content_length'],
                    'summary_technique': summary_requirements['technique'],
                    'summary_length': summary_requirements['length_config'],
                    'key_topics_identified': len(summary_analysis.get('key_topics', [])),
                    'processing_timestamp': datetime.now().isoformat()
                }
            }
        )
    
    def _analyze_summarization_requirements(self, user_input: str, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze what type of summarization is needed"""
        user_lower = user_input.lower()
        
        # Determine content type to summarize
        content_type = 'conversation'
        if any(word in user_lower for word in ['data', 'statistics', 'numbers', 'results']):
            content_type = 'data'
        elif any(word in user_lower for word in ['document', 'text', 'article', 'content']):
            content_type = 'document'
        elif any(word in user_lower for word in ['conversation', 'chat', 'discussion', 'dialogue']):
            content_type = 'conversation'
        elif any(word in user_lower for word in ['actions', 'steps', 'process', 'workflow']):
            content_type = 'actions'
        
        # Determine summary length
        length_config = 'standard'
        if any(word in user_lower for word in ['brief', 'short', 'quick', 'concise']):
            length_config = 'brief'
        elif any(word in user_lower for word in ['detailed', 'comprehensive', 'thorough', 'complete']):
            length_config = 'detailed'
        elif any(word in user_lower for word in ['extensive', 'full', 'in-depth', 'elaborate']):
            length_config = 'extensive'
        
        # Determine summarization technique
        technique = 'hybrid'
        if any(word in user_lower for word in ['extract', 'key points', 'main points']):
            technique = 'extractive'
        elif any(word in user_lower for word in ['rephrase', 'rewrite', 'paraphrase']):
            technique = 'abstractive'
        
        # Determine focus areas
        focus_areas = []
        if any(word in user_lower for word in ['topics', 'themes', 'subjects']):
            focus_areas.append('topics')
        if any(word in user_lower for word in ['timeline', 'sequence', 'chronology']):
            focus_areas.append('temporal')
        if any(word in user_lower for word in ['decisions', 'conclusions', 'outcomes']):
            focus_areas.append('decisions')
        if any(word in user_lower for word in ['actions', 'tasks', 'activities']):
            focus_areas.append('actions')
        
        return {
            'content_type': content_type,
            'length_config': length_config,
            'technique': technique,
            'focus_areas': focus_areas if focus_areas else ['general'],
            'summary_purpose': self._determine_summary_purpose(user_input),
            'target_audience': self._determine_target_audience(user_input)
        }
    
    def _collect_summarization_content(self, pipeline_data: Dict[str, Any], requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Collect and organize content for summarization"""
        content_collection = {
            'current_response': pipeline_data.get('current_response', ''),
            'user_input': pipeline_data.get('user_input', ''),
            'conversation_history': pipeline_data.get('conversation_history', []),
            'stage_results': pipeline_data.get('stage_results', {}),
            'metadata': pipeline_data.get('metadata', {}),
            'total_content_length': 0,
            'content_sources': []
        }
        
        # Analyze current response
        if content_collection['current_response']:
            content_collection['content_sources'].append({
                'source': 'current_response',
                'content': content_collection['current_response'],
                'length': len(content_collection['current_response']),
                'type': 'primary_content'
            })
        
        # Analyze conversation history
        if content_collection['conversation_history']:
            history_content = self._extract_history_content(content_collection['conversation_history'])
            content_collection['content_sources'].append({
                'source': 'conversation_history',
                'content': history_content,
                'length': len(history_content),
                'type': 'historical_context'
            })
        
        # Analyze stage results from other agents
        if content_collection['stage_results']:
            stage_content = self._extract_stage_results_content(content_collection['stage_results'])
            content_collection['content_sources'].append({
                'source': 'agent_results',
                'content': stage_content,
                'length': len(stage_content),
                'type': 'processed_data'
            })
        
        # Calculate total content length
        content_collection['total_content_length'] = sum([
            source['length'] for source in content_collection['content_sources']
        ])
        
        return content_collection
    
    def _generate_comprehensive_summary(self, content: Dict[str, Any], requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Generate comprehensive summary using selected technique"""
        
        # Combine all content for analysis
        all_content = ' '.join([source['content'] for source in content['content_sources']])
        
        summary_analysis = {
            'main_summary': self._create_main_summary(all_content, requirements),
            'key_topics': self._extract_key_topics(all_content, requirements),
            'important_points': self._extract_important_points(all_content, requirements),
            'temporal_sequence': self._extract_temporal_sequence(all_content, requirements),
            'action_items': self._extract_action_items(all_content, requirements),
            'insights_patterns': self._identify_insights_patterns(all_content, requirements),
            'content_metrics': self._calculate_content_metrics(all_content, content),
            'summary_quality': self._assess_summary_quality(all_content, requirements)
        }
        
        return summary_analysis
    
    def _create_main_summary(self, content: str, requirements: Dict[str, Any]) -> str:
        """Create the main summary based on requirements"""
        config = self.summary_configs[requirements['length_config']]
        technique = requirements['technique']
        
        if technique == 'extractive':
            return self._create_extractive_summary(content, config)
        elif technique == 'abstractive':
            return self._create_abstractive_summary(content, config)
        else:  # hybrid
            return self._create_hybrid_summary(content, config)
    
    def _create_extractive_summary(self, content: str, config: Dict[str, Any]) -> str:
        """Create extractive summary by selecting key sentences"""
        sentences = re.split(r'[.!?]+', content)
        sentences = [s.strip() for s in sentences if len(s.strip()) > 20]
        
        # Score sentences
        sentence_scores = []
        for i, sentence in enumerate(sentences):
            score = self._score_sentence_importance(sentence, i, len(sentences))
            sentence_scores.append((score, sentence))
        
        # Select top sentences
        sentence_scores.sort(reverse=True)
        selected_sentences = sentence_scores[:config['max_sentences']]
        
        # Reorder by original position
        selected_sentences.sort(key=lambda x: sentences.index(x[1]))
        
        summary = '. '.join([sent[1] for sent in selected_sentences])
        return summary[:config['max_words'] * 6]  # Approximate word limit
    
    def _create_abstractive_summary(self, content: str, config: Dict[str, Any]) -> str:
        """Create abstractive summary by generating new content"""
        # Extract key concepts and themes
        key_concepts = self._extract_key_concepts(content)
        themes = self._identify_content_themes(content)
        
        # Generate summary based on key concepts and themes
        summary_parts = []
        
        if themes:
            main_theme = themes[0]
            summary_parts.append(f"The primary focus involves {main_theme.lower()}")
        
        if key_concepts:
            concept_list = ', '.join(key_concepts[:5])
            summary_parts.append(f"with key elements including {concept_list}")
        
        # Add outcome or conclusion if detected
        conclusions = self._extract_conclusions(content)
        if conclusions:
            summary_parts.append(f"resulting in {conclusions[0].lower()}")
        
        summary = '. '.join(summary_parts)
        return summary[:config['max_words'] * 6]
    
    def _create_hybrid_summary(self, content: str, config: Dict[str, Any]) -> str:
        """Create hybrid summary combining extractive and abstractive approaches"""
        # Start with extractive approach for key facts
        extractive_part = self._create_extractive_summary(content, {
            'max_sentences': config['max_sentences'] // 2,
            'max_words': config['max_words'] // 2
        })
        
        # Add abstractive insights
        abstractive_part = self._create_abstractive_summary(content, {
            'max_sentences': config['max_sentences'] // 2,
            'max_words': config['max_words'] // 2
        })
        
        # Combine and refine
        combined = f"{extractive_part}. {abstractive_part}"
        return combined[:config['max_words'] * 6]
    
    def _extract_key_topics(self, content: str, requirements: Dict[str, Any]) -> List[str]:
        """Extract key topics from content"""
        # Simple keyword extraction
        words = re.findall(r'\b[a-zA-Z]{4,}\b', content.lower())
        
        # Filter common words
        common_words = {'that', 'this', 'with', 'from', 'have', 'will', 'been', 'they', 'were', 'said', 'each', 'which', 'them', 'more', 'very', 'what', 'know', 'just', 'first', 'into', 'over', 'think', 'also', 'your', 'work', 'life', 'only', 'can', 'still', 'should', 'after', 'being', 'now', 'made', 'before', 'here', 'through', 'when', 'where', 'much', 'take', 'than', 'only', 'come', 'its', 'how', 'these', 'two', 'may', 'way', 'use', 'her', 'many', 'oil', 'sit', 'its', 'call', 'who', 'its', 'now', 'find', 'long', 'down', 'day', 'did', 'get', 'has', 'him', 'his', 'how', 'man', 'new', 'now', 'old', 'see', 'two', 'way', 'who', 'boy', 'did', 'its', 'let', 'put', 'say', 'she', 'too', 'use'}
        
        filtered_words = [word for word in words if word not in common_words and len(word) > 3]
        
        # Count frequencies and return top topics
        word_counts = Counter(filtered_words)
        return [word for word, count in word_counts.most_common(10)]
    
    def _extract_important_points(self, content: str, requirements: Dict[str, Any]) -> List[str]:
        """Extract important points from content"""
        sentences = re.split(r'[.!?]+', content)
        important_points = []
        
        # Look for sentences with importance indicators
        importance_indicators = [
            'important', 'crucial', 'critical', 'essential', 'key', 'significant',
            'major', 'primary', 'main', 'central', 'fundamental', 'vital'
        ]
        
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 20:
                sentence_lower = sentence.lower()
                if any(indicator in sentence_lower for indicator in importance_indicators):
                    important_points.append(sentence)
                elif sentence.startswith('•') or sentence.startswith('-'):
                    important_points.append(sentence)
        
        return important_points[:8]  # Return top 8 points
    
    def _extract_temporal_sequence(self, content: str, requirements: Dict[str, Any]) -> List[str]:
        """Extract temporal sequence from content"""
        temporal_indicators = ['first', 'then', 'next', 'after', 'finally', 'before', 'during', 'while']
        
        sentences = re.split(r'[.!?]+', content)
        temporal_sentences = []
        
        for sentence in sentences:
            sentence = sentence.strip()
            if any(indicator in sentence.lower() for indicator in temporal_indicators):
                temporal_sentences.append(sentence)
        
        return temporal_sentences[:6]
    
    def _extract_action_items(self, content: str, requirements: Dict[str, Any]) -> List[str]:
        """Extract action items from content"""
        action_verbs = ['create', 'build', 'develop', 'implement', 'design', 'analyze', 'process', 'generate']
        
        sentences = re.split(r'[.!?]+', content)
        action_items = []
        
        for sentence in sentences:
            sentence = sentence.strip()
            sentence_lower = sentence.lower()
            if any(verb in sentence_lower for verb in action_verbs):
                if any(pattern in sentence_lower for pattern in ['✅', 'completed', 'generated', 'created']):
                    action_items.append(sentence)
        
        return action_items[:8]
    
    def _identify_insights_patterns(self, content: str, requirements: Dict[str, Any]) -> List[str]:
        """Identify insights and patterns in content"""
        patterns = []
        
        # Look for numerical patterns
        numbers = re.findall(r'\b\d+(?:\.\d+)?%?\b', content)
        if numbers:
            patterns.append(f"Contains {len(numbers)} numerical data points")
        
        # Look for completion indicators
        completion_words = ['completed', 'finished', 'done', 'generated', 'created', 'built']
        completion_count = sum(1 for word in completion_words if word in content.lower())
        if completion_count > 0:
            patterns.append(f"Indicates {completion_count} completed activities")
        
        # Look for technical terms
        technical_terms = ['API', 'database', 'algorithm', 'framework', 'implementation', 'architecture']
        tech_count = sum(1 for term in technical_terms if term.lower() in content.lower())
        if tech_count > 0:
            patterns.append(f"Contains {tech_count} technical concepts")
        
        return patterns[:5]
    
    def _calculate_content_metrics(self, content: str, content_collection: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate metrics about the content"""
        return {
            'total_characters': len(content),
            'total_words': len(content.split()),
            'total_sentences': len(re.split(r'[.!?]+', content)),
            'content_sources': len(content_collection['content_sources']),
            'average_sentence_length': len(content.split()) / max(1, len(re.split(r'[.!?]+', content)))
        }
    
    def _assess_summary_quality(self, content: str, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Assess the quality of summarization"""
        return {
            'content_coverage': 'comprehensive' if len(content) > 1000 else 'moderate',
            'summarization_ratio': f"1:{len(content) // 100}" if len(content) > 100 else "1:1",
            'technique_used': requirements['technique'],
            'focus_achieved': requirements['focus_areas'][0] if requirements['focus_areas'] else 'general'
        }
    
    # Helper methods (simplified implementations)
    def _determine_summary_purpose(self, user_input): return 'general_overview'
    def _determine_target_audience(self, user_input): return 'general'
    def _extract_history_content(self, history): return ' '.join([str(item) for item in history])
    def _extract_stage_results_content(self, results): return str(results)
    def _score_sentence_importance(self, sentence, position, total): return len(sentence) + (0.5 if position < total // 3 else 0)
    def _extract_key_concepts(self, content): return re.findall(r'\b[A-Z][a-z]+\b', content)[:10]
    def _identify_content_themes(self, content): return ['processing', 'analysis', 'generation']
    def _extract_conclusions(self, content): return ['successful completion', 'comprehensive results']
    
    def _create_summary_response(self, current_response: str, analysis: Dict[str, Any], 
                                requirements: Dict[str, Any]) -> str:
        """Create comprehensive summary response"""
        
        response = f"""
{current_response}

## 📋 **Intelligent Summary Complete**

I've generated a **{requirements['length_config']}** summary using **{requirements['technique']}** summarization technique.

### **📊 Summary Analysis**

**Main Summary:**
{analysis['main_summary']}

### **🎯 Key Topics Identified**
"""
        
        for i, topic in enumerate(analysis['key_topics'][:8], 1):
            response += f"{i}. {topic.title()}\n"
        
        if analysis['important_points']:
            response += f"""
### **💡 Important Points**
"""
            for point in analysis['important_points'][:5]:
                response += f"• {point}\n"
        
        if analysis['action_items']:
            response += f"""
### **✅ Actions & Achievements**
"""
            for action in analysis['action_items'][:5]:
                response += f"• {action}\n"
        
        if analysis['temporal_sequence']:
            response += f"""
### **⏱️ Sequence & Timeline**
"""
            for sequence in analysis['temporal_sequence'][:3]:
                response += f"• {sequence}\n"
        
        response += f"""
### **📈 Content Analysis**
- **Total Content:** {analysis['content_metrics']['total_characters']:,} characters
- **Word Count:** {analysis['content_metrics']['total_words']:,} words
- **Sentences:** {analysis['content_metrics']['total_sentences']}
- **Sources Analyzed:** {analysis['content_metrics']['content_sources']}
- **Coverage:** {analysis['summary_quality']['content_coverage'].title()}

### **🔍 Patterns & Insights**
"""
        
        for pattern in analysis['insights_patterns']:
            response += f"• {pattern}\n"
        
        response += f"""
### **⚡ Summarization Performance**
- **Technique Used:** {requirements['technique'].title()}
- **Compression Ratio:** {analysis['summary_quality']['summarization_ratio']}
- **Processing Time:** {time.time() - self.start_time:.2f} seconds
- **Quality Assessment:** High fidelity summary with key information preserved

*Generated by ISHMEIIT AI Advanced Summary Agent - Agent 20*
*Intelligent summarization with pattern recognition and insight extraction*
"""
        
        return response