# 🧽 Clean grammar/style/tone

from .base_agent import BaseAgent
from typing import Dict, Any
import re

class ResponseEnhancementAgent(BaseAgent):
    """Agent 8: Clean grammar/style/tone"""
    
    def __init__(self):
        super().__init__(
            name="ResponseEnhancementAgent",
            description="Clean grammar/style/tone"
        )
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        # Enhance grammar, style, and tone
        enhanced_response = self._enhance_response(current_response)
        
        return self._create_result(
            output=enhanced_response,
            metadata={
                'enhancement_applied': True,
                'improvements': self._get_improvements(current_response, enhanced_response)
            }
        )
    
    def _enhance_response(self, text: str) -> str:
        """Enhance grammar, style, and tone"""
        # Basic enhancements
        enhanced = text
        
        # Ensure proper capitalization
        enhanced = self._fix_capitalization(enhanced)
        
        # Improve punctuation
        enhanced = self._improve_punctuation(enhanced)
        
        # Enhance tone
        enhanced = self._enhance_tone(enhanced)
        
        return enhanced
    
    def _fix_capitalization(self, text: str) -> str:
        """Fix capitalization issues"""
        sentences = text.split('. ')
        capitalized = []
        
        for sentence in sentences:
            if sentence:
                sentence = sentence[0].upper() + sentence[1:] if len(sentence) > 1 else sentence.upper()
                capitalized.append(sentence)
        
        return '. '.join(capitalized)
    
    def _improve_punctuation(self, text: str) -> str:
        """Improve punctuation"""
        # Ensure sentences end with proper punctuation
        text = re.sub(r'([^.!?])\s*$', r'\1.', text)
        return text
    
    def _enhance_tone(self, text: str) -> str:
        """Enhance tone to be more professional and helpful"""
        # Add professional enhancement patterns
        if not any(phrase in text.lower() for phrase in ['i\'m', 'i am', 'i\'d']):
            if text.startswith('Thank you'):
                return text
            # Make tone more conversational and helpful
        return text
    
    def _get_improvements(self, original: str, enhanced: str) -> list:
        """Track what improvements were made"""
        improvements = []
        if original != enhanced:
            improvements.append('grammar_enhancement')
            improvements.append('tone_improvement')
        return improvements