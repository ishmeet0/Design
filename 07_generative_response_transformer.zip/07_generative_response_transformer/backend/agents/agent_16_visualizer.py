# 🖼️ Generates plots/images if needed

from .base_agent import BaseAgent
from typing import Dict, Any

class VisualizerAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="VisualizerAgent", description="Generates plots/images if needed")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        visualization_needs = self._assess_visualization(current_response)
        
        return self._create_result(
            output=current_response,
            metadata={'visualization': visualization_needs}
        )
    
    def _assess_visualization(self, text: str) -> Dict[str, Any]:
        needs_viz = any(word in text.lower() for word in ['chart', 'graph', 'plot', 'visual', 'diagram'])
        return {'needs_visualization': needs_viz, 'viz_type': 'none'}