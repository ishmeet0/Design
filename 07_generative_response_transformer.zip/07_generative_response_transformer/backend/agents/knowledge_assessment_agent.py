
"""
Knowledge Assessment Agent - Step 3 of the Enhanced GRT Pipeline  
Determines if external knowledge is needed and what type
"""

import logging
import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class KnowledgeAssessmentAgent:
    """Knowledge Assessment Agent for determining external knowledge requirements"""
    
    def __init__(self):
        self.agent_id = "knowledge_assessment_agent"
        self.capabilities = [
            "knowledge_gap_detection",
            "external_source_identification", 
            "knowledge_domain_classification",
            "search_strategy_generation"
        ]
        
        # Knowledge domains that typically require external sources
        self.external_knowledge_domains = {
            'current_events': ['news', 'recent', 'today', 'latest', 'current', 'now'],
            'real_time_data': ['weather', 'stock', 'price', 'live', 'status'],
            'technical_specs': ['specification', 'version', 'release', 'update'],
            'research_data': ['study', 'research', 'paper', 'academic', 'scientific'],
            'factual_verification': ['fact', 'verify', 'confirm', 'check', 'validate'],
            'specialized_knowledge': ['medical', 'legal', 'financial', 'regulatory']
        }
        
        # Internal knowledge capabilities
        self.internal_knowledge_areas = [
            'general_programming', 'basic_math', 'common_algorithms',
            'general_design_principles', 'basic_physics', 'common_sense'
        ]
    
    async def assess_knowledge_requirements(self, context_data: Dict[str, Any]) -> Dict[str, Any]:
        """Assess knowledge requirements for the given context"""
        logger.info("📚 Knowledge Assessment Agent processing...")
        
        try:
            processed_input = context_data.get('processed_input', '')
            intent_analysis = context_data.get('intent_analysis', {})
            context_analysis = context_data.get('context_analysis', {})
            entities = context_data.get('extracted_entities', [])
            
            # Step 1: Analyze knowledge gaps
            knowledge_gaps = await self._identify_knowledge_gaps(
                processed_input, intent_analysis, context_analysis, entities
            )
            
            # Step 2: Assess internal knowledge sufficiency
            internal_sufficiency = await self._assess_internal_knowledge(
                processed_input, context_analysis
            )
            
            # Step 3: Determine external knowledge needs
            external_needs = await self._determine_external_needs(
                knowledge_gaps, internal_sufficiency
            )
            
            # Step 4: Generate search strategy if needed
            search_strategy = None
            if external_needs['requires_external']:
                search_strategy = await self._generate_search_strategy(
                    external_needs, context_analysis
                )
            
            # Step 5: Assess knowledge confidence
            confidence_assessment = await self._assess_knowledge_confidence(
                internal_sufficiency, external_needs
            )
            
            result = {
                'requires_external_knowledge': external_needs['requires_external'],
                'knowledge_gaps': knowledge_gaps,
                'internal_sufficiency': internal_sufficiency,
                'external_needs': external_needs,
                'search_strategy': search_strategy,
                'confidence_assessment': confidence_assessment,
                'knowledge_domains': external_needs.get('domains', []),
                'priority_level': external_needs.get('priority', 'medium'),
                'processing_metadata': {
                    'assessment_timestamp': datetime.now().isoformat(),
                    'agent_id': self.agent_id,
                    'assessment_confidence': confidence_assessment.get('overall_confidence', 0.7)
                }
            }
            
            logger.info(f"✅ Knowledge Assessment complete - External needed: {external_needs['requires_external']}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Knowledge Assessment Agent error: {e}")
            return {
                'requires_external_knowledge': False,
                'error': str(e),
                'agent_id': self.agent_id,
                'confidence_assessment': {'overall_confidence': 0.0}
            }
    
    async def _identify_knowledge_gaps(self, text: str, intent: Dict[str, Any], 
                                     context: Dict[str, Any], entities: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Identify potential knowledge gaps"""
        text_lower = text.lower()
        
        knowledge_gaps = {
            'temporal_gaps': [],
            'domain_specific_gaps': [],
            'factual_gaps': [],
            'technical_gaps': [],
            'contextual_gaps': []
        }
        
        # Temporal knowledge gaps (current/recent information)
        temporal_indicators = ['today', 'now', 'current', 'latest', 'recent', 'new']
        for indicator in temporal_indicators:
            if indicator in text_lower:
                knowledge_gaps['temporal_gaps'].append({
                    'type': 'temporal',
                    'indicator': indicator,
                    'requires_real_time': True
                })
        
        # Domain-specific gaps
        domain = context.get('domain', 'general')
        if domain in ['technology', 'medical', 'legal', 'finance']:
            knowledge_gaps['domain_specific_gaps'].append({
                'domain': domain,
                'specialization_level': 'high',
                'requires_expert_knowledge': True
            })
        
        # Factual verification needs
        factual_indicators = ['fact', 'true', 'correct', 'accurate', 'verify']
        for indicator in factual_indicators:
            if indicator in text_lower:
                knowledge_gaps['factual_gaps'].append({
                    'type': 'factual_verification',
                    'indicator': indicator,
                    'requires_verification': True
                })
        
        # Technical specification gaps
        tech_entities = [e for e in entities if e['type'] == 'technology']
        for entity in tech_entities:
            knowledge_gaps['technical_gaps'].append({
                'technology': entity['text'],
                'requires_specs': True,
                'knowledge_type': 'technical_specification'
            })
        
        return knowledge_gaps
    
    async def _assess_internal_knowledge(self, text: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Assess if internal knowledge is sufficient"""
        text_lower = text.lower()
        domain = context.get('domain', 'general')
        
        internal_capability_score = 0
        max_score = 5
        
        # Check against internal knowledge areas
        for area in self.internal_knowledge_areas:
            area_keywords = area.replace('_', ' ').split()
            if any(keyword in text_lower for keyword in area_keywords):
                internal_capability_score += 1
        
        # Domain-specific assessment
        if domain == 'general':
            internal_capability_score += 2
        elif domain in ['technology', 'design']:
            internal_capability_score += 1
        
        sufficiency_score = min(internal_capability_score / max_score, 1.0)
        
        return {
            'sufficiency_score': sufficiency_score,
            'capable_areas': [area for area in self.internal_knowledge_areas 
                            if any(keyword in text_lower for keyword in area.replace('_', ' ').split())],
            'confidence_level': 'high' if sufficiency_score > 0.7 else 'medium' if sufficiency_score > 0.4 else 'low',
            'internal_knowledge_available': sufficiency_score > 0.3
        }
    
    async def _determine_external_needs(self, knowledge_gaps: Dict[str, Any], 
                                      internal_sufficiency: Dict[str, Any]) -> Dict[str, Any]:
        """Determine if external knowledge is needed"""
        requires_external = False
        domains = []
        priority = 'low'
        reasons = []
        
        # Check temporal gaps
        if knowledge_gaps['temporal_gaps']:
            requires_external = True
            domains.append('real_time_data')
            priority = 'high'
            reasons.append('Real-time information required')
        
        # Check domain-specific gaps
        if knowledge_gaps['domain_specific_gaps']:
            domain_gap = knowledge_gaps['domain_specific_gaps'][0]
            if domain_gap.get('requires_expert_knowledge'):
                requires_external = True
                domains.append('specialized_knowledge')
                priority = max(priority, 'medium')
                reasons.append('Expert domain knowledge required')
        
        # Check factual verification needs
        if knowledge_gaps['factual_gaps']:
            requires_external = True
            domains.append('factual_verification')
            priority = max(priority, 'medium')
            reasons.append('Factual verification required')
        
        # Check technical specification needs
        if knowledge_gaps['technical_gaps']:
            requires_external = True
            domains.append('technical_specs')
            reasons.append('Technical specifications required')
        
        # Override if internal knowledge is sufficient
        if internal_sufficiency['sufficiency_score'] > 0.8 and priority == 'low':
            requires_external = False
            reasons.append('Internal knowledge sufficient')
        
        return {
            'requires_external': requires_external,
            'domains': list(set(domains)),
            'priority': priority,
            'reasons': reasons,
            'confidence': self._calculate_need_confidence(knowledge_gaps, internal_sufficiency)
        }
    
    async def _generate_search_strategy(self, external_needs: Dict[str, Any], 
                                      context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate search strategy for external knowledge"""
        domains = external_needs.get('domains', [])
        priority = external_needs.get('priority', 'medium')
        
        strategy = {
            'search_types': [],
            'source_preferences': [],
            'query_strategy': 'broad',
            'max_results': 5,
            'require_recent': False,
            'verification_needed': False
        }
        
        # Determine search types based on domains
        if 'real_time_data' in domains:
            strategy['search_types'].extend(['news', 'real_time'])
            strategy['source_preferences'].extend(['news_api', 'live_data'])
            strategy['require_recent'] = True
            strategy['max_results'] = 3
        
        if 'specialized_knowledge' in domains:
            strategy['search_types'].extend(['academic', 'expert'])
            strategy['source_preferences'].extend(['academic_db', 'expert_sites'])
            strategy['verification_needed'] = True
        
        if 'technical_specs' in domains:
            strategy['search_types'].extend(['documentation', 'technical'])
            strategy['source_preferences'].extend(['official_docs', 'tech_sites'])
        
        if 'factual_verification' in domains:
            strategy['search_types'].extend(['factual', 'reference'])
            strategy['source_preferences'].extend(['fact_checkers', 'reference_sites'])
            strategy['verification_needed'] = True
        
        # Adjust strategy based on priority
        if priority == 'high':
            strategy['max_results'] = min(strategy['max_results'], 3)
            strategy['query_strategy'] = 'focused'
        elif priority == 'low':
            strategy['max_results'] = min(strategy['max_results'], 2)
        
        return strategy
    
    async def _assess_knowledge_confidence(self, internal_sufficiency: Dict[str, Any], 
                                         external_needs: Dict[str, Any]) -> Dict[str, Any]:
        """Assess confidence in knowledge assessment"""
        internal_confidence = internal_sufficiency.get('sufficiency_score', 0.5)
        external_confidence = external_needs.get('confidence', 0.5)
        
        # Calculate overall confidence
        if external_needs['requires_external']:
            # Confidence based on ability to identify and source external needs
            overall_confidence = (external_confidence + 0.7) / 2
        else:
            # Confidence based on internal knowledge sufficiency
            overall_confidence = internal_confidence
        
        confidence_level = 'high' if overall_confidence > 0.8 else 'medium' if overall_confidence > 0.5 else 'low'
        
        return {
            'overall_confidence': overall_confidence,
            'confidence_level': confidence_level,
            'internal_confidence': internal_confidence,
            'external_assessment_confidence': external_confidence,
            'assessment_reliability': 'reliable' if overall_confidence > 0.7 else 'moderate'
        }
    
    def _calculate_need_confidence(self, knowledge_gaps: Dict[str, Any], 
                                 internal_sufficiency: Dict[str, Any]) -> float:
        """Calculate confidence in external knowledge need assessment"""
        gap_indicators = sum(len(gaps) for gaps in knowledge_gaps.values())
        internal_score = internal_sufficiency.get('sufficiency_score', 0.5)
        
        # Higher confidence if clear indicators of external need
        if gap_indicators > 3:
            return 0.9
        elif gap_indicators > 1:
            return 0.7
        elif internal_score < 0.3:
            return 0.6
        else:
            return 0.5
    
    def classify_knowledge_domain(self, text: str) -> List[str]:
        """Classify the knowledge domain(s) of the request"""
        text_lower = text.lower()
        domains = []
        
        for domain, keywords in self.external_knowledge_domains.items():
            if any(keyword in text_lower for keyword in keywords):
                domains.append(domain)
        
        return domains if domains else ['general']
