
"""
Agent 11 - Dialog Flow Agent
Manages natural conversation flow, dialog transitions, and conversational coherence
"""

import logging
import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import re
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)

class DialogFlowAgent(BaseAgent):
    """
    Agent 11 - Dialog Flow Agent
    
    Responsibilities:
    - Natural dialog transition management
    - Conversation flow optimization
    - Context continuity maintenance
    - Turn-taking and response timing
    - Dialog state tracking
    """
    
    def __init__(self):
        super().__init__(
            name="DialogFlowAgent",
            description="Advanced dialog flow management and conversation orchestration"
        )
        
        # Dialog flow patterns
        self.flow_patterns = {
            'greeting': {
                'triggers': ['hello', 'hi', 'hey', 'good morning', 'good afternoon'],
                'responses': ['acknowledgment', 'reciprocal_greeting', 'engagement']
            },
            'question_answer': {
                'triggers': ['what', 'how', 'why', 'when', 'where', 'who'],
                'responses': ['direct_answer', 'clarifying_question', 'detailed_explanation']
            },
            'request_fulfillment': {
                'triggers': ['can you', 'please', 'would you', 'i need', 'help me'],
                'responses': ['confirmation', 'clarification', 'execution', 'alternative']
            },
            'conversation_closure': {
                'triggers': ['goodbye', 'bye', 'thanks', 'that\'s all', 'see you'],
                'responses': ['acknowledgment', 'summary', 'farewell', 'availability']
            }
        }
        
        # Dialog state tracking
        self.dialog_states = {
            'opening': 'conversation_start',
            'building': 'context_development', 
            'exploring': 'deep_discussion',
            'resolving': 'solution_provision',
            'closing': 'conversation_end'
        }
        
        # Conversation coherence markers
        self.coherence_markers = {
            'continuation': ['furthermore', 'additionally', 'moreover', 'also'],
            'contrast': ['however', 'but', 'although', 'on the other hand'],
            'causation': ['because', 'therefore', 'as a result', 'consequently'],
            'sequence': ['first', 'next', 'then', 'finally', 'meanwhile']
        }
        
        # Initialize conversation memory
        self.conversation_memory = {}
        
    async def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process dialog flow management
        """
        try:
            self._log_processing("Managing dialog flow and conversation coherence")
            
            # Extract input data
            user_input = pipeline_data.get('user_input', '')
            current_response = pipeline_data.get('current_response', '')
            conversation_id = pipeline_data.get('conversation_id', 'default')
            context = pipeline_data.get('context', {})
            
            # Analyze dialog flow
            dialog_analysis = await self._analyze_dialog_flow(
                user_input, current_response, conversation_id, context
            )
            
            # Enhance response with dialog flow
            enhanced_response = await self._enhance_dialog_flow(
                current_response, dialog_analysis, context
            )
            
            # Update conversation state
            updated_state = await self._update_conversation_state(
                conversation_id, dialog_analysis
            )
            
            # Generate flow metadata
            flow_metadata = {
                'dialog_state': dialog_analysis.get('current_state'),
                'flow_pattern': dialog_analysis.get('pattern_type'),
                'coherence_score': dialog_analysis.get('coherence_score'),
                'transition_quality': dialog_analysis.get('transition_quality'),
                'conversation_depth': dialog_analysis.get('depth_level'),
                'engagement_level': dialog_analysis.get('engagement_level')
            }
            
            return self._create_result(
                output=enhanced_response,
                metadata={
                    'agent_name': 'DialogFlowAgent',
                    'processing_time': datetime.now().isoformat(),
                    'dialog_analysis': dialog_analysis,
                    'flow_enhancements': flow_metadata,
                    'conversation_state': updated_state,
                    'quality_score': dialog_analysis.get('quality_score', 0.7)
                }
            )
            
        except Exception as e:
            logger.error(f"Dialog flow processing error: {e}")
            return self._create_result(
                output=pipeline_data.get('current_response', ''),
                metadata={
                    'agent_name': 'DialogFlowAgent',
                    'error': str(e),
                    'fallback_applied': True
                }
            )
    
    async def _analyze_dialog_flow(
        self, 
        user_input: str, 
        current_response: str, 
        conversation_id: str,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Analyze current dialog flow and patterns
        """
        try:
            # Determine dialog pattern
            pattern_type = self._identify_dialog_pattern(user_input)
            
            # Assess conversation state
            current_state = self._determine_conversation_state(
                user_input, context.get('conversation_history', [])
            )
            
            # Calculate coherence score
            coherence_score = self._calculate_coherence_score(
                user_input, current_response, context
            )
            
            # Evaluate transition quality
            transition_quality = self._evaluate_transition_quality(
                context.get('conversation_history', []), user_input
            )
            
            # Assess conversation depth
            depth_level = self._assess_conversation_depth(context)
            
            # Calculate engagement level
            engagement_level = self._calculate_engagement_level(
                user_input, current_response
            )
            
            # Overall quality score
            quality_score = (coherence_score + transition_quality + engagement_level) / 3
            
            return {
                'pattern_type': pattern_type,
                'current_state': current_state,
                'coherence_score': coherence_score,
                'transition_quality': transition_quality,
                'depth_level': depth_level,
                'engagement_level': engagement_level,
                'quality_score': quality_score,
                'flow_recommendations': self._generate_flow_recommendations(
                    pattern_type, current_state, quality_score
                )
            }
            
        except Exception as e:
            logger.error(f"Dialog flow analysis error: {e}")
            return {
                'pattern_type': 'general',
                'current_state': 'building',
                'coherence_score': 0.5,
                'transition_quality': 0.5,
                'depth_level': 'moderate',
                'engagement_level': 0.5,
                'quality_score': 0.5
            }
    
    def _identify_dialog_pattern(self, user_input: str) -> str:
        """
        Identify the type of dialog pattern
        """
        user_input_lower = user_input.lower()
        
        for pattern_name, pattern_data in self.flow_patterns.items():
            for trigger in pattern_data['triggers']:
                if trigger in user_input_lower:
                    return pattern_name
        
        # Check for complex patterns
        if '?' in user_input:
            return 'question_answer'
        elif any(word in user_input_lower for word in ['please', 'can you', 'would you']):
            return 'request_fulfillment'
        elif len(user_input.split()) > 20:
            return 'detailed_discussion'
        else:
            return 'general_conversation'
    
    def _determine_conversation_state(
        self, 
        user_input: str, 
        history: List[Dict[str, Any]]
    ) -> str:
        """
        Determine current conversation state
        """
        history_length = len(history)
        
        # Analyze conversation progression
        if history_length == 0:
            return 'opening'
        elif history_length < 3:
            return 'building'
        elif history_length < 8:
            return 'exploring'
        elif any(word in user_input.lower() for word in ['thanks', 'bye', 'goodbye']):
            return 'closing'
        else:
            return 'resolving'
    
    def _calculate_coherence_score(
        self, 
        user_input: str, 
        current_response: str, 
        context: Dict[str, Any]
    ) -> float:
        """
        Calculate conversation coherence score
        """
        try:
            coherence_factors = []
            
            # Topic continuity
            previous_topics = context.get('topics', [])
            current_topics = self._extract_topics(user_input + ' ' + current_response)
            topic_overlap = len(set(previous_topics) & set(current_topics))
            coherence_factors.append(min(topic_overlap / max(len(previous_topics), 1), 1.0))
            
            # Contextual relevance
            context_keywords = context.get('keywords', [])
            response_keywords = self._extract_keywords(current_response)
            keyword_overlap = len(set(context_keywords) & set(response_keywords))
            coherence_factors.append(min(keyword_overlap / max(len(context_keywords), 1), 1.0))
            
            # Logical flow
            logical_flow_score = self._assess_logical_flow(user_input, current_response)
            coherence_factors.append(logical_flow_score)
            
            return sum(coherence_factors) / len(coherence_factors)
            
        except Exception as e:
            logger.error(f"Coherence calculation error: {e}")
            return 0.6
    
    def _evaluate_transition_quality(
        self, 
        history: List[Dict[str, Any]], 
        current_input: str
    ) -> float:
        """
        Evaluate quality of dialog transitions
        """
        try:
            if len(history) < 2:
                return 0.7  # Default for short conversations
            
            # Analyze smoothness of transitions
            transition_scores = []
            
            # Check for abrupt topic changes
            recent_topics = []
            for entry in history[-3:]:
                if isinstance(entry, dict) and 'message' in entry:
                    recent_topics.extend(self._extract_topics(entry['message']))
            
            current_topics = self._extract_topics(current_input)
            topic_continuity = len(set(recent_topics) & set(current_topics)) / max(len(current_topics), 1)
            transition_scores.append(topic_continuity)
            
            # Check for natural flow markers
            flow_marker_score = self._check_flow_markers(current_input, history)
            transition_scores.append(flow_marker_score)
            
            return sum(transition_scores) / len(transition_scores)
            
        except Exception as e:
            logger.error(f"Transition quality evaluation error: {e}")
            return 0.6
    
    def _assess_conversation_depth(self, context: Dict[str, Any]) -> str:
        """
        Assess the depth level of conversation
        """
        try:
            # Analyze context complexity
            complexity_indicators = [
                len(context.get('topics', [])),
                len(context.get('entities', [])),
                context.get('technical_level', 0),
                len(context.get('conversation_history', []))
            ]
            
            depth_score = sum(complexity_indicators) / 4
            
            if depth_score < 2:
                return 'surface'
            elif depth_score < 5:
                return 'moderate'
            elif depth_score < 8:
                return 'deep'
            else:
                return 'profound'
                
        except Exception as e:
            logger.error(f"Conversation depth assessment error: {e}")
            return 'moderate'
    
    def _calculate_engagement_level(self, user_input: str, current_response: str) -> float:
        """
        Calculate engagement level of the dialog
        """
        try:
            engagement_factors = []
            
            # Question asking (shows curiosity)
            questions_in_response = len([s for s in current_response.split('.') if '?' in s])
            engagement_factors.append(min(questions_in_response / 2, 1.0))
            
            # Personal pronouns (shows personal engagement)
            personal_pronouns = len(re.findall(r'\b(you|your|i|my|we|our)\b', 
                                             current_response.lower()))
            engagement_factors.append(min(personal_pronouns / 5, 1.0))
            
            # Response length appropriateness
            response_length = len(current_response.split())
            input_length = len(user_input.split())
            length_ratio = min(response_length / max(input_length, 1), 3.0) / 3.0
            engagement_factors.append(length_ratio)
            
            # Emotional words
            emotional_words = len(re.findall(
                r'\b(excited|happy|concerned|interested|curious|amazed)\b', 
                current_response.lower()
            ))
            engagement_factors.append(min(emotional_words / 2, 1.0))
            
            return sum(engagement_factors) / len(engagement_factors)
            
        except Exception as e:
            logger.error(f"Engagement level calculation error: {e}")
            return 0.6
    
    async def _enhance_dialog_flow(
        self, 
        current_response: str, 
        dialog_analysis: Dict[str, Any],
        context: Dict[str, Any]
    ) -> str:
        """
        Enhance response with dialog flow improvements
        """
        try:
            enhanced_response = current_response
            
            # Add flow connectors if needed
            if dialog_analysis.get('coherence_score', 0) < 0.6:
                enhanced_response = self._add_flow_connectors(enhanced_response, context)
            
            # Improve transitions
            if dialog_analysis.get('transition_quality', 0) < 0.6:
                enhanced_response = self._improve_transitions(enhanced_response, dialog_analysis)
            
            # Add engagement elements
            if dialog_analysis.get('engagement_level', 0) < 0.6:
                enhanced_response = self._add_engagement_elements(enhanced_response)
            
            # Adjust for conversation state
            conversation_state = dialog_analysis.get('current_state', 'building')
            enhanced_response = self._adjust_for_conversation_state(
                enhanced_response, conversation_state
            )
            
            return enhanced_response
            
        except Exception as e:
            logger.error(f"Dialog flow enhancement error: {e}")
            return current_response
    
    def _add_flow_connectors(self, response: str, context: Dict[str, Any]) -> str:
        """
        Add natural flow connectors to improve coherence
        """
        try:
            # Determine appropriate connector type
            previous_sentiment = context.get('previous_sentiment', 'neutral')
            current_sentiment = context.get('current_sentiment', 'neutral')
            
            connector = ""
            
            if previous_sentiment != current_sentiment:
                connector = "That said, "
            elif len(context.get('conversation_history', [])) > 3:
                connector = "Building on that, "
            elif context.get('topic_shift', False):
                connector = "Speaking of which, "
            else:
                connector = "Additionally, "
            
            # Only add if response doesn't already start with a connector
            if not any(response.startswith(marker) for markers in self.coherence_markers.values() 
                      for marker in markers):
                response = connector + response
            
            return response
            
        except Exception as e:
            logger.error(f"Flow connector addition error: {e}")
            return response
    
    def _improve_transitions(self, response: str, dialog_analysis: Dict[str, Any]) -> str:
        """
        Improve dialog transitions
        """
        try:
            pattern_type = dialog_analysis.get('pattern_type', 'general')
            
            # Add appropriate transition phrases based on pattern
            if pattern_type == 'question_answer':
                if not response.startswith(("Let me explain", "Here's", "The answer")):
                    response = "Let me explain. " + response
                    
            elif pattern_type == 'request_fulfillment':
                if not response.startswith(("I'd be happy to", "Certainly", "Of course")):
                    response = "I'd be happy to help. " + response
                    
            elif pattern_type == 'conversation_closure':
                if not response.startswith(("Thank you", "It was great", "I'm glad")):
                    response = "Thank you for the conversation. " + response
            
            return response
            
        except Exception as e:
            logger.error(f"Transition improvement error: {e}")
            return response
    
    def _add_engagement_elements(self, response: str) -> str:
        """
        Add elements to increase engagement
        """
        try:
            # Add a thoughtful question if response doesn't have one
            if '?' not in response:
                engagement_questions = [
                    " What are your thoughts on this?",
                    " Does this align with what you were expecting?",
                    " Would you like me to elaborate on any part?",
                    " How does this relate to your specific situation?"
                ]
                
                # Choose based on response content
                if len(response) > 100:
                    response += engagement_questions[2]  # elaborate
                else:
                    response += engagement_questions[0]  # thoughts
            
            return response
            
        except Exception as e:
            logger.error(f"Engagement element addition error: {e}")
            return response
    
    def _adjust_for_conversation_state(self, response: str, state: str) -> str:
        """
        Adjust response based on conversation state
        """
        try:
            if state == 'opening':
                if not response.startswith(("Hello", "Hi", "Welcome", "Great to")):
                    response = "Great to connect with you! " + response
                    
            elif state == 'closing':
                if not response.endswith((".", "!", "?")):
                    response += "."
                if "thank" not in response.lower():
                    response += " Thank you for our conversation!"
                    
            elif state == 'exploring':
                # Add depth indicators
                if len(response.split()) < 30:
                    response += " Let me dive deeper into this topic."
            
            return response
            
        except Exception as e:
            logger.error(f"Conversation state adjustment error: {e}")
            return response
    
    async def _update_conversation_state(
        self, 
        conversation_id: str, 
        dialog_analysis: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Update conversation state tracking
        """
        try:
            if conversation_id not in self.conversation_memory:
                self.conversation_memory[conversation_id] = {
                    'start_time': datetime.now().isoformat(),
                    'states': [],
                    'patterns': [],
                    'quality_trend': []
                }
            
            # Update state tracking
            self.conversation_memory[conversation_id]['states'].append({
                'timestamp': datetime.now().isoformat(),
                'state': dialog_analysis.get('current_state'),
                'pattern': dialog_analysis.get('pattern_type'),
                'quality': dialog_analysis.get('quality_score')
            })
            
            # Keep only recent states
            if len(self.conversation_memory[conversation_id]['states']) > 20:
                self.conversation_memory[conversation_id]['states'] = \
                    self.conversation_memory[conversation_id]['states'][-20:]
            
            return self.conversation_memory[conversation_id]
            
        except Exception as e:
            logger.error(f"Conversation state update error: {e}")
            return {}
    
    def _generate_flow_recommendations(
        self, 
        pattern_type: str, 
        current_state: str, 
        quality_score: float
    ) -> List[str]:
        """
        Generate recommendations for improving dialog flow
        """
        recommendations = []
        
        try:
            if quality_score < 0.6:
                recommendations.append("Improve coherence with better topic continuity")
                recommendations.append("Add more natural transitions between ideas")
            
            if pattern_type == 'question_answer' and current_state == 'building':
                recommendations.append("Provide more comprehensive answers")
                recommendations.append("Ask follow-up questions to deepen understanding")
            
            if current_state == 'exploring':
                recommendations.append("Maintain engagement with relevant examples")
                recommendations.append("Guide conversation toward resolution")
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Flow recommendation generation error: {e}")
            return ["Continue natural conversation flow"]
    
    # Helper methods
    def _extract_topics(self, text: str) -> List[str]:
        """Extract topics from text"""
        # Simple topic extraction (can be enhanced with NLP)
        words = re.findall(r'\b[a-zA-Z]{4,}\b', text.lower())
        return list(set(words))[:5]  # Return top 5 unique topics
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extract keywords from text"""
        # Simple keyword extraction
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
        return list(set(words))[:10]  # Return top 10 unique keywords
    
    def _assess_logical_flow(self, user_input: str, response: str) -> float:
        """Assess logical flow between input and response"""
        # Simple logical flow assessment
        input_words = set(user_input.lower().split())
        response_words = set(response.lower().split())
        overlap = len(input_words & response_words)
        return min(overlap / max(len(input_words), 1), 1.0)
    
    def _check_flow_markers(self, text: str, history: List[Dict[str, Any]]) -> float:
        """Check for natural flow markers in text"""
        score = 0.5  # Default score
        
        for marker_type, markers in self.coherence_markers.items():
            if any(marker in text.lower() for marker in markers):
                score += 0.1
        
        return min(score, 1.0)


# Agent registry entry
def create_dialog_flow_agent():
    """Factory function to create DialogFlowAgent instance"""
    return DialogFlowAgent()
