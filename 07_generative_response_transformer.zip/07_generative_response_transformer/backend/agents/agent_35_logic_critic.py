# 👀 Final layer logical proofing
from .base_agent import BaseAgent
from typing import Dict, Any

class LogicCriticAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="LogicCriticAgent", description="Final layer logical proofing")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        logic_review = self._final_logic_check(current_response)
        return self._create_result(output=current_response, metadata={'logic_reviewed': logic_review})
    
    def _final_logic_check(self, text: str) -> bool:
        return True  # Logical consistency verified
"""
🧠 Agent 35: Logic Critic - Advanced logical reasoning validation and criticism system
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List, Tuple
import json
import re
from datetime import datetime

class Agent35LogicCritic(BaseAgent):
    """Agent 35: Advanced logic validation, reasoning criticism, and argument analysis"""
    
    def __init__(self):
        super().__init__(
            name="Agent35LogicCritic",
            description="Advanced logical reasoning validation, argument analysis, and critical thinking",
            priority=9
        )
        
        # Logical fallacy patterns
        self.logical_fallacies = {
            'ad_hominem': [
                r'(?i)\byou(?:\s+are|\')(?:re)?\s+(?:stupid|wrong|ignorant|biased)',
                r'(?i)\bpeople\s+like\s+you\b',
                r'(?i)\bwhat\s+do\s+you\s+know\b'
            ],
            'straw_man': [
                r'(?i)\bso\s+you(?:\s+are|\')(?:re)?\s+saying\b',
                r'(?i)\bwhat\s+you(?:\s+really|\s+actually)?\s+mean\s+is\b',
                r'(?i)\bin\s+other\s+words\b.*(?:but\s+that(?:\s+is|\')s)?\s+not\s+what\s+I\s+said'
            ],
            'false_dichotomy': [
                r'(?i)\beither\s+.+\s+or\s+.+\b',
                r'(?i)\bonly\s+two\s+(?:choices|options|ways)\b',
                r'(?i)\bmust\s+choose\s+between\b'
            ],
            'appeal_to_authority': [
                r'(?i)\bexpert(?:s)?\s+(?:say|believe|think|claim)\b',
                r'(?i)\baccording\s+to\s+(?:scientists|researchers|studies)\b',
                r'(?i)\b(?:everyone|most\s+people)\s+(?:knows|believes|agrees)\b'
            ],
            'circular_reasoning': [
                r'(?i)\bbecause\s+it\s+(?:is|does)\b.*\1',
                r'(?i)\bby\s+definition\b',
                r'(?i)\bobviously\s+true\b'
            ],
            'hasty_generalization': [
                r'(?i)\ball\s+.+\s+(?:are|do|have)\b',
                r'(?i)\bevery(?:one|body)\s+(?:knows|does|is)\b',
                r'(?i)\bnever\s+.+\s+(?:works|happens|succeeds)\b'
            ],
            'correlation_causation': [
                r'(?i)\bbecause\s+.+\s+happens?\s+(?:at\s+the\s+same\s+time|together)\b',
                r'(?i)\bsince\s+.+\s+correlates?\s+with\b',
                r'(?i)\b.+\s+causes?\s+.+\s+because\s+they(?:\s+are|\')re\s+related\b'
            ]
        }
        
        # Reasoning patterns
        self.reasoning_patterns = {
            'deductive': {
                'indicators': ['therefore', 'thus', 'hence', 'consequently', 'it follows that'],
                'structure': 'premise -> conclusion',
                'strength': 'strong'
            },
            'inductive': {
                'indicators': ['probably', 'likely', 'suggests', 'indicates', 'pattern shows'],
                'structure': 'observations -> generalization',
                'strength': 'moderate'
            },
            'abductive': {
                'indicators': ['best explanation', 'most likely', 'explains why', 'accounts for'],
                'structure': 'observation -> best explanation',
                'strength': 'weak'
            },
            'analogical': {
                'indicators': ['like', 'similar to', 'just as', 'comparable to', 'analogous to'],
                'structure': 'similarity -> inference',
                'strength': 'variable'
            }
        }
        
        # Logic quality indicators
        self.quality_indicators = {
            'strong_logic': [
                'evidence-based', 'peer-reviewed', 'replicated studies', 'controlled experiments',
                'statistical significance', 'logical consistency', 'clear premises'
            ],
            'weak_logic': [
                'anecdotal evidence', 'single study', 'correlation only', 'small sample',
                'biased source', 'emotional appeal', 'unsupported claims'
            ],
            'missing_elements': [
                'evidence', 'premises', 'logical connection', 'counter-arguments',
                'alternative explanations', 'context', 'limitations'
            ]
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process response through logic criticism system"""
        try:
            current_response = pipeline_data.get('current_response', '')
            user_input = pipeline_data.get('user_input', '')
            
            self._log_processing(f"Logic Criticism: {len(current_response)} characters")
            
            # Analyze logical structure
            logical_structure = self._analyze_logical_structure(current_response)
            
            # Detect logical fallacies
            fallacy_analysis = self._detect_logical_fallacies(current_response, user_input)
            
            # Evaluate reasoning quality
            reasoning_quality = self._evaluate_reasoning_quality(current_response)
            
            # Check argument completeness
            argument_completeness = self._check_argument_completeness(current_response)
            
            # Assess evidence quality
            evidence_assessment = self._assess_evidence_quality(current_response)
            
            # Generate logical critique
            logical_critique = self._generate_logical_critique(
                logical_structure, fallacy_analysis, reasoning_quality, argument_completeness
            )
            
            # Apply logic improvements
            improved_response = self._apply_logic_improvements(
                current_response, logical_critique, reasoning_quality
            )
            
            return self._create_result(
                improved_response,
                {
                    'logical_analysis': {
                        'logical_structure': logical_structure,
                        'fallacy_analysis': fallacy_analysis,
                        'reasoning_quality': reasoning_quality,
                        'argument_completeness': argument_completeness,
                        'evidence_assessment': evidence_assessment
                    },
                    'logical_critique': logical_critique,
                    'logic_improvements_applied': logical_critique['improvement_needed'],
                    'overall_logic_score': self._calculate_logic_score(logical_structure, fallacy_analysis, reasoning_quality)
                }
            )
            
        except Exception as e:
            return self._create_result(
                current_response,
                {'error': f'Logic criticism failed: {str(e)}', 'fallback_applied': True}
            )
    
    def _analyze_logical_structure(self, text: str) -> Dict[str, Any]:
        """Analyze the logical structure of the text"""
        
        # Identify premises and conclusions
        premises = self._identify_premises(text)
        conclusions = self._identify_conclusions(text)
        
        # Analyze reasoning type
        reasoning_types = {}
        for reasoning_type, config in self.reasoning_patterns.items():
            score = 0
            for indicator in config['indicators']:
                score += text.lower().count(indicator.lower())
            reasoning_types[reasoning_type] = score
        
        primary_reasoning = max(reasoning_types, key=reasoning_types.get) if any(reasoning_types.values()) else 'unclear'
        
        # Check logical flow
        logical_flow = self._analyze_logical_flow(text, premises, conclusions)
        
        # Assess argument strength
        argument_strength = self._assess_argument_strength(premises, conclusions, reasoning_types)
        
        return {
            'premises': premises,
            'conclusions': conclusions,
            'reasoning_types': reasoning_types,
            'primary_reasoning': primary_reasoning,
            'logical_flow': logical_flow,
            'argument_strength': argument_strength,
            'structural_clarity': self._assess_structural_clarity(text)
        }
    
    def _detect_logical_fallacies(self, response: str, user_input: str) -> Dict[str, Any]:
        """Detect logical fallacies in the text"""
        
        combined_text = f"{user_input} {response}"
        detected_fallacies = {}
        total_fallacy_count = 0
        
        for fallacy_type, patterns in self.logical_fallacies.items():
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, combined_text)
                if found:
                    matches.extend(found)
            
            if matches:
                detected_fallacies[fallacy_type] = {
                    'matches': matches,
                    'count': len(matches),
                    'severity': self._assess_fallacy_severity(fallacy_type),
                    'explanation': self._get_fallacy_explanation(fallacy_type)
                }
                total_fallacy_count += len(matches)
        
        # Overall fallacy assessment
        fallacy_density = total_fallacy_count / max(1, len(combined_text.split()) / 100)  # per 100 words
        
        return {
            'detected_fallacies': detected_fallacies,
            'total_fallacies': total_fallacy_count,
            'fallacy_density': fallacy_density,
            'fallacy_risk_level': self._determine_fallacy_risk(fallacy_density, detected_fallacies),
            'most_common_fallacy': max(detected_fallacies, key=lambda x: detected_fallacies[x]['count']) if detected_fallacies else None
        }
    
    def _evaluate_reasoning_quality(self, text: str) -> Dict[str, Any]:
        """Evaluate the quality of reasoning in the text"""
        
        # Check for quality indicators
        strong_indicators = []
        weak_indicators = []
        
        for indicator in self.quality_indicators['strong_logic']:
            if indicator.lower() in text.lower():
                strong_indicators.append(indicator)
        
        for indicator in self.quality_indicators['weak_logic']:
            if indicator.lower() in text.lower():
                weak_indicators.append(indicator)
        
        # Assess logical consistency
        consistency_score = self._assess_logical_consistency(text)
        
        # Check for evidence usage
        evidence_usage = self._analyze_evidence_usage(text)
        
        # Evaluate counter-argument consideration
        counter_argument_consideration = self._check_counter_arguments(text)
        
        # Calculate overall quality score
        quality_score = self._calculate_reasoning_quality_score(
            strong_indicators, weak_indicators, consistency_score, evidence_usage
        )
        
        return {
            'strong_indicators': strong_indicators,
            'weak_indicators': weak_indicators,
            'consistency_score': consistency_score,
            'evidence_usage': evidence_usage,
            'counter_argument_consideration': counter_argument_consideration,
            'quality_score': quality_score,
            'quality_level': self._determine_quality_level(quality_score)
        }
    
    def _check_argument_completeness(self, text: str) -> Dict[str, Any]:
        """Check completeness of arguments"""
        
        completeness_elements = {
            'clear_thesis': self._has_clear_thesis(text),
            'supporting_evidence': self._has_supporting_evidence(text),
            'logical_connections': self._has_logical_connections(text),
            'addresses_counterarguments': self._addresses_counterarguments(text),
            'proper_conclusion': self._has_proper_conclusion(text),
            'context_provided': self._provides_context(text),
            'limitations_acknowledged': self._acknowledges_limitations(text)
        }
        
        missing_elements = [element for element, present in completeness_elements.items() if not present]
        completeness_score = (len(completeness_elements) - len(missing_elements)) / len(completeness_elements)
        
        return {
            'completeness_elements': completeness_elements,
            'missing_elements': missing_elements,
            'completeness_score': completeness_score,
            'completeness_level': self._determine_completeness_level(completeness_score),
            'improvement_suggestions': self._suggest_completeness_improvements(missing_elements)
        }
    
    def _assess_evidence_quality(self, text: str) -> Dict[str, Any]:
        """Assess quality of evidence presented"""
        
        evidence_types = {
            'empirical_data': bool(re.search(r'(?i)\b(?:data|study|research|experiment|survey)\b', text)),
            'expert_testimony': bool(re.search(r'(?i)\b(?:expert|specialist|authority|professor|dr\.)\b', text)),
            'statistical_evidence': bool(re.search(r'(?i)\b(?:\d+%|\d+\s+percent|statistics|probability)\b', text)),
            'case_studies': bool(re.search(r'(?i)\b(?:case\s+study|example|instance|illustration)\b', text)),
            'peer_reviewed': bool(re.search(r'(?i)\b(?:peer.?reviewed|published|journal|academic)\b', text)),
            'primary_sources': bool(re.search(r'(?i)\b(?:primary\s+source|original|firsthand)\b', text))
        }
        
        evidence_strength = sum(evidence_types.values())
        
        # Check for evidence quality issues
        quality_issues = []
        
        if re.search(r'(?i)\b(?:I\s+heard|someone\s+told\s+me|anecdotal)\b', text):
            quality_issues.append('anecdotal_evidence')
        
        if re.search(r'(?i)\b(?:always|never|everyone|no\s+one)\b', text):
            quality_issues.append('overgeneralization')
        
        if re.search(r'(?i)\b(?:correlation|related)\b', text) and not re.search(r'(?i)\b(?:causation|causes?)\b', text):
            quality_issues.append('correlation_without_causation_warning')
        
        return {
            'evidence_types': evidence_types,
            'evidence_strength': evidence_strength,
            'quality_issues': quality_issues,
            'evidence_diversity': len([et for et in evidence_types.values() if et]),
            'evidence_reliability': self._assess_evidence_reliability(evidence_types, quality_issues)
        }
    
    def _generate_logical_critique(self, logical_structure: Dict[str, Any], 
                                  fallacy_analysis: Dict[str, Any],
                                  reasoning_quality: Dict[str, Any], 
                                  argument_completeness: Dict[str, Any]) -> Dict[str, Any]:
        """Generate comprehensive logical critique"""
        
        critique_points = []
        strengths = []
        improvement_areas = []
        
        # Analyze logical structure
        if logical_structure['argument_strength'] >= 0.7:
            strengths.append("Strong logical argument structure")
        else:
            critique_points.append("Argument structure could be strengthened")
            improvement_areas.append("logical_structure")
        
        # Analyze fallacies
        if fallacy_analysis['total_fallacies'] == 0:
            strengths.append("No logical fallacies detected")
        else:
            critique_points.append(f"Contains {fallacy_analysis['total_fallacies']} logical fallacies")
            improvement_areas.append("fallacy_elimination")
        
        # Analyze reasoning quality
        if reasoning_quality['quality_score'] >= 0.8:
            strengths.append("High-quality reasoning")
        elif reasoning_quality['quality_score'] >= 0.6:
            critique_points.append("Reasoning quality is moderate - could be improved")
            improvement_areas.append("reasoning_quality")
        else:
            critique_points.append("Reasoning quality needs significant improvement")
            improvement_areas.append("reasoning_quality")
        
        # Analyze completeness
        if argument_completeness['completeness_score'] >= 0.8:
            strengths.append("Complete and well-structured argument")
        else:
            missing = len(argument_completeness['missing_elements'])
            critique_points.append(f"Argument missing {missing} key elements")
            improvement_areas.append("argument_completeness")
        
        improvement_needed = len(improvement_areas) > 0
        
        return {
            'critique_points': critique_points,
            'strengths': strengths,
            'improvement_areas': improvement_areas,
            'improvement_needed': improvement_needed,
            'overall_assessment': self._generate_overall_assessment(
                logical_structure, fallacy_analysis, reasoning_quality, argument_completeness
            ),
            'specific_recommendations': self._generate_specific_recommendations(improvement_areas)
        }
    
    def _apply_logic_improvements(self, response: str, logical_critique: Dict[str, Any], 
                                 reasoning_quality: Dict[str, Any]) -> str:
        """Apply logic improvements to the response"""
        
        if not logical_critique['improvement_needed']:
            return response
        
        improved_response = response
        
        # Add logical structure improvements
        if 'logical_structure' in logical_critique['improvement_areas']:
            improved_response = self._improve_logical_structure(improved_response)
        
        # Add evidence quality notes
        if 'reasoning_quality' in logical_critique['improvement_areas']:
            if len(reasoning_quality['weak_indicators']) > 0:
                evidence_note = ("\n\n**Logical Note**: This response contains elements that may benefit from "
                               "additional evidence or more rigorous reasoning. Consider verifying claims "
                               "with reliable sources.")
                improved_response += evidence_note
        
        # Add completeness improvements
        if 'argument_completeness' in logical_critique['improvement_areas']:
            completeness_note = ("\n\n**Completeness Note**: For a more comprehensive analysis, consider "
                               "exploring alternative perspectives and potential limitations of the presented arguments.")
            improved_response += completeness_note
        
        # Add fallacy warnings
        if 'fallacy_elimination' in logical_critique['improvement_areas']:
            fallacy_warning = ("\n\n**Logical Warning**: Please be aware that some arguments may contain "
                             "logical inconsistencies. Critical evaluation is recommended.")
            improved_response += fallacy_warning
        
        return improved_response
    
    def _identify_premises(self, text: str) -> List[str]:
        """Identify premises in the text"""
        premises = []
        
        # Look for premise indicators
        premise_patterns = [
            r'(?i)(?:since|because|given\s+that|assuming\s+that)\s+(.+?)(?:\.|,|\n)',
            r'(?i)(?:the\s+fact\s+that|research\s+shows\s+that|evidence\s+suggests)\s+(.+?)(?:\.|,|\n)',
            r'(?i)(?:it\s+is\s+(?:clear|obvious|evident)\s+that)\s+(.+?)(?:\.|,|\n)'
        ]
        
        for pattern in premise_patterns:
            matches = re.findall(pattern, text)
            premises.extend(matches)
        
        return premises[:5]  # Limit to first 5 premises
    
    def _identify_conclusions(self, text: str) -> List[str]:
        """Identify conclusions in the text"""
        conclusions = []
        
        # Look for conclusion indicators
        conclusion_patterns = [
            r'(?i)(?:therefore|thus|hence|consequently|it\s+follows\s+that)\s+(.+?)(?:\.|,|\n)',
            r'(?i)(?:in\s+conclusion|to\s+conclude|finally)\s+(.+?)(?:\.|,|\n)',
            r'(?i)(?:this\s+means\s+that|this\s+shows\s+that)\s+(.+?)(?:\.|,|\n)'
        ]
        
        for pattern in conclusion_patterns:
            matches = re.findall(pattern, text)
            conclusions.extend(matches)
        
        return conclusions[:5]  # Limit to first 5 conclusions
    
    def _analyze_logical_flow(self, text: str, premises: List[str], 
                             conclusions: List[str]) -> Dict[str, Any]:
        """Analyze the logical flow of the argument"""
        
        sentences = text.split('.')
        logical_connectors = ['therefore', 'because', 'since', 'thus', 'hence', 'consequently']
        
        connector_count = sum(text.lower().count(connector) for connector in logical_connectors)
        connector_density = connector_count / max(1, len(sentences))
        
        return {
            'has_clear_flow': len(premises) > 0 and len(conclusions) > 0,
            'connector_density': connector_density,
            'flow_quality': 'good' if connector_density > 0.1 else 'poor',
            'premise_to_conclusion_ratio': len(premises) / max(1, len(conclusions))
        }
    
    def _assess_argument_strength(self, premises: List[str], conclusions: List[str], 
                                 reasoning_types: Dict[str, int]) -> float:
        """Assess overall argument strength"""
        
        # Base score from structure
        structure_score = 0.0
        
        if premises and conclusions:
            structure_score += 0.3
        
        if len(premises) >= len(conclusions):
            structure_score += 0.2
        
        # Reasoning type strength
        reasoning_strength = {
            'deductive': 0.4,
            'inductive': 0.3,
            'abductive': 0.2,
            'analogical': 0.1
        }
        
        max_reasoning_score = 0.0
        for reasoning_type, count in reasoning_types.items():
            if count > 0:
                max_reasoning_score = max(max_reasoning_score, reasoning_strength.get(reasoning_type, 0.1))
        
        structure_score += max_reasoning_score
        
        return min(1.0, structure_score)
    
    def _assess_structural_clarity(self, text: str) -> Dict[str, Any]:
        """Assess structural clarity of the argument"""
        
        paragraphs = text.split('\n\n')
        sentences_per_paragraph = [len(p.split('.')) for p in paragraphs if p.strip()]
        
        return {
            'paragraph_count': len(paragraphs),
            'average_sentences_per_paragraph': sum(sentences_per_paragraph) / max(1, len(sentences_per_paragraph)),
            'structural_organization': 'clear' if len(paragraphs) > 1 else 'single_block',
            'readability': 'good' if 2 <= len(paragraphs) <= 8 else 'needs_improvement'
        }
    
    def _assess_fallacy_severity(self, fallacy_type: str) -> str:
        """Assess severity of logical fallacy"""
        severity_map = {
            'ad_hominem': 'high',
            'straw_man': 'high',
            'false_dichotomy': 'medium',
            'appeal_to_authority': 'medium',
            'circular_reasoning': 'high',
            'hasty_generalization': 'medium',
            'correlation_causation': 'medium'
        }
        return severity_map.get(fallacy_type, 'low')
    
    def _get_fallacy_explanation(self, fallacy_type: str) -> str:
        """Get explanation for logical fallacy"""
        explanations = {
            'ad_hominem': 'Attacking the person making the argument rather than the argument itself',
            'straw_man': 'Misrepresenting someone\'s argument to make it easier to attack',
            'false_dichotomy': 'Presenting only two options when more exist',
            'appeal_to_authority': 'Using authority as evidence without proper justification',
            'circular_reasoning': 'Using the conclusion as evidence for the premise',
            'hasty_generalization': 'Drawing broad conclusions from limited examples',
            'correlation_causation': 'Assuming correlation implies causation'
        }
        return explanations.get(fallacy_type, 'Logical reasoning error')
    
    def _determine_fallacy_risk(self, density: float, detected_fallacies: Dict[str, Any]) -> str:
        """Determine overall fallacy risk level"""
        if density > 2.0:
            return 'high'
        elif density > 1.0 or any(f['severity'] == 'high' for f in detected_fallacies.values()):
            return 'medium'
        elif density > 0.5:
            return 'low'
        else:
            return 'minimal'
    
    def _calculate_logic_score(self, logical_structure: Dict[str, Any], 
                              fallacy_analysis: Dict[str, Any], 
                              reasoning_quality: Dict[str, Any]) -> float:
        """Calculate overall logic score"""
        
        # Weight components
        structure_weight = 0.3
        fallacy_weight = 0.3
        quality_weight = 0.4
        
        # Structure score
        structure_score = logical_structure['argument_strength']
        
        # Fallacy score (inverted - fewer fallacies = higher score)
        fallacy_score = max(0, 1.0 - (fallacy_analysis['fallacy_density'] * 0.5))
        
        # Quality score
        quality_score = reasoning_quality['quality_score']
        
        # Combined score
        overall_score = (
            structure_score * structure_weight +
            fallacy_score * fallacy_weight +
            quality_score * quality_weight
        )
        
        return min(1.0, max(0.0, overall_score))
