# 🚫 Filters made-up content
from .base_agent import BaseAgent
from typing import Dict, Any

class HallucinationFilterAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="HallucinationFilterAgent", description="Filters made-up content")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        return self._create_result(output=current_response, metadata={'hallucination_check': True})
"""
🛡️ Agent 30: Hallucination Filter - Advanced reality checking and fact validation
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List
import json
import re
from datetime import datetime

class Agent30HallucinationFilter(BaseAgent):
    """Agent 30: Advanced hallucination detection and filtering system"""
    
    def __init__(self):
        super().__init__(
            name="Agent30HallucinationFilter",
            description="Advanced hallucination detection, fact validation, and reality checking",
            priority=10
        )
        
        # Hallucination detection patterns
        self.hallucination_patterns = {
            'impossible_claims': [
                r'(?i)temperature of (?:absolute zero|0 kelvin) and (?:fire|heat)',
                r'(?i)faster than light (?:travel|communication) (?:is|was) achieved',
                r'(?i)perpetual motion machine (?:works|exists)',
                r'(?i)square circle|circular square'
            ],
            'contradictory_statements': [
                r'(?i)both (?:true and false|possible and impossible)',
                r'(?i)never (?:always|constantly)',
                r'(?i)impossible (?:certainty|definitely)'
            ],
            'temporal_impossibilities': [
                r'(?i)before (?:the big bang|time began)',
                r'(?i)future event (?:caused|created) past',
                r'(?i)tomorrow (?:happened|occurred) yesterday'
            ],
            'mathematical_impossibilities': [
                r'(?i)divide by zero equals',
                r'(?i)square root of negative (?:real )?number is real',
                r'(?i)pi (?:equals|=) exactly \d+'
            ]
        }
        
        # Common knowledge validation
        self.knowledge_validators = {
            'basic_physics': {
                'speed_of_light': 299792458,  # m/s
                'absolute_zero': -273.15,      # Celsius
                'water_boiling': 100           # Celsius at 1 atm
            },
            'basic_math': {
                'pi_approximation': 3.14159,
                'e_approximation': 2.71828
            },
            'basic_biology': {
                'human_body_temp': 37,         # Celsius
                'human_heart_chambers': 4
            }
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process response through hallucination filter"""
        try:
            current_response = pipeline_data.get('current_response', '')
            user_input = pipeline_data.get('user_input', '')
            
            self._log_processing(f"Hallucination Filter Analysis: {len(current_response)} characters")
            
            # Perform comprehensive hallucination detection
            hallucination_analysis = self._analyze_for_hallucinations(current_response)
            
            # Validate factual claims
            factual_validation = self._validate_factual_claims(current_response)
            
            # Check for logical consistency
            logical_consistency = self._check_logical_consistency(current_response)
            
            # Assess confidence and uncertainty markers
            confidence_analysis = self._analyze_confidence_markers(current_response)
            
            # Generate filtered response
            filtered_response = self._apply_hallucination_filter(
                current_response, hallucination_analysis, factual_validation
            )
            
            # Add warning flags if needed
            final_response = self._add_uncertainty_warnings(
                filtered_response, hallucination_analysis, confidence_analysis
            )
            
            return self._create_result(
                final_response,
                {
                    'hallucination_detection': hallucination_analysis,
                    'factual_validation': factual_validation,
                    'logical_consistency': logical_consistency,
                    'confidence_analysis': confidence_analysis,
                    'filter_applied': hallucination_analysis['risk_level'] != 'low',
                    'warnings_added': len(confidence_analysis.get('uncertainty_markers', [])) > 0
                }
            )
            
        except Exception as e:
            return self._create_result(
                current_response,
                {'error': f'Hallucination filter failed: {str(e)}', 'fallback_applied': True}
            )
    
    def _analyze_for_hallucinations(self, text: str) -> Dict[str, Any]:
        """Analyze text for potential hallucinations"""
        detected_patterns = {}
        total_flags = 0
        
        for category, patterns in self.hallucination_patterns.items():
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, text)
                if found:
                    matches.extend(found)
            
            if matches:
                detected_patterns[category] = matches
                total_flags += len(matches)
        
        # Assess risk level
        if total_flags == 0:
            risk_level = 'low'
        elif total_flags <= 2:
            risk_level = 'medium'
        else:
            risk_level = 'high'
        
        return {
            'detected_patterns': detected_patterns,
            'total_flags': total_flags,
            'risk_level': risk_level,
            'analysis_timestamp': datetime.now().isoformat()
        }
    
    def _validate_factual_claims(self, text: str) -> Dict[str, Any]:
        """Validate factual claims against known knowledge"""
        validation_results = {}
        
        # Check basic physics claims
        physics_issues = []
        if re.search(r'speed of light.*?(\d+\.?\d*)', text, re.IGNORECASE):
            match = re.search(r'speed of light.*?(\d+\.?\d*)', text, re.IGNORECASE)
            claimed_value = float(match.group(1))
            expected = self.knowledge_validators['basic_physics']['speed_of_light']
            if abs(claimed_value - expected) > expected * 0.1:  # 10% tolerance
                physics_issues.append(f"Speed of light claim: {claimed_value} vs expected ~{expected}")
        
        # Check temperature claims
        temp_pattern = r'absolute zero.*?(-?\d+\.?\d*)'
        if re.search(temp_pattern, text, re.IGNORECASE):
            match = re.search(temp_pattern, text, re.IGNORECASE)
            claimed_temp = float(match.group(1))
            expected = self.knowledge_validators['basic_physics']['absolute_zero']
            if abs(claimed_temp - expected) > 10:  # 10 degree tolerance
                physics_issues.append(f"Absolute zero claim: {claimed_temp}°C vs expected {expected}°C")
        
        validation_results['physics_validation'] = {
            'issues': physics_issues,
            'passed': len(physics_issues) == 0
        }
        
        # Check mathematical claims
        math_issues = []
        pi_pattern = r'pi.*?(?:equals|=).*?(\d+\.?\d*)'
        if re.search(pi_pattern, text, re.IGNORECASE):
            match = re.search(pi_pattern, text, re.IGNORECASE)
            claimed_pi = float(match.group(1))
            expected = self.knowledge_validators['basic_math']['pi_approximation']
            if abs(claimed_pi - expected) > 0.01:
                math_issues.append(f"Pi value claim: {claimed_pi} vs expected ~{expected}")
        
        validation_results['math_validation'] = {
            'issues': math_issues,
            'passed': len(math_issues) == 0
        }
        
        return validation_results
    
    def _check_logical_consistency(self, text: str) -> Dict[str, Any]:
        """Check for logical consistency in the text"""
        inconsistencies = []
        
        # Check for contradictory statements within the same text
        sentences = text.split('.')
        
        # Look for positive/negative pairs
        for i, sentence1 in enumerate(sentences):
            for j, sentence2 in enumerate(sentences[i+1:], i+1):
                if self._sentences_contradict(sentence1.strip(), sentence2.strip()):
                    inconsistencies.append({
                        'sentence1': sentence1.strip(),
                        'sentence2': sentence2.strip(),
                        'type': 'contradiction'
                    })
        
        return {
            'inconsistencies': inconsistencies,
            'consistency_score': max(0, 1.0 - len(inconsistencies) * 0.2),
            'passed': len(inconsistencies) == 0
        }
    
    def _sentences_contradict(self, sent1: str, sent2: str) -> bool:
        """Check if two sentences contradict each other"""
        # Simple contradiction detection
        sent1_lower = sent1.lower()
        sent2_lower = sent2.lower()
        
        # Look for explicit contradictions
        if ('not' in sent1_lower and sent1_lower.replace('not ', '') in sent2_lower) or \
           ('not' in sent2_lower and sent2_lower.replace('not ', '') in sent1_lower):
            return True
        
        # Look for opposite adjectives
        opposites = [
            ('hot', 'cold'), ('large', 'small'), ('fast', 'slow'),
            ('possible', 'impossible'), ('true', 'false'), ('correct', 'incorrect')
        ]
        
        for pos, neg in opposites:
            if (pos in sent1_lower and neg in sent2_lower) or \
               (neg in sent1_lower and pos in sent2_lower):
                return True
        
        return False
    
    def _analyze_confidence_markers(self, text: str) -> Dict[str, Any]:
        """Analyze confidence and uncertainty markers in text"""
        high_confidence = re.findall(r'(?i)\b(definitely|certainly|absolutely|guaranteed|proven|fact)\b', text)
        medium_confidence = re.findall(r'(?i)\b(likely|probably|seems|appears|suggests)\b', text)
        low_confidence = re.findall(r'(?i)\b(might|may|could|possibly|perhaps|potentially)\b', text)
        uncertainty = re.findall(r'(?i)\b(unclear|uncertain|unknown|disputed|debated)\b', text)
        
        total_markers = len(high_confidence) + len(medium_confidence) + len(low_confidence)
        
        if total_markers > 0:
            confidence_ratio = len(high_confidence) / total_markers
        else:
            confidence_ratio = 0.5  # neutral
        
        return {
            'high_confidence_markers': high_confidence,
            'medium_confidence_markers': medium_confidence,
            'low_confidence_markers': low_confidence,
            'uncertainty_markers': uncertainty,
            'confidence_ratio': confidence_ratio,
            'appropriate_uncertainty': len(uncertainty) > 0 and confidence_ratio < 0.7
        }
    
    def _apply_hallucination_filter(self, text: str, hallucination_analysis: Dict[str, Any], 
                                   factual_validation: Dict[str, Any]) -> str:
        """Apply filtering based on hallucination detection"""
        
        if hallucination_analysis['risk_level'] == 'low':
            return text
        
        filtered_text = text
        
        # Remove or modify high-risk content
        for category, matches in hallucination_analysis['detected_patterns'].items():
            for match in matches:
                if category == 'impossible_claims':
                    # Replace with more cautious language
                    filtered_text = filtered_text.replace(match, f"[Note: This claim requires verification] {match}")
                elif category == 'contradictory_statements':
                    # Flag contradictions
                    filtered_text = filtered_text.replace(match, f"[Note: This appears contradictory] {match}")
        
        # Add validation warnings for factual issues
        physics_issues = factual_validation.get('physics_validation', {}).get('issues', [])
        math_issues = factual_validation.get('math_validation', {}).get('issues', [])
        
        if physics_issues or math_issues:
            warning = "\n\n⚠️ **Note**: Some factual claims in this response may require verification."
            filtered_text += warning
        
        return filtered_text
    
    def _add_uncertainty_warnings(self, text: str, hallucination_analysis: Dict[str, Any],
                                 confidence_analysis: Dict[str, Any]) -> str:
        """Add appropriate uncertainty warnings"""
        
        # If high risk and high confidence, add uncertainty
        if (hallucination_analysis['risk_level'] in ['medium', 'high'] and 
            confidence_analysis['confidence_ratio'] > 0.7):
            
            uncertainty_note = ("\n\n**Disclaimer**: The information provided should be verified "
                              "independently as AI responses may contain inaccuracies.")
            return text + uncertainty_note
        
        # If discussing complex topics without uncertainty markers
        complex_topics = ['quantum', 'consciousness', 'multiverse', 'dark matter', 'artificial intelligence']
        has_complex_topics = any(topic.lower() in text.lower() for topic in complex_topics)
        
        if has_complex_topics and len(confidence_analysis.get('uncertainty_markers', [])) == 0:
            complexity_note = ("\n\n**Note**: This topic involves complex concepts that are "
                             "actively researched and may have multiple perspectives.")
            return text + complexity_note
        
        return text
