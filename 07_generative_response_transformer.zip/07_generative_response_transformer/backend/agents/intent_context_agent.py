
"""
Intent & Context Agent - Step 2 of the Enhanced GRT Pipeline
Analyzes user intent and builds contextual understanding
"""

import logging
import asyncio
from typing import Dict, Any, List
from datetime import datetime
import json

logger = logging.getLogger(__name__)

class IntentContextAgent:
    """Intent & Context Agent for analyzing user intent and building context"""
    
    def __init__(self):
        self.agent_id = "intent_context_agent"
        self.capabilities = [
            "intent_analysis",
            "context_building",
            "entity_extraction",
            "relationship_mapping"
        ]
        
        # Intent categories
        self.intent_categories = {
            'creative': ['create', 'generate', 'design', 'build', 'make', 'develop'],
            'analytical': ['analyze', 'examine', 'study', 'investigate', 'research'],
            'informational': ['explain', 'describe', 'tell', 'what', 'how', 'why'],
            'operational': ['execute', 'run', 'perform', 'do', 'process'],
            'conversational': ['hello', 'hi', 'chat', 'talk', 'discuss'],
            'problem_solving': ['fix', 'solve', 'resolve', 'debug', 'troubleshoot']
        }
    
    async def process_intent_and_context(self, input_data: Dict[str, Any], 
                                       session_context: Dict[str, Any]) -> Dict[str, Any]:
        """Process intent and context analysis"""
        logger.info("🎯 Intent & Context Agent processing...")
        
        try:
            processed_input = input_data.get('processed_input', '')
            
            # Step 1: Intent analysis
            intent_analysis = await self._analyze_intent(processed_input)
            
            # Step 2: Context building
            context_analysis = await self._build_context(processed_input, session_context)
            
            # Step 3: Entity extraction
            entities = await self._extract_entities(processed_input)
            
            # Step 4: Relationship mapping
            relationships = await self._map_relationships(entities, context_analysis)
            
            # Step 5: Generate processing strategy
            processing_strategy = await self._generate_processing_strategy(
                intent_analysis, context_analysis, entities
            )
            
            result = {
                'intent_analysis': intent_analysis,
                'context_analysis': context_analysis,
                'extracted_entities': entities,
                'relationships': relationships,
                'processing_strategy': processing_strategy,
                'confidence_score': self._calculate_confidence(
                    intent_analysis, context_analysis
                ),
                'processing_metadata': {
                    'analysis_timestamp': datetime.now().isoformat(),
                    'agent_id': self.agent_id,
                    'processing_time': 0.1  # Simulated
                }
            }
            
            logger.info("✅ Intent & Context Agent processing complete")
            return result
            
        except Exception as e:
            logger.error(f"❌ Intent & Context Agent error: {e}")
            return {
                'error': str(e),
                'agent_id': self.agent_id,
                'intent_analysis': {'primary_intent': 'unknown'},
                'context_analysis': {'context_type': 'unknown'}
            }
    
    async def _analyze_intent(self, text: str) -> Dict[str, Any]:
        """Analyze user intent"""
        text_lower = text.lower()
        words = text_lower.split()
        
        intent_scores = {}
        
        # Score each intent category
        for category, keywords in self.intent_categories.items():
            score = sum(1 for keyword in keywords if keyword in text_lower)
            if score > 0:
                intent_scores[category] = score
        
        # Determine primary intent
        if intent_scores:
            primary_intent = max(intent_scores, key=intent_scores.get)
            confidence = intent_scores[primary_intent] / len(words)
        else:
            primary_intent = 'general'
            confidence = 0.5
        
        # Detect sub-intents
        sub_intents = []
        if 'and' in text_lower or ',' in text:
            sub_intents = [cat for cat, score in intent_scores.items() 
                          if cat != primary_intent and score > 0]
        
        return {
            'primary_intent': primary_intent,
            'sub_intents': sub_intents,
            'intent_scores': intent_scores,
            'confidence': min(confidence, 1.0),
            'intent_complexity': 'multi' if len(sub_intents) > 1 else 'single'
        }
    
    async def _build_context(self, text: str, session_context: Dict[str, Any]) -> Dict[str, Any]:
        """Build contextual understanding"""
        context_analysis = {
            'domain': self._identify_domain(text),
            'topic': self._extract_topic(text),
            'context_type': self._classify_context_type(text),
            'temporal_context': self._extract_temporal_context(text),
            'session_continuity': self._assess_session_continuity(text, session_context),
            'user_expertise_level': self._estimate_user_expertise(text),
            'formality_level': self._assess_formality(text)
        }
        
        return context_analysis
    
    async def _extract_entities(self, text: str) -> List[Dict[str, Any]]:
        """Extract entities from text"""
        entities = []
        words = text.split()
        
        # Simple entity extraction patterns
        patterns = {
            'technology': ['python', 'javascript', 'react', 'flask', 'api', 'database'],
            'action': ['create', 'build', 'develop', 'design', 'analyze'],
            'object': ['app', 'website', 'system', 'model', 'interface'],
            'domain': ['web', 'mobile', 'ai', 'ml', 'data', 'backend', 'frontend']
        }
        
        for word in words:
            word_lower = word.lower().strip('.,!?')
            for entity_type, keywords in patterns.items():
                if word_lower in keywords:
                    entities.append({
                        'text': word,
                        'type': entity_type,
                        'confidence': 0.8
                    })
        
        return entities
    
    async def _map_relationships(self, entities: List[Dict[str, Any]], 
                               context: Dict[str, Any]) -> Dict[str, Any]:
        """Map relationships between entities"""
        relationships = {
            'entity_connections': [],
            'context_entity_links': [],
            'dependency_chain': []
        }
        
        # Simple relationship mapping
        for i, entity1 in enumerate(entities):
            for j, entity2 in enumerate(entities[i+1:], i+1):
                if entity1['type'] == 'action' and entity2['type'] == 'object':
                    relationships['entity_connections'].append({
                        'source': entity1,
                        'target': entity2,
                        'relationship': 'acts_on'
                    })
        
        return relationships
    
    async def _generate_processing_strategy(self, intent: Dict[str, Any], 
                                          context: Dict[str, Any], 
                                          entities: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate processing strategy based on analysis"""
        strategy = {
            'recommended_agents': self._recommend_agents(intent, context, entities),
            'processing_priority': self._determine_priority(intent, context),
            'resource_requirements': self._estimate_resources(intent, context),
            'expected_output_type': self._predict_output_type(intent, context),
            'processing_complexity': self._assess_processing_complexity(intent, entities)
        }
        
        return strategy
    
    def _identify_domain(self, text: str) -> str:
        """Identify the domain of the request"""
        text_lower = text.lower()
        
        domains = {
            'technology': ['code', 'programming', 'software', 'app', 'web', 'api'],
            'design': ['design', 'ui', 'ux', 'interface', 'visual', 'layout'],
            'business': ['business', 'strategy', 'market', 'sales', 'revenue'],
            'education': ['learn', 'teach', 'explain', 'tutorial', 'guide'],
            'creative': ['creative', 'art', 'writing', 'content', 'story']
        }
        
        for domain, keywords in domains.items():
            if any(keyword in text_lower for keyword in keywords):
                return domain
        
        return 'general'
    
    def _extract_topic(self, text: str) -> str:
        """Extract the main topic"""
        # Simple topic extraction based on key nouns
        words = text.split()
        potential_topics = [word for word in words if len(word) > 4 and word.isalpha()]
        
        if potential_topics:
            return potential_topics[0].lower()
        else:
            return 'general'
    
    def _classify_context_type(self, text: str) -> str:
        """Classify the type of context"""
        if '?' in text:
            return 'question'
        elif any(word in text.lower() for word in ['create', 'build', 'make']):
            return 'creation_request'
        elif any(word in text.lower() for word in ['explain', 'describe']):
            return 'explanation_request'
        else:
            return 'statement'
    
    def _extract_temporal_context(self, text: str) -> Dict[str, Any]:
        """Extract temporal context"""
        temporal_indicators = {
            'immediate': ['now', 'immediately', 'asap'],
            'short_term': ['today', 'soon', 'quickly'],
            'long_term': ['eventually', 'later', 'future']
        }
        
        text_lower = text.lower()
        for timeframe, indicators in temporal_indicators.items():
            if any(indicator in text_lower for indicator in indicators):
                return {'timeframe': timeframe, 'urgency': timeframe == 'immediate'}
        
        return {'timeframe': 'unspecified', 'urgency': False}
    
    def _assess_session_continuity(self, text: str, session_context: Dict[str, Any]) -> Dict[str, Any]:
        """Assess continuity with previous session context"""
        continuity_indicators = ['also', 'additionally', 'furthermore', 'continue', 'next']
        
        has_continuity = any(indicator in text.lower() for indicator in continuity_indicators)
        
        return {
            'has_continuity': has_continuity,
            'session_id': session_context.get('session_id'),
            'previous_context': session_context.get('previous_context', {})
        }
    
    def _estimate_user_expertise(self, text: str) -> str:
        """Estimate user expertise level"""
        technical_terms = ['api', 'database', 'algorithm', 'framework', 'architecture']
        beginner_phrases = ['how to', 'what is', 'explain', 'simple', 'basic']
        
        text_lower = text.lower()
        
        if any(term in text_lower for term in technical_terms):
            return 'advanced'
        elif any(phrase in text_lower for phrase in beginner_phrases):
            return 'beginner'
        else:
            return 'intermediate'
    
    def _assess_formality(self, text: str) -> str:
        """Assess formality level"""
        informal_indicators = ['hey', 'hi', 'please', 'thanks', 'cool']
        formal_indicators = ['request', 'require', 'kindly', 'would appreciate']
        
        text_lower = text.lower()
        
        if any(indicator in text_lower for indicator in informal_indicators):
            return 'informal'
        elif any(indicator in text_lower for indicator in formal_indicators):
            return 'formal'
        else:
            return 'neutral'
    
    def _recommend_agents(self, intent: Dict[str, Any], context: Dict[str, Any], 
                         entities: List[Dict[str, Any]]) -> List[str]:
        """Recommend which agents to use"""
        recommended = ['response_agent']  # Always include response agent
        
        primary_intent = intent['primary_intent']
        domain = context['domain']
        
        # Add domain-specific agents
        if domain == 'technology':
            recommended.extend(['code_interpreter', 'fact_checker'])
        elif domain == 'design':
            recommended.extend(['visualizer', 'ui_ux_designer'])
        elif domain == 'creative':
            recommended.extend(['content_creation_agent', 'image_generator'])
        
        # Add intent-specific agents
        if primary_intent == 'creative':
            recommended.extend(['cad_generator', 'drawing_generator'])
        elif primary_intent == 'analytical':
            recommended.extend(['math_solver', 'logic_bridge'])
        
        return list(set(recommended))  # Remove duplicates
    
    def _determine_priority(self, intent: Dict[str, Any], context: Dict[str, Any]) -> str:
        """Determine processing priority"""
        if context.get('temporal_context', {}).get('urgency', False):
            return 'high'
        elif intent['intent_complexity'] == 'multi':
            return 'medium'
        else:
            return 'normal'
    
    def _estimate_resources(self, intent: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """Estimate resource requirements"""
        return {
            'processing_time': 'medium' if intent['intent_complexity'] == 'multi' else 'low',
            'memory_usage': 'medium',
            'external_apis': context['domain'] in ['technology', 'design'],
            'file_generation': 'create' in intent.get('primary_intent', '')
        }
    
    def _predict_output_type(self, intent: Dict[str, Any], context: Dict[str, Any]) -> str:
        """Predict the type of output expected"""
        primary_intent = intent['primary_intent']
        
        if primary_intent == 'creative':
            return 'generated_content'
        elif primary_intent == 'informational':
            return 'explanation'
        elif primary_intent == 'analytical':
            return 'analysis_report'
        else:
            return 'text_response'
    
    def _assess_processing_complexity(self, intent: Dict[str, Any], 
                                    entities: List[Dict[str, Any]]) -> str:
        """Assess overall processing complexity"""
        complexity_factors = 0
        
        if intent['intent_complexity'] == 'multi':
            complexity_factors += 2
        if len(entities) > 5:
            complexity_factors += 1
        if len(intent.get('sub_intents', [])) > 1:
            complexity_factors += 1
        
        if complexity_factors >= 3:
            return 'high'
        elif complexity_factors >= 1:
            return 'medium'
        else:
            return 'low'
    
    def _calculate_confidence(self, intent: Dict[str, Any], context: Dict[str, Any]) -> float:
        """Calculate overall confidence score"""
        intent_confidence = intent.get('confidence', 0.5)
        context_confidence = 0.8 if context['domain'] != 'general' else 0.5
        
        return (intent_confidence + context_confidence) / 2
