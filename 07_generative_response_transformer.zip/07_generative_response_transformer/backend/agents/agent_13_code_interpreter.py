# 💻 Evaluates Python code blocks

from .base_agent import BaseAgent
from typing import Dict, Any

class CodeInterpreterAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="CodeInterpreterAgent", description="Evaluates Python code blocks")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        code_analysis = self._analyze_code(current_response)
        
        return self._create_result(
            output=current_response,
            metadata={'code_analysis': code_analysis, 'code_present': bool(code_analysis)}
        )
    
    def _analyze_code(self, text: str) -> Dict[str, Any]:
        """Enhanced code analysis for multiple languages"""
        # Extract code blocks
        code_blocks = self._extract_code_blocks(text)
        
        analysis_results = []
        overall_safe = True
        
        for code_block in code_blocks:
            language = code_block.get('language', 'python')
            code_content = code_block.get('content', '')
            
            if language.lower() == 'python':
                analysis = self._analyze_python_code(code_content)
            elif language.lower() in ['javascript', 'js']:
                analysis = self._analyze_javascript_code(code_content)
            elif language.lower() in ['bash', 'shell']:
                analysis = self._analyze_shell_code(code_content)
            else:
                analysis = self._analyze_generic_code(code_content, language)
                
            analysis_results.append({
                'language': language,
                'analysis': analysis,
                'code_snippet': code_content[:100] + '...' if len(code_content) > 100 else code_content
            })
            
            if analysis.security_issues:
                overall_safe = False
        
        return {
            'has_code_blocks': len(code_blocks) > 0,
            'code_safe': overall_safe,
            'languages_detected': list(set(block.get('language', 'unknown') for block in code_blocks)),
            'analysis_results': analysis_results,
            'total_blocks': len(code_blocks)
        }
    
    def _extract_code_blocks(self, text: str) -> List[Dict[str, str]]:
        """Extract code blocks from text (markdown format and inline)"""
        code_blocks = []
        
        # Extract fenced code blocks (```language)
        fenced_pattern = r'```(\w+)?\n(.*?)\n```'
        fenced_matches = re.findall(fenced_pattern, text, re.DOTALL)
        
        for language, code in fenced_matches:
            code_blocks.append({
                'language': language or 'unknown',
                'content': code.strip(),
                'type': 'fenced'
            })
        
        # Extract inline code blocks with keywords
        inline_patterns = [
            (r'(def\s+\w+.*?(?:\n.*?)*)', 'python'),
            (r'(import\s+\w+.*)', 'python'),
            (r'(function\s+\w+.*?{.*?})', 'javascript'),
            (r'(var\s+\w+.*?;)', 'javascript'),
            (r'(sudo\s+.*)', 'bash'),
            (r'(npm\s+install.*)', 'bash')
        ]
        
        for pattern, language in inline_patterns:
            matches = re.findall(pattern, text, re.MULTILINE)
            for match in matches:
                if not any(match in block['content'] for block in code_blocks):
                    code_blocks.append({
                        'language': language,
                        'content': match.strip(),
                        'type': 'inline'
                    })
        
        return code_blocks
    
    def _analyze_javascript_code(self, code: str) -> CodeAnalysis:
        """Analyze JavaScript code for common issues"""
        security_issues = []
        performance_issues = []
        style_issues = []
        suggestions = []
        
        # Security analysis
        dangerous_patterns = [
            (r'eval\(', 'Use of eval() can be dangerous'),
            (r'innerHTML\s*=', 'innerHTML assignment can lead to XSS'),
            (r'document\.write\(', 'document.write() can be problematic'),
            (r'window\[\w+\]', 'Dynamic window property access')
        ]
        
        for pattern, issue in dangerous_patterns:
            if re.search(pattern, code):
                security_issues.append(issue)
        
        # Performance analysis
        if 'for(' in code and 'querySelector' in code:
            performance_issues.append('DOM queries in loops can be slow')
        
        if 'setTimeout' in code and '0' in code:
            performance_issues.append('setTimeout with 0 delay should be replaced with requestAnimationFrame')
        
        # Style analysis
        if not re.search(r'(let|const)', code) and re.search(r'var\s', code):
            style_issues.append('Consider using let/const instead of var')
        
        # Suggestions
        if 'fetch(' in code and 'catch' not in code:
            suggestions.append('Add error handling to fetch requests')
        
        return CodeAnalysis(
            syntax_valid=True,  # Basic check, would need proper parser
            complexity_score=len(code.split('\n')) / 20.0,
            security_issues=security_issues,
            performance_issues=performance_issues,
            style_issues=style_issues,
            suggestions=suggestions,
            dependencies=self._extract_js_dependencies(code),
            estimated_runtime="browser"
        )
    
    def _analyze_shell_code(self, code: str) -> CodeAnalysis:
        """Analyze shell/bash code for security and best practices"""
        security_issues = []
        performance_issues = []
        style_issues = []
        suggestions = []
        
        # Security analysis
        dangerous_commands = [
            (r'rm\s+-rf\s+/', 'Dangerous recursive delete'),
            (r'chmod\s+777', 'Overly permissive file permissions'),
            (r'sudo\s+.*\|\s*sh', 'Piping to shell with sudo'),
            (r'curl.*\|\s*sh', 'Piping curl output to shell'),
            (r'\$\([^)]*\)', 'Command substitution - verify input safety')
        ]
        
        for pattern, issue in dangerous_commands:
            if re.search(pattern, code):
                security_issues.append(issue)
        
        # Style analysis
        if not code.startswith('#!/bin/bash') and len(code.split('\n')) > 3:
            style_issues.append('Script should include shebang line')
        
        if 'set -e' not in code and len(code.split('\n')) > 5:
            suggestions.append('Consider adding "set -e" for error handling')
        
        return CodeAnalysis(
            syntax_valid=True,
            complexity_score=len(code.split('|')) * 0.5,
            security_issues=security_issues,
            performance_issues=performance_issues,
            style_issues=style_issues,
            suggestions=suggestions,
            dependencies=self._extract_shell_dependencies(code),
            estimated_runtime="shell"
        )
    
    def _analyze_generic_code(self, code: str, language: str) -> CodeAnalysis:
        """Generic analysis for unsupported languages"""
        return CodeAnalysis(
            syntax_valid=True,
            complexity_score=len(code.split('\n')) / 10.0,
            security_issues=[],
            performance_issues=[],
            style_issues=[],
            suggestions=[f"Manual review recommended for {language} code"],
            dependencies=[],
            estimated_runtime=f"{language}_runtime"
        )
    
    def _extract_js_dependencies(self, code: str) -> List[str]:
        """Extract JavaScript dependencies"""
        dependencies = []
        
        # Import statements
        import_patterns = [
            r'import.*from\s+[\'"]([^\'"]+)[\'"]',
            r'require\([\'"]([^\'"]+)[\'"]\)',
            r'<script.*src=[\'"]([^\'"]+)[\'"]'
        ]
        
        for pattern in import_patterns:
            matches = re.findall(pattern, code)
            dependencies.extend(matches)
        
        return dependencies
    
    def _extract_shell_dependencies(self, code: str) -> List[str]:
        """Extract shell command dependencies"""
        commands = []
        
        # Find command invocations
        command_patterns = [
            r'^(\w+)\s',  # Commands at start of line
            r'\s(\w+)\s',  # Commands in middle
            r'which\s+(\w+)',  # Explicit which checks
            r'command\s+-v\s+(\w+)'  # Command checks
        ]
        
        for line in code.split('\n'):
            for pattern in command_patterns:
                matches = re.findall(pattern, line)
                commands.extend(matches)
        
        # Filter out common built-ins
        builtins = {'echo', 'cd', 'pwd', 'exit', 'test', 'if', 'then', 'else', 'fi', 'for', 'do', 'done'}
        return [cmd for cmd in set(commands) if cmd not in builtins]
"""
Agent 13 - Code Interpreter Agent
Advanced code execution, analysis, and debugging capabilities
"""

import logging
import asyncio
import subprocess
import tempfile
import os
import sys
import re
import json
import traceback
from typing import Dict, Any, List, Optional, Tuple, Union
from datetime import datetime
import ast
import importlib.util
import inspect
from dataclasses import dataclass
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)

@dataclass
class CodeExecution:
    """Result of code execution"""
    code: str
    language: str
    output: str
    error: Optional[str]
    execution_time: float
    exit_code: int
    variables_created: Dict[str, Any]
    imports_used: List[str]
    functions_defined: List[str]
    classes_defined: List[str]

@dataclass
class CodeAnalysis:
    """Result of code analysis"""
    syntax_valid: bool
    complexity_score: float
    security_issues: List[str]
    performance_issues: List[str]
    style_issues: List[str]
    suggestions: List[str]
    dependencies: List[str]
    estimated_runtime: str

class CodeInterpreterAgent(BaseAgent):
    """
    Agent 13 - Code Interpreter Agent
    
    Responsibilities:
    - Safe code execution in multiple languages
    - Code analysis and debugging
    - Performance optimization suggestions
    - Security vulnerability detection
    - Code explanation and documentation
    - Interactive code sessions
    """
    
    def __init__(self):
        super().__init__(
            name="CodeInterpreterAgent",
            description="Advanced code execution, analysis, and debugging system"
        )
        
        # Supported languages and their configurations
        self.supported_languages = {
            'python': {
                'extension': '.py',
                'command': [sys.executable],
                'timeout': 30,
                'sandbox': True
            },
            'javascript': {
                'extension': '.js',
                'command': ['node'],
                'timeout': 30,
                'sandbox': True
            },
            'bash': {
                'extension': '.sh',
                'command': ['bash'],
                'timeout': 15,
                'sandbox': True
            },
            'sql': {
                'extension': '.sql',
                'command': ['sqlite3', ':memory:'],
                'timeout': 10,
                'sandbox': True
            }
        }
        
        # Security constraints
        self.security_constraints = {
            'forbidden_imports': [
                'os.system', 'subprocess.call', 'eval', 'exec',
                'open', '__import__', 'compile', 'globals', 'locals'
            ],
            'forbidden_keywords': [
                'rm -rf', 'del', 'format', 'exit', 'quit',
                'import os', 'import subprocess', 'import sys'
            ],
            'max_execution_time': 30,
            'max_memory_usage': 100 * 1024 * 1024,  # 100MB
            'max_output_length': 10000
        }
        
        # Code analysis patterns
        self.analysis_patterns = {
            'performance_issues': [
                r'for.*in.*range\(len\(',  # inefficient iteration
                r'\.append\(.*\) in.*for',  # list comprehension candidate
                r'time\.sleep\(\d+\)',  # blocking sleep
            ],
            'security_issues': [
                r'eval\s*\(',
                r'exec\s*\(',
                r'os\.system\s*\(',
                r'subprocess\.',
                r'__import__\s*\(',
            ],
            'style_issues': [
                r'[a-z]+[A-Z]',  # camelCase in Python
                r'def\s+[A-Z]',  # PascalCase function
                r'^\s*#.*TODO',  # TODO comments
            ]
        }
        
        # Code execution history
        self.execution_history = []
        self.session_variables = {}
        
        # Initialize secure execution environment
        self._initialize_secure_environment()
        
    def _initialize_secure_environment(self):
        """Initialize secure code execution environment"""
        try:
            # Create temporary directory for code execution
            self.temp_dir = tempfile.mkdtemp(prefix='code_interpreter_')
            
            # Set up restricted Python environment
            self.restricted_builtins = {
                'print': print,
                'len': len,
                'range': range,
                'list': list,
                'dict': dict,
                'str': str,
                'int': int,
                'float': float,
                'bool': bool,
                'sum': sum,
                'min': min,
                'max': max,
                'sorted': sorted,
                'abs': abs,
                'round': round,
            }
            
            logger.info("Secure execution environment initialized")
            
        except Exception as e:
            logger.error(f"Failed to initialize secure environment: {e}")
    
    async def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process code interpretation requests
        """
        try:
            self._log_processing("Initiating advanced code interpretation system")
            
            # Extract data for code interpretation
            user_input = pipeline_data.get('user_input', '')
            current_response = pipeline_data.get('current_response', '')
            context = pipeline_data.get('context', {})
            conversation_id = pipeline_data.get('conversation_id', 'default')
            
            # Check if code interpretation is needed
            code_requests = await self._identify_code_requests(
                user_input, current_response, context
            )
            
            if not code_requests:
                # No code interpretation needed
                return self._create_result(
                    output=current_response,
                    metadata={
                        'agent_name': 'CodeInterpreterAgent',
                        'code_interpretation_needed': False,
                        'processing_time': datetime.now().isoformat()
                    }
                )
            
            # Process code requests
            interpretation_results = []
            enhanced_response = current_response
            
            for request in code_requests:
                result = await self._process_code_request(request, context)
                interpretation_results.append(result)
                
                # Enhance response with code results
                enhanced_response = await self._integrate_code_results(
                    enhanced_response, result, request
                )
            
            # Update session state
            await self._update_session_state(
                conversation_id, interpretation_results
            )
            
            # Generate metadata
            code_metadata = {
                'total_code_blocks_processed': len(code_requests),
                'languages_used': list(set([r['language'] for r in code_requests])),
                'execution_results': [
                    {
                        'language': result.language,
                        'success': result.error is None,
                        'execution_time': result.execution_time,
                        'output_length': len(result.output)
                    } for result in interpretation_results
                ],
                'security_checks_passed': all(
                    not result.error or 'security' not in result.error.lower()
                    for result in interpretation_results
                ),
                'new_variables_created': sum(
                    len(result.variables_created) for result in interpretation_results
                ),
                'functions_defined': sum(
                    len(result.functions_defined) for result in interpretation_results
                )
            }
            
            return self._create_result(
                output=enhanced_response,
                metadata={
                    'agent_name': 'CodeInterpreterAgent',
                    'processing_time': datetime.now().isoformat(),
                    'code_interpretation_results': [
                        {
                            'code': r.code,
                            'language': r.language,
                            'output': r.output[:500],  # Truncate for metadata
                            'success': r.error is None,
                            'execution_time': r.execution_time
                        } for r in interpretation_results
                    ],
                    'code_metadata': code_metadata,
                    'quality_score': self._calculate_quality_score(interpretation_results)
                }
            )
            
        except Exception as e:
            logger.error(f"Code interpretation processing error: {e}")
            return self._create_result(
                output=pipeline_data.get('current_response', ''),
                metadata={
                    'agent_name': 'CodeInterpreterAgent',
                    'error': str(e),
                    'fallback_applied': True,
                    'code_interpretation_skipped': True
                }
            )
    
    async def _identify_code_requests(
        self, 
        user_input: str, 
        current_response: str, 
        context: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """
        Identify code blocks and execution requests
        """
        try:
            code_requests = []
            
            # Check user input for explicit code execution requests
            execution_keywords = [
                'run this code', 'execute', 'run the following', 'can you run',
                'execute this', 'run python', 'run javascript', 'test this code'
            ]
            
            user_lower = user_input.lower()
            explicit_request = any(keyword in user_lower for keyword in execution_keywords)
            
            # Find code blocks in user input and current response
            combined_text = f"{user_input}\n{current_response}"
            
            # Pattern to match code blocks
            code_block_patterns = [
                r'```(\w+)?\n(.*?)\n```',  # Markdown code blocks
                r'`([^`]+)`',  # Inline code
                r'def\s+\w+\([^)]*\):',  # Python function definitions
                r'function\s+\w+\([^)]*\)\s*{',  # JavaScript functions
                r'class\s+\w+.*:',  # Python classes
            ]
            
            for pattern in code_block_patterns:
                matches = re.finditer(pattern, combined_text, re.DOTALL | re.MULTILINE)
                for match in matches:
                    if len(match.groups()) >= 2:
                        language = match.group(1) or 'python'
                        code = match.group(2)
                    else:
                        language = self._detect_language(match.group(0))
                        code = match.group(0)
                    
                    if len(code.strip()) > 5:  # Skip very short snippets
                        code_requests.append({
                            'code': code.strip(),
                            'language': language.lower(),
                            'explicit_request': explicit_request,
                            'context': 'user_input' if match.group(0) in user_input else 'response'
                        })
            
            # Check for code-related questions
            code_question_patterns = [
                r'how do I.*code', r'write.*function', r'create.*script',
                r'debug.*code', r'fix.*error', r'optimize.*code'
            ]
            
            if any(re.search(pattern, user_lower) for pattern in code_question_patterns):
                # Look for code in the response that might need execution for demonstration
                response_code = self._extract_code_from_response(current_response)
                if response_code:
                    code_requests.extend(response_code)
            
            return code_requests[:5]  # Limit to 5 code blocks for performance
            
        except Exception as e:
            logger.error(f"Code request identification error: {e}")
            return []
    
    def _detect_language(self, code: str) -> str:
        """
        Detect programming language from code snippet
        """
        code_lower = code.lower()
        
        # Language detection patterns
        if any(keyword in code_lower for keyword in ['def ', 'import ', 'print(', 'if __name__']):
            return 'python'
        elif any(keyword in code_lower for keyword in ['function', 'var ', 'let ', 'const ', 'console.log']):
            return 'javascript'
        elif any(keyword in code_lower for keyword in ['select', 'from', 'where', 'insert', 'update']):
            return 'sql'
        elif any(keyword in code_lower for keyword in ['echo', 'ls', 'cd', 'grep', 'awk']):
            return 'bash'
        else:
            return 'python'  # Default to Python
    
    def _extract_code_from_response(self, response: str) -> List[Dict[str, Any]]:
        """
        Extract executable code from response text
        """
        code_blocks = []
        
        # Look for code blocks in response
        patterns = [
            r'```(\w+)?\n(.*?)\n```',
            r'Here\'s.*code:.*?\n(.*?)(?=\n\n|\n[A-Z]|\Z)',
            r'Example:.*?\n(.*?)(?=\n\n|\n[A-Z]|\Z)'
        ]
        
        for pattern in patterns:
            matches = re.finditer(pattern, response, re.DOTALL)
            for match in matches:
                if len(match.groups()) >= 2:
                    language = match.group(1) or 'python'
                    code = match.group(2)
                else:
                    code = match.group(1)
                    language = self._detect_language(code)
                
                if len(code.strip()) > 10:
                    code_blocks.append({
                        'code': code.strip(),
                        'language': language.lower(),
                        'explicit_request': False,
                        'context': 'response_example'
                    })
        
        return code_blocks
    
    async def _process_code_request(
        self, 
        request: Dict[str, Any], 
        context: Dict[str, Any]
    ) -> CodeExecution:
        """
        Process a single code execution request
        """
        try:
            code = request['code']
            language = request['language']
            
            # Security check
            security_check = await self._security_check(code, language)
            if not security_check['safe']:
                return CodeExecution(
                    code=code,
                    language=language,
                    output="",
                    error=f"Security violation: {security_check['reason']}",
                    execution_time=0.0,
                    exit_code=1,
                    variables_created={},
                    imports_used=[],
                    functions_defined=[],
                    classes_defined=[]
                )
            
            # Code analysis
            analysis = await self._analyze_code(code, language)
            
            # Execute code if safe
            if language in self.supported_languages:
                execution_result = await self._execute_code(code, language, context)
            else:
                execution_result = CodeExecution(
                    code=code,
                    language=language,
                    output="",
                    error=f"Unsupported language: {language}",
                    execution_time=0.0,
                    exit_code=1,
                    variables_created={},
                    imports_used=[],
                    functions_defined=[],
                    classes_defined=[]
                )
            
            # Add analysis results to execution
            if analysis:
                execution_result.output = f"{execution_result.output}\n\n--- Code Analysis ---\n{self._format_analysis(analysis)}"
            
            return execution_result
            
        except Exception as e:
            logger.error(f"Code processing error: {e}")
            return CodeExecution(
                code=request.get('code', ''),
                language=request.get('language', 'unknown'),
                output="",
                error=f"Processing error: {str(e)}",
                execution_time=0.0,
                exit_code=1,
                variables_created={},
                imports_used=[],
                functions_defined=[],
                classes_defined=[]
            )
    
    async def _security_check(self, code: str, language: str) -> Dict[str, Any]:
        """
        Perform security check on code
        """
        try:
            # Check for forbidden patterns
            for forbidden in self.security_constraints['forbidden_keywords']:
                if forbidden.lower() in code.lower():
                    return {
                        'safe': False,
                        'reason': f"Forbidden keyword: {forbidden}"
                    }
            
            # Check for dangerous imports (Python specific)
            if language == 'python':
                for forbidden_import in self.security_constraints['forbidden_imports']:
                    if forbidden_import in code:
                        return {
                            'safe': False,
                            'reason': f"Forbidden import: {forbidden_import}"
                        }
            
            # Check code length
            if len(code) > 10000:
                return {
                    'safe': False,
                    'reason': "Code too long (max 10,000 characters)"
                }
            
            # Additional language-specific checks
            if language == 'bash':
                dangerous_commands = ['rm', 'dd', 'mkfs', 'fdisk', 'chmod 777']
                if any(cmd in code.lower() for cmd in dangerous_commands):
                    return {
                        'safe': False,
                        'reason': "Dangerous bash command detected"
                    }
            
            return {'safe': True, 'reason': 'Code passed security checks'}
            
        except Exception as e:
            logger.error(f"Security check error: {e}")
            return {
                'safe': False,
                'reason': f"Security check failed: {str(e)}"
            }
    
    async def _analyze_code(self, code: str, language: str) -> Optional[CodeAnalysis]:
        """
        Analyze code for quality, performance, and style issues
        """
        try:
            if language != 'python':
                return None  # Only Python analysis for now
            
            # Parse Python code
            try:
                tree = ast.parse(code)
                syntax_valid = True
            except SyntaxError as e:
                return CodeAnalysis(
                    syntax_valid=False,
                    complexity_score=0.0,
                    security_issues=[f"Syntax error: {str(e)}"],
                    performance_issues=[],
                    style_issues=[],
                    suggestions=[],
                    dependencies=[],
                    estimated_runtime="unknown"
                )
            
            # Analyze AST
            complexity_score = self._calculate_complexity(tree)
            security_issues = self._find_security_issues(code)
            performance_issues = self._find_performance_issues(code)
            style_issues = self._find_style_issues(code)
            dependencies = self._extract_dependencies(tree)
            suggestions = self._generate_suggestions(code, tree)
            
            return CodeAnalysis(
                syntax_valid=syntax_valid,
                complexity_score=complexity_score,
                security_issues=security_issues,
                performance_issues=performance_issues,
                style_issues=style_issues,
                suggestions=suggestions,
                dependencies=dependencies,
                estimated_runtime=self._estimate_runtime(tree)
            )
            
        except Exception as e:
            logger.error(f"Code analysis error: {e}")
            return None
    
    def _calculate_complexity(self, tree: ast.AST) -> float:
        """
        Calculate cyclomatic complexity of Python code
        """
        complexity = 1  # Base complexity
        
        for node in ast.walk(tree):
            if isinstance(node, (ast.If, ast.While, ast.For, ast.AsyncFor)):
                complexity += 1
            elif isinstance(node, ast.ExceptHandler):
                complexity += 1
            elif isinstance(node, ast.With, ast.AsyncWith):
                complexity += 1
        
        return complexity / 10.0  # Normalize to 0-1 range
    
    def _find_security_issues(self, code: str) -> List[str]:
        """
        Find potential security issues in code
        """
        issues = []
        
        for pattern_name, patterns in self.analysis_patterns.items():
            if pattern_name == 'security_issues':
                for pattern in patterns:
                    if re.search(pattern, code):
                        issues.append(f"Potential security risk: {pattern}")
        
        return issues
    
    def _find_performance_issues(self, code: str) -> List[str]:
        """
        Find potential performance issues in code
        """
        issues = []
        
        for pattern_name, patterns in self.analysis_patterns.items():
            if pattern_name == 'performance_issues':
                for pattern in patterns:
                    if re.search(pattern, code):
                        issues.append(f"Performance issue: {pattern}")
        
        return issues
    
    def _find_style_issues(self, code: str) -> List[str]:
        """
        Find style issues in code
        """
        issues = []
        
        for pattern_name, patterns in self.analysis_patterns.items():
            if pattern_name == 'style_issues':
                for pattern in patterns:
                    if re.search(pattern, code):
                        issues.append(f"Style issue: {pattern}")
        
        return issues
    
    def _extract_dependencies(self, tree: ast.AST) -> List[str]:
        """
        Extract import dependencies from AST
        """
        dependencies = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    dependencies.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    dependencies.append(node.module)
        
        return dependencies
    
    def _generate_suggestions(self, code: str, tree: ast.AST) -> List[str]:
        """
        Generate improvement suggestions
        """
        suggestions = []
        
        # Check for list comprehension opportunities
        if 'for' in code and '.append(' in code:
            suggestions.append("Consider using list comprehension for better performance")
        
        # Check for function documentation
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                if not ast.get_docstring(node):
                    suggestions.append(f"Add docstring to function '{node.name}'")
        
        # Check for variable naming
        if re.search(r'[a-z]+[A-Z]', code):
            suggestions.append("Use snake_case instead of camelCase for Python variables")
        
        return suggestions
    
    def _estimate_runtime(self, tree: ast.AST) -> str:
        """
        Estimate code runtime complexity
        """
        loop_count = 0
        nested_loops = 0
        
        for node in ast.walk(tree):
            if isinstance(node, (ast.For, ast.While)):
                loop_count += 1
                # Check for nested loops
                for child in ast.walk(node):
                    if child != node and isinstance(child, (ast.For, ast.While)):
                        nested_loops += 1
        
        if nested_loops > 0:
            return "O(n²) or higher - potential performance concern"
        elif loop_count > 0:
            return "O(n) - linear complexity"
        else:
            return "O(1) - constant time"
    
    async def _execute_code(
        self, 
        code: str, 
        language: str, 
        context: Dict[str, Any]
    ) -> CodeExecution:
        """
        Execute code in secure environment
        """
        start_time = datetime.now()
        
        try:
            if language == 'python':
                result = await self._execute_python(code, context)
            elif language == 'javascript':
                result = await self._execute_javascript(code, context)
            elif language == 'bash':
                result = await self._execute_bash(code, context)
            elif language == 'sql':
                result = await self._execute_sql(code, context)
            else:
                result = CodeExecution(
                    code=code,
                    language=language,
                    output="",
                    error=f"Unsupported language: {language}",
                    execution_time=0.0,
                    exit_code=1,
                    variables_created={},
                    imports_used=[],
                    functions_defined=[],
                    classes_defined=[]
                )
            
            execution_time = (datetime.now() - start_time).total_seconds()
            result.execution_time = execution_time
            
            return result
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            logger.error(f"Code execution error: {e}")
            
            return CodeExecution(
                code=code,
                language=language,
                output="",
                error=f"Execution error: {str(e)}",
                execution_time=execution_time,
                exit_code=1,
                variables_created={},
                imports_used=[],
                functions_defined=[],
                classes_defined=[]
            )
    
    async def _execute_python(self, code: str, context: Dict[str, Any]) -> CodeExecution:
        """
        Execute Python code in restricted environment
        """
        import io
        import contextlib
        
        # Capture output
        output_buffer = io.StringIO()
        error_output = None
        variables_created = {}
        imports_used = []
        functions_defined = []
        classes_defined = []
        
        try:
            # Create restricted globals
            restricted_globals = self.restricted_builtins.copy()
            restricted_globals.update(self.session_variables)
            
            # Parse and analyze code before execution
            tree = ast.parse(code)
            
            # Extract imports and definitions
            for node in ast.walk(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    if isinstance(node, ast.Import):
                        imports_used.extend([alias.name for alias in node.names])
                    else:
                        if node.module:
                            imports_used.append(node.module)
                elif isinstance(node, ast.FunctionDef):
                    functions_defined.append(node.name)
                elif isinstance(node, ast.ClassDef):
                    classes_defined.append(node.name)
            
            # Execute with output capture
            with contextlib.redirect_stdout(output_buffer), \
                 contextlib.redirect_stderr(output_buffer):
                
                # Execute in restricted environment
                exec(code, restricted_globals)
                
                # Capture new variables
                for key, value in restricted_globals.items():
                    if key not in self.restricted_builtins and key not in self.session_variables:
                        variables_created[key] = str(value)[:100]  # Truncate for safety
                
                # Update session variables
                self.session_variables.update(variables_created)
            
            output = output_buffer.getvalue()
            
            return CodeExecution(
                code=code,
                language='python',
                output=output[:self.security_constraints['max_output_length']],
                error=None,
                execution_time=0.0,  # Will be set by caller
                exit_code=0,
                variables_created=variables_created,
                imports_used=imports_used,
                functions_defined=functions_defined,
                classes_defined=classes_defined
            )
            
        except Exception as e:
            error_output = str(e)
            return CodeExecution(
                code=code,
                language='python',
                output=output_buffer.getvalue(),
                error=error_output,
                execution_time=0.0,
                exit_code=1,
                variables_created={},
                imports_used=imports_used,
                functions_defined=functions_defined,
                classes_defined=classes_defined
            )
    
    async def _execute_javascript(self, code: str, context: Dict[str, Any]) -> CodeExecution:
        """
        Execute JavaScript code using Node.js
        """
        try:
            # Create temporary file
            temp_file = os.path.join(self.temp_dir, 'code.js')
            with open(temp_file, 'w') as f:
                f.write(code)
            
            # Execute with timeout
            process = await asyncio.create_subprocess_exec(
                'node', temp_file,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.temp_dir
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self.security_constraints['max_execution_time']
                )
            except asyncio.TimeoutError:
                process.kill()
                return CodeExecution(
                    code=code,
                    language='javascript',
                    output="",
                    error="Execution timeout",
                    execution_time=0.0,
                    exit_code=1,
                    variables_created={},
                    imports_used=[],
                    functions_defined=[],
                    classes_defined=[]
                )
            
            output = stdout.decode('utf-8') if stdout else ""
            error = stderr.decode('utf-8') if stderr else None
            
            return CodeExecution(
                code=code,
                language='javascript',
                output=output[:self.security_constraints['max_output_length']],
                error=error,
                execution_time=0.0,
                exit_code=process.returncode or 0,
                variables_created={},
                imports_used=[],
                functions_defined=[],
                classes_defined=[]
            )
            
        except Exception as e:
            return CodeExecution(
                code=code,
                language='javascript',
                output="",
                error=f"JavaScript execution error: {str(e)}",
                execution_time=0.0,
                exit_code=1,
                variables_created={},
                imports_used=[],
                functions_defined=[],
                classes_defined=[]
            )
        finally:
            # Cleanup
            if 'temp_file' in locals() and os.path.exists(temp_file):
                os.remove(temp_file)
    
    async def _execute_bash(self, code: str, context: Dict[str, Any]) -> CodeExecution:
        """
        Execute Bash code with restrictions
        """
        try:
            # Additional security for bash
            if any(dangerous in code.lower() for dangerous in ['rm', 'dd', 'format', '>']):
                return CodeExecution(
                    code=code,
                    language='bash',
                    output="",
                    error="Dangerous bash command blocked",
                    execution_time=0.0,
                    exit_code=1,
                    variables_created={},
                    imports_used=[],
                    functions_defined=[],
                    classes_defined=[]
                )
            
            # Execute with timeout
            process = await asyncio.create_subprocess_shell(
                code,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.temp_dir
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self.security_constraints['max_execution_time']
                )
            except asyncio.TimeoutError:
                process.kill()
                return CodeExecution(
                    code=code,
                    language='bash',
                    output="",
                    error="Execution timeout",
                    execution_time=0.0,
                    exit_code=1,
                    variables_created={},
                    imports_used=[],
                    functions_defined=[],
                    classes_defined=[]
                )
            
            output = stdout.decode('utf-8') if stdout else ""
            error = stderr.decode('utf-8') if stderr else None
            
            return CodeExecution(
                code=code,
                language='bash',
                output=output[:self.security_constraints['max_output_length']],
                error=error,
                execution_time=0.0,
                exit_code=process.returncode or 0,
                variables_created={},
                imports_used=[],
                functions_defined=[],
                classes_defined=[]
            )
            
        except Exception as e:
            return CodeExecution(
                code=code,
                language='bash',
                output="",
                error=f"Bash execution error: {str(e)}",
                execution_time=0.0,
                exit_code=1,
                variables_created={},
                imports_used=[],
                functions_defined=[],
                classes_defined=[]
            )
    
    async def _execute_sql(self, code: str, context: Dict[str, Any]) -> CodeExecution:
        """
        Execute SQL code in SQLite
        """
        try:
            import sqlite3
            
            # Create in-memory database
            conn = sqlite3.connect(':memory:')
            cursor = conn.cursor()
            
            # Create sample tables for demonstration
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    name TEXT,
                    email TEXT
                )
            ''')
            cursor.execute('''
                INSERT INTO users (name, email) VALUES 
                ('John Doe', 'john@example.com'),
                ('Jane Smith', 'jane@example.com')
            ''')
            
            # Execute user's SQL
            cursor.execute(code)
            
            # Fetch results
            if code.strip().upper().startswith('SELECT'):
                results = cursor.fetchall()
                output = '\n'.join([str(row) for row in results])
            else:
                conn.commit()
                output = f"Query executed successfully. Rows affected: {cursor.rowcount}"
            
            conn.close()
            
            return CodeExecution(
                code=code,
                language='sql',
                output=output[:self.security_constraints['max_output_length']],
                error=None,
                execution_time=0.0,
                exit_code=0,
                variables_created={},
                imports_used=[],
                functions_defined=[],
                classes_defined=[]
            )
            
        except Exception as e:
            return CodeExecution(
                code=code,
                language='sql',
                output="",
                error=f"SQL execution error: {str(e)}",
                execution_time=0.0,
                exit_code=1,
                variables_created={},
                imports_used=[],
                functions_defined=[],
                classes_defined=[]
            )
    
    def _format_analysis(self, analysis: CodeAnalysis) -> str:
        """
        Format code analysis results for display
        """
        lines = []
        
        if analysis.security_issues:
            lines.append("🔒 Security Issues:")
            for issue in analysis.security_issues:
                lines.append(f"  - {issue}")
        
        if analysis.performance_issues:
            lines.append("⚡ Performance Issues:")
            for issue in analysis.performance_issues:
                lines.append(f"  - {issue}")
        
        if analysis.suggestions:
            lines.append("💡 Suggestions:")
            for suggestion in analysis.suggestions:
                lines.append(f"  - {suggestion}")
        
        lines.append(f"📊 Complexity Score: {analysis.complexity_score:.2f}")
        lines.append(f"⏱️ Estimated Runtime: {analysis.estimated_runtime}")
        
        return '\n'.join(lines)
    
    async def _integrate_code_results(
        self,
        response: str,
        result: CodeExecution,
        request: Dict[str, Any]
    ) -> str:
        """
        Integrate code execution results into response
        """
        try:
            if request.get('explicit_request'):
                # User explicitly asked for code execution
                if result.error:
                    addition = f"\n\n❌ **Code Execution Error:**\n```\n{result.error}\n```"
                else:
                    addition = f"\n\n✅ **Code Execution Result:**\n```\n{result.output}\n```"
                    
                    if result.variables_created:
                        addition += f"\n\n📝 **Variables Created:** {', '.join(result.variables_created.keys())}"
                    
                    if result.functions_defined:
                        addition += f"\n\n🔧 **Functions Defined:** {', '.join(result.functions_defined)}"
                
                return response + addition
            
            elif result.error:
                # Code had errors, mention it
                addition = f"\n\n*Note: The code example above contains an error: {result.error}*"
                return response + addition
            
            else:
                # Code executed successfully, optionally show result
                if result.output and len(result.output.strip()) > 0:
                    addition = f"\n\n*Output:* `{result.output.strip()[:100]}...`"
                    return response + addition
            
            return response
            
        except Exception as e:
            logger.error(f"Result integration error: {e}")
            return response
    
    async def _update_session_state(
        self,
        conversation_id: str,
        results: List[CodeExecution]
    ):
        """
        Update session state with execution results
        """
        try:
            # Add to execution history
            for result in results:
                self.execution_history.append({
                    'timestamp': datetime.now().isoformat(),
                    'conversation_id': conversation_id,
                    'code': result.code,
                    'language': result.language,
                    'success': result.error is None,
                    'output': result.output[:200],  # Truncated for storage
                    'variables_created': list(result.variables_created.keys()),
                    'functions_defined': result.functions_defined
                })
            
            # Keep only last 50 executions
            if len(self.execution_history) > 50:
                self.execution_history = self.execution_history[-50:]
                
        except Exception as e:
            logger.error(f"Session state update error: {e}")
    
    def _calculate_quality_score(self, results: List[CodeExecution]) -> float:
        """
        Calculate overall quality score for code interpretation
        """
        if not results:
            return 0.7
        
        successful_executions = len([r for r in results if r.error is None])
        total_executions = len(results)
        
        success_rate = successful_executions / total_executions
        
        # Consider execution times
        avg_time = sum(r.execution_time for r in results) / len(results)
        time_score = max(0, 1 - (avg_time / 10))  # Penalize slow executions
        
        # Consider code analysis results
        analysis_score = 0.8  # Default good score
        
        overall_score = (success_rate * 0.6 + time_score * 0.2 + analysis_score * 0.2)
        
        return min(1.0, max(0.0, overall_score))


# Agent registry entry
def create_code_interpreter_agent():
    """Factory function to create CodeInterpreterAgent instance"""
    return CodeInterpreterAgent()
