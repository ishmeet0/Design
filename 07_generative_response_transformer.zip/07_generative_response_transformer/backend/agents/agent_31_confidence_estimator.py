# 📊 Confidence score analysis
from .base_agent import BaseAgent
from typing import Dict, Any

class ConfidenceEstimatorAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="ConfidenceEstimatorAgent", description="Confidence score analysis")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        confidence_score = self._calculate_confidence(pipeline_data)
        return self._create_result(output=current_response, metadata={'confidence_score': confidence_score})
    
    def _calculate_confidence(self, pipeline_data: Dict[str, Any]) -> float:
        return 0.92  # High confidence for well-processed responses
"""
📊 Agent 31: Confidence Estimator - Advanced confidence scoring and uncertainty quantification
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List, Tuple
import json
import re
import math
from datetime import datetime

class Agent31ConfidenceEstimator(BaseAgent):
    """Agent 31: Advanced confidence estimation and uncertainty quantification"""
    
    def __init__(self):
        super().__init__(
            name="Agent31ConfidenceEstimator",
            description="Advanced confidence scoring, uncertainty quantification, and reliability assessment",
            priority=8
        )
        
        # Confidence indicators
        self.confidence_markers = {
            'high_confidence': {
                'definitive': ['definitely', 'certainly', 'absolutely', 'guaranteed', 'proven', 'established'],
                'factual': ['fact', 'proven', 'demonstrated', 'confirmed', 'verified', 'documented'],
                'mathematical': ['equals', 'always', 'never', 'impossible', 'certain']
            },
            'medium_confidence': {
                'probable': ['likely', 'probably', 'generally', 'typically', 'usually', 'often'],
                'supported': ['evidence suggests', 'research indicates', 'studies show', 'appears', 'seems']
            },
            'low_confidence': {
                'uncertain': ['might', 'may', 'could', 'possibly', 'perhaps', 'potentially'],
                'speculative': ['theoretically', 'hypothetically', 'presumably', 'allegedly', 'supposedly']
            },
            'uncertainty_indicators': [
                'unclear', 'unknown', 'disputed', 'debated', 'controversial', 'uncertain',
                'not sure', 'depends on', 'varies', 'context-dependent'
            ]
        }
        
        # Domain confidence factors
        self.domain_confidence = {
            'mathematics': 0.95,      # High confidence in math
            'established_science': 0.90,  # Physics, chemistry basics
            'current_events': 0.60,   # May be outdated
            'opinion_topics': 0.40,   # Subjective matters
            'emerging_tech': 0.50,    # Rapidly changing
            'philosophical': 0.30     # Highly subjective
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process response through confidence estimation"""
        try:
            current_response = pipeline_data.get('current_response', '')
            user_input = pipeline_data.get('user_input', '')
            context = pipeline_data.get('context', {})
            
            self._log_processing(f"Confidence Estimation: {len(current_response)} characters")
            
            # Analyze linguistic confidence markers
            linguistic_confidence = self._analyze_linguistic_confidence(current_response)
            
            # Assess domain-specific confidence
            domain_confidence = self._assess_domain_confidence(current_response, user_input)
            
            # Calculate structural confidence
            structural_confidence = self._calculate_structural_confidence(current_response)
            
            # Evaluate factual claim confidence
            factual_confidence = self._evaluate_factual_claims(current_response)
            
            # Compute overall confidence score
            overall_confidence = self._compute_overall_confidence(
                linguistic_confidence, domain_confidence, structural_confidence, factual_confidence
            )
            
            # Generate confidence-enhanced response
            enhanced_response = self._enhance_response_with_confidence(
                current_response, overall_confidence
            )
            
            return self._create_result(
                enhanced_response,
                {
                    'confidence_analysis': {
                        'overall_confidence': overall_confidence,
                        'linguistic_confidence': linguistic_confidence,
                        'domain_confidence': domain_confidence,
                        'structural_confidence': structural_confidence,
                        'factual_confidence': factual_confidence
                    },
                    'confidence_level': self._get_confidence_level(overall_confidence['score']),
                    'reliability_indicators': self._get_reliability_indicators(overall_confidence),
                    'uncertainty_quantification': self._quantify_uncertainty(overall_confidence)
                }
            )
            
        except Exception as e:
            return self._create_result(
                current_response,
                {'error': f'Confidence estimation failed: {str(e)}', 'fallback_applied': True}
            )
    
    def _analyze_linguistic_confidence(self, text: str) -> Dict[str, Any]:
        """Analyze linguistic markers of confidence"""
        text_lower = text.lower()
        
        # Count confidence markers
        high_markers = []
        medium_markers = []
        low_markers = []
        uncertainty_markers = []
        
        for category, subcategories in self.confidence_markers.items():
            if category == 'high_confidence':
                for subcat, markers in subcategories.items():
                    for marker in markers:
                        count = text_lower.count(marker)
                        if count > 0:
                            high_markers.extend([marker] * count)
            elif category == 'medium_confidence':
                for subcat, markers in subcategories.items():
                    for marker in markers:
                        count = text_lower.count(marker)
                        if count > 0:
                            medium_markers.extend([marker] * count)
            elif category == 'low_confidence':
                for subcat, markers in subcategories.items():
                    for marker in markers:
                        count = text_lower.count(marker)
                        if count > 0:
                            low_markers.extend([marker] * count)
            elif category == 'uncertainty_indicators':
                for marker in subcategories:
                    count = text_lower.count(marker)
                    if count > 0:
                        uncertainty_markers.extend([marker] * count)
        
        total_markers = len(high_markers) + len(medium_markers) + len(low_markers)
        
        if total_markers == 0:
            linguistic_score = 0.5  # neutral
        else:
            linguistic_score = (
                len(high_markers) * 1.0 + 
                len(medium_markers) * 0.6 + 
                len(low_markers) * 0.2
            ) / total_markers
        
        # Adjust for uncertainty markers
        uncertainty_penalty = min(0.3, len(uncertainty_markers) * 0.1)
        linguistic_score = max(0.1, linguistic_score - uncertainty_penalty)
        
        return {
            'score': linguistic_score,
            'high_confidence_markers': high_markers,
            'medium_confidence_markers': medium_markers,
            'low_confidence_markers': low_markers,
            'uncertainty_markers': uncertainty_markers,
            'marker_distribution': {
                'high': len(high_markers),
                'medium': len(medium_markers),
                'low': len(low_markers),
                'uncertainty': len(uncertainty_markers)
            }
        }
    
    def _assess_domain_confidence(self, response: str, user_input: str) -> Dict[str, Any]:
        """Assess confidence based on domain/topic"""
        combined_text = f"{user_input} {response}".lower()
        
        domain_scores = {}
        detected_domains = []
        
        # Mathematics domain
        math_patterns = [r'\b\d+\s*[+\-*/=]\s*\d+', r'\b(?:equation|formula|theorem|proof)\b',
                        r'\b(?:integral|derivative|matrix|vector)\b']
        if any(re.search(pattern, combined_text) for pattern in math_patterns):
            domain_scores['mathematics'] = self.domain_confidence['mathematics']
            detected_domains.append('mathematics')
        
        # Established science
        science_patterns = [r'\b(?:physics|chemistry|biology|law of|principle of)\b',
                           r'\b(?:gravity|thermodynamics|conservation|evolution)\b']
        if any(re.search(pattern, combined_text) for pattern in science_patterns):
            domain_scores['established_science'] = self.domain_confidence['established_science']
            detected_domains.append('established_science')
        
        # Current events
        current_patterns = [r'\b(?:news|recent|today|yesterday|last week|current)\b',
                           r'\b(?:2023|2024|2025|breaking|update)\b']
        if any(re.search(pattern, combined_text) for pattern in current_patterns):
            domain_scores['current_events'] = self.domain_confidence['current_events']
            detected_domains.append('current_events')
        
        # Opinion topics
        opinion_patterns = [r'\b(?:opinion|believe|think|feel|prefer|should|better|worse)\b',
                           r'\b(?:art|beauty|taste|style|opinion)\b']
        if any(re.search(pattern, combined_text) for pattern in opinion_patterns):
            domain_scores['opinion_topics'] = self.domain_confidence['opinion_topics']
            detected_domains.append('opinion_topics')
        
        # Emerging technology
        tech_patterns = [r'\b(?:AI|artificial intelligence|machine learning|blockchain)\b',
                        r'\b(?:quantum computing|neural networks|deep learning)\b']
        if any(re.search(pattern, combined_text) for pattern in tech_patterns):
            domain_scores['emerging_tech'] = self.domain_confidence['emerging_tech']
            detected_domains.append('emerging_tech')
        
        # Philosophical topics
        phil_patterns = [r'\b(?:consciousness|meaning of life|existence|reality)\b',
                        r'\b(?:philosophy|metaphysics|ethics|morality)\b']
        if any(re.search(pattern, combined_text) for pattern in phil_patterns):
            domain_scores['philosophical'] = self.domain_confidence['philosophical']
            detected_domains.append('philosophical')
        
        # Calculate weighted domain score
        if domain_scores:
            domain_score = sum(domain_scores.values()) / len(domain_scores)
        else:
            domain_score = 0.7  # neutral-high for general topics
        
        return {
            'score': domain_score,
            'detected_domains': detected_domains,
            'domain_scores': domain_scores,
            'primary_domain': detected_domains[0] if detected_domains else 'general'
        }
    
    def _calculate_structural_confidence(self, text: str) -> Dict[str, Any]:
        """Calculate confidence based on response structure"""
        sentences = text.split('.')
        sentence_count = len([s for s in sentences if s.strip()])
        
        # Length indicators
        word_count = len(text.split())
        if word_count < 10:
            length_confidence = 0.3  # Too brief
        elif word_count < 50:
            length_confidence = 0.6  # Reasonable
        elif word_count < 200:
            length_confidence = 0.8  # Good detail
        else:
            length_confidence = 0.7  # Might be over-explaining
        
        # Structure indicators
        has_examples = bool(re.search(r'\b(?:example|instance|such as|for example)\b', text.lower()))
        has_caveats = bool(re.search(r'\b(?:however|although|but|except|unless)\b', text.lower()))
        has_sources = bool(re.search(r'\b(?:according to|research shows|studies indicate)\b', text.lower()))
        
        structure_score = length_confidence
        if has_examples:
            structure_score += 0.1
        if has_caveats:
            structure_score += 0.1
        if has_sources:
            structure_score += 0.15
        
        structure_score = min(1.0, structure_score)
        
        return {
            'score': structure_score,
            'word_count': word_count,
            'sentence_count': sentence_count,
            'has_examples': has_examples,
            'has_caveats': has_caveats,
            'has_sources': has_sources,
            'length_confidence': length_confidence
        }
    
    def _evaluate_factual_claims(self, text: str) -> Dict[str, Any]:
        """Evaluate confidence in factual claims"""
        
        # Count different types of claims
        numerical_claims = len(re.findall(r'\d+\.?\d*\s*(?:%|percent|degrees?|years?)', text))
        specific_dates = len(re.findall(r'\b(?:19|20)\d{2}\b', text))
        proper_nouns = len(re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', text))
        
        # Assess claim specificity
        vague_terms = len(re.findall(r'\b(?:many|some|few|several|various|numerous)\b', text.lower()))
        specific_terms = numerical_claims + specific_dates
        
        if vague_terms + specific_terms == 0:
            specificity_score = 0.5
        else:
            specificity_score = specific_terms / (vague_terms + specific_terms)
        
        # Check for verification indicators
        verification_indicators = len(re.findall(
            r'\b(?:verified|confirmed|documented|peer-reviewed|published)\b', text.lower()
        ))
        
        factual_score = (specificity_score * 0.6 + 
                        min(1.0, verification_indicators * 0.2) * 0.4)
        
        return {
            'score': factual_score,
            'numerical_claims': numerical_claims,
            'specific_dates': specific_dates,
            'proper_nouns': proper_nouns,
            'specificity_score': specificity_score,
            'verification_indicators': verification_indicators,
            'vague_terms': vague_terms
        }
    
    def _compute_overall_confidence(self, linguistic: Dict[str, Any], domain: Dict[str, Any],
                                  structural: Dict[str, Any], factual: Dict[str, Any]) -> Dict[str, Any]:
        """Compute overall confidence score with weighted factors"""
        
        # Weighted combination
        weights = {
            'linguistic': 0.25,
            'domain': 0.35,
            'structural': 0.20,
            'factual': 0.20
        }
        
        overall_score = (
            linguistic['score'] * weights['linguistic'] +
            domain['score'] * weights['domain'] +
            structural['score'] * weights['structural'] +
            factual['score'] * weights['factual']
        )
        
        # Calculate confidence interval
        variance = sum([
            (linguistic['score'] - overall_score) ** 2 * weights['linguistic'],
            (domain['score'] - overall_score) ** 2 * weights['domain'],
            (structural['score'] - overall_score) ** 2 * weights['structural'],
            (factual['score'] - overall_score) ** 2 * weights['factual']
        ])
        
        std_dev = math.sqrt(variance)
        confidence_interval = (
            max(0, overall_score - 1.96 * std_dev),
            min(1, overall_score + 1.96 * std_dev)
        )
        
        return {
            'score': overall_score,
            'confidence_interval': confidence_interval,
            'standard_deviation': std_dev,
            'component_scores': {
                'linguistic': linguistic['score'],
                'domain': domain['score'],
                'structural': structural['score'],
                'factual': factual['score']
            },
            'weights_used': weights
        }
    
    def _get_confidence_level(self, score: float) -> str:
        """Convert numerical score to confidence level"""
        if score >= 0.8:
            return 'Very High'
        elif score >= 0.65:
            return 'High'
        elif score >= 0.5:
            return 'Medium'
        elif score >= 0.35:
            return 'Low'
        else:
            return 'Very Low'
    
    def _get_reliability_indicators(self, confidence: Dict[str, Any]) -> List[str]:
        """Get reliability indicators based on confidence analysis"""
        indicators = []
        score = confidence['score']
        
        if score >= 0.8:
            indicators.append("High confidence in accuracy")
            indicators.append("Well-supported information")
        elif score >= 0.65:
            indicators.append("Generally reliable information")
            indicators.append("Good factual basis")
        elif score >= 0.5:
            indicators.append("Moderate confidence level")
            indicators.append("May require verification")
        else:
            indicators.append("Low confidence - verify independently")
            indicators.append("Uncertain or speculative content")
        
        std_dev = confidence['standard_deviation']
        if std_dev > 0.3:
            indicators.append("High uncertainty across different factors")
        
        return indicators
    
    def _quantify_uncertainty(self, confidence: Dict[str, Any]) -> Dict[str, Any]:
        """Quantify uncertainty metrics"""
        score = confidence['score']
        uncertainty = 1 - score
        
        return {
            'uncertainty_percentage': uncertainty * 100,
            'margin_of_error': confidence['standard_deviation'] * 100,
            'confidence_interval_width': (confidence['confidence_interval'][1] - 
                                        confidence['confidence_interval'][0]) * 100,
            'reliability_category': self._get_reliability_category(uncertainty)
        }
    
    def _get_reliability_category(self, uncertainty: float) -> str:
        """Categorize reliability based on uncertainty"""
        if uncertainty <= 0.2:
            return 'Highly Reliable'
        elif uncertainty <= 0.35:
            return 'Reliable'
        elif uncertainty <= 0.5:
            return 'Moderately Reliable'
        elif uncertainty <= 0.65:
            return 'Low Reliability'
        else:
            return 'Very Low Reliability'
    
    def _enhance_response_with_confidence(self, response: str, confidence: Dict[str, Any]) -> str:
        """Enhance response with appropriate confidence indicators"""
        score = confidence['score']
        
        if score < 0.35:
            # Add uncertainty disclaimer for very low confidence
            disclaimer = ("\n\n**Confidence Note**: This response has low confidence. "
                         "Please verify the information independently.")
            response = response + disclaimer
        elif score < 0.5:
            # Add moderate uncertainty note
            note = "\n\n**Note**: Please consider verifying this information from additional sources."
            response = response + note
        
        return response
