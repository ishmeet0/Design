# 💬 Handles action commands
from .base_agent import BaseAgent
from typing import Dict, Any

class CommandAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="CommandAgent", description="Handles action commands")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        return self._create_result(output=current_response, metadata={'commands_processed': True})