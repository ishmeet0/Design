
"""
Input Agent - Step 1 of the Enhanced GRT Pipeline
Handles initial user input processing and validation
"""

import logging
import asyncio
from typing import Dict, Any, List
from datetime import datetime

logger = logging.getLogger(__name__)

class InputAgent:
    """Input Agent for processing user input through the pipeline"""
    
    def __init__(self):
        self.agent_id = "input_agent"
        self.capabilities = [
            "text_processing",
            "input_validation", 
            "language_detection",
            "encoding_normalization"
        ]
    
    async def process_input(self, user_input: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Process raw user input"""
        logger.info(f"🔍 Input Agent processing: {user_input[:50]}...")
        
        try:
            # Step 1: Input validation
            validated_input = self._validate_input(user_input)
            
            # Step 2: Language detection
            detected_language = self._detect_language(validated_input)
            
            # Step 3: Text normalization
            normalized_input = self._normalize_text(validated_input)
            
            # Step 4: Context extraction
            initial_context = self._extract_initial_context(normalized_input, context)
            
            result = {
                'processed_input': normalized_input,
                'original_input': user_input,
                'detected_language': detected_language,
                'input_metadata': {
                    'length': len(user_input),
                    'word_count': len(user_input.split()),
                    'character_count': len(user_input),
                    'processing_timestamp': datetime.now().isoformat()
                },
                'initial_context': initial_context,
                'validation_status': 'valid',
                'agent_id': self.agent_id
            }
            
            logger.info("✅ Input Agent processing complete")
            return result
            
        except Exception as e:
            logger.error(f"❌ Input Agent error: {e}")
            return {
                'processed_input': user_input,
                'error': str(e),
                'validation_status': 'error',
                'agent_id': self.agent_id
            }
    
    def _validate_input(self, user_input: str) -> str:
        """Validate and clean user input"""
        if not user_input or not user_input.strip():
            raise ValueError("Empty input provided")
        
        # Remove excessive whitespace
        cleaned_input = ' '.join(user_input.strip().split())
        
        # Basic content filtering
        if len(cleaned_input) > 10000:
            cleaned_input = cleaned_input[:10000] + "..."
            logger.warning("Input truncated due to length")
        
        return cleaned_input
    
    def _detect_language(self, text: str) -> str:
        """Detect the language of the input text"""
        # Simple language detection (can be enhanced with proper libraries)
        english_indicators = ['the', 'and', 'is', 'in', 'to', 'of', 'a', 'that']
        words = text.lower().split()
        
        english_count = sum(1 for word in words[:20] if word in english_indicators)
        
        if english_count > 2:
            return 'english'
        else:
            return 'unknown'
    
    def _normalize_text(self, text: str) -> str:
        """Normalize text for processing"""
        # Basic text normalization
        normalized = text.strip()
        
        # Handle common contractions
        contractions = {
            "can't": "cannot",
            "won't": "will not",
            "n't": " not",
            "'re": " are",
            "'ve": " have",
            "'ll": " will",
            "'d": " would"
        }
        
        for contraction, expansion in contractions.items():
            normalized = normalized.replace(contraction, expansion)
        
        return normalized
    
    def _extract_initial_context(self, text: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Extract initial context from input"""
        initial_context = {
            'session_id': context.get('session_id'),
            'user_id': context.get('user_id'),
            'timestamp': datetime.now().isoformat(),
            'input_type': self._classify_input_type(text),
            'urgency_level': self._assess_urgency(text),
            'complexity_estimate': self._estimate_complexity(text)
        }
        
        return initial_context
    
    def _classify_input_type(self, text: str) -> str:
        """Classify the type of input"""
        text_lower = text.lower()
        
        if any(word in text_lower for word in ['create', 'generate', 'make', 'build']):
            return 'creation_request'
        elif any(word in text_lower for word in ['explain', 'what is', 'how does', 'why']):
            return 'information_request'
        elif any(word in text_lower for word in ['help', 'assist', 'support']):
            return 'assistance_request'
        elif '?' in text:
            return 'question'
        else:
            return 'general_statement'
    
    def _assess_urgency(self, text: str) -> str:
        """Assess urgency level of the request"""
        text_lower = text.lower()
        
        urgent_indicators = ['urgent', 'asap', 'immediately', 'emergency', 'critical']
        if any(indicator in text_lower for indicator in urgent_indicators):
            return 'high'
        elif any(word in text_lower for word in ['quick', 'fast', 'soon']):
            return 'medium'
        else:
            return 'normal'
    
    def _estimate_complexity(self, text: str) -> str:
        """Estimate complexity of the request"""
        word_count = len(text.split())
        
        complex_indicators = [
            'complex', 'detailed', 'comprehensive', 'advanced', 
            'multiple', 'various', 'several', 'integrate'
        ]
        
        complexity_score = 0
        
        # Length factor
        if word_count > 50:
            complexity_score += 2
        elif word_count > 20:
            complexity_score += 1
        
        # Content factor
        for indicator in complex_indicators:
            if indicator in text.lower():
                complexity_score += 1
        
        if complexity_score >= 3:
            return 'high'
        elif complexity_score >= 1:
            return 'medium'
        else:
            return 'low'
