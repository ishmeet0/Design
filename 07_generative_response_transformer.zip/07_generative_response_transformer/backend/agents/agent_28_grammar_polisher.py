# 🧹 Grammatical finisher
from .base_agent import BaseAgent
from typing import Dict, Any

class GrammarPolisherAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="GrammarPolisherAgent", description="Grammatical finisher")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        polished = self._polish_grammar(current_response)
        return self._create_result(output=polished, metadata={'grammar_polished': True})
    
    def _polish_grammar(self, text: str) -> str:
        # Ensure proper sentence ending
        if text and not text.endswith(('.', '!', '?')):
            text += '.'
        return text