# ➕ Solves complex math expressions

from .base_agent import BaseAgent
from typing import Dict, Any
import re

class MathSolverAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="MathSolverAgent", description="Solves complex math expressions")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        math_analysis = self._analyze_math(current_response)
        
        return self._create_result(
            output=current_response,
            metadata={'math_analysis': math_analysis}
        )
    
    def _analyze_math(self, text: str) -> Dict[str, Any]:
        """Enhanced mathematical analysis"""
        # Extract mathematical expressions
        expressions = self._extract_math_expressions(text)
        
        analysis_results = []
        overall_complexity = 'none'
        
        for expr in expressions:
            try:
                analysis = self._analyze_expression(expr)
                analysis_results.append(analysis)
                
                # Update overall complexity
                if analysis['complexity'] == 'expert':
                    overall_complexity = 'expert'
                elif analysis['complexity'] == 'advanced' and overall_complexity != 'expert':
                    overall_complexity = 'advanced'
                elif analysis['complexity'] == 'intermediate' and overall_complexity not in ['expert', 'advanced']:
                    overall_complexity = 'intermediate'
                elif analysis['complexity'] == 'basic' and overall_complexity == 'none':
                    overall_complexity = 'basic'
                    
            except Exception as e:
                logger.warning(f"Error analyzing expression {expr}: {e}")
                
        return {
            'has_math_expressions': len(expressions) > 0,
            'math_complexity': overall_complexity,
            'expressions_found': len(expressions),
            'expression_types': [result['type'] for result in analysis_results],
            'solvable_expressions': sum(1 for result in analysis_results if result['solvable']),
            'analysis_results': analysis_results
        }
    
    def _extract_math_expressions(self, text: str) -> List[str]:
        """Extract mathematical expressions from text"""
        expressions = []
        
        # Pattern for equations (contains = sign)
        equation_pattern = r'[^a-zA-Z]*[x-z\d\+\-\*\/\^\(\)\s=\.]+=[x-z\d\+\-\*\/\^\(\)\s=\.]+'
        equations = re.findall(equation_pattern, text)
        expressions.extend([eq.strip() for eq in equations])
        
        # Pattern for mathematical expressions
        math_patterns = [
            r'\d+\s*[\+\-\*\/\^]\s*\d+',  # Simple arithmetic
            r'\([^)]*[\+\-\*\/\^][^)]*\)',  # Expressions in parentheses
            r'[a-z]\^?\d*[\+\-\*\/][a-z\d\^]*',  # Algebraic expressions
            r'(sin|cos|tan|log|ln|sqrt|abs)\([^)]+\)',  # Function expressions
            r'∫[^d]*d[a-z]',  # Integral notation
            r'd\/d[a-z]\s*\([^)]+\)',  # Derivative notation
            r'lim[^→]*→[^(]*\([^)]+\)'  # Limit notation
        ]
        
        for pattern in math_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            expressions.extend(matches)
        
        # Remove duplicates and filter out very short expressions
        unique_expressions = list(set(expr for expr in expressions if len(expr.strip()) > 2))
        return unique_expressions
    
    def _analyze_expression(self, expression: str) -> Dict[str, Any]:
        """Analyze individual mathematical expression"""
        expr = expression.strip()
        
        # Determine expression type
        expr_type = self._classify_expression_type(expr)
        
        # Determine complexity
        complexity = self._assess_expression_complexity(expr)
        
        # Check if solvable
        solvable = self._is_expression_solvable(expr)
        
        # Extract variables
        variables = self._extract_variables(expr)
        
        return {
            'expression': expr,
            'type': expr_type,
            'complexity': complexity,
            'solvable': solvable,
            'variables': variables,
            'contains_functions': bool(re.search(r'(sin|cos|tan|log|ln|sqrt|abs)', expr)),
            'is_equation': '=' in expr,
            'estimated_solve_time': self._estimate_solve_time(complexity)
        }
    
    def _classify_expression_type(self, expr: str) -> str:
        """Classify the type of mathematical expression"""
        if '∫' in expr or 'integral' in expr.lower():
            return 'integral'
        elif 'd/d' in expr or 'derivative' in expr.lower():
            return 'derivative'
        elif 'lim' in expr or 'limit' in expr.lower():
            return 'limit'
        elif any(func in expr for func in ['sin', 'cos', 'tan', 'log', 'ln']):
            return 'transcendental'
        elif '^' in expr or '**' in expr:
            return 'polynomial'
        elif '=' in expr:
            return 'equation'
        elif any(op in expr for op in ['+', '-', '*', '/']):
            return 'arithmetic'
        else:
            return 'algebraic'
    
    def _assess_expression_complexity(self, expr: str) -> str:
        """Assess the complexity level of an expression"""
        complexity_score = 0
        
        # Basic complexity indicators
        if any(func in expr for func in ['sin', 'cos', 'tan', 'log', 'ln', 'sqrt']):
            complexity_score += 2
        if '^' in expr or '**' in expr:
            complexity_score += 1
        if '∫' in expr or 'd/d' in expr:
            complexity_score += 3
        if len(re.findall(r'[a-z]', expr)) > 2:  # Multiple variables
            complexity_score += 1
        if '(' in expr:
            complexity_score += len(re.findall(r'\(', expr)) * 0.5
            
        # Classify based on score
        if complexity_score >= 5:
            return 'expert'
        elif complexity_score >= 3:
            return 'advanced'
        elif complexity_score >= 1:
            return 'intermediate'
        else:
            return 'basic'
    
    def _is_expression_solvable(self, expr: str) -> bool:
        """Determine if expression can be solved programmatically"""
        # Simple heuristics for solvability
        unsolvable_patterns = [
            r'[∫∑∏].*[∫∑∏]',  # Multiple integrals/sums
            r'lim.*lim',  # Nested limits
            r'[a-z]{4,}'  # Very long variable names (likely text)
        ]
        
        for pattern in unsolvable_patterns:
            if re.search(pattern, expr):
                return False
                
        return True
    
    def _extract_variables(self, expr: str) -> List[str]:
        """Extract variables from mathematical expression"""
        # Find single letter variables (a-z)
        variables = re.findall(r'\b[a-z]\b', expr.lower())
        
        # Remove function names
        function_names = ['e', 'i', 'pi', 'sin', 'cos', 'tan', 'log', 'ln']
        variables = [var for var in variables if var not in function_names]
        
        return list(set(variables))
    
    def _estimate_solve_time(self, complexity: str) -> str:
        """Estimate time to solve based on complexity"""
        time_estimates = {
            'basic': '< 1 second',
            'intermediate': '1-5 seconds',
            'advanced': '5-30 seconds',
            'expert': '30+ seconds'
        }
        return time_estimates.get(complexity, 'unknown')
"""
Agent 14 - Math Solver Agent
Advanced mathematical computation, equation solving, and mathematical analysis
"""

import logging
import asyncio
import re
import math
import cmath
import numpy as np
import sympy as sp
from typing import Dict, Any, List, Optional, Tuple, Union
from datetime import datetime
from dataclasses import dataclass
from fractions import Fraction
import json
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)

@dataclass
class MathProblem:
    """Represents a mathematical problem"""
    problem_text: str
    problem_type: str
    variables: List[str]
    equations: List[str]
    constraints: List[str]
    solution_method: str

@dataclass
class MathSolution:
    """Represents a mathematical solution"""
    problem: MathProblem
    solution: Dict[str, Any]
    steps: List[str]
    verification: bool
    confidence: float
    alternative_methods: List[str]
    visualization_data: Optional[Dict[str, Any]]

class MathSolverAgent(BaseAgent):
    """
    Agent 14 - Math Solver Agent
    
    Responsibilities:
    - Solve algebraic equations and systems
    - Perform calculus operations (derivatives, integrals)
    - Handle linear algebra computations
    - Statistical analysis and probability
    - Geometric calculations
    - Number theory operations
    - Mathematical optimization
    - Step-by-step solution explanations
    """
    
    def __init__(self):
        super().__init__(
            name="MathSolverAgent",
            description="Advanced mathematical computation and equation solving system"
        )
        
        # Mathematical operation categories
        self.math_categories = {
            'algebra': {
                'patterns': [
                    r'solve.*equation', r'find.*x', r'solve.*for', r'algebraic',
                    r'linear.*equation', r'quadratic', r'polynomial', r'factor'
                ],
                'operations': ['solve_equation', 'factor', 'expand', 'simplify']
            },
            'calculus': {
                'patterns': [
                    r'derivative', r'integral', r'limit', r'calculus',
                    r'differentiate', r'integrate', r'∫', r'd/dx', r'∂'
                ],
                'operations': ['differentiate', 'integrate', 'limit', 'series']
            },
            'linear_algebra': {
                'patterns': [
                    r'matrix', r'vector', r'determinant', r'eigenvalue',
                    r'linear.*system', r'dot.*product', r'cross.*product'
                ],
                'operations': ['matrix_operations', 'solve_system', 'eigenvalues']
            },
            'statistics': {
                'patterns': [
                    r'mean', r'median', r'mode', r'standard.*deviation',
                    r'probability', r'distribution', r'regression', r'correlation'
                ],
                'operations': ['descriptive_stats', 'probability', 'regression']
            },
            'geometry': {
                'patterns': [
                    r'area', r'volume', r'perimeter', r'angle', r'triangle',
                    r'circle', r'sphere', r'geometric', r'coordinate'
                ],
                'operations': ['area_volume', 'distance', 'angles']
            },
            'number_theory': {
                'patterns': [
                    r'prime', r'factor', r'gcd', r'lcm', r'modular',
                    r'fibonacci', r'combinatorics', r'permutation'
                ],
                'operations': ['prime_operations', 'combinatorics', 'modular_math']
            }
        }
        
        # Mathematical constants and symbols
        self.math_constants = {
            'pi': math.pi,
            'e': math.e,
            'phi': (1 + math.sqrt(5)) / 2,  # Golden ratio
            'gamma': 0.5772156649015329,  # Euler-Mascheroni constant
            'sqrt2': math.sqrt(2),
            'sqrt3': math.sqrt(3)
        }
        
        # Symbolic math setup
        self.symbols_cache = {}
        self.solution_history = []
        
        # Calculation precision settings
        self.precision_settings = {
            'decimal_places': 10,
            'significant_figures': 6,
            'use_fractions': True,
            'symbolic_preferred': True
        }
        
        logger.info("Math Solver Agent initialized with advanced computational capabilities")
    
    async def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process mathematical computation requests
        """
        try:
            self._log_processing("Initiating advanced mathematical computation system")
            
            # Extract data for mathematical processing
            user_input = pipeline_data.get('user_input', '')
            current_response = pipeline_data.get('current_response', '')
            context = pipeline_data.get('context', {})
            conversation_id = pipeline_data.get('conversation_id', 'default')
            
            # Detect mathematical problems
            math_problems = await self._identify_math_problems(
                user_input, current_response, context
            )
            
            if not math_problems:
                # No mathematical computation needed
                return self._create_result(
                    output=current_response,
                    metadata={
                        'agent_name': 'MathSolverAgent',
                        'mathematical_processing_needed': False,
                        'processing_time': datetime.now().isoformat()
                    }
                )
            
            # Solve mathematical problems
            solutions = []
            enhanced_response = current_response
            
            for problem in math_problems:
                solution = await self._solve_math_problem(problem, context)
                solutions.append(solution)
                
                # Integrate solution into response
                enhanced_response = await self._integrate_math_solution(
                    enhanced_response, solution, problem
                )
            
            # Update solution history
            await self._update_solution_history(conversation_id, solutions)
            
            # Generate mathematical metadata
            math_metadata = {
                'problems_solved': len(math_problems),
                'problem_types': [p.problem_type for p in math_problems],
                'solution_methods': [s.solution.get('method', 'unknown') for s in solutions],
                'verification_status': [s.verification for s in solutions],
                'average_confidence': np.mean([s.confidence for s in solutions]) if solutions else 0.0,
                'has_visualizations': any(s.visualization_data for s in solutions),
                'computational_complexity': self._assess_computational_complexity(math_problems),
                'mathematical_domains': list(set([p.problem_type for p in math_problems]))
            }
            
            return self._create_result(
                output=enhanced_response,
                metadata={
                    'agent_name': 'MathSolverAgent',
                    'processing_time': datetime.now().isoformat(),
                    'mathematical_solutions': [
                        {
                            'problem_type': s.problem.problem_type,
                            'solution_summary': str(s.solution.get('result', 'No solution'))[:200],
                            'steps_count': len(s.steps),
                            'verified': s.verification,
                            'confidence': s.confidence
                        } for s in solutions
                    ],
                    'math_metadata': math_metadata,
                    'quality_score': self._calculate_quality_score(solutions)
                }
            )
            
        except Exception as e:
            logger.error(f"Mathematical processing error: {e}")
            return self._create_result(
                output=pipeline_data.get('current_response', ''),
                metadata={
                    'agent_name': 'MathSolverAgent',
                    'error': str(e),
                    'fallback_applied': True,
                    'mathematical_processing_skipped': True
                }
            )
    
    async def _identify_math_problems(
        self,
        user_input: str,
        current_response: str,
        context: Dict[str, Any]
    ) -> List[MathProblem]:
        """
        Identify mathematical problems in the input and response
        """
        try:
            problems = []
            combined_text = f"{user_input}\n{current_response}"
            
            # Check for explicit mathematical requests
            math_keywords = [
                'solve', 'calculate', 'compute', 'find', 'evaluate',
                'simplify', 'factor', 'expand', 'integrate', 'differentiate'
            ]
            
            has_math_request = any(keyword in user_input.lower() for keyword in math_keywords)
            
            # Look for mathematical expressions and equations
            math_patterns = [
                r'[x-z]\s*[+\-*/=]\s*\d+',  # Simple equations
                r'\d+\s*[+\-*/]\s*\d+',  # Arithmetic expressions
                r'[∫∂].*d[x-z]',  # Calculus notation
                r'\b\d+\s*[x-z]\b',  # Terms with variables
                r'[a-z]\s*=\s*\d+',  # Variable assignments
                r'f\([x-z]\)\s*=',  # Function definitions
                r'\b(sin|cos|tan|log|ln|exp|sqrt)\s*\(',  # Mathematical functions
                r'\d+\s*×\s*\d+',  # Multiplication symbols
                r'\d+\s*÷\s*\d+',  # Division symbols
                r'\d+\^\d+',  # Exponentiation
                r'matrix|vector|determinant',  # Linear algebra
                r'derivative|integral|limit',  # Calculus terms
                r'probability|statistics|mean|median'  # Statistics terms
            ]
            
            # Find mathematical expressions
            found_expressions = []
            for pattern in math_patterns:
                matches = re.finditer(pattern, combined_text, re.IGNORECASE)
                for match in matches:
                    found_expressions.append(match.group(0))
            
            # Categorize and create problem objects
            for expr in found_expressions:
                problem_type = self._categorize_math_expression(expr)
                if problem_type:
                    variables = self._extract_variables(expr)
                    equations = self._extract_equations(expr)
                    
                    problem = MathProblem(
                        problem_text=expr,
                        problem_type=problem_type,
                        variables=variables,
                        equations=equations,
                        constraints=[],
                        solution_method=self._determine_solution_method(problem_type, expr)
                    )
                    problems.append(problem)
            
            # Check for word problems
            word_problems = await self._identify_word_problems(combined_text)
            problems.extend(word_problems)
            
            return problems[:5]  # Limit to 5 problems for performance
            
        except Exception as e:
            logger.error(f"Math problem identification error: {e}")
            return []
    
    def _categorize_math_expression(self, expression: str) -> Optional[str]:
        """
        Categorize mathematical expression by type
        """
        expr_lower = expression.lower()
        
        for category, config in self.math_categories.items():
            for pattern in config['patterns']:
                if re.search(pattern, expr_lower):
                    return category
        
        # Default categorization based on content
        if any(op in expression for op in ['+', '-', '*', '/', '=']):
            if any(func in expr_lower for func in ['sin', 'cos', 'tan', 'log', 'exp']):
                return 'calculus'
            elif re.search(r'[x-z]', expression):
                return 'algebra'
            else:
                return 'arithmetic'
        
        return None
    
    def _extract_variables(self, expression: str) -> List[str]:
        """
        Extract variables from mathematical expression
        """
        # Find single letter variables (a-z)
        variables = re.findall(r'\b[a-z]\b', expression.lower())
        
        # Find function variables like f(x), g(y)
        func_vars = re.findall(r'\b[a-z]\([a-z]\)', expression.lower())
        
        # Combine and deduplicate
        all_vars = list(set(variables + [v[-2] for v in func_vars]))
        
        return all_vars
    
    def _extract_equations(self, expression: str) -> List[str]:
        """
        Extract equations from mathematical expression
        """
        # Split by common separators and look for equations
        parts = re.split(r'[,;]', expression)
        equations = []
        
        for part in parts:
            part = part.strip()
            if '=' in part:
                equations.append(part)
        
        return equations
    
    def _determine_solution_method(self, problem_type: str, expression: str) -> str:
        """
        Determine the best solution method for the problem
        """
        method_map = {
            'algebra': 'symbolic_solve',
            'calculus': 'symbolic_calculus',
            'linear_algebra': 'matrix_operations',
            'statistics': 'statistical_analysis',
            'geometry': 'geometric_calculation',
            'number_theory': 'number_theoretic',
            'arithmetic': 'numerical_computation'
        }
        
        return method_map.get(problem_type, 'general_solve')
    
    async def _identify_word_problems(self, text: str) -> List[MathProblem]:
        """
        Identify mathematical word problems in text
        """
        word_problems = []
        
        # Common word problem patterns
        word_patterns = [
            r'if.*costs.*how much',
            r'calculate.*total',
            r'find.*area.*of',
            r'what.*percentage',
            r'how many.*are.*needed',
            r'at.*rate.*how long',
            r'probability.*of.*occurring'
        ]
        
        for pattern in word_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                problem_text = match.group(0)
                problem_type = self._categorize_word_problem(problem_text)
                
                problem = MathProblem(
                    problem_text=problem_text,
                    problem_type=problem_type,
                    variables=[],
                    equations=[],
                    constraints=[],
                    solution_method='word_problem_solve'
                )
                word_problems.append(problem)
        
        return word_problems
    
    def _categorize_word_problem(self, problem_text: str) -> str:
        """
        Categorize word problem by mathematical domain
        """
        text_lower = problem_text.lower()
        
        if any(word in text_lower for word in ['percentage', 'percent', 'rate']):
            return 'percentage_calculation'
        elif any(word in text_lower for word in ['area', 'volume', 'perimeter']):
            return 'geometry'
        elif any(word in text_lower for word in ['probability', 'chance', 'odds']):
            return 'statistics'
        elif any(word in text_lower for word in ['cost', 'price', 'total', 'sum']):
            return 'arithmetic'
        else:
            return 'word_problem'
    
    async def _solve_math_problem(
        self,
        problem: MathProblem,
        context: Dict[str, Any]
    ) -> MathSolution:
        """
        Solve a mathematical problem using appropriate methods
        """
        try:
            # Choose solution method based on problem type
            if problem.problem_type == 'algebra':
                solution_data = await self._solve_algebraic_problem(problem)
            elif problem.problem_type == 'calculus':
                solution_data = await self._solve_calculus_problem(problem)
            elif problem.problem_type == 'linear_algebra':
                solution_data = await self._solve_linear_algebra_problem(problem)
            elif problem.problem_type == 'statistics':
                solution_data = await self._solve_statistics_problem(problem)
            elif problem.problem_type == 'geometry':
                solution_data = await self._solve_geometry_problem(problem)
            elif problem.problem_type == 'number_theory':
                solution_data = await self._solve_number_theory_problem(problem)
            else:
                solution_data = await self._solve_general_problem(problem)
            
            # Verify solution
            verification = await self._verify_solution(problem, solution_data)
            
            # Calculate confidence
            confidence = self._calculate_solution_confidence(
                problem, solution_data, verification
            )
            
            # Generate visualization if applicable
            visualization_data = await self._generate_visualization(
                problem, solution_data
            )
            
            return MathSolution(
                problem=problem,
                solution=solution_data,
                steps=solution_data.get('steps', []),
                verification=verification,
                confidence=confidence,
                alternative_methods=solution_data.get('alternative_methods', []),
                visualization_data=visualization_data
            )
            
        except Exception as e:
            logger.error(f"Math problem solving error: {e}")
            return MathSolution(
                problem=problem,
                solution={'error': str(e), 'result': None},
                steps=[f"Error occurred: {str(e)}"],
                verification=False,
                confidence=0.0,
                alternative_methods=[],
                visualization_data=None
            )
    
    async def _solve_algebraic_problem(self, problem: MathProblem) -> Dict[str, Any]:
        """
        Solve algebraic equations and expressions
        """
        try:
            expression = problem.problem_text
            steps = []
            
            # Parse expression with SymPy
            try:
                # Replace common mathematical notation
                expr_cleaned = self._clean_mathematical_notation(expression)
                
                # Create symbols
                variables = problem.variables if problem.variables else ['x']
                symbols = [sp.Symbol(var) for var in variables]
                
                # Parse the expression
                if '=' in expr_cleaned:
                    # It's an equation
                    left, right = expr_cleaned.split('=', 1)
                    equation = sp.Eq(sp.sympify(left), sp.sympify(right))
                    steps.append(f"Equation to solve: {equation}")
                    
                    # Solve the equation
                    solutions = sp.solve(equation, symbols[0])
                    steps.append(f"Solving for {variables[0]}")
                    
                    result = {
                        'type': 'equation_solution',
                        'solutions': [str(sol) for sol in solutions],
                        'symbolic_solutions': solutions
                    }
                    
                else:
                    # It's an expression to simplify
                    expr_sympy = sp.sympify(expr_cleaned)
                    simplified = sp.simplify(expr_sympy)
                    steps.append(f"Simplifying: {expr_sympy}")
                    steps.append(f"Result: {simplified}")
                    
                    result = {
                        'type': 'expression_simplification',
                        'original': str(expr_sympy),
                        'simplified': str(simplified),
                        'symbolic_result': simplified
                    }
                
                # Add additional operations
                if 'factor' in expression.lower():
                    factored = sp.factor(expr_sympy if '=' not in expr_cleaned else equation.lhs)
                    result['factored'] = str(factored)
                    steps.append(f"Factored form: {factored}")
                
                if 'expand' in expression.lower():
                    expanded = sp.expand(expr_sympy if '=' not in expr_cleaned else equation.lhs)
                    result['expanded'] = str(expanded)
                    steps.append(f"Expanded form: {expanded}")
                
                return {
                    'result': result,
                    'method': 'symbolic_algebra',
                    'steps': steps,
                    'success': True
                }
                
            except Exception as sympy_error:
                # Fallback to numerical methods
                return await self._solve_numerical_fallback(problem, str(sympy_error))
                
        except Exception as e:
            logger.error(f"Algebraic solving error: {e}")
            return {
                'result': None,
                'method': 'algebraic_solve',
                'steps': [f"Error in algebraic solving: {str(e)}"],
                'success': False,
                'error': str(e)
            }
    
    async def _solve_calculus_problem(self, problem: MathProblem) -> Dict[str, Any]:
        """
        Solve calculus problems (derivatives, integrals, limits)
        """
        try:
            expression = problem.problem_text
            steps = []
            
            # Detect calculus operation
            if any(word in expression.lower() for word in ['derivative', 'differentiate', "d/dx"]):
                return await self._compute_derivative(expression, steps)
            elif any(word in expression.lower() for word in ['integral', 'integrate', '∫']):
                return await self._compute_integral(expression, steps)
            elif 'limit' in expression.lower():
                return await self._compute_limit(expression, steps)
            else:
                return await self._general_calculus_solve(expression, steps)
                
        except Exception as e:
            logger.error(f"Calculus solving error: {e}")
            return {
                'result': None,
                'method': 'calculus_solve',
                'steps': [f"Error in calculus solving: {str(e)}"],
                'success': False,
                'error': str(e)
            }
    
    async def _compute_derivative(self, expression: str, steps: List[str]) -> Dict[str, Any]:
        """
        Compute derivative of mathematical expression
        """
        try:
            # Extract function from expression
            func_match = re.search(r'f\(x\)\s*=\s*(.+)', expression)
            if func_match:
                func_expr = func_match.group(1)
            else:
                # Look for expression to differentiate
                func_expr = re.sub(r'(derivative|differentiate|d/dx)\s*(of\s*)?', '', expression, flags=re.IGNORECASE).strip()
            
            x = sp.Symbol('x')
            f = sp.sympify(func_expr)
            
            steps.append(f"Function: f(x) = {f}")
            
            # Compute derivative
            derivative = sp.diff(f, x)
            steps.append(f"Computing derivative: d/dx({f})")
            steps.append(f"Result: f'(x) = {derivative}")
            
            # Simplify if possible
            simplified = sp.simplify(derivative)
            if simplified != derivative:
                steps.append(f"Simplified: f'(x) = {simplified}")
            
            return {
                'result': {
                    'type': 'derivative',
                    'original_function': str(f),
                    'derivative': str(simplified),
                    'symbolic_derivative': simplified
                },
                'method': 'symbolic_differentiation',
                'steps': steps,
                'success': True
            }
            
        except Exception as e:
            return {
                'result': None,
                'method': 'derivative_computation',
                'steps': steps + [f"Error computing derivative: {str(e)}"],
                'success': False,
                'error': str(e)
            }
    
    async def _compute_integral(self, expression: str, steps: List[str]) -> Dict[str, Any]:
        """
        Compute integral of mathematical expression
        """
        try:
            # Extract function from expression
            func_match = re.search(r'∫\s*(.+?)\s*d[x-z]', expression)
            if func_match:
                func_expr = func_match.group(1)
                var_match = re.search(r'd([x-z])', expression)
                variable = var_match.group(1) if var_match else 'x'
            else:
                func_expr = re.sub(r'(integral|integrate)\s*(of\s*)?', '', expression, flags=re.IGNORECASE).strip()
                variable = 'x'
            
            var_symbol = sp.Symbol(variable)
            f = sp.sympify(func_expr)
            
            steps.append(f"Function: f({variable}) = {f}")
            steps.append(f"Computing integral: ∫ {f} d{variable}")
            
            # Compute indefinite integral
            integral = sp.integrate(f, var_symbol)
            steps.append(f"Indefinite integral: {integral} + C")
            
            # Check for definite integral bounds
            bounds_match = re.search(r'from\s*(\d+)\s*to\s*(\d+)', expression)
            if bounds_match:
                a, b = int(bounds_match.group(1)), int(bounds_match.group(2))
                definite_integral = sp.integrate(f, (var_symbol, a, b))
                steps.append(f"Definite integral from {a} to {b}: {definite_integral}")
                
                return {
                    'result': {
                        'type': 'definite_integral',
                        'original_function': str(f),
                        'indefinite_integral': str(integral),
                        'definite_integral': str(definite_integral),
                        'bounds': [a, b],
                        'symbolic_result': definite_integral
                    },
                    'method': 'symbolic_integration',
                    'steps': steps,
                    'success': True
                }
            else:
                return {
                    'result': {
                        'type': 'indefinite_integral',
                        'original_function': str(f),
                        'integral': str(integral),
                        'symbolic_result': integral
                    },
                    'method': 'symbolic_integration',
                    'steps': steps,
                    'success': True
                }
                
        except Exception as e:
            return {
                'result': None,
                'method': 'integral_computation',
                'steps': steps + [f"Error computing integral: {str(e)}"],
                'success': False,
                'error': str(e)
            }
    
    async def _compute_limit(self, expression: str, steps: List[str]) -> Dict[str, Any]:
        """
        Compute limit of mathematical expression
        """
        try:
            # Parse limit expression
            limit_match = re.search(r'lim.*?x\s*→\s*(\d+|∞|-∞)\s*(.+)', expression)
            if not limit_match:
                limit_match = re.search(r'limit.*?as\s*x\s*approaches\s*(\d+|infinity)\s*of\s*(.+)', expression)
            
            if limit_match:
                approach_value = limit_match.group(1)
                func_expr = limit_match.group(2)
                
                # Convert approach value
                if approach_value in ['∞', 'infinity']:
                    approach = sp.oo
                elif approach_value == '-∞':
                    approach = -sp.oo
                else:
                    approach = sp.sympify(approach_value)
                
                x = sp.Symbol('x')
                f = sp.sympify(func_expr)
                
                steps.append(f"Computing limit: lim(x→{approach_value}) {f}")
                
                # Compute limit
                limit_result = sp.limit(f, x, approach)
                steps.append(f"Result: {limit_result}")
                
                return {
                    'result': {
                        'type': 'limit',
                        'function': str(f),
                        'approach_value': str(approach),
                        'limit_value': str(limit_result),
                        'symbolic_result': limit_result
                    },
                    'method': 'symbolic_limit',
                    'steps': steps,
                    'success': True
                }
            else:
                raise ValueError("Could not parse limit expression")
                
        except Exception as e:
            return {
                'result': None,
                'method': 'limit_computation',
                'steps': steps + [f"Error computing limit: {str(e)}"],
                'success': False,
                'error': str(e)
            }
    
    async def _solve_linear_algebra_problem(self, problem: MathProblem) -> Dict[str, Any]:
        """
        Solve linear algebra problems
        """
        try:
            expression = problem.problem_text
            steps = []
            
            if 'matrix' in expression.lower():
                return await self._solve_matrix_problem(expression, steps)
            elif 'vector' in expression.lower():
                return await self._solve_vector_problem(expression, steps)
            elif 'system' in expression.lower():
                return await self._solve_linear_system(expression, steps)
            else:
                return await self._general_linear_algebra_solve(expression, steps)
                
        except Exception as e:
            logger.error(f"Linear algebra solving error: {e}")
            return {
                'result': None,
                'method': 'linear_algebra_solve',
                'steps': [f"Error in linear algebra solving: {str(e)}"],
                'success': False,
                'error': str(e)
            }
    
    def _clean_mathematical_notation(self, expression: str) -> str:
        """
        Clean and standardize mathematical notation
        """
        # Replace common mathematical symbols
        replacements = {
            '×': '*',
            '÷': '/',
            '²': '**2',
            '³': '**3',
            '√': 'sqrt',
            'π': 'pi',
            '∞': 'oo'
        }
        
        cleaned = expression
        for old, new in replacements.items():
            cleaned = cleaned.replace(old, new)
        
        return cleaned
    
    async def _verify_solution(self, problem: MathProblem, solution_data: Dict[str, Any]) -> bool:
        """
        Verify the correctness of a mathematical solution
        """
        try:
            if not solution_data.get('success', False):
                return False
            
            result = solution_data.get('result')
            if not result:
                return False
            
            # Different verification methods based on problem type
            if problem.problem_type == 'algebra':
                return await self._verify_algebraic_solution(problem, result)
            elif problem.problem_type == 'calculus':
                return await self._verify_calculus_solution(problem, result)
            else:
                return True  # Default to true for other types
                
        except Exception as e:
            logger.error(f"Solution verification error: {e}")
            return False
    
    async def _verify_algebraic_solution(self, problem: MathProblem, result: Dict[str, Any]) -> bool:
        """
        Verify algebraic solution by substitution
        """
        try:
            if result.get('type') == 'equation_solution':
                # Substitute solution back into original equation
                solutions = result.get('symbolic_solutions', [])
                if not solutions:
                    return False
                
                # This is a simplified verification
                # In practice, you'd substitute back into the original equation
                return len(solutions) > 0
            
            return True
            
        except Exception as e:
            logger.error(f"Algebraic verification error: {e}")
            return False
    
    async def _verify_calculus_solution(self, problem: MathProblem, result: Dict[str, Any]) -> bool:
        """
        Verify calculus solution
        """
        try:
            # For derivatives, verify by differentiating the result
            # For integrals, verify by differentiating the integral
            # This is a simplified verification
            return result.get('symbolic_result') is not None
            
        except Exception as e:
            logger.error(f"Calculus verification error: {e}")
            return False
    
    def _calculate_solution_confidence(
        self,
        problem: MathProblem,
        solution_data: Dict[str, Any],
        verification: bool
    ) -> float:
        """
        Calculate confidence score for the solution
        """
        confidence = 0.5  # Base confidence
        
        # Increase confidence if verification passed
        if verification:
            confidence += 0.3
        
        # Increase confidence if solution method is symbolic
        if solution_data.get('method', '').startswith('symbolic'):
            confidence += 0.2
        
        # Increase confidence if no errors occurred
        if solution_data.get('success', False):
            confidence += 0.2
        
        # Decrease confidence if there were fallbacks
        if 'error' in solution_data:
            confidence -= 0.3
        
        return min(1.0, max(0.0, confidence))
    
    async def _generate_visualization(
        self,
        problem: MathProblem,
        solution_data: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Generate visualization data for mathematical solutions
        """
        try:
            if problem.problem_type in ['algebra', 'calculus']:
                return await self._generate_function_plot_data(problem, solution_data)
            elif problem.problem_type == 'geometry':
                return await self._generate_geometry_visualization(problem, solution_data)
            elif problem.problem_type == 'statistics':
                return await self._generate_statistics_visualization(problem, solution_data)
            
            return None
            
        except Exception as e:
            logger.error(f"Visualization generation error: {e}")
            return None
    
    async def _generate_function_plot_data(
        self,
        problem: MathProblem,
        solution_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate plot data for functions
        """
        try:
            result = solution_data.get('result', {})
            
            if 'original_function' in result:
                # Generate plot points for the function
                x_values = np.linspace(-10, 10, 100)
                
                # This is a simplified example
                # In practice, you'd evaluate the symbolic function
                return {
                    'type': 'function_plot',
                    'x_values': x_values.tolist(),
                    'function_data': {
                        'original': result.get('original_function'),
                        'derivative': result.get('derivative'),
                        'integral': result.get('integral')
                    },
                    'plot_range': [-10, 10]
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Function plot generation error: {e}")
            return None
    
    async def _integrate_math_solution(
        self,
        response: str,
        solution: MathSolution,
        problem: MathProblem
    ) -> str:
        """
        Integrate mathematical solution into the response
        """
        try:
            if not solution.solution.get('success', False):
                # Handle failed solutions
                addition = f"\n\n❌ **Mathematical Solution Error:**\n"
                addition += f"Problem: {problem.problem_text}\n"
                addition += f"Error: {solution.solution.get('error', 'Unknown error')}"
                return response + addition
            
            # Format successful solution
            result = solution.solution.get('result', {})
            
            addition = f"\n\n🧮 **Mathematical Solution:**\n"
            addition += f"**Problem:** {problem.problem_text}\n"
            addition += f"**Type:** {problem.problem_type.title()}\n"
            
            if solution.steps:
                addition += f"**Solution Steps:**\n"
                for i, step in enumerate(solution.steps, 1):
                    addition += f"{i}. {step}\n"
            
            # Add result based on type
            if result.get('type') == 'equation_solution':
                solutions = result.get('solutions', [])
                addition += f"**Solutions:** {', '.join(solutions)}\n"
            elif result.get('type') == 'derivative':
                addition += f"**Derivative:** {result.get('derivative')}\n"
            elif result.get('type') == 'indefinite_integral':
                addition += f"**Integral:** {result.get('integral')} + C\n"
            elif result.get('type') == 'definite_integral':
                addition += f"**Definite Integral:** {result.get('definite_integral')}\n"
            
            addition += f"**Verification:** {'✅ Verified' if solution.verification else '⚠️ Unverified'}\n"
            addition += f"**Confidence:** {solution.confidence:.1%}"
            
            return response + addition
            
        except Exception as e:
            logger.error(f"Math solution integration error: {e}")
            return response
    
    async def _update_solution_history(
        self,
        conversation_id: str,
        solutions: List[MathSolution]
    ):
        """
        Update mathematical solution history
        """
        try:
            for solution in solutions:
                self.solution_history.append({
                    'timestamp': datetime.now().isoformat(),
                    'conversation_id': conversation_id,
                    'problem_type': solution.problem.problem_type,
                    'problem_text': solution.problem.problem_text,
                    'solution_summary': str(solution.solution.get('result', {}))[:200],
                    'verified': solution.verification,
                    'confidence': solution.confidence
                })
            
            # Keep only last 100 solutions
            if len(self.solution_history) > 100:
                self.solution_history = self.solution_history[-100:]
                
        except Exception as e:
            logger.error(f"Solution history update error: {e}")
    
    def _assess_computational_complexity(self, problems: List[MathProblem]) -> str:
        """
        Assess computational complexity of mathematical problems
        """
        try:
            if not problems:
                return 'none'
            
            complexity_scores = {
                'arithmetic': 1,
                'algebra': 2,
                'geometry': 2,
                'statistics': 3,
                'calculus': 4,
                'linear_algebra': 4,
                'number_theory': 3
            }
            
            max_complexity = max(
                complexity_scores.get(p.problem_type, 1) for p in problems
            )
            
            if max_complexity <= 1:
                return 'low'
            elif max_complexity <= 2:
                return 'medium'
            elif max_complexity <= 3:
                return 'high'
            else:
                return 'very_high'
                
        except Exception:
            return 'unknown'
    
    def _calculate_quality_score(self, solutions: List[MathSolution]) -> float:
        """
        Calculate overall quality score for mathematical solutions
        """
        if not solutions:
            return 0.7
        
        # Average confidence of all solutions
        avg_confidence = np.mean([s.confidence for s in solutions])
        
        # Success rate
        success_rate = len([s for s in solutions if s.solution.get('success', False)]) / len(solutions)
        
        # Verification rate
        verification_rate = len([s for s in solutions if s.verification]) / len(solutions)
        
        # Combined score
        quality_score = (avg_confidence * 0.4 + success_rate * 0.3 + verification_rate * 0.3)
        
        return min(1.0, max(0.0, quality_score))
    
    # Placeholder methods for other math problem types
    async def _solve_statistics_problem(self, problem: MathProblem) -> Dict[str, Any]:
        """Solve statistics problems"""
        return {
            'result': {'type': 'statistics', 'message': 'Statistics solving not fully implemented'},
            'method': 'statistical_analysis',
            'steps': ['Statistics problem detected'],
            'success': False
        }
    
    async def _solve_geometry_problem(self, problem: MathProblem) -> Dict[str, Any]:
        """Solve geometry problems"""
        return {
            'result': {'type': 'geometry', 'message': 'Geometry solving not fully implemented'},
            'method': 'geometric_calculation',
            'steps': ['Geometry problem detected'],
            'success': False
        }
    
    async def _solve_number_theory_problem(self, problem: MathProblem) -> Dict[str, Any]:
        """Solve number theory problems"""
        return {
            'result': {'type': 'number_theory', 'message': 'Number theory solving not fully implemented'},
            'method': 'number_theoretic',
            'steps': ['Number theory problem detected'],
            'success': False
        }
    
    async def _solve_general_problem(self, problem: MathProblem) -> Dict[str, Any]:
        """Solve general mathematical problems"""
        return {
            'result': {'type': 'general', 'message': 'General problem solving not fully implemented'},
            'method': 'general_solve',
            'steps': ['General math problem detected'],
            'success': False
        }
    
    async def _solve_numerical_fallback(self, problem: MathProblem, error_msg: str) -> Dict[str, Any]:
        """Fallback to numerical methods when symbolic fails"""
        return {
            'result': {'type': 'numerical_fallback', 'message': f'Symbolic failed: {error_msg}'},
            'method': 'numerical_fallback',
            'steps': [f'Symbolic processing failed: {error_msg}', 'Attempting numerical approach'],
            'success': False
        }
    
    async def _general_calculus_solve(self, expression: str, steps: List[str]) -> Dict[str, Any]:
        """General calculus problem solving"""
        return {
            'result': {'type': 'general_calculus', 'message': 'General calculus solving not fully implemented'},
            'method': 'general_calculus',
            'steps': steps + ['General calculus problem detected'],
            'success': False
        }
    
    async def _solve_matrix_problem(self, expression: str, steps: List[str]) -> Dict[str, Any]:
        """Solve matrix problems"""
        return {
            'result': {'type': 'matrix', 'message': 'Matrix solving not fully implemented'},
            'method': 'matrix_operations',
            'steps': steps + ['Matrix problem detected'],
            'success': False
        }
    
    async def _solve_vector_problem(self, expression: str, steps: List[str]) -> Dict[str, Any]:
        """Solve vector problems"""
        return {
            'result': {'type': 'vector', 'message': 'Vector solving not fully implemented'},
            'method': 'vector_operations',
            'steps': steps + ['Vector problem detected'],
            'success': False
        }
    
    async def _solve_linear_system(self, expression: str, steps: List[str]) -> Dict[str, Any]:
        """Solve linear systems"""
        return {
            'result': {'type': 'linear_system', 'message': 'Linear system solving not fully implemented'},
            'method': 'linear_system_solve',
            'steps': steps + ['Linear system detected'],
            'success': False
        }
    
    async def _general_linear_algebra_solve(self, expression: str, steps: List[str]) -> Dict[str, Any]:
        """General linear algebra solving"""
        return {
            'result': {'type': 'general_linear_algebra', 'message': 'General linear algebra not fully implemented'},
            'method': 'general_linear_algebra',
            'steps': steps + ['Linear algebra problem detected'],
            'success': False
        }
    
    async def _generate_geometry_visualization(self, problem: MathProblem, solution_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate geometry visualization"""
        return {
            'type': 'geometry_visualization',
            'message': 'Geometry visualization not implemented'
        }
    
    async def _generate_statistics_visualization(self, problem: MathProblem, solution_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate statistics visualization"""
        return {
            'type': 'statistics_visualization',
            'message': 'Statistics visualization not implemented'
        }


# Agent registry entry
def create_math_solver_agent():
    """Factory function to create MathSolverAgent instance"""
    return MathSolverAgent()
