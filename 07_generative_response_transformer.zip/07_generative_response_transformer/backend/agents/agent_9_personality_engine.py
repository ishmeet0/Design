# 🎭 Add personality, emotion, voice

from .base_agent import BaseAgent
from typing import Dict, Any

class PersonalityEngineAgent(BaseAgent):
    """Agent 9: Add personality, emotion, voice"""
    
    def __init__(self):
        super().__init__(
            name="PersonalityEngineAgent",
            description="Add personality, emotion, voice"
        )
        self.personality_traits = {
            'helpful': True,
            'professional': True,
            'curious': True,
            'empathetic': True
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        intent_data = pipeline_data.get('stage_results', {}).get(3, {}).get('metadata', {})
        
        self._log_processing(current_response)
        
        # Add personality and emotional intelligence
        personality_enhanced = self._add_personality(current_response, intent_data)
        
        return self._create_result(
            output=personality_enhanced,
            metadata={
                'personality_applied': True,
                'personality_traits': self.personality_traits,
                'emotional_tone': self._detect_emotional_tone(intent_data)
            }
        )
    
    def _add_personality(self, text: str, intent_data: Dict[str, Any]) -> str:
        """Add personality traits to the response"""
        user_intent = intent_data.get('user_intent', 'general')
        
        # Adjust response based on personality traits and user intent
        if user_intent == 'greeting':
            return self._add_friendly_personality(text)
        elif user_intent == 'question':
            return self._add_helpful_personality(text)
        elif user_intent == 'creation':
            return self._add_creative_personality(text)
        else:
            return self._add_professional_personality(text)
    
    def _add_friendly_personality(self, text: str) -> str:
        """Add friendly, welcoming personality"""
        if not text.endswith('!'):
            text = text.rstrip('.') + '!'
        return text
    
    def _add_helpful_personality(self, text: str) -> str:
        """Add helpful, knowledgeable personality"""
        return text + " I'm here to provide detailed explanations and guide you through any complexities."
    
    def _add_creative_personality(self, text: str) -> str:
        """Add creative, innovative personality"""
        return text + " Let's explore creative possibilities together!"
    
    def _add_professional_personality(self, text: str) -> str:
        """Add professional, reliable personality"""
        return text + " How can I further assist you?"
    
    def _detect_emotional_tone(self, intent_data: Dict[str, Any]) -> str:
        """Detect appropriate emotional tone"""
        user_intent = intent_data.get('user_intent', 'general')
        
        tone_mapping = {
            'greeting': 'warm',
            'question': 'supportive',
            'creation': 'enthusiastic',
            'assistance': 'helpful',
            'general': 'professional'
        }
        
        return tone_mapping.get(user_intent, 'neutral')