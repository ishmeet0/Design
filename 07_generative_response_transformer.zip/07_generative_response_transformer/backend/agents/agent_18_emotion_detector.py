# ❤️ Detects sentiment/emotions

from .base_agent import BaseAgent
from typing import Dict, Any

class EmotionDetectorAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="EmotionDetectorAgent", description="Detects sentiment/emotions")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        user_input = pipeline_data.get('user_input', '')
        self._log_processing(current_response)
        
        emotion_analysis = self._analyze_emotions(user_input, current_response)
        
        return self._create_result(
            output=current_response,
            metadata={'emotion_analysis': emotion_analysis}
        )
    
    def _analyze_emotions(self, user_input: str, response: str) -> Dict[str, Any]:
        return {
            'user_sentiment': self._detect_sentiment(user_input),
            'response_tone': self._detect_sentiment(response)
        }
    
    def _detect_sentiment(self, text: str) -> str:
        positive_words = ['happy', 'good', 'great', 'excellent', 'wonderful']
        negative_words = ['sad', 'bad', 'terrible', 'awful', 'horrible']
        
        text_lower = text.lower()
        if any(word in text_lower for word in positive_words):
            return 'positive'
        elif any(word in text_lower for word in negative_words):
            return 'negative'
        return 'neutral'