# 🧠 Advanced multi-layered reasoning engine with logical analysis and cognitive processing

from .base_agent import BaseAgent
from typing import Dict, Any, List, Tuple, Optional
import re
import json
from datetime import datetime
from dataclasses import dataclass, field

@dataclass
class ReasoningChain:
    """Represents a chain of reasoning steps"""
    premise: str
    steps: List[str] = field(default_factory=list)
    conclusion: str = ""
    confidence: float = 0.0
    reasoning_type: str = "unknown"
    logical_validity: str = "unknown"

@dataclass
class CognitiveAnalysis:
    """Comprehensive cognitive analysis results"""
    complexity_level: str = "medium"
    cognitive_load: float = 0.5
    required_knowledge_domains: List[str] = field(default_factory=list)
    reasoning_patterns: List[str] = field(default_factory=list)
    fallacies_detected: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)

class ThinkingAgent(BaseAgent):
    """Agent 2: Advanced multi-layered reasoning with cognitive analysis"""
    
    def __init__(self):
        super().__init__(
            name="ThinkingAgent",
            description="Advanced logical reasoning with cognitive analysis and multi-step thinking",
            priority=9
        )
        
        # Advanced reasoning patterns
        self.logical_indicators = {
            'deductive': [
                r'\b(all|every|if.*then|premise|major premise|minor premise)\b',
                r'\b(syllogism|therefore|hence|thus|consequently)\b'
            ],
            'inductive': [
                r'\b(most|many|some|usually|typically|generally|often)\b',
                r'\b(pattern|trend|observation|evidence suggests|likely)\b'
            ],
            'abductive': [
                r'\b(best explanation|most likely|probably|hypothesis|theory)\b',
                r'\b(inference to|explain|account for|reason why)\b'
            ],
            'causal': [
                r'\b(because|since|due to|caused by|results in|leads to)\b',
                r'\b(consequence|effect|impact|influence|factor)\b'
            ],
            'analogical': [
                r'\b(like|similar to|analogous|comparable|just as|in the same way)\b',
                r'\b(metaphor|parallel|correspondence|resembles)\b'
            ]
        }
        
        self.cognitive_complexity_indicators = {
            'high': [
                r'\b(paradox|contradiction|complex|intricate|sophisticated)\b',
                r'\b(multiple factors|various aspects|several dimensions)\b',
                r'\b(abstract|theoretical|conceptual|philosophical)\b'
            ],
            'medium': [
                r'\b(analyze|consider|examine|evaluate|assess)\b',
                r'\b(relationship|connection|correlation|dependency)\b'
            ],
            'low': [
                r'\b(simple|basic|straightforward|obvious|clear)\b',
                r'\b(direct|immediate|apparent|evident)\b'
            ]
        }
        
        self.logical_fallacies = {
            'ad_hominem': [r'\b(attack.*person|stupid|idiot|moron)\b'],
            'straw_man': [r'\b(you claim|you say.*but|misrepresent)\b'],
            'false_dichotomy': [r'\b(either.*or|only two|black and white)\b'],
            'circular_reasoning': [r'\b(because.*because|definition.*definition)\b'],
            'hasty_generalization': [r'\b(all.*are|everyone.*is|always.*never)\b'],
            'appeal_to_authority': [r'\b(expert says|authority|famous person)\b'],
            'appeal_to_emotion': [r'\b(terrible|wonderful|disgusting|beautiful)\s+therefore\b'],
            'slippery_slope': [r'\b(if.*then.*then.*then|leads to.*leads to)\b']
        }
        
        self.knowledge_domains = {
            'mathematics': [r'\b(equation|formula|calculate|number|statistic)\b'],
            'science': [r'\b(hypothesis|experiment|theory|research|study)\b'],
            'technology': [r'\b(algorithm|software|computer|digital|AI)\b'],
            'philosophy': [r'\b(ethics|morality|existence|consciousness|truth)\b'],
            'psychology': [r'\b(behavior|mind|cognitive|emotion|mental)\b'],
            'economics': [r'\b(market|price|cost|benefit|economic)\b'],
            'history': [r'\b(historical|past|ancient|century|era)\b'],
            'literature': [r'\b(story|narrative|character|plot|theme)\b'],
            'art': [r'\b(aesthetic|beauty|creative|artistic|design)\b'],
            'law': [r'\b(legal|court|judge|rights|law)\b']
        }
    
    def _define_capabilities(self) -> List[str]:
        """Define advanced reasoning capabilities"""
        return [
            'logical_reasoning', 'cognitive_analysis', 'pattern_recognition',
            'argument_structure', 'fallacy_detection', 'reasoning_validation',
            'multi_step_thinking', 'complexity_assessment', 'knowledge_mapping'
        ]
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Advanced multi-layered reasoning process"""
        current_input = pipeline_data.get('current_response', '')
        user_input = pipeline_data.get('user_input', '')
        
        self._log_processing(current_input)
        
        # Stage 1: Initial logical structure analysis
        logical_structure = self._analyze_logical_structure(current_input)
        
        # Stage 2: Reasoning pattern identification
        reasoning_patterns = self._identify_reasoning_patterns(current_input)
        
        # Stage 3: Multi-step reasoning chain construction
        reasoning_chains = self._construct_reasoning_chains(current_input)
        
        # Stage 4: Cognitive complexity assessment
        cognitive_analysis = self._assess_cognitive_complexity(current_input)
        
        # Stage 5: Logical fallacy detection
        fallacy_analysis = self._detect_logical_fallacies(current_input)
        
        # Stage 6: Knowledge domain mapping
        knowledge_domains = self._map_knowledge_domains(current_input)
        
        # Stage 7: Reasoning validation and confidence scoring
        reasoning_validation = self._validate_reasoning(reasoning_chains, fallacy_analysis)
        
        # Stage 8: Generate thinking output with enhanced reasoning
        enhanced_output = self._generate_enhanced_reasoning_output(
            current_input, logical_structure, reasoning_patterns, 
            reasoning_chains, cognitive_analysis
        )
        
        comprehensive_metadata = {
            'processing_stage': 'logical_reasoning',
            'reasoning_timestamp': datetime.now().isoformat(),
            'input_analysis': {
                'logical_structure': logical_structure,
                'reasoning_patterns': reasoning_patterns,
                'cognitive_analysis': cognitive_analysis.__dict__,
                'knowledge_domains': knowledge_domains
            },
            'reasoning_chains': [chain.__dict__ for chain in reasoning_chains],
            'fallacy_analysis': fallacy_analysis,
            'reasoning_validation': reasoning_validation,
            'thinking_enhancement': {
                'original_complexity': cognitive_analysis.complexity_level,
                'enhanced_reasoning_applied': True,
                'logical_steps_added': len(reasoning_chains),
                'fallacies_corrected': len([f for f in fallacy_analysis.values() if f['detected']])
            }
        }
        
        return self._create_result(
            output=enhanced_output,
            metadata=comprehensive_metadata
        )
    
    def _analyze_logical_structure(self, text: str) -> Dict[str, Any]:
        """Comprehensive logical structure analysis"""
        text_lower = text.lower()
        
        # Identify structural components
        premises = re.findall(r'(?:premise|given|assume|suppose|if).*?(?:\.|;|,|\n)', text_lower)
        conclusions = re.findall(r'(?:therefore|thus|hence|so|conclude).*?(?:\.|;|,|\n)', text_lower)
        evidence = re.findall(r'(?:evidence|proof|data|research shows).*?(?:\.|;|,|\n)', text_lower)
        
        # Logical connectors analysis
        connectors = {
            'causal': len(re.findall(r'\b(because|since|due to|caused by|results in)\b', text_lower)),
            'conditional': len(re.findall(r'\b(if|when|unless|provided that|assuming)\b', text_lower)),
            'comparative': len(re.findall(r'\b(than|compared to|relative to|versus)\b', text_lower)),
            'additive': len(re.findall(r'\b(and|also|furthermore|moreover|additionally)\b', text_lower)),
            'contrastive': len(re.findall(r'\b(but|however|although|despite|nevertheless)\b', text_lower))
        }
        
        # Determine argument structure
        structure_type = self._determine_argument_structure(premises, conclusions, evidence, connectors)
        
        return {
            'premises_count': len(premises),
            'conclusions_count': len(conclusions),
            'evidence_count': len(evidence),
            'logical_connectors': connectors,
            'structure_type': structure_type,
            'argument_complexity': sum(connectors.values()),
            'has_complete_argument': len(premises) > 0 and len(conclusions) > 0,
            'reasoning_density': (len(premises) + len(conclusions) + len(evidence)) / max(1, len(text.split()))
        }
    
    def _identify_reasoning_patterns(self, text: str) -> Dict[str, Any]:
        """Identify various reasoning patterns in the text"""
        text_lower = text.lower()
        patterns_found = {}
        
        for pattern_type, indicators in self.logical_indicators.items():
            pattern_score = 0
            matches = []
            
            for indicator_pattern in indicators:
                pattern_matches = re.findall(indicator_pattern, text_lower, re.IGNORECASE)
                matches.extend(pattern_matches)
                pattern_score += len(pattern_matches)
            
            patterns_found[pattern_type] = {
                'score': pattern_score,
                'matches': matches,
                'confidence': min(1.0, pattern_score / max(1, len(text.split()) * 0.05))
            }
        
        # Determine dominant reasoning pattern
        dominant_pattern = max(patterns_found, key=lambda x: patterns_found[x]['score'])
        
        return {
            'all_patterns': patterns_found,
            'dominant_pattern': dominant_pattern,
            'pattern_diversity': len([p for p in patterns_found.values() if p['score'] > 0]),
            'mixed_reasoning': len([p for p in patterns_found.values() if p['confidence'] > 0.3]) > 1
        }
    
    def _construct_reasoning_chains(self, text: str) -> List[ReasoningChain]:
        """Construct detailed reasoning chains from the input"""
        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        reasoning_chains = []
        
        # Simple chain construction based on sentence patterns
        for i, sentence in enumerate(sentences):
            if re.search(r'\b(if|since|because|given)\b', sentence.lower()):
                # This could be a premise
                premise = sentence
                steps = []
                conclusion = ""
                
                # Look for following sentences that could be steps or conclusion
                for j in range(i + 1, min(i + 4, len(sentences))):  # Look ahead max 3 sentences
                    next_sentence = sentences[j]
                    if re.search(r'\b(therefore|thus|so|hence)\b', next_sentence.lower()):
                        conclusion = next_sentence
                        break
                    else:
                        steps.append(next_sentence)
                
                if steps or conclusion:
                    reasoning_type = self._classify_reasoning_type(premise, steps, conclusion)
                    confidence = self._calculate_chain_confidence(premise, steps, conclusion)
                    
                    chain = ReasoningChain(
                        premise=premise,
                        steps=steps,
                        conclusion=conclusion,
                        confidence=confidence,
                        reasoning_type=reasoning_type,
                        logical_validity=self._assess_logical_validity(premise, steps, conclusion)
                    )
                    reasoning_chains.append(chain)
        
        return reasoning_chains
    
    def _assess_cognitive_complexity(self, text: str) -> CognitiveAnalysis:
        """Comprehensive cognitive complexity assessment"""
        text_lower = text.lower()
        
        # Complexity level assessment
        complexity_scores = {}
        for level, indicators in self.cognitive_complexity_indicators.items():
            score = 0
            for pattern in indicators:
                score += len(re.findall(pattern, text_lower, re.IGNORECASE))
            complexity_scores[level] = score
        
        complexity_level = max(complexity_scores, key=complexity_scores.get) if any(complexity_scores.values()) else "medium"
        
        # Cognitive load calculation
        factors = [
            len(re.findall(r'\b(complex|difficult|challenging|intricate)\b', text_lower)) * 0.2,
            len(re.findall(r'\b(multiple|various|several|many)\b', text_lower)) * 0.1,
            len(text.split()) / 100,  # Word count factor
            len(re.findall(r'[(),;:]', text)) / 20,  # Punctuation complexity
        ]
        cognitive_load = min(1.0, sum(factors))
        
        # Required knowledge domains
        required_domains = []
        for domain, patterns in self.knowledge_domains.items():
            for pattern in patterns:
                if re.search(pattern, text_lower, re.IGNORECASE):
                    required_domains.append(domain)
                    break
        
        # Reasoning patterns
        reasoning_patterns = []
        for pattern_type, indicators in self.logical_indicators.items():
            for indicator in indicators:
                if re.search(indicator, text_lower, re.IGNORECASE):
                    reasoning_patterns.append(pattern_type)
                    break
        
        return CognitiveAnalysis(
            complexity_level=complexity_level,
            cognitive_load=cognitive_load,
            required_knowledge_domains=list(set(required_domains)),
            reasoning_patterns=list(set(reasoning_patterns)),
            fallacies_detected=[],  # Will be filled by fallacy detection
            suggestions=self._generate_reasoning_suggestions(complexity_level, cognitive_load, required_domains)
        )
    
    def _detect_logical_fallacies(self, text: str) -> Dict[str, Any]:
        """Detect logical fallacies in the reasoning"""
        text_lower = text.lower()
        detected_fallacies = {}
        
        for fallacy_type, patterns in self.logical_fallacies.items():
            matches = []
            for pattern in patterns:
                pattern_matches = re.findall(pattern, text_lower, re.IGNORECASE)
                matches.extend(pattern_matches)
            
            detected_fallacies[fallacy_type] = {
                'detected': len(matches) > 0,
                'matches': matches,
                'count': len(matches),
                'severity': 'high' if len(matches) > 2 else 'medium' if len(matches) > 0 else 'none'
            }
        
        total_fallacies = sum(1 for f in detected_fallacies.values() if f['detected'])
        fallacy_score = max(0.0, 1.0 - (total_fallacies * 0.2))
        
        return {
            'fallacies': detected_fallacies,
            'total_fallacies': total_fallacies,
            'logical_soundness_score': fallacy_score,
            'requires_correction': total_fallacies > 0,
            'critical_issues': [name for name, data in detected_fallacies.items() if data['severity'] == 'high']
        }
    
    def _map_knowledge_domains(self, text: str) -> Dict[str, Any]:
        """Map the knowledge domains referenced in the text"""
        text_lower = text.lower()
        domain_analysis = {}
        
        for domain, patterns in self.knowledge_domains.items():
            matches = []
            score = 0
            
            for pattern in patterns:
                pattern_matches = re.findall(pattern, text_lower, re.IGNORECASE)
                matches.extend(pattern_matches)
                score += len(pattern_matches)
            
            domain_analysis[domain] = {
                'relevance_score': score,
                'matches': matches,
                'is_relevant': score > 0,
                'confidence': min(1.0, score / max(1, len(text.split()) * 0.1))
            }
        
        relevant_domains = [domain for domain, data in domain_analysis.items() if data['is_relevant']]
        primary_domain = max(domain_analysis, key=lambda x: domain_analysis[x]['relevance_score']) if relevant_domains else None
        
        return {
            'all_domains': domain_analysis,
            'relevant_domains': relevant_domains,
            'primary_domain': primary_domain,
            'interdisciplinary': len(relevant_domains) > 2,
            'domain_complexity': len(relevant_domains)
        }
    
    def _validate_reasoning(self, reasoning_chains: List[ReasoningChain], fallacy_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Validate the overall reasoning quality"""
        if not reasoning_chains:
            return {
                'overall_validity': 'insufficient_reasoning',
                'confidence_score': 0.0,
                'recommendations': ['Add more explicit reasoning steps', 'Provide clearer logical connections']
            }
        
        # Calculate average confidence across chains
        avg_confidence = sum(chain.confidence for chain in reasoning_chains) / len(reasoning_chains)
        
        # Factor in fallacy analysis
        fallacy_penalty = 1.0 - (fallacy_analysis['total_fallacies'] * 0.1)
        
        # Calculate overall validity score
        validity_score = (avg_confidence * 0.7 + fallacy_penalty * 0.3)
        
        validity_level = (
            'high' if validity_score > 0.8 else
            'medium' if validity_score > 0.6 else
            'low' if validity_score > 0.3 else
            'poor'
        )
        
        recommendations = []
        if validity_score < 0.6:
            recommendations.append('Strengthen logical connections between ideas')
        if fallacy_analysis['total_fallacies'] > 0:
            recommendations.append('Address identified logical fallacies')
        if avg_confidence < 0.5:
            recommendations.append('Provide more supporting evidence')
        
        return {
            'overall_validity': validity_level,
            'confidence_score': validity_score,
            'average_chain_confidence': avg_confidence,
            'logical_soundness': fallacy_analysis['logical_soundness_score'],
            'recommendations': recommendations
        }
    
    def _generate_enhanced_reasoning_output(self, original_input: str, logical_structure: Dict[str, Any], 
                                          reasoning_patterns: Dict[str, Any], reasoning_chains: List[ReasoningChain],
                                          cognitive_analysis: CognitiveAnalysis) -> str:
        """Generate enhanced output with improved reasoning"""
        # For now, return the original input with some reasoning enhancement indicators
        # In a full implementation, this would add logical structure and reasoning steps
        
        enhanced_sections = []
        
        # Add reasoning clarity if needed
        if logical_structure['reasoning_density'] < 0.1:
            enhanced_sections.append("Logical analysis: This input could benefit from more explicit reasoning steps.")
        
        # Add pattern recognition insights
        if reasoning_patterns['dominant_pattern'] != 'unknown':
            enhanced_sections.append(f"Reasoning pattern detected: {reasoning_patterns['dominant_pattern']}")
        
        # Add complexity assessment
        if cognitive_analysis.complexity_level == 'high':
            enhanced_sections.append("High cognitive complexity detected - multiple factors and abstract concepts involved.")
        
        # Combine original input with enhancements
        if enhanced_sections:
            return original_input + "\n\n[Reasoning Analysis: " + " | ".join(enhanced_sections) + "]"
        else:
            return original_input
    
    # Helper methods
    def _determine_argument_structure(self, premises: List[str], conclusions: List[str], 
                                    evidence: List[str], connectors: Dict[str, int]) -> str:
        """Determine the type of argument structure"""
        if premises and conclusions and connectors['causal'] > 0:
            return 'causal_argument'
        elif premises and conclusions:
            return 'deductive_argument'
        elif evidence and conclusions:
            return 'inductive_argument'
        elif connectors['conditional'] > 0:
            return 'conditional_reasoning'
        elif connectors['comparative'] > 0:
            return 'comparative_analysis'
        else:
            return 'descriptive_text'
    
    def _classify_reasoning_type(self, premise: str, steps: List[str], conclusion: str) -> str:
        """Classify the type of reasoning in a chain"""
        combined_text = (premise + " " + " ".join(steps) + " " + conclusion).lower()
        
        if re.search(r'\b(all|every|always)\b', combined_text):
            return 'deductive'
        elif re.search(r'\b(most|many|usually)\b', combined_text):
            return 'inductive'
        elif re.search(r'\b(best explanation|most likely)\b', combined_text):
            return 'abductive'
        elif re.search(r'\b(because|since|due to)\b', combined_text):
            return 'causal'
        else:
            return 'general'
    
    def _calculate_chain_confidence(self, premise: str, steps: List[str], conclusion: str) -> float:
        """Calculate confidence score for a reasoning chain"""
        factors = []
        
        # Length and detail factor
        total_length = len(premise) + sum(len(step) for step in steps) + len(conclusion)
        length_factor = min(1.0, total_length / 200)  # Normalize to 200 chars
        factors.append(length_factor * 0.3)
        
        # Logical connector factor
        combined_text = (premise + " " + " ".join(steps) + " " + conclusion).lower()
        connectors = len(re.findall(r'\b(because|therefore|since|thus|hence|so)\b', combined_text))
        connector_factor = min(1.0, connectors / 3)  # Normalize to 3 connectors
        factors.append(connector_factor * 0.4)
        
        # Evidence factor
        evidence_indicators = len(re.findall(r'\b(evidence|data|research|study|proof)\b', combined_text))
        evidence_factor = min(1.0, evidence_indicators / 2)
        factors.append(evidence_factor * 0.3)
        
        return sum(factors)
    
    def _assess_logical_validity(self, premise: str, steps: List[str], conclusion: str) -> str:
        """Assess the logical validity of a reasoning chain"""
        combined_text = (premise + " " + " ".join(steps) + " " + conclusion).lower()
        
        # Check for basic logical structure
        has_proper_flow = bool(re.search(r'\b(if|since|because).*\b(then|therefore|thus|so)\b', combined_text))
        has_evidence = bool(re.search(r'\b(evidence|proof|data|research)\b', combined_text))
        has_clear_conclusion = len(conclusion.strip()) > 10
        
        validity_score = sum([has_proper_flow, has_evidence, has_clear_conclusion])
        
        return 'high' if validity_score >= 2 else 'medium' if validity_score == 1 else 'low'
    
    def _generate_reasoning_suggestions(self, complexity_level: str, cognitive_load: float, 
                                      required_domains: List[str]) -> List[str]:
        """Generate suggestions for improving reasoning"""
        suggestions = []
        
        if complexity_level == 'high':
            suggestions.append('Break down complex concepts into simpler components')
            suggestions.append('Use clear logical connectors to show relationships')
        
        if cognitive_load > 0.7:
            suggestions.append('Reduce cognitive load by focusing on key points')
            suggestions.append('Use examples to illustrate abstract concepts')
        
        if len(required_domains) > 3:
            suggestions.append('Consider focusing on fewer knowledge domains for clarity')
        
        if not required_domains:
            suggestions.append('Ground reasoning in specific knowledge domains')
        
        return suggestions