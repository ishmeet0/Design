# 📝 Handles feedback/ratings
from .base_agent import BaseAgent
from typing import Dict, Any

class FeedbackHandlerAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="FeedbackHandlerAgent", description="Handles feedback/ratings")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        return self._create_result(output=current_response, metadata={'feedback_handling': True})
# 📝 Advanced Feedback Handler - Processes user feedback and system improvement suggestions

from .base_agent import BaseAgent
from typing import Dict, Any, List, Tuple, Optional
import re
import json
import time
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict

@dataclass
class FeedbackSpecification:
    """Comprehensive feedback specification"""
    feedback_type: str = "general"  # general, bug_report, feature_request, rating, suggestion
    priority: str = "medium"  # low, medium, high, critical
    category: str = "user_experience"  # user_experience, functionality, performance, content_quality
    rating: int = 3  # 1-5 scale
    sentiment: str = "neutral"  # positive, neutral, negative
    actionable: bool = True

@dataclass
class FeedbackAnalysis:
    """Advanced feedback analysis structure"""
    sentiment_analysis: Dict[str, Any] = field(default_factory=dict)
    improvement_suggestions: List[Dict[str, Any]] = field(default_factory=list)
    priority_classification: Dict[str, Any] = field(default_factory=dict)
    response_strategy: Dict[str, Any] = field(default_factory=dict)
    learning_insights: List[Dict[str, Any]] = field(default_factory=list)
    follow_up_actions: List[Dict[str, Any]] = field(default_factory=list)

class FeedbackHandlerAgent(BaseAgent):
    """Agent 25: Advanced feedback processing with sentiment analysis and improvement tracking"""
    
    def __init__(self):
        super().__init__(
            name="FeedbackHandlerAgent",
            description="Advanced feedback processing with sentiment analysis, improvement tracking, and response generation",
            priority=8
        )
        
        # Feedback classification systems
        self.feedback_categories = {
            'user_experience': {
                'indicators': ['interface', 'design', 'usability', 'navigation', 'confusing', 'intuitive'],
                'processing_approach': 'ux_analysis',
                'priority_weight': 0.8,
                'response_type': 'empathetic_improvement'
            },
            'functionality': {
                'indicators': ['feature', 'bug', 'error', 'crash', 'not working', 'broken'],
                'processing_approach': 'technical_analysis',
                'priority_weight': 0.9,
                'response_type': 'solution_focused'
            },
            'performance': {
                'indicators': ['slow', 'fast', 'lag', 'responsive', 'speed', 'performance'],
                'processing_approach': 'performance_analysis',
                'priority_weight': 0.7,
                'response_type': 'optimization_focused'
            },
            'content_quality': {
                'indicators': ['accurate', 'helpful', 'wrong', 'misleading', 'informative'],
                'processing_approach': 'content_analysis',
                'priority_weight': 0.85,
                'response_type': 'educational_improvement'
            },
            'feature_request': {
                'indicators': ['want', 'need', 'wish', 'suggestion', 'add', 'include'],
                'processing_approach': 'innovation_analysis',
                'priority_weight': 0.6,
                'response_type': 'collaborative_exploration'
            }
        }
        
        # Sentiment analysis patterns
        self.sentiment_patterns = {
            'positive': {
                'keywords': ['love', 'great', 'amazing', 'excellent', 'perfect', 'helpful', 'awesome'],
                'phrases': ['really like', 'works well', 'very helpful', 'impressed with'],
                'intensity_modifiers': ['very', 'really', 'extremely', 'absolutely'],
                'score_range': (0.6, 1.0)
            },
            'negative': {
                'keywords': ['hate', 'terrible', 'awful', 'broken', 'useless', 'frustrated', 'disappointed'],
                'phrases': ['does not work', 'very bad', 'waste of time', 'completely broken'],
                'intensity_modifiers': ['very', 'completely', 'totally', 'extremely'],
                'score_range': (-1.0, -0.3)
            },
            'neutral': {
                'keywords': ['okay', 'fine', 'average', 'normal', 'acceptable'],
                'phrases': ['it works', 'could be better', 'not bad'],
                'intensity_modifiers': ['somewhat', 'fairly', 'reasonably'],
                'score_range': (-0.3, 0.6)
            }
        }
        
        # Response generation templates
        self.response_templates = {
            'empathetic_improvement': {
                'acknowledgment': "Thank you for sharing your experience with the interface",
                'validation': "Your feedback about usability is valuable to us",
                'action': "We're working to improve the user experience based on insights like yours",
                'follow_up': "Would you be interested in testing interface improvements?"
            },
            'solution_focused': {
                'acknowledgment': "Thank you for reporting this technical issue",
                'validation': "We understand how frustrating functionality problems can be",
                'action': "Our team is investigating this issue and working on a solution",
                'follow_up': "We'll keep you updated on the progress of this fix"
            },
            'optimization_focused': {
                'acknowledgment': "Thank you for your feedback on system performance",
                'validation': "Performance optimization is a key priority for us",
                'action': "We're continuously working to improve speed and responsiveness",
                'follow_up': "Please let us know if you notice any performance improvements"
            },
            'educational_improvement': {
                'acknowledgment': "Thank you for your feedback on content quality",
                'validation': "Accurate and helpful information is our primary goal",
                'action': "We're reviewing and improving our content based on your input",
                'follow_up': "Your expertise helps us provide better information"
            },
            'collaborative_exploration': {
                'acknowledgment': "Thank you for your feature suggestion",
                'validation': "User-driven innovation is important to our development process",
                'action': "We're evaluating how to incorporate ideas like yours",
                'follow_up': "Would you like to participate in feature design discussions?"
            }
        }

    def process(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process feedback with comprehensive analysis"""
        try:
            # Extract feedback content
            feedback_content = self._extract_feedback_content(request_data)
            
            # Create feedback specification
            feedback_spec = self._create_feedback_specification(feedback_content)
            
            # Perform comprehensive analysis
            feedback_analysis = self._analyze_feedback(feedback_content, feedback_spec)
            
            # Generate response strategy
            response_strategy = self._generate_response_strategy(feedback_analysis, feedback_spec)
            
            # Create improvement action plan
            improvement_plan = self._create_improvement_plan(feedback_analysis, feedback_spec)
            
            # Generate learning insights
            learning_insights = self._extract_learning_insights(feedback_analysis, feedback_spec)
            
            return {
                'feedback_processed': True,
                'feedback_specification': {
                    'type': feedback_spec.feedback_type,
                    'priority': feedback_spec.priority,
                    'category': feedback_spec.category,
                    'rating': feedback_spec.rating,
                    'sentiment': feedback_spec.sentiment,
                    'actionable': feedback_spec.actionable
                },
                'analysis_results': {
                    'sentiment_analysis': feedback_analysis.sentiment_analysis,
                    'priority_classification': feedback_analysis.priority_classification,
                    'improvement_suggestions': feedback_analysis.improvement_suggestions,
                    'learning_insights': feedback_analysis.learning_insights
                },
                'response_strategy': response_strategy,
                'improvement_plan': improvement_plan,
                'follow_up_actions': feedback_analysis.follow_up_actions,
                'processing_metadata': {
                    'agent': self.name,
                    'processing_time': time.time(),
                    'confidence_score': self._calculate_processing_confidence(feedback_analysis),
                    'feedback_id': f"fb_{int(time.time())}_{hash(str(feedback_content)) % 10000}"
                }
            }
            
        except Exception as e:
            return self._create_error_response(f"Feedback processing failed: {str(e)}")

    def _extract_feedback_content(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract and structure feedback content"""
        content = {
            'text': request_data.get('feedback_text', ''),
            'rating': request_data.get('rating', 0),
            'category': request_data.get('category', ''),
            'user_context': request_data.get('user_context', {}),
            'system_context': request_data.get('system_context', {}),
            'timestamp': request_data.get('timestamp', datetime.now().isoformat())
        }
        
        # Extract metadata
        content['metadata'] = {
            'user_id': request_data.get('user_id', 'anonymous'),
            'session_id': request_data.get('session_id', ''),
            'feature_used': request_data.get('feature_used', ''),
            'interaction_type': request_data.get('interaction_type', 'general')
        }
        
        return content

    def _create_feedback_specification(self, feedback_content: Dict[str, Any]) -> FeedbackSpecification:
        """Create detailed feedback specification"""
        feedback_text = feedback_content.get('text', '').lower()
        rating = feedback_content.get('rating', 3)
        
        # Classify feedback type
        feedback_type = self._classify_feedback_type(feedback_text, rating)
        
        # Determine category
        category = self._determine_category(feedback_text)
        
        # Calculate priority
        priority = self._calculate_priority(feedback_text, rating, category)
        
        # Analyze sentiment
        sentiment = self._analyze_sentiment(feedback_text, rating)
        
        # Determine if actionable
        actionable = self._is_actionable(feedback_text, category)
        
        return FeedbackSpecification(
            feedback_type=feedback_type,
            priority=priority,
            category=category,
            rating=rating,
            sentiment=sentiment,
            actionable=actionable
        )

    def _classify_feedback_type(self, feedback_text: str, rating: int) -> str:
        """Classify the type of feedback"""
        if rating <= 2:
            if any(word in feedback_text for word in ['bug', 'error', 'crash', 'broken']):
                return 'bug_report'
            else:
                return 'complaint'
        elif rating >= 4:
            if any(word in feedback_text for word in ['want', 'need', 'suggest', 'add']):
                return 'feature_request'
            else:
                return 'praise'
        else:
            if any(word in feedback_text for word in ['suggest', 'improve', 'could']):
                return 'suggestion'
            else:
                return 'general'

    def _determine_category(self, feedback_text: str) -> str:
        """Determine feedback category based on content"""
        category_scores = {}
        
        for category, info in self.feedback_categories.items():
            score = 0
            for indicator in info['indicators']:
                if indicator in feedback_text:
                    score += 1
            category_scores[category] = score * info['priority_weight']
        
        if category_scores:
            return max(category_scores, key=category_scores.get)
        else:
            return 'user_experience'

    def _calculate_priority(self, feedback_text: str, rating: int, category: str) -> str:
        """Calculate feedback priority"""
        priority_score = 0
        
        # Rating influence
        if rating <= 2:
            priority_score += 3
        elif rating == 3:
            priority_score += 1
        
        # Critical keywords
        critical_words = ['crash', 'broken', 'error', 'security', 'data loss']
        if any(word in feedback_text for word in critical_words):
            priority_score += 4
        
        # Category weight
        category_weight = self.feedback_categories.get(category, {}).get('priority_weight', 0.5)
        priority_score += category_weight * 2
        
        # Determine priority level
        if priority_score >= 4:
            return 'critical'
        elif priority_score >= 2.5:
            return 'high'
        elif priority_score >= 1:
            return 'medium'
        else:
            return 'low'

    def _analyze_sentiment(self, feedback_text: str, rating: int) -> str:
        """Analyze sentiment of feedback"""
        sentiment_scores = {'positive': 0, 'negative': 0, 'neutral': 0}
        
        for sentiment, patterns in self.sentiment_patterns.items():
            # Check keywords
            for keyword in patterns['keywords']:
                if keyword in feedback_text:
                    sentiment_scores[sentiment] += 1
            
            # Check phrases
            for phrase in patterns['phrases']:
                if phrase in feedback_text:
                    sentiment_scores[sentiment] += 2
            
            # Check intensity modifiers
            for modifier in patterns['intensity_modifiers']:
                if modifier in feedback_text:
                    sentiment_scores[sentiment] += 0.5
        
        # Rating influence
        if rating <= 2:
            sentiment_scores['negative'] += 2
        elif rating >= 4:
            sentiment_scores['positive'] += 2
        
        # Determine dominant sentiment
        if sentiment_scores['positive'] > sentiment_scores['negative'] and sentiment_scores['positive'] > sentiment_scores['neutral']:
            return 'positive'
        elif sentiment_scores['negative'] > sentiment_scores['positive'] and sentiment_scores['negative'] > sentiment_scores['neutral']:
            return 'negative'
        else:
            return 'neutral'

    def _is_actionable(self, feedback_text: str, category: str) -> bool:
        """Determine if feedback is actionable"""
        actionable_indicators = [
            'improve', 'fix', 'add', 'remove', 'change', 'update', 
            'better', 'faster', 'easier', 'clearer', 'more'
        ]
        
        non_actionable_indicators = [
            'just saying', 'by the way', 'random thought', 'no big deal'
        ]
        
        # Check for actionable indicators
        actionable_score = sum(1 for indicator in actionable_indicators if indicator in feedback_text)
        
        # Check for non-actionable indicators
        non_actionable_score = sum(1 for indicator in non_actionable_indicators if indicator in feedback_text)
        
        # Category-based actionability
        if category in ['functionality', 'performance']:
            actionable_score += 1
        
        return actionable_score > non_actionable_score

    def _analyze_feedback(self, feedback_content: Dict[str, Any], feedback_spec: FeedbackSpecification) -> FeedbackAnalysis:
        """Perform comprehensive feedback analysis"""
        feedback_text = feedback_content.get('text', '')
        
        # Sentiment analysis
        sentiment_analysis = {
            'primary_sentiment': feedback_spec.sentiment,
            'confidence': self._calculate_sentiment_confidence(feedback_text),
            'emotional_indicators': self._extract_emotional_indicators(feedback_text),
            'intensity': self._measure_sentiment_intensity(feedback_text)
        }
        
        # Priority classification
        priority_classification = {
            'calculated_priority': feedback_spec.priority,
            'urgency_factors': self._identify_urgency_factors(feedback_text),
            'impact_assessment': self._assess_impact(feedback_text, feedback_spec.category),
            'business_value': self._assess_business_value(feedback_text, feedback_spec)
        }
        
        # Improvement suggestions
        improvement_suggestions = self._generate_improvement_suggestions(feedback_text, feedback_spec)
        
        # Learning insights
        learning_insights = self._extract_learning_insights_detailed(feedback_text, feedback_spec)
        
        # Follow-up actions
        follow_up_actions = self._determine_follow_up_actions(feedback_spec)
        
        return FeedbackAnalysis(
            sentiment_analysis=sentiment_analysis,
            priority_classification=priority_classification,
            improvement_suggestions=improvement_suggestions,
            learning_insights=learning_insights,
            follow_up_actions=follow_up_actions
        )

    def _generate_response_strategy(self, analysis: FeedbackAnalysis, spec: FeedbackSpecification) -> Dict[str, Any]:
        """Generate personalized response strategy"""
        category = spec.category
        response_type = self.feedback_categories.get(category, {}).get('response_type', 'empathetic_improvement')
        template = self.response_templates.get(response_type, self.response_templates['empathetic_improvement'])
        
        return {
            'response_type': response_type,
            'tone': self._determine_response_tone(spec.sentiment, spec.priority),
            'template_elements': template,
            'personalization': {
                'acknowledge_specifics': self._extract_specific_acknowledgments(analysis),
                'show_understanding': self._generate_understanding_statements(spec),
                'provide_timeline': self._estimate_response_timeline(spec.priority),
                'offer_involvement': self._suggest_user_involvement(spec)
            },
            'response_goals': {
                'primary': self._define_primary_goal(spec),
                'secondary': self._define_secondary_goals(analysis, spec)
            }
        }

    def _create_improvement_plan(self, analysis: FeedbackAnalysis, spec: FeedbackSpecification) -> Dict[str, Any]:
        """Create actionable improvement plan"""
        return {
            'immediate_actions': self._define_immediate_actions(spec),
            'short_term_improvements': self._define_short_term_improvements(analysis, spec),
            'long_term_enhancements': self._define_long_term_enhancements(analysis),
            'success_metrics': self._define_success_metrics(spec),
            'implementation_timeline': self._create_implementation_timeline(spec.priority),
            'resource_requirements': self._assess_resource_requirements(analysis, spec),
            'stakeholder_involvement': self._identify_stakeholders(spec.category)
        }

    def _calculate_processing_confidence(self, analysis: FeedbackAnalysis) -> float:
        """Calculate confidence in feedback processing"""
        confidence_factors = [
            analysis.sentiment_analysis.get('confidence', 0.5),
            0.8 if analysis.priority_classification.get('urgency_factors') else 0.6,
            0.9 if len(analysis.improvement_suggestions) > 0 else 0.4,
            0.7 if len(analysis.learning_insights) > 0 else 0.5
        ]
        
        return sum(confidence_factors) / len(confidence_factors)

    def _extract_learning_insights(self, analysis: FeedbackAnalysis, spec: FeedbackSpecification) -> List[Dict[str, Any]]:
        """Extract learning insights for system improvement"""
        insights = []
        
        # Pattern recognition insights
        if spec.feedback_type in ['bug_report', 'complaint']:
            insights.append({
                'type': 'pattern_recognition',
                'insight': f"Recurring {spec.category} issues need systematic review",
                'action': f"Analyze patterns in {spec.category} feedback",
                'priority': 'high' if spec.priority in ['critical', 'high'] else 'medium'
            })
        
        # User behavior insights
        if spec.sentiment == 'negative' and spec.category == 'user_experience':
            insights.append({
                'type': 'user_behavior',
                'insight': "User experience challenges affecting satisfaction",
                'action': "Conduct UX analysis and usability testing",
                'priority': 'high'
            })
        
        # Feature evolution insights
        if spec.feedback_type == 'feature_request':
            insights.append({
                'type': 'feature_evolution',
                'insight': f"Users seeking enhanced {spec.category} capabilities",
                'action': f"Evaluate {spec.category} feature roadmap",
                'priority': 'medium'
            })
        
        return insights

    # Helper methods for detailed analysis
    def _calculate_sentiment_confidence(self, feedback_text: str) -> float:
        """Calculate confidence in sentiment analysis"""
        # Implementation would analyze linguistic patterns, certainty indicators, etc.
        return 0.8  # Placeholder

    def _extract_emotional_indicators(self, feedback_text: str) -> List[str]:
        """Extract emotional indicators from feedback"""
        emotional_words = []
        emotion_patterns = {
            'frustration': ['frustrated', 'annoying', 'irritating'],
            'satisfaction': ['happy', 'satisfied', 'pleased'],
            'confusion': ['confused', 'unclear', 'lost'],
            'excitement': ['excited', 'amazing', 'fantastic']
        }
        
        for emotion, words in emotion_patterns.items():
            if any(word in feedback_text for word in words):
                emotional_words.append(emotion)
        
        return emotional_words

    def _measure_sentiment_intensity(self, feedback_text: str) -> str:
        """Measure the intensity of sentiment"""
        intensity_modifiers = ['very', 'extremely', 'incredibly', 'absolutely', 'completely']
        if any(modifier in feedback_text for modifier in intensity_modifiers):
            return 'high'
        elif len(feedback_text.split('!')) > 2:
            return 'high'
        else:
            return 'moderate'

    def _identify_urgency_factors(self, feedback_text: str) -> List[str]:
        """Identify factors that indicate urgency"""
        urgency_indicators = []
        urgent_phrases = [
            'urgent', 'immediately', 'asap', 'critical', 'emergency',
            'blocking', 'cannot work', 'stopped working'
        ]
        
        for phrase in urgent_phrases:
            if phrase in feedback_text.lower():
                urgency_indicators.append(phrase)
        
        return urgency_indicators

    def _assess_impact(self, feedback_text: str, category: str) -> Dict[str, Any]:
        """Assess the potential impact of the feedback"""
        return {
            'user_impact': 'high' if category in ['functionality', 'performance'] else 'medium',
            'business_impact': self._estimate_business_impact(feedback_text),
            'technical_impact': self._estimate_technical_impact(feedback_text, category),
            'scale': self._estimate_affected_users(feedback_text)
        }

    def _assess_business_value(self, feedback_text: str, spec: FeedbackSpecification) -> str:
        """Assess business value of addressing the feedback"""
        if spec.priority == 'critical':
            return 'high'
        elif spec.feedback_type == 'feature_request' and spec.sentiment == 'positive':
            return 'medium'
        elif spec.category == 'user_experience':
            return 'high'
        else:
            return 'medium'

    def _generate_improvement_suggestions(self, feedback_text: str, spec: FeedbackSpecification) -> List[Dict[str, Any]]:
        """Generate specific improvement suggestions"""
        suggestions = []
        
        if spec.category == 'user_experience':
            suggestions.append({
                'area': 'interface_design',
                'suggestion': 'Review and simplify user interface elements',
                'priority': spec.priority,
                'estimated_effort': 'medium'
            })
        
        if spec.category == 'functionality':
            suggestions.append({
                'area': 'feature_enhancement',
                'suggestion': 'Enhance feature reliability and performance',
                'priority': spec.priority,
                'estimated_effort': 'high'
            })
        
        return suggestions

    def _extract_learning_insights_detailed(self, feedback_text: str, spec: FeedbackSpecification) -> List[Dict[str, Any]]:
        """Extract detailed learning insights"""
        insights = []
        
        # User expectation insights
        if 'expected' in feedback_text or 'thought' in feedback_text:
            insights.append({
                'type': 'expectation_mismatch',
                'description': 'User expectations not aligned with current functionality',
                'learning': 'Need to better communicate feature capabilities',
                'action': 'Improve user onboarding and documentation'
            })
        
        return insights

    def _determine_follow_up_actions(self, spec: FeedbackSpecification) -> List[Dict[str, Any]]:
        """Determine appropriate follow-up actions"""
        actions = []
        
        if spec.priority in ['critical', 'high']:
            actions.append({
                'action': 'immediate_response',
                'timeline': '24 hours',
                'responsible': 'customer_success_team'
            })
        
        if spec.feedback_type == 'feature_request':
            actions.append({
                'action': 'product_team_review',
                'timeline': '1 week',
                'responsible': 'product_management'
            })
        
        return actions

    # Response strategy helper methods
    def _determine_response_tone(self, sentiment: str, priority: str) -> str:
        """Determine appropriate response tone"""
        if sentiment == 'negative' and priority in ['critical', 'high']:
            return 'apologetic_action_oriented'
        elif sentiment == 'positive':
            return 'grateful_collaborative'
        else:
            return 'professional_helpful'

    def _extract_specific_acknowledgments(self, analysis: FeedbackAnalysis) -> List[str]:
        """Extract specific points to acknowledge in response"""
        acknowledgments = []
        
        if analysis.sentiment_analysis.get('emotional_indicators'):
            for emotion in analysis.sentiment_analysis['emotional_indicators']:
                acknowledgments.append(f"Understanding your {emotion}")
        
        return acknowledgments

    def _generate_understanding_statements(self, spec: FeedbackSpecification) -> List[str]:
        """Generate statements that show understanding"""
        statements = []
        
        if spec.category == 'performance':
            statements.append("We understand how important system responsiveness is to your productivity")
        elif spec.category == 'functionality':
            statements.append("We recognize that reliable functionality is essential for your work")
        
        return statements

    def _estimate_response_timeline(self, priority: str) -> str:
        """Estimate response timeline based on priority"""
        timelines = {
            'critical': '24 hours',
            'high': '2-3 business days',
            'medium': '1 week',
            'low': '2 weeks'
        }
        return timelines.get(priority, '1 week')

    def _suggest_user_involvement(self, spec: FeedbackSpecification) -> Dict[str, Any]:
        """Suggest ways for user to be involved in improvements"""
        if spec.feedback_type == 'feature_request':
            return {
                'type': 'design_feedback',
                'description': 'Participate in feature design sessions',
                'benefit': 'Help shape the feature development'
            }
        elif spec.category == 'user_experience':
            return {
                'type': 'usability_testing',
                'description': 'Test interface improvements',
                'benefit': 'Ensure improvements meet your needs'
            }
        else:
            return {
                'type': 'beta_testing',
                'description': 'Early access to improvements',
                'benefit': 'First to experience enhancements'
            }

    # Improvement plan helper methods
    def _define_immediate_actions(self, spec: FeedbackSpecification) -> List[Dict[str, Any]]:
        """Define immediate actions based on feedback"""
        actions = []
        
        if spec.priority == 'critical':
            actions.append({
                'action': 'emergency_review',
                'description': 'Immediate technical team review',
                'timeline': '2 hours'
            })
        
        return actions

    def _define_short_term_improvements(self, analysis: FeedbackAnalysis, spec: FeedbackSpecification) -> List[Dict[str, Any]]:
        """Define short-term improvements"""
        improvements = []
        
        for suggestion in analysis.improvement_suggestions:
            if suggestion.get('estimated_effort') in ['low', 'medium']:
                improvements.append({
                    'improvement': suggestion['suggestion'],
                    'timeline': '2-4 weeks',
                    'expected_impact': 'high' if spec.priority in ['critical', 'high'] else 'medium'
                })
        
        return improvements

    def _define_long_term_enhancements(self, analysis: FeedbackAnalysis) -> List[Dict[str, Any]]:
        """Define long-term enhancements"""
        enhancements = []
        
        for insight in analysis.learning_insights:
            if insight.get('type') == 'feature_evolution':
                enhancements.append({
                    'enhancement': insight['insight'],
                    'timeline': '3-6 months',
                    'strategic_value': 'high'
                })
        
        return enhancements

    def _define_success_metrics(self, spec: FeedbackSpecification) -> Dict[str, Any]:
        """Define success metrics for improvements"""
        metrics = {
            'user_satisfaction': 'User satisfaction rating improvement',
            'category_specific': f"{spec.category} related feedback reduction"
        }
        
        if spec.category == 'performance':
            metrics['performance'] = 'System response time improvement'
        elif spec.category == 'functionality':
            metrics['reliability'] = 'Feature error rate reduction'
        
        return metrics

    def _create_implementation_timeline(self, priority: str) -> Dict[str, str]:
        """Create implementation timeline"""
        timelines = {
            'critical': {
                'immediate': '24 hours',
                'short_term': '1 week',
                'long_term': '1 month'
            },
            'high': {
                'immediate': '3 days',
                'short_term': '2 weeks',
                'long_term': '2 months'
            },
            'medium': {
                'immediate': '1 week',
                'short_term': '1 month',
                'long_term': '3 months'
            },
            'low': {
                'immediate': '2 weeks',
                'short_term': '2 months',
                'long_term': '6 months'
            }
        }
        return timelines.get(priority, timelines['medium'])

    def _assess_resource_requirements(self, analysis: FeedbackAnalysis, spec: FeedbackSpecification) -> Dict[str, Any]:
        """Assess resource requirements for improvements"""
        return {
            'development_effort': 'high' if spec.priority == 'critical' else 'medium',
            'team_involvement': self._determine_team_involvement(spec.category),
            'external_dependencies': self._identify_external_dependencies(analysis),
            'budget_impact': 'low' if spec.category == 'user_experience' else 'medium'
        }

    def _identify_stakeholders(self, category: str) -> List[str]:
        """Identify relevant stakeholders"""
        stakeholder_mapping = {
            'user_experience': ['UX_team', 'product_management', 'customer_success'],
            'functionality': ['engineering_team', 'QA_team', 'product_management'],
            'performance': ['engineering_team', 'infrastructure_team', 'QA_team'],
            'content_quality': ['content_team', 'product_management', 'customer_success']
        }
        return stakeholder_mapping.get(category, ['product_management'])

    # Additional helper methods
    def _estimate_business_impact(self, feedback_text: str) -> str:
        """Estimate business impact"""
        if any(word in feedback_text for word in ['cancel', 'switch', 'competitor', 'alternative']):
            return 'high'
        elif any(word in feedback_text for word in ['recommend', 'share', 'promote']):
            return 'positive'
        else:
            return 'medium'

    def _estimate_technical_impact(self, feedback_text: str, category: str) -> str:
        """Estimate technical impact"""
        if category == 'functionality' and any(word in feedback_text for word in ['crash', 'error', 'broken']):
            return 'high'
        elif category == 'performance':
            return 'medium'
        else:
            return 'low'

    def _estimate_affected_users(self, feedback_text: str) -> str:
        """Estimate scale of affected users"""
        if any(phrase in feedback_text for phrase in ['everyone', 'all users', 'widespread']):
            return 'large'
        elif any(phrase in feedback_text for phrase in ['many people', 'others', 'colleagues']):
            return 'medium'
        else:
            return 'individual'

    def _determine_team_involvement(self, category: str) -> List[str]:
        """Determine which teams need to be involved"""
        team_mapping = {
            'user_experience': ['design', 'frontend'],
            'functionality': ['backend', 'qa'],
            'performance': ['infrastructure', 'backend'],
            'content_quality': ['content', 'qa']
        }
        return team_mapping.get(category, ['product'])

    def _identify_external_dependencies(self, analysis: FeedbackAnalysis) -> List[str]:
        """Identify external dependencies for improvements"""
        dependencies = []
        
        # Check for third-party service mentions
        if any('integration' in str(suggestion) for suggestion in analysis.improvement_suggestions):
            dependencies.append('third_party_apis')
        
        return dependencies

    def _define_primary_goal(self, spec: FeedbackSpecification) -> str:
        """Define primary goal for response"""
        if spec.sentiment == 'negative':
            return 'resolve_issue_and_restore_satisfaction'
        elif spec.feedback_type == 'feature_request':
            return 'acknowledge_and_explore_feasibility'
        else:
            return 'thank_and_encourage_continued_feedback'

    def _define_secondary_goals(self, analysis: FeedbackAnalysis, spec: FeedbackSpecification) -> List[str]:
        """Define secondary goals for response"""
        goals = ['maintain_user_engagement']
        
        if spec.actionable:
            goals.append('demonstrate_commitment_to_improvement')
        
        if len(analysis.learning_insights) > 0:
            goals.append('show_value_of_user_input')
        
        return goals

    def get_agent_capability_summary(self) -> Dict[str, Any]:
        """Get comprehensive capability summary"""
        return {
            'feedback_processing': {
                'types_supported': ['general', 'bug_report', 'feature_request', 'rating', 'suggestion'],
                'categories': list(self.feedback_categories.keys()),
                'sentiment_analysis': 'Advanced multi-pattern sentiment detection',
                'priority_classification': 'Automated priority scoring with business impact assessment'
            },
            'analysis_capabilities': {
                'sentiment_analysis': 'Emotional indicator extraction and intensity measurement',
                'priority_assessment': 'Multi-factor priority scoring with urgency detection',
                'improvement_suggestions': 'Context-aware actionable recommendations',
                'learning_insights': 'Pattern recognition and system improvement insights'
            },
            'response_generation': {
                'personalization': 'Context-aware response customization',
                'tone_adaptation': 'Sentiment-appropriate response tone selection',
                'action_orientation': 'Clear next steps and improvement commitments',
                'user_involvement': 'Collaborative improvement participation opportunities'
            },
            'improvement_planning': {
                'timeline_estimation': 'Priority-based implementation scheduling',
                'resource_assessment': 'Team and effort requirement analysis',
                'success_metrics': 'Measurable improvement goal definition',
                'stakeholder_mapping': 'Relevant team and role identification'
            },
            'specializations': [
                'Enterprise feedback management',
                'User experience optimization',
                'Product development insights',
                'Customer satisfaction enhancement',
                'System improvement prioritization'
            ]
        }

    def _create_error_response(self, error_message: str) -> Dict[str, Any]:
        """Create standardized error response"""
        return {
            'feedback_processed': False,
            'error': error_message,
            'agent': self.name,
            'timestamp': datetime.now().isoformat(),
            'suggested_action': 'Please review feedback format and try again'
        }
