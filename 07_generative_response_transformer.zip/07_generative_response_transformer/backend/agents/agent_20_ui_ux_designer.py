# 🎨 Advanced UI/UX Designer - Creates user interfaces, user experiences, and digital product designs

from .base_agent import BaseAgent
from typing import Dict, Any, List, Tuple, Optional
import re
import json
from datetime import datetime
from dataclasses import dataclass, field

@dataclass
class UIUXSpecification:
    """Comprehensive UI/UX design specification"""
    design_type: str = "web_interface"  # web_interface, mobile_app, desktop_app, dashboard
    design_system: str = "modern"  # modern, material, minimal, corporate, creative
    platform: str = "responsive"  # responsive, ios, android, desktop, tablet
    complexity: str = "medium"  # simple, medium, complex, enterprise
    user_type: str = "general"  # general, professional, technical, creative
    accessibility: str = "wcag_aa"  # basic, wcag_aa, wcag_aaa, full_inclusive
    interaction_style: str = "intuitive"  # intuitive, advanced, guided, exploratory

@dataclass
class UIUXElements:
    """Advanced UI/UX design elements"""
    layout_components: List[Dict[str, Any]] = field(default_factory=list)
    interaction_flows: List[Dict[str, Any]] = field(default_factory=list)
    visual_hierarchy: Dict[str, Any] = field(default_factory=dict)
    design_tokens: Dict[str, Any] = field(default_factory=dict)
    accessibility_features: List[Dict[str, Any]] = field(default_factory=list)
    user_journeys: List[Dict[str, Any]] = field(default_factory=list)

class UIUXDesignerAgent(BaseAgent):
    """Agent 20: Advanced UI/UX design with user-centered design and modern interface creation"""
    
    def __init__(self):
        super().__init__(
            name="UIUXDesignerAgent",
            description="Advanced UI/UX design with user-centered design, modern interfaces, and accessibility-first approach",
            priority=9
        )
        
        # Design system frameworks
        self.design_systems = {
            'modern': {
                'principles': ['clean_aesthetics', 'minimal_clutter', 'purposeful_design'],
                'color_approach': ['neutral_base', 'accent_colors', 'high_contrast'],
                'typography': ['geometric_sans', 'clear_hierarchy', 'readable_scales'],
                'spacing': ['consistent_grid', '8px_system', 'generous_whitespace'],
                'components': ['cards', 'buttons', 'forms', 'navigation', 'modals']
            },
            'material': {
                'principles': ['material_metaphor', 'bold_graphic', 'meaningful_motion'],
                'color_approach': ['primary_secondary', 'surface_variants', 'semantic_colors'],
                'typography': ['roboto_family', 'type_scale', 'clear_hierarchy'],
                'spacing': ['4dp_grid', 'consistent_padding', 'touch_targets'],
                'components': ['fab', 'cards', 'sheets', 'navigation_drawer', 'snackbars']
            },
            'minimal': {
                'principles': ['essential_only', 'maximum_clarity', 'refined_simplicity'],
                'color_approach': ['monochrome_base', 'single_accent', 'subtle_variations'],
                'typography': ['clean_fonts', 'generous_spacing', 'minimal_weights'],
                'spacing': ['generous_whitespace', 'breathing_room', 'focused_content'],
                'components': ['simple_forms', 'clean_navigation', 'minimal_chrome']
            },
            'corporate': {
                'principles': ['professional_appearance', 'trustworthy_design', 'consistent_branding'],
                'color_approach': ['brand_colors', 'professional_palette', 'accessible_contrast'],
                'typography': ['corporate_fonts', 'formal_hierarchy', 'readable_body'],
                'spacing': ['structured_layout', 'organized_content', 'clear_sections'],
                'components': ['data_tables', 'dashboards', 'forms', 'reports', 'navigation']
            }
        }
        
        # User experience patterns
        self.ux_patterns = {
            'navigation': {
                'primary_navigation': ['top_bar', 'side_menu', 'bottom_tabs', 'breadcrumbs'],
                'secondary_navigation': ['sub_menus', 'contextual_menus', 'pagination', 'filters'],
                'mobile_patterns': ['hamburger_menu', 'tab_bar', 'gesture_navigation'],
                'accessibility': ['skip_links', 'keyboard_navigation', 'screen_reader_support']
            },
            'content_organization': {
                'layout_patterns': ['grid_system', 'card_layouts', 'list_views', 'masonry'],
                'hierarchy_techniques': ['visual_weight', 'color_coding', 'size_variation', 'spacing'],
                'scanning_patterns': ['f_pattern', 'z_pattern', 'layer_cake', 'gutenberg'],
                'responsive_behavior': ['mobile_first', 'progressive_enhancement', 'adaptive_layout']
            },
            'interaction_design': {
                'input_methods': ['forms', 'search', 'filters', 'voice_input', 'gesture'],
                'feedback_systems': ['loading_states', 'error_handling', 'success_confirmation'],
                'microinteractions': ['hover_effects', 'button_animations', 'state_changes'],
                'progressive_disclosure': ['accordions', 'tabs', 'modals', 'overlays']
            },
            'user_flow_optimization': {
                'onboarding': ['welcome_screens', 'feature_tours', 'progressive_onboarding'],
                'task_completion': ['multi_step_forms', 'progress_indicators', 'save_draft'],
                'error_recovery': ['inline_validation', 'helpful_errors', 'undo_functionality'],
                'personalization': ['user_preferences', 'customizable_dashboard', 'smart_defaults']
            }
        }
        
        # Accessibility guidelines
        self.accessibility_standards = {
            'wcag_aa': {
                'color_contrast': {'normal_text': 4.5, 'large_text': 3.0, 'ui_components': 3.0},
                'keyboard_navigation': ['tab_order', 'focus_indicators', 'keyboard_shortcuts'],
                'screen_reader': ['alt_text', 'aria_labels', 'semantic_markup', 'heading_structure'],
                'motor_disabilities': ['large_touch_targets', 'click_alternatives', 'timing_controls']
            },
            'wcag_aaa': {
                'color_contrast': {'normal_text': 7.0, 'large_text': 4.5, 'ui_components': 4.5},
                'enhanced_features': ['sign_language', 'audio_descriptions', 'simplified_language'],
                'advanced_navigation': ['multiple_ways', 'consistent_navigation', 'focus_management'],
                'cognitive_support': ['clear_instructions', 'error_prevention', 'help_context']
            }
        }
        
        # Design token systems
        self.design_token_categories = {
            'color': {
                'semantic_colors': ['primary', 'secondary', 'success', 'warning', 'error', 'info'],
                'neutral_colors': ['background', 'surface', 'border', 'text_primary', 'text_secondary'],
                'brand_colors': ['brand_primary', 'brand_secondary', 'accent_colors'],
                'accessibility': ['focus_color', 'high_contrast_mode', 'dark_mode_variants']
            },
            'typography': {
                'font_families': ['heading_font', 'body_font', 'monospace_font'],
                'font_sizes': ['xs', 'sm', 'base', 'lg', 'xl', '2xl', '3xl', '4xl'],
                'font_weights': ['light', 'normal', 'medium', 'semibold', 'bold'],
                'line_heights': ['tight', 'normal', 'relaxed', 'loose']
            },
            'spacing': {
                'spacing_scale': ['xs', 'sm', 'md', 'lg', 'xl', '2xl', '3xl', '4xl'],
                'component_spacing': ['padding', 'margin', 'gap', 'border_radius'],
                'layout_spacing': ['container_padding', 'section_spacing', 'grid_gaps'],
                'responsive_spacing': ['mobile', 'tablet', 'desktop', 'large_desktop']
            },
            'elevation': {
                'shadow_levels': ['none', 'xs', 'sm', 'md', 'lg', 'xl', '2xl'],
                'depth_indicators': ['raised', 'floating', 'overlay', 'modal'],
                'interactive_states': ['hover', 'active', 'focus', 'disabled']
            }
        }
    
    def _define_capabilities(self) -> List[str]:
        """Define advanced UI/UX design capabilities"""
        return [
            'user_interface_design', 'user_experience_design', 'responsive_design',
            'accessibility_design', 'design_system_creation', 'user_journey_mapping',
            'wireframe_creation', 'prototype_design', 'interaction_design',
            'usability_optimization', 'conversion_optimization', 'design_token_systems'
        ]
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Advanced UI/UX design processing"""
        current_input = pipeline_data.get('current_response', '')
        user_input = pipeline_data.get('user_input', '')
        
        context_metadata = pipeline_data.get('stage_results', {})
        intent_data = context_metadata.get('agent_3_intent_and_context_advanced', {})
        
        self._log_processing(current_input)
        
        # Stage 1: Analyze design requirements
        design_requirements = self._analyze_design_requirements(user_input, intent_data)
        
        # Stage 2: Create UI/UX specification
        uiux_specification = self._create_uiux_specification(design_requirements)
        
        # Stage 3: Plan user experience flow
        ux_flow_plan = self._plan_user_experience_flow(uiux_specification, design_requirements)
        
        # Stage 4: Design information architecture
        information_architecture = self._design_information_architecture(ux_flow_plan, uiux_specification)
        
        # Stage 5: Create design system
        design_system = self._create_comprehensive_design_system(information_architecture, uiux_specification)
        
        # Stage 6: Generate UI components
        ui_components = self._generate_ui_components(design_system, uiux_specification)
        
        # Stage 7: Apply accessibility standards
        accessible_design = self._apply_accessibility_standards(ui_components, uiux_specification)
        
        # Stage 8: Generate design deliverables
        design_deliverables = self._generate_design_deliverables(accessible_design, uiux_specification)
        
        comprehensive_metadata = {
            'processing_stage': 'uiux_design',
            'generation_timestamp': datetime.now().isoformat(),
            'design_analysis': {
                'requirements': design_requirements,
                'specification': uiux_specification.__dict__,
                'ux_flow_plan': ux_flow_plan,
                'information_architecture': information_architecture
            },
            'design_metrics': {
                'component_count': len(ui_components.layout_components),
                'interaction_flows': len(ui_components.interaction_flows),
                'accessibility_features': len(ui_components.accessibility_features),
                'user_journeys': len(ui_components.user_journeys),
                'design_complexity_score': self._calculate_design_complexity(accessible_design)
            },
            'design_specifications': {
                'design_type': uiux_specification.design_type,
                'design_system': uiux_specification.design_system,
                'platform': uiux_specification.platform,
                'accessibility_level': uiux_specification.accessibility,
                'user_focus': uiux_specification.user_type
            }
        }
        
        return self._create_result(
            output=design_deliverables,
            metadata=comprehensive_metadata
        )
    
    # Implementation methods (simplified for brevity)
    def _analyze_design_requirements(self, user_input: str, intent_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze comprehensive design requirements"""
        text_lower = user_input.lower()
        
        # Detect design type
        design_type = self._detect_design_type(text_lower)
        
        # Detect platform requirements
        platform = self._detect_platform_requirements(text_lower)
        
        # Detect user type
        user_type = self._detect_user_type(text_lower)
        
        # Detect accessibility needs
        accessibility_level = self._detect_accessibility_requirements(text_lower)
        
        return {
            'design_type': design_type,
            'platform': platform,
            'user_type': user_type,
            'accessibility_level': accessibility_level,
            'complexity': intent_data.get('intent_analysis', {}).get('complexity_assessment', {}).get('final_complexity', 'medium')
        }
    
    def _detect_design_type(self, text: str) -> str:
        """Detect the type of design needed"""
        if re.search(r'\b(website|web|landing|page)\b', text):
            return 'web_interface'
        elif re.search(r'\b(mobile|app|ios|android)\b', text):
            return 'mobile_app'
        elif re.search(r'\b(dashboard|analytics|admin|data)\b', text):
            return 'dashboard'
        elif re.search(r'\b(desktop|software|application)\b', text):
            return 'desktop_app'
        else:
            return 'web_interface'
    
    def _detect_platform_requirements(self, text: str) -> str:
        """Detect platform requirements"""
        if re.search(r'\b(responsive|multi.device|cross.platform)\b', text):
            return 'responsive'
        elif re.search(r'\b(ios|iphone|ipad)\b', text):
            return 'ios'
        elif re.search(r'\b(android|google.play)\b', text):
            return 'android'
        elif re.search(r'\b(desktop|windows|mac|linux)\b', text):
            return 'desktop'
        else:
            return 'responsive'
    
    def _detect_user_type(self, text: str) -> str:
        """Detect target user type"""
        if re.search(r'\b(professional|business|enterprise|corporate)\b', text):
            return 'professional'
        elif re.search(r'\b(technical|developer|admin|power.user)\b', text):
            return 'technical'
        elif re.search(r'\b(creative|designer|artist|agency)\b', text):
            return 'creative'
        else:
            return 'general'
    
    def _detect_accessibility_requirements(self, text: str) -> str:
        """Detect accessibility requirements"""
        if re.search(r'\b(accessible|accessibility|wcag|inclusive)\b', text):
            return 'wcag_aa'
        elif re.search(r'\b(full.accessibility|maximum.accessibility|wcag.aaa)\b', text):
            return 'wcag_aaa'
        else:
            return 'basic'
    
    def _create_uiux_specification(self, requirements: Dict[str, Any]) -> UIUXSpecification:
        """Create comprehensive UI/UX specification"""
        return UIUXSpecification(
            design_type=requirements['design_type'],
            platform=requirements['platform'],
            user_type=requirements['user_type'],
            accessibility=requirements['accessibility_level'],
            complexity=requirements['complexity']
        )
    
    def _plan_user_experience_flow(self, specification: UIUXSpecification, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Plan comprehensive user experience flow"""
        return {
            'user_entry_points': ['homepage', 'landing_page', 'direct_link'],
            'primary_user_paths': ['discovery', 'engagement', 'conversion', 'retention'],
            'interaction_patterns': ['browse', 'search', 'filter', 'compare', 'select'],
            'exit_strategies': ['completion', 'abandonment_recovery', 'alternative_paths']
        }
    
    def _design_information_architecture(self, ux_flow: Dict[str, Any], specification: UIUXSpecification) -> Dict[str, Any]:
        """Design comprehensive information architecture"""
        return {
            'site_structure': ['homepage', 'main_sections', 'sub_pages', 'utility_pages'],
            'navigation_hierarchy': ['primary_nav', 'secondary_nav', 'contextual_nav'],
            'content_organization': ['categories', 'tags', 'filters', 'search'],
            'user_mental_models': ['familiar_patterns', 'intuitive_grouping', 'logical_flow']
        }
    
    def _create_comprehensive_design_system(self, architecture: Dict[str, Any], specification: UIUXSpecification) -> Dict[str, Any]:
        """Create comprehensive design system"""
        design_system_config = self.design_systems.get(specification.design_system, self.design_systems['modern'])
        
        return {
            'design_principles': design_system_config['principles'],
            'color_system': self._create_color_system(specification),
            'typography_system': self._create_typography_system(specification),
            'spacing_system': self._create_spacing_system(specification),
            'component_library': self._create_component_library(specification)
        }
    
    def _generate_ui_components(self, design_system: Dict[str, Any], specification: UIUXSpecification) -> UIUXElements:
        """Generate comprehensive UI components"""
        ui_elements = UIUXElements()
        
        # Generate layout components
        ui_elements.layout_components = self._create_layout_components(design_system, specification)
        
        # Generate interaction flows
        ui_elements.interaction_flows = self._create_interaction_flows(design_system, specification)
        
        # Generate visual hierarchy
        ui_elements.visual_hierarchy = self._create_visual_hierarchy(design_system)
        
        # Generate design tokens
        ui_elements.design_tokens = self._create_design_tokens(design_system)
        
        return ui_elements
    
    def _apply_accessibility_standards(self, ui_components: UIUXElements, specification: UIUXSpecification) -> UIUXElements:
        """Apply comprehensive accessibility standards"""
        accessible_components = ui_components
        
        # Apply accessibility standards
        accessibility_config = self.accessibility_standards.get(specification.accessibility, {})
        
        # Generate accessibility features
        accessible_components.accessibility_features = self._create_accessibility_features(accessibility_config)
        
        return accessible_components
    
    def _generate_design_deliverables(self, design: UIUXElements, specification: UIUXSpecification) -> Dict[str, Any]:
        """Generate comprehensive design deliverables"""
        return {
            'wireframes': self._generate_wireframes(design, specification),
            'high_fidelity_mockups': self._generate_mockups(design, specification),
            'interactive_prototype': self._generate_prototype_specs(design, specification),
            'design_system_documentation': self._generate_design_system_docs(design),
            'component_library': self._generate_component_library_docs(design),
            'accessibility_report': self._generate_accessibility_report(design),
            'user_journey_maps': self._generate_user_journey_maps(design),
            'technical_specifications': self._generate_technical_specs(design, specification)
        }
    
    # Helper methods (simplified implementations)
    def _create_color_system(self, specification: UIUXSpecification) -> Dict[str, Any]:
        """Create comprehensive color system"""
        return {
            'primary_colors': {'primary': '#007bff', 'secondary': '#6c757d'},
            'semantic_colors': {'success': '#28a745', 'warning': '#ffc107', 'error': '#dc3545'},
            'neutral_colors': {'background': '#ffffff', 'text': '#212529', 'border': '#dee2e6'},
            'accessibility_compliance': 'wcag_aa_compliant'
        }
    
    def _create_typography_system(self, specification: UIUXSpecification) -> Dict[str, Any]:
        """Create comprehensive typography system"""
        return {
            'font_families': {'heading': 'Inter', 'body': 'Inter', 'mono': 'Fira Code'},
            'type_scale': {'xs': '12px', 'sm': '14px', 'base': '16px', 'lg': '18px', 'xl': '20px'},
            'font_weights': {'normal': 400, 'medium': 500, 'semibold': 600, 'bold': 700},
            'line_heights': {'tight': 1.2, 'normal': 1.5, 'relaxed': 1.75}
        }
    
    def _create_spacing_system(self, specification: UIUXSpecification) -> Dict[str, Any]:
        """Create comprehensive spacing system"""
        return {
            'spacing_scale': {'xs': '4px', 'sm': '8px', 'md': '16px', 'lg': '24px', 'xl': '32px'},
            'grid_system': {'columns': 12, 'gutter': '24px', 'container_max_width': '1200px'},
            'responsive_breakpoints': {'sm': '640px', 'md': '768px', 'lg': '1024px', 'xl': '1280px'}
        }
    
    def _create_component_library(self, specification: UIUXSpecification) -> List[str]:
        """Create component library list"""
        design_system_config = self.design_systems.get(specification.design_system, {})
        return design_system_config.get('components', ['buttons', 'forms', 'navigation', 'cards'])
    
    def _create_layout_components(self, design_system: Dict[str, Any], specification: UIUXSpecification) -> List[Dict[str, Any]]:
        """Create layout components"""
        return [
            {'type': 'header', 'description': 'Main site header with navigation'},
            {'type': 'main_content', 'description': 'Primary content area'},
            {'type': 'sidebar', 'description': 'Secondary navigation and content'},
            {'type': 'footer', 'description': 'Site footer with utility links'}
        ]
    
    def _create_interaction_flows(self, design_system: Dict[str, Any], specification: UIUXSpecification) -> List[Dict[str, Any]]:
        """Create interaction flows"""
        return [
            {'flow': 'user_onboarding', 'steps': ['welcome', 'setup', 'first_use']},
            {'flow': 'main_task_completion', 'steps': ['discovery', 'selection', 'completion']},
            {'flow': 'error_recovery', 'steps': ['error_detection', 'guidance', 'resolution']}
        ]
    
    def _create_visual_hierarchy(self, design_system: Dict[str, Any]) -> Dict[str, Any]:
        """Create visual hierarchy"""
        return {
            'primary_elements': ['main_heading', 'primary_cta', 'key_content'],
            'secondary_elements': ['subheadings', 'secondary_actions', 'supporting_content'],
            'tertiary_elements': ['metadata', 'utility_actions', 'footer_content']
        }
    
    def _create_design_tokens(self, design_system: Dict[str, Any]) -> Dict[str, Any]:
        """Create design tokens"""
        return {
            'colors': design_system.get('color_system', {}),
            'typography': design_system.get('typography_system', {}),
            'spacing': design_system.get('spacing_system', {}),
            'shadows': {'sm': '0 1px 2px rgba(0,0,0,0.05)', 'md': '0 4px 6px rgba(0,0,0,0.1)'}
        }
    
    def _create_accessibility_features(self, accessibility_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create accessibility features"""
        return [
            {'feature': 'keyboard_navigation', 'implementation': 'full_keyboard_support'},
            {'feature': 'screen_reader_support', 'implementation': 'semantic_markup_and_aria'},
            {'feature': 'color_contrast', 'implementation': 'wcag_aa_compliant_contrast'},
            {'feature': 'focus_management', 'implementation': 'visible_focus_indicators'}
        ]
    
    def _calculate_design_complexity(self, design: UIUXElements) -> float:
        """Calculate design complexity score"""
        base_score = 0.5
        base_score += len(design.layout_components) * 0.05
        base_score += len(design.interaction_flows) * 0.1
        base_score += len(design.accessibility_features) * 0.05
        return min(1.0, base_score)
    
    # Output generation methods (simplified)
    def _generate_wireframes(self, design: UIUXElements, specification: UIUXSpecification) -> Dict[str, Any]:
        """Generate wireframe specifications"""
        return {
            'wireframe_type': 'low_fidelity',
            'pages_included': ['homepage', 'main_pages', 'forms', 'error_states'],
            'interaction_notes': 'included',
            'responsive_views': ['mobile', 'tablet', 'desktop']
        }
    
    def _generate_mockups(self, design: UIUXElements, specification: UIUXSpecification) -> Dict[str, Any]:
        """Generate high-fidelity mockup specifications"""
        return {
            'mockup_type': 'high_fidelity',
            'design_system_applied': 'complete',
            'interactive_states': ['default', 'hover', 'active', 'disabled'],
            'responsive_breakpoints': 'all_major_breakpoints'
        }
    
    def _generate_prototype_specs(self, design: UIUXElements, specification: UIUXSpecification) -> Dict[str, Any]:
        """Generate interactive prototype specifications"""
        return {
            'prototype_fidelity': 'high',
            'interactions_included': 'all_major_flows',
            'animation_details': 'micro_interactions',
            'user_testing_ready': True
        }
    
    def _generate_design_system_docs(self, design: UIUXElements) -> Dict[str, Any]:
        """Generate design system documentation"""
        return {
            'documentation_type': 'comprehensive',
            'sections_included': ['principles', 'colors', 'typography', 'components', 'patterns'],
            'code_examples': 'included',
            'usage_guidelines': 'detailed'
        }
    
    def _generate_component_library_docs(self, design: UIUXElements) -> Dict[str, Any]:
        """Generate component library documentation"""
        return {
            'library_type': 'comprehensive',
            'components_documented': len(design.layout_components),
            'code_snippets': 'included',
            'design_tokens': 'integrated'
        }
    
    def _generate_accessibility_report(self, design: UIUXElements) -> Dict[str, Any]:
        """Generate accessibility compliance report"""
        return {
            'compliance_level': 'wcag_aa',
            'features_implemented': len(design.accessibility_features),
            'testing_recommendations': 'included',
            'remediation_notes': 'provided'
        }
    
    def _generate_user_journey_maps(self, design: UIUXElements) -> Dict[str, Any]:
        """Generate user journey maps"""
        return {
            'journey_count': len(design.user_journeys),
            'touchpoints_mapped': 'comprehensive',
            'pain_points_identified': 'included',
            'optimization_opportunities': 'highlighted'
        }
    
    def _generate_technical_specs(self, design: UIUXElements, specification: UIUXSpecification) -> Dict[str, Any]:
        """Generate technical implementation specifications"""
        return {
            'framework_recommendations': self._recommend_frameworks(specification),
            'implementation_guidelines': 'detailed',
            'performance_considerations': 'included',
            'browser_compatibility': 'modern_browsers'
        }
    
    def _recommend_frameworks(self, specification: UIUXSpecification) -> List[str]:
        """Recommend appropriate frameworks"""
        if specification.design_type == 'web_interface':
            return ['React', 'Vue.js', 'Angular']
        elif specification.design_type == 'mobile_app':
            return ['React Native', 'Flutter', 'Native iOS/Android']
        else:
            return ['Electron', 'Tauri', 'Progressive Web App']