# 🔁 Layered refinement over reasoning

from .base_agent import BaseAgent
from typing import Dict, Any

class LayeredThinkingAgent(BaseAgent):
    """Agent 4: Layered refinement over reasoning"""
    
    def __init__(self):
        super().__init__(
            name="LayeredThinkingAgent",
            description="Layered refinement over reasoning"
        )
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        user_input = pipeline_data.get('current_response', '')
        previous_analysis = pipeline_data.get('stage_results', {}).get(2, {}).get('metadata', {})
        
        self._log_processing(user_input)
        
        # Perform layered reasoning refinement
        refined_reasoning = self._refine_reasoning(user_input, previous_analysis)
        
        return self._create_result(
            output=user_input,
            metadata={
                'refined_reasoning': refined_reasoning,
                'reasoning_layers': ['logical', 'contextual', 'pragmatic'],
                'refinement_applied': True
            }
        )
    
    def _refine_reasoning(self, text: str, previous_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Apply layered reasoning refinement"""
        return {
            'logical_layer': self._logical_refinement(text),
            'contextual_layer': self._contextual_refinement(text, previous_analysis),
            'pragmatic_layer': self._pragmatic_refinement(text)
        }
    
    def _logical_refinement(self, text: str) -> Dict[str, Any]:
        """Logical layer refinement"""
        return {
            'argument_structure': 'valid' if len(text.split()) > 5 else 'simple',
            'logical_flow': 'coherent'
        }
    
    def _contextual_refinement(self, text: str, previous_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Contextual layer refinement"""
        return {
            'context_relevance': 'high',
            'builds_on_previous': bool(previous_analysis)
        }
    
    def _pragmatic_refinement(self, text: str) -> Dict[str, Any]:
        """Pragmatic layer refinement"""
        return {
            'actionable': any(word in text.lower() for word in ['do', 'make', 'create', 'help']),
            'clear_intent': True
        }