# 🔒 Detects unsafe inputs
from .base_agent import BaseAgent
from typing import Dict, Any

class SecurityFilterAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="SecurityFilterAgent", description="Detects unsafe inputs")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        security_check = self._security_scan(current_response)
        return self._create_result(output=current_response, metadata={'security_check': security_check})
    
    def _security_scan(self, text: str) -> Dict[str, Any]:
        return {'safe': True, 'threats_detected': []}
"""
🛡️ Agent 33: Security Filter - Advanced security scanning and content protection
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List, Set
import json
import re
import hashlib
from datetime import datetime

class Agent33SecurityFilter(BaseAgent):
    """Agent 33: Advanced security filtering and content protection system"""
    
    def __init__(self):
        super().__init__(
            name="Agent33SecurityFilter",
            description="Advanced security filtering, threat detection, and content protection",
            priority=10
        )
        
        # Security threat patterns
        self.threat_patterns = {
            'malicious_code': [
                r'(?i)\beval\s*\(',
                r'(?i)\bexec\s*\(',
                r'(?i)\b__import__\s*\(',
                r'(?i)\bos\.system\s*\(',
                r'(?i)\bsubprocess\.',
                r'(?i)\bshell=True',
                r'(?i)rm\s+-rf\s+/',
                r'(?i)del\s+/\w+',
                r'(?i)format\s+c:',
                r'(?i)DROP\s+TABLE',
                r'(?i)DELETE\s+FROM.*WHERE\s+1=1'
            ],
            'injection_attempts': [
                r'(?i)(?:\'|\")\s*;\s*(?:DROP|DELETE|INSERT|UPDATE)',
                r'(?i)(?:union|UNION).*(?:select|SELECT)',
                r'(?i)<script[^>]*>.*?</script>',
                r'(?i)javascript:',
                r'(?i)onload\s*=',
                r'(?i)onerror\s*=',
                r'(?i)onclick\s*='
            ],
            'sensitive_data_exposure': [
                r'(?i)password\s*[:=]\s*["\']?\w+',
                r'(?i)api[_-]?key\s*[:=]\s*["\']?[\w\-]+',
                r'(?i)secret\s*[:=]\s*["\']?\w+',
                r'(?i)token\s*[:=]\s*["\']?[\w\-\.]+',
                r'\b(?:\d{4}[-\s]?){3}\d{4}\b',  # Credit card pattern
                r'\b\d{3}-\d{2}-\d{4}\b',       # SSN pattern
                r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'  # Email pattern
            ],
            'malicious_urls': [
                r'(?i)http://bit\.ly/',
                r'(?i)http://tinyurl\.com/',
                r'(?i)(?:phishing|malware|virus).*\.(?:exe|bat|scr|com)',
                r'(?i)(?:download|click).*(?:now|here|free).*\.(?:exe|zip|rar)'
            ],
            'social_engineering': [
                r'(?i)urgent.*(?:verify|update).*(?:account|password)',
                r'(?i)click.*(?:here|now).*(?:claim|win|free)',
                r'(?i)congratulations.*(?:winner|selected|won)',
                r'(?i)limited.*time.*offer.*expires',
                r'(?i)your.*(?:account|payment).*(?:suspended|locked|frozen)'
            ]
        }
        
        # Sensitive topics that require careful handling
        self.sensitive_topics = {
            'violence_harm': [
                'violence', 'harm', 'kill', 'murder', 'suicide', 'self-harm',
                'torture', 'abuse', 'assault', 'terrorism', 'bomb', 'weapon'
            ],
            'illegal_activities': [
                'illegal', 'drugs', 'hacking', 'fraud', 'theft', 'piracy',
                'money laundering', 'tax evasion', 'counterfeiting'
            ],
            'hate_speech': [
                'discrimination', 'racism', 'sexism', 'hate speech', 
                'harassment', 'bullying', 'extremism'
            ],
            'adult_content': [
                'explicit', 'adult content', 'pornography', 'sexual content',
                'inappropriate material'
            ]
        }
        
        # Privacy protection patterns
        self.privacy_patterns = [
            r'\b\d{3}-\d{2}-\d{4}\b',  # SSN
            r'\b(?:\d{4}[-\s]?){3}\d{4}\b',  # Credit card
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',  # Email
            r'\b(?:\+?1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}\b'  # Phone
        ]
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process content through security filter"""
        try:
            current_response = pipeline_data.get('current_response', '')
            user_input = pipeline_data.get('user_input', '')
            
            self._log_processing(f"Security Filter Scan: {len(current_response)} characters")
            
            # Scan for security threats
            threat_analysis = self._scan_for_threats(current_response, user_input)
            
            # Check for sensitive content
            sensitivity_analysis = self._analyze_sensitive_content(current_response, user_input)
            
            # Scan for privacy violations
            privacy_analysis = self._scan_privacy_violations(current_response)
            
            # Validate content safety
            safety_analysis = self._validate_content_safety(current_response)
            
            # Generate security score
            security_score = self._calculate_security_score(
                threat_analysis, sensitivity_analysis, privacy_analysis, safety_analysis
            )
            
            # Apply security filtering
            filtered_response = self._apply_security_filtering(
                current_response, threat_analysis, sensitivity_analysis, privacy_analysis
            )
            
            # Add security warnings if needed
            final_response = self._add_security_warnings(
                filtered_response, security_score, threat_analysis
            )
            
            return self._create_result(
                final_response,
                {
                    'security_analysis': {
                        'threat_analysis': threat_analysis,
                        'sensitivity_analysis': sensitivity_analysis,
                        'privacy_analysis': privacy_analysis,
                        'safety_analysis': safety_analysis,
                        'security_score': security_score
                    },
                    'filtering_applied': security_score < 0.7,
                    'warnings_added': security_score < 0.5,
                    'content_blocked': security_score < 0.3
                }
            )
            
        except Exception as e:
            return self._create_result(
                current_response,
                {'error': f'Security filtering failed: {str(e)}', 'fallback_applied': True}
            )
    
    def _scan_for_threats(self, response: str, user_input: str) -> Dict[str, Any]:
        """Scan content for security threats"""
        combined_content = f"{user_input} {response}"
        detected_threats = {}
        total_threat_score = 0
        
        for threat_type, patterns in self.threat_patterns.items():
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, combined_content)
                if found:
                    matches.extend(found)
            
            if matches:
                detected_threats[threat_type] = {
                    'matches': matches,
                    'count': len(matches),
                    'severity': self._assess_threat_severity(threat_type)
                }
                total_threat_score += len(matches) * detected_threats[threat_type]['severity']
        
        return {
            'detected_threats': detected_threats,
            'total_threats': sum(threat['count'] for threat in detected_threats.values()),
            'threat_score': min(10, total_threat_score),
            'highest_severity': max([threat['severity'] for threat in detected_threats.values()], default=0)
        }
    
    def _analyze_sensitive_content(self, response: str, user_input: str) -> Dict[str, Any]:
        """Analyze content for sensitive topics"""
        combined_content = f"{user_input} {response}".lower()
        detected_topics = {}
        sensitivity_flags = 0
        
        for topic_category, keywords in self.sensitive_topics.items():
            matches = []
            for keyword in keywords:
                if keyword.lower() in combined_content:
                    matches.append(keyword)
            
            if matches:
                detected_topics[topic_category] = {
                    'keywords': matches,
                    'count': len(matches),
                    'sensitivity_level': self._get_sensitivity_level(topic_category)
                }
                sensitivity_flags += len(matches) * detected_topics[topic_category]['sensitivity_level']
        
        return {
            'detected_topics': detected_topics,
            'total_flags': sensitivity_flags,
            'requires_caution': sensitivity_flags > 5,
            'high_sensitivity': any(topic['sensitivity_level'] >= 8 
                                  for topic in detected_topics.values())
        }
    
    def _scan_privacy_violations(self, content: str) -> Dict[str, Any]:
        """Scan for potential privacy violations"""
        privacy_violations = {}
        
        for i, pattern in enumerate(self.privacy_patterns):
            pattern_name = ['SSN', 'Credit Card', 'Email', 'Phone'][i]
            matches = re.findall(pattern, content)
            
            if matches:
                privacy_violations[pattern_name] = {
                    'matches': matches,
                    'count': len(matches),
                    'masked_matches': [self._mask_sensitive_data(match) for match in matches]
                }
        
        return {
            'violations': privacy_violations,
            'total_violations': sum(v['count'] for v in privacy_violations.values()),
            'requires_masking': len(privacy_violations) > 0,
            'privacy_risk_level': 'high' if len(privacy_violations) > 2 else 
                                 'medium' if len(privacy_violations) > 0 else 'low'
        }
    
    def _validate_content_safety(self, content: str) -> Dict[str, Any]:
        """Validate overall content safety"""
        safety_indicators = {
            'excessive_caps': len(re.findall(r'\b[A-Z]{4,}\b', content)),
            'excessive_punctuation': len(re.findall(r'[!?]{3,}', content)),
            'suspicious_links': len(re.findall(r'(?i)(?:click|download).*(?:here|now)', content)),
            'urgency_markers': len(re.findall(r'(?i)\b(?:urgent|immediately|now|asap)\b', content))
        }
        
        safety_score = 10
        for indicator, count in safety_indicators.items():
            if count > 0:
                safety_score -= min(3, count)  # Deduct points for safety concerns
        
        return {
            'safety_indicators': safety_indicators,
            'safety_score': max(0, safety_score),
            'is_safe': safety_score >= 7,
            'requires_review': safety_score < 5
        }
    
    def _assess_threat_severity(self, threat_type: str) -> int:
        """Assess severity of threat type (1-10 scale)"""
        severity_map = {
            'malicious_code': 10,
            'injection_attempts': 9,
            'sensitive_data_exposure': 8,
            'malicious_urls': 7,
            'social_engineering': 6
        }
        return severity_map.get(threat_type, 5)
    
    def _get_sensitivity_level(self, topic_category: str) -> int:
        """Get sensitivity level for topic category (1-10 scale)"""
        sensitivity_map = {
            'violence_harm': 9,
            'illegal_activities': 8,
            'hate_speech': 8,
            'adult_content': 6
        }
        return sensitivity_map.get(topic_category, 5)
    
    def _calculate_security_score(self, threat_analysis: Dict[str, Any], 
                                 sensitivity_analysis: Dict[str, Any],
                                 privacy_analysis: Dict[str, Any], 
                                 safety_analysis: Dict[str, Any]) -> float:
        """Calculate overall security score (0-1 scale)"""
        
        # Start with perfect score
        score = 1.0
        
        # Deduct for threats
        threat_penalty = min(0.5, threat_analysis['threat_score'] * 0.05)
        score -= threat_penalty
        
        # Deduct for sensitivity
        sensitivity_penalty = min(0.3, sensitivity_analysis['total_flags'] * 0.02)
        score -= sensitivity_penalty
        
        # Deduct for privacy violations
        privacy_penalty = min(0.2, privacy_analysis['total_violations'] * 0.1)
        score -= privacy_penalty
        
        # Deduct for safety concerns
        safety_penalty = (10 - safety_analysis['safety_score']) * 0.02
        score -= safety_penalty
        
        return max(0.0, score)
    
    def _mask_sensitive_data(self, data: str) -> str:
        """Mask sensitive data for logging"""
        if '@' in data:  # Email
            parts = data.split('@')
            return f"{parts[0][:2]}***@{parts[1]}"
        elif '-' in data and len(data) > 10:  # Phone or SSN
            return f"{data[:3]}-**-{data[-4:]}"
        else:  # Generic masking
            return f"{data[:2]}***{data[-2:]}" if len(data) > 4 else "***"
    
    def _apply_security_filtering(self, content: str, threat_analysis: Dict[str, Any],
                                 sensitivity_analysis: Dict[str, Any], 
                                 privacy_analysis: Dict[str, Any]) -> str:
        """Apply security filtering to content"""
        
        filtered_content = content
        
        # Remove or neutralize malicious code
        for threat_type, threat_data in threat_analysis['detected_threats'].items():
            if threat_type == 'malicious_code':
                for match in threat_data['matches']:
                    filtered_content = filtered_content.replace(match, '[POTENTIALLY HARMFUL CODE REMOVED]')
            elif threat_type == 'injection_attempts':
                for match in threat_data['matches']:
                    filtered_content = filtered_content.replace(match, '[INJECTION ATTEMPT BLOCKED]')
        
        # Mask privacy violations
        for violation_type, violation_data in privacy_analysis['violations'].items():
            for original, masked in zip(violation_data['matches'], violation_data['masked_matches']):
                filtered_content = filtered_content.replace(original, masked)
        
        # Add content warnings for sensitive topics
        if sensitivity_analysis['high_sensitivity']:
            warning = "\n\n⚠️ **Content Warning**: This response discusses sensitive topics. "
            filtered_content = warning + filtered_content
        
        return filtered_content
    
    def _add_security_warnings(self, content: str, security_score: float, 
                              threat_analysis: Dict[str, Any]) -> str:
        """Add appropriate security warnings"""
        
        if security_score < 0.3:
            # Block content entirely
            return ("🚫 **Security Alert**: This content has been blocked due to security concerns. "
                   "Please contact support if you believe this is an error.")
        
        elif security_score < 0.5:
            # Add strong warning
            warning = ("🛡️ **Security Warning**: This content contains elements that may pose "
                     "security risks. Please verify all information independently.\n\n")
            return warning + content
        
        elif security_score < 0.7:
            # Add caution notice
            if threat_analysis['total_threats'] > 0:
                caution = ("⚠️ **Caution**: This response has been filtered for security. "
                         "Some content may have been modified or removed.\n\n")
                return caution + content
        
        return content
