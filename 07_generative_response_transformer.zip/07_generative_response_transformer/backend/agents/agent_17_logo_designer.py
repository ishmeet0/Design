# 🎯 Advanced Logo Designer - Creates professional logos and brand identities

from .base_agent import BaseAgent
from typing import Dict, Any, List, Tuple, Optional
import re
import json
import math
from datetime import datetime
from dataclasses import dataclass, field
from collections import defaultdict

@dataclass
class LogoSpecification:
    """Comprehensive logo design specification"""
    logo_type: str = "wordmark"  # wordmark, symbol, combination, emblem, monogram
    style: str = "modern"  # modern, classic, vintage, minimalist, bold, elegant
    industry: str = "technology"  # technology, healthcare, finance, creative, retail
    color_scheme: str = "monochrome"  # monochrome, two_color, full_color, gradient
    typography: str = "sans_serif"  # sans_serif, serif, script, display, custom
    complexity: str = "medium"  # simple, medium, complex
    scalability: str = "vector"  # vector, bitmap, hybrid

@dataclass
class LogoElements:
    """Advanced logo design elements"""
    text_elements: List[Dict[str, Any]] = field(default_factory=list)
    graphic_elements: List[Dict[str, Any]] = field(default_factory=list)
    colors: List[Dict[str, Any]] = field(default_factory=list)
    typography: List[Dict[str, Any]] = field(default_factory=list)
    layout: Dict[str, Any] = field(default_factory=dict)
    brand_guidelines: Dict[str, Any] = field(default_factory=dict)

class LogoDesignerAgent(BaseAgent):
    """Agent 17: Advanced logo design with professional brand identity creation"""
    
    def __init__(self):
        super().__init__(
            name="LogoDesignerAgent",
            description="Advanced logo design with professional brand identity and visual branding",
            priority=9
        )
        
        # Logo type templates and characteristics
        self.logo_types = {
            'wordmark': {
                'characteristics': ['text_only', 'typography_focused', 'company_name'],
                'examples': ['Google', 'Coca-Cola', 'FedEx'],
                'best_for': ['established_brands', 'distinctive_names', 'service_companies'],
                'design_focus': 'typography_excellence'
            },
            'symbol': {
                'characteristics': ['icon_only', 'no_text', 'symbolic_representation'],
                'examples': ['Apple', 'Nike', 'Twitter'],
                'best_for': ['global_brands', 'simple_concepts', 'recognition_focused'],
                'design_focus': 'iconic_imagery'
            },
            'combination': {
                'characteristics': ['text_and_symbol', 'flexible_usage', 'comprehensive'],
                'examples': ['Adidas', 'Burger King', 'Lacoste'],
                'best_for': ['new_brands', 'versatile_applications', 'brand_building'],
                'design_focus': 'balanced_composition'
            },
            'emblem': {
                'characteristics': ['enclosed_design', 'badge_like', 'traditional'],
                'examples': ['Harley Davidson', 'Starbucks', 'BMW'],
                'best_for': ['heritage_brands', 'premium_products', 'institutional'],
                'design_focus': 'unified_composition'
            },
            'monogram': {
                'characteristics': ['initials_based', 'letter_focused', 'sophisticated'],
                'examples': ['IBM', 'HP', 'GE'],
                'best_for': ['long_names', 'professional_services', 'corporate_identity'],
                'design_focus': 'letter_relationships'
            }
        }
        
        # Design style systems
        self.design_styles = {
            'modern': {
                'characteristics': ['clean_lines', 'minimal_details', 'contemporary_feel'],
                'color_preferences': ['bold_colors', 'high_contrast', 'gradient_accents'],
                'typography': ['geometric_sans', 'modern_serif', 'custom_lettering'],
                'visual_elements': ['geometric_shapes', 'negative_space', 'asymmetry']
            },
            'classic': {
                'characteristics': ['timeless_appeal', 'balanced_proportions', 'refined_elegance'],
                'color_preferences': ['traditional_colors', 'subdued_palette', 'elegant_combinations'],
                'typography': ['classic_serif', 'traditional_sans', 'established_fonts'],
                'visual_elements': ['symmetry', 'classical_proportions', 'refined_details']
            },
            'vintage': {
                'characteristics': ['retro_aesthetic', 'nostalgic_feel', 'handcrafted_quality'],
                'color_preferences': ['muted_tones', 'aged_colors', 'sepia_influences'],
                'typography': ['vintage_serif', 'script_fonts', 'decorative_elements'],
                'visual_elements': ['ornamental_details', 'textured_effects', 'aged_appearance']
            },
            'minimalist': {
                'characteristics': ['extreme_simplicity', 'essential_elements_only', 'maximum_impact'],
                'color_preferences': ['monochrome', 'single_accent', 'high_contrast'],
                'typography': ['ultra_clean', 'geometric_precision', 'perfect_spacing'],
                'visual_elements': ['negative_space', 'geometric_purity', 'single_focal_point']
            },
            'bold': {
                'characteristics': ['strong_presence', 'high_impact', 'memorable_design'],
                'color_preferences': ['vibrant_colors', 'strong_contrasts', 'attention_grabbing'],
                'typography': ['heavy_weights', 'impactful_fonts', 'strong_presence'],
                'visual_elements': ['large_scale', 'bold_shapes', 'dynamic_composition']
            },
            'elegant': {
                'characteristics': ['sophisticated_refinement', 'luxury_appeal', 'premium_quality'],
                'color_preferences': ['sophisticated_palette', 'metallic_accents', 'refined_combinations'],
                'typography': ['elegant_serif', 'refined_sans', 'luxury_lettering'],
                'visual_elements': ['graceful_curves', 'refined_details', 'premium_aesthetics']
            }
        }
        
        # Industry-specific design guidelines
        self.industry_guidelines = {
            'technology': {
                'preferred_styles': ['modern', 'minimalist', 'bold'],
                'common_elements': ['geometric_shapes', 'circuit_patterns', 'digital_aesthetics'],
                'color_tendencies': ['blue', 'gray', 'green', 'orange'],
                'typography': ['geometric_sans', 'modern_fonts', 'tech_inspired'],
                'brand_personality': ['innovative', 'reliable', 'forward_thinking']
            },
            'healthcare': {
                'preferred_styles': ['clean', 'trustworthy', 'professional'],
                'common_elements': ['medical_crosses', 'heart_symbols', 'caring_imagery'],
                'color_tendencies': ['blue', 'green', 'white', 'red'],
                'typography': ['readable_sans', 'professional_fonts', 'accessible_design'],
                'brand_personality': ['trustworthy', 'caring', 'professional']
            },
            'finance': {
                'preferred_styles': ['classic', 'professional', 'elegant'],
                'common_elements': ['pillars', 'shields', 'growth_arrows'],
                'color_tendencies': ['blue', 'green', 'gold', 'navy'],
                'typography': ['classic_serif', 'professional_sans', 'established_fonts'],
                'brand_personality': ['trustworthy', 'stable', 'professional']
            },
            'creative': {
                'preferred_styles': ['artistic', 'bold', 'unique'],
                'common_elements': ['artistic_brushes', 'creative_tools', 'expressive_shapes'],
                'color_tendencies': ['vibrant_spectrum', 'artistic_combinations', 'expressive_colors'],
                'typography': ['custom_lettering', 'artistic_fonts', 'expressive_typography'],
                'brand_personality': ['creative', 'innovative', 'expressive']
            },
            'retail': {
                'preferred_styles': ['approachable', 'friendly', 'memorable'],
                'common_elements': ['shopping_symbols', 'friendly_shapes', 'accessible_design'],
                'color_tendencies': ['warm_colors', 'inviting_palette', 'brand_differentiation'],
                'typography': ['friendly_fonts', 'readable_design', 'approachable_style'],
                'brand_personality': ['friendly', 'accessible', 'trustworthy']
            }
        }
        
        # Advanced typography system
        self.typography_system = {
            'sans_serif': {
                'characteristics': ['clean', 'modern', 'readable'],
                'subcategories': {
                    'geometric': ['perfect_circles', 'mathematical_precision', 'consistent_weights'],
                    'humanist': ['organic_shapes', 'readable_forms', 'friendly_appearance'],
                    'grotesque': ['neutral_appearance', 'versatile_usage', 'professional_look']
                },
                'applications': ['modern_brands', 'tech_companies', 'clean_aesthetics']
            },
            'serif': {
                'characteristics': ['traditional', 'readable', 'authoritative'],
                'subcategories': {
                    'old_style': ['calligraphic_origin', 'organic_stress', 'traditional_feel'],
                    'transitional': ['balanced_design', 'vertical_stress', 'refined_appearance'],
                    'modern': ['high_contrast', 'vertical_stress', 'elegant_appearance']
                },
                'applications': ['established_brands', 'luxury_products', 'editorial_design']
            },
            'script': {
                'characteristics': ['handwritten_feel', 'personal_touch', 'elegant_flow'],
                'subcategories': {
                    'formal': ['elegant_curves', 'sophisticated_appearance', 'luxury_appeal'],
                    'casual': ['relaxed_feel', 'friendly_appearance', 'approachable_style'],
                    'calligraphic': ['artistic_flair', 'handcrafted_quality', 'unique_character']
                },
                'applications': ['luxury_brands', 'personal_services', 'creative_businesses']
            },
            'display': {
                'characteristics': ['attention_grabbing', 'unique_personality', 'large_size_optimized'],
                'subcategories': {
                    'decorative': ['ornamental_elements', 'artistic_flair', 'unique_character'],
                    'experimental': ['innovative_forms', 'cutting_edge_design', 'distinctive_appearance'],
                    'themed': ['specific_industry', 'contextual_design', 'purpose_built']
                },
                'applications': ['brand_headlines', 'logo_design', 'distinctive_identity']
            }
        }
        
        # Color psychology and branding
        self.color_psychology = {
            'red': {
                'psychology': ['energy', 'passion', 'urgency', 'strength'],
                'industry_fit': ['food', 'entertainment', 'sports', 'emergency_services'],
                'brand_personality': ['bold', 'energetic', 'passionate'],
                'usage_notes': ['attention_grabbing', 'appetite_stimulating', 'action_oriented']
            },
            'blue': {
                'psychology': ['trust', 'reliability', 'professionalism', 'calm'],
                'industry_fit': ['technology', 'healthcare', 'finance', 'corporate'],
                'brand_personality': ['trustworthy', 'professional', 'reliable'],
                'usage_notes': ['most_popular_corporate', 'universally_accepted', 'professional_standard']
            },
            'green': {
                'psychology': ['growth', 'nature', 'health', 'prosperity'],
                'industry_fit': ['environmental', 'health', 'finance', 'organic'],
                'brand_personality': ['natural', 'healthy', 'growing'],
                'usage_notes': ['environmental_association', 'health_implications', 'growth_symbolism']
            },
            'orange': {
                'psychology': ['creativity', 'enthusiasm', 'warmth', 'energy'],
                'industry_fit': ['creative', 'food', 'technology', 'youth_oriented'],
                'brand_personality': ['creative', 'energetic', 'friendly'],
                'usage_notes': ['attention_grabbing', 'youthful_appeal', 'creative_energy']
            },
            'purple': {
                'psychology': ['luxury', 'creativity', 'wisdom', 'mystery'],
                'industry_fit': ['luxury', 'beauty', 'creative', 'spiritual'],
                'brand_personality': ['luxurious', 'creative', 'sophisticated'],
                'usage_notes': ['premium_positioning', 'creative_industries', 'unique_appeal']
            },
            'black': {
                'psychology': ['sophistication', 'elegance', 'power', 'mystery'],
                'industry_fit': ['luxury', 'fashion', 'technology', 'premium'],
                'brand_personality': ['sophisticated', 'premium', 'powerful'],
                'usage_notes': ['luxury_standard', 'timeless_appeal', 'premium_positioning']
            }
        }
    
    def _define_capabilities(self) -> List[str]:
        """Define advanced logo design capabilities"""
        return [
            'logo_design', 'brand_identity_creation', 'typography_design',
            'color_scheme_development', 'brand_guidelines_creation', 'scalable_design',
            'industry_specific_design', 'psychological_color_application', 'trademark_optimization',
            'multi_format_generation', 'brand_system_development', 'visual_identity_standards'
        ]
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Advanced logo design processing"""
        current_input = pipeline_data.get('current_response', '')
        user_input = pipeline_data.get('user_input', '')
        
        # Extract context from previous agents
        context_metadata = pipeline_data.get('stage_results', {})
        intent_data = context_metadata.get('agent_3_intent_and_context_advanced', {})
        
        self._log_processing(current_input)
        
        # Stage 1: Analyze logo design requirements
        logo_requirements = self._analyze_logo_requirements(user_input, intent_data)
        
        # Stage 2: Create logo specification
        logo_specification = self._create_logo_specification(logo_requirements, context_metadata)
        
        # Stage 3: Develop brand strategy
        brand_strategy = self._develop_brand_strategy(logo_specification, logo_requirements)
        
        # Stage 4: Design logo concepts
        logo_concepts = self._design_logo_concepts(brand_strategy, logo_specification)
        
        # Stage 5: Apply typography and color systems
        styled_logos = self._apply_typography_and_colors(logo_concepts, logo_specification)
        
        # Stage 6: Create brand guidelines
        brand_guidelines = self._create_brand_guidelines(styled_logos, logo_specification)
        
        # Stage 7: Generate multiple formats and variations
        logo_variations = self._generate_logo_variations(styled_logos, logo_specification)
        
        # Stage 8: Create comprehensive brand package
        brand_package = self._create_comprehensive_brand_package(logo_variations, brand_guidelines)
        
        comprehensive_metadata = {
            'processing_stage': 'logo_design',
            'generation_timestamp': datetime.now().isoformat(),
            'logo_analysis': {
                'requirements': logo_requirements,
                'specification': logo_specification.__dict__,
                'brand_strategy': brand_strategy,
            },
            'design_metrics': {
                'concepts_generated': len(logo_concepts.graphic_elements),
                'color_variations': len(styled_logos.colors),
                'typography_variations': len(styled_logos.typography),
                'format_variations': len(logo_variations),
                'scalability_score': self._calculate_scalability_score(styled_logos)
            },
            'brand_specifications': {
                'logo_type': logo_specification.logo_type,
                'design_style': logo_specification.style,
                'industry_focus': logo_specification.industry,
                'color_system': logo_specification.color_scheme,
                'complexity_level': logo_specification.complexity
            }
        }
        
        return self._create_result(
            output=brand_package,
            metadata=comprehensive_metadata
        )
    
    def _analyze_logo_requirements(self, user_input: str, intent_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze comprehensive logo design requirements"""
        text_lower = user_input.lower()
        
        # Extract company/brand name
        brand_name = self._extract_brand_name(user_input)
        
        # Detect logo type preference
        logo_type = self._detect_logo_type(text_lower)
        
        # Detect industry context
        industry = self._detect_industry_context(text_lower)
        
        # Detect style preferences
        style_preferences = self._detect_style_preferences(text_lower)
        
        # Detect color preferences
        color_preferences = self._detect_color_preferences(text_lower)
        
        # Detect usage requirements
        usage_requirements = self._detect_usage_requirements(text_lower)
        
        # Detect brand personality
        brand_personality = self._detect_brand_personality(text_lower, industry)
        
        return {
            'brand_name': brand_name,
            'logo_type': logo_type,
            'industry': industry,
            'style_preferences': style_preferences,
            'color_preferences': color_preferences,
            'usage_requirements': usage_requirements,
            'brand_personality': brand_personality,
            'target_audience': self._identify_target_audience(text_lower, industry)
        }
    
    def _create_logo_specification(self, requirements: Dict[str, Any], context_metadata: Dict[str, Any]) -> LogoSpecification:
        """Create comprehensive logo specification"""
        
        return LogoSpecification(
            logo_type=requirements['logo_type'],
            style=requirements['style_preferences']['primary_style'],
            industry=requirements['industry'],
            color_scheme=requirements['color_preferences']['scheme_type'],
            typography=requirements['style_preferences'].get('typography_preference', 'sans_serif'),
            complexity=requirements.get('complexity_level', 'medium'),
            scalability='vector'  # Always design for scalability
        )
    
    def _develop_brand_strategy(self, specification: LogoSpecification, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Develop comprehensive brand strategy"""
        
        industry_guidelines = self.industry_guidelines.get(specification.industry, {})
        
        brand_strategy = {
            'brand_positioning': self._define_brand_positioning(requirements, industry_guidelines),
            'visual_hierarchy': self._establish_visual_hierarchy(specification),
            'brand_attributes': self._define_brand_attributes(requirements),
            'differentiation_strategy': self._create_differentiation_strategy(requirements, specification),
            'scalability_plan': self._create_scalability_plan(specification),
            'application_strategy': self._plan_logo_applications(requirements)
        }
        
        return brand_strategy
    
    def _design_logo_concepts(self, brand_strategy: Dict[str, Any], specification: LogoSpecification) -> LogoElements:
        """Design comprehensive logo concepts"""
        
        logo_elements = LogoElements()
        
        # Create primary logo concept
        primary_concept = self._create_primary_logo_concept(specification, brand_strategy)
        logo_elements.graphic_elements.append(primary_concept)
        
        # Create text elements if needed
        if specification.logo_type in ['wordmark', 'combination', 'emblem']:
            text_elements = self._create_text_elements(specification, brand_strategy)
            logo_elements.text_elements.extend(text_elements)
        
        # Create symbolic elements if needed
        if specification.logo_type in ['symbol', 'combination', 'emblem']:
            symbolic_elements = self._create_symbolic_elements(specification, brand_strategy)
            logo_elements.graphic_elements.extend(symbolic_elements)
        
        # Design layout composition
        layout_design = self._design_layout_composition(logo_elements, specification)
        logo_elements.layout = layout_design
        
        return logo_elements
    
    def _apply_typography_and_colors(self, concepts: LogoElements, specification: LogoSpecification) -> LogoElements:
        """Apply sophisticated typography and color systems"""
        
        enhanced_concepts = concepts
        
        # Apply typography system
        typography_config = self.typography_system.get(specification.typography, {})
        
        for text_element in enhanced_concepts.text_elements:
            typography_style = self._create_typography_style(text_element, typography_config, specification)
            enhanced_concepts.typography.append(typography_style)
        
        # Apply color system
        color_palette = self._create_color_palette(specification)
        enhanced_concepts.colors = color_palette
        
        # Apply colors to elements
        enhanced_concepts = self._apply_colors_to_elements(enhanced_concepts, color_palette)
        
        return enhanced_concepts
    
    def _create_brand_guidelines(self, logo_elements: LogoElements, specification: LogoSpecification) -> Dict[str, Any]:
        """Create comprehensive brand guidelines"""
        
        brand_guidelines = {
            'logo_usage': {
                'minimum_sizes': self._define_minimum_sizes(specification),
                'clear_space': self._define_clear_space_requirements(),
                'placement_guidelines': self._create_placement_guidelines(),
                'usage_examples': self._create_usage_examples()
            },
            'color_specifications': {
                'primary_colors': self._extract_primary_colors(logo_elements.colors),
                'secondary_colors': self._extract_secondary_colors(logo_elements.colors),
                'color_codes': self._generate_color_codes(logo_elements.colors),
                'color_usage_rules': self._create_color_usage_rules()
            },
            'typography_guidelines': {
                'primary_typeface': self._extract_primary_typeface(logo_elements.typography),
                'secondary_typefaces': self._extract_secondary_typefaces(logo_elements.typography),
                'typography_hierarchy': self._create_typography_hierarchy(),
                'usage_specifications': self._create_typography_usage_specs()
            },
            'logo_variations': {
                'horizontal_version': self._create_horizontal_variation(logo_elements),
                'vertical_version': self._create_vertical_variation(logo_elements),
                'icon_only_version': self._create_icon_only_variation(logo_elements),
                'monochrome_versions': self._create_monochrome_variations(logo_elements)
            }
        }
        
        return brand_guidelines
    
    def _generate_logo_variations(self, logo_elements: LogoElements, specification: LogoSpecification) -> Dict[str, Any]:
        """Generate comprehensive logo variations"""
        
        variations = {}
        
        # Size variations
        variations['size_variations'] = {
            'large_format': self._create_large_format_version(logo_elements),
            'medium_format': self._create_medium_format_version(logo_elements),
            'small_format': self._create_small_format_version(logo_elements),
            'favicon': self._create_favicon_version(logo_elements)
        }
        
        # Color variations
        variations['color_variations'] = {
            'full_color': self._create_full_color_version(logo_elements),
            'two_color': self._create_two_color_version(logo_elements),
            'single_color': self._create_single_color_version(logo_elements),
            'reversed': self._create_reversed_version(logo_elements)
        }
        
        # Format variations
        variations['format_variations'] = {
            'svg_vector': self._generate_svg_version(logo_elements, specification),
            'png_raster': self._generate_png_specifications(logo_elements),
            'eps_print': self._generate_eps_specifications(logo_elements),
            'pdf_document': self._generate_pdf_specifications(logo_elements)
        }
        
        # Application variations
        variations['application_variations'] = {
            'business_card': self._create_business_card_version(logo_elements),
            'letterhead': self._create_letterhead_version(logo_elements),
            'website_header': self._create_website_header_version(logo_elements),
            'social_media': self._create_social_media_versions(logo_elements)
        }
        
        return variations
    
    def _create_comprehensive_brand_package(self, logo_variations: Dict[str, Any], brand_guidelines: Dict[str, Any]) -> Dict[str, Any]:
        """Create comprehensive brand package"""
        
        brand_package = {
            'primary_logo_files': logo_variations['format_variations'],
            'logo_variations': logo_variations,
            'brand_guidelines': brand_guidelines,
            'application_examples': self._create_application_examples(logo_variations),
            'brand_assets': self._create_brand_asset_library(logo_variations, brand_guidelines),
            'implementation_guide': self._create_implementation_guide(brand_guidelines),
            'quality_checklist': self._create_quality_checklist(),
            'trademark_considerations': self._create_trademark_guidance()
        }
        
        return brand_package
    
    # Helper methods for requirement analysis
    def _extract_brand_name(self, user_input: str) -> str:
        """Extract brand name from user input"""
        # Look for quoted names or capitalized words
        quoted_match = re.search(r'"([^"]+)"', user_input)
        if quoted_match:
            return quoted_match.group(1)
        
        # Look for "logo for [brand name]" patterns
        for_match = re.search(r'logo for ([A-Z][a-zA-Z0-9\s]+)', user_input)
        if for_match:
            return for_match.group(1).strip()
        
        # Look for "called [brand name]" patterns
        called_match = re.search(r'called ([A-Z][a-zA-Z0-9\s]+)', user_input)
        if called_match:
            return called_match.group(1).strip()
        
        return "Brand Name"  # Default placeholder
    
    def _detect_logo_type(self, text: str) -> str:
        """Detect preferred logo type"""
        if re.search(r'\b(text only|wordmark|typography|lettering)\b', text):
            return 'wordmark'
        elif re.search(r'\b(symbol only|icon only|mark|symbol)\b', text):
            return 'symbol'
        elif re.search(r'\b(combination|text and symbol|logo and text)\b', text):
            return 'combination'
        elif re.search(r'\b(emblem|badge|seal|crest)\b', text):
            return 'emblem'
        elif re.search(r'\b(monogram|initials|letters only)\b', text):
            return 'monogram'
        else:
            return 'combination'  # Most versatile default
    
    def _detect_industry_context(self, text: str) -> str:
        """Detect industry context"""
        if re.search(r'\b(tech|technology|software|digital|app|startup)\b', text):
            return 'technology'
        elif re.search(r'\b(health|medical|healthcare|doctor|clinic|hospital)\b', text):
            return 'healthcare'
        elif re.search(r'\b(finance|bank|financial|investment|money)\b', text):
            return 'finance'
        elif re.search(r'\b(creative|design|art|agency|studio|artist)\b', text):
            return 'creative'
        elif re.search(r'\b(retail|store|shop|ecommerce|sales)\b', text):
            return 'retail'
        elif re.search(r'\b(food|restaurant|cafe|culinary|dining)\b', text):
            return 'food'
        elif re.search(r'\b(education|school|university|learning|academic)\b', text):
            return 'education'
        else:
            return 'technology'  # Default to technology
    
    def _detect_style_preferences(self, text: str) -> Dict[str, str]:
        """Detect style preferences"""
        preferences = {
            'primary_style': 'modern',
            'typography_preference': 'sans_serif',
            'visual_approach': 'balanced'
        }
        
        # Style detection
        if re.search(r'\b(modern|contemporary|current|fresh|clean)\b', text):
            preferences['primary_style'] = 'modern'
        elif re.search(r'\b(classic|traditional|timeless|established)\b', text):
            preferences['primary_style'] = 'classic'
        elif re.search(r'\b(vintage|retro|nostalgic|old.fashioned)\b', text):
            preferences['primary_style'] = 'vintage'
        elif re.search(r'\b(minimal|minimalist|simple|clean|basic)\b', text):
            preferences['primary_style'] = 'minimalist'
        elif re.search(r'\b(bold|strong|powerful|impactful|striking)\b', text):
            preferences['primary_style'] = 'bold'
        elif re.search(r'\b(elegant|sophisticated|refined|luxury|premium)\b', text):
            preferences['primary_style'] = 'elegant'
        
        # Typography detection
        if re.search(r'\b(serif|traditional|classic.font)\b', text):
            preferences['typography_preference'] = 'serif'
        elif re.search(r'\b(script|handwritten|elegant.font|flowing)\b', text):
            preferences['typography_preference'] = 'script'
        elif re.search(r'\b(display|decorative|unique.font|custom)\b', text):
            preferences['typography_preference'] = 'display'
        
        return preferences
    
    def _detect_color_preferences(self, text: str) -> Dict[str, Any]:
        """Detect color preferences"""
        preferences = {
            'scheme_type': 'monochrome',
            'preferred_colors': [],
            'color_psychology': []
        }
        
        # Color scheme detection
        if re.search(r'\b(colorful|full.color|vibrant|rainbow)\b', text):
            preferences['scheme_type'] = 'full_color'
        elif re.search(r'\b(two.color|dual.color|limited.palette)\b', text):
            preferences['scheme_type'] = 'two_color'
        elif re.search(r'\b(gradient|blend|transition)\b', text):
            preferences['scheme_type'] = 'gradient'
        
        # Specific color detection
        color_patterns = {
            'blue': r'\b(blue|navy|azure|cyan)\b',
            'red': r'\b(red|crimson|scarlet|burgundy)\b',
            'green': r'\b(green|emerald|forest|lime)\b',
            'orange': r'\b(orange|amber|tangerine)\b',
            'purple': r'\b(purple|violet|lavender|magenta)\b',
            'black': r'\b(black|dark|charcoal)\b',
            'white': r'\b(white|light|bright|clean)\b',
            'gray': r'\b(gray|grey|silver|neutral)\b'
        }
        
        for color, pattern in color_patterns.items():
            if re.search(pattern, text):
                preferences['preferred_colors'].append(color)
        
        return preferences
    
    def _detect_usage_requirements(self, text: str) -> Dict[str, Any]:
        """Detect usage requirements"""
        requirements = {
            'primary_applications': [],
            'scalability_needs': 'standard',
            'versatility_level': 'medium'
        }
        
        # Application detection
        if re.search(r'\b(website|web|online|digital)\b', text):
            requirements['primary_applications'].append('digital')
        if re.search(r'\b(business.card|stationery|print|paper)\b', text):
            requirements['primary_applications'].append('print')
        if re.search(r'\b(signage|sign|billboard|large.format)\b', text):
            requirements['primary_applications'].append('large_format')
        if re.search(r'\b(merchandise|product|apparel|promotional)\b', text):
            requirements['primary_applications'].append('merchandise')
        
        # Scalability detection
        if re.search(r'\b(small.sizes|favicon|tiny|miniature)\b', text):
            requirements['scalability_needs'] = 'high'
        elif re.search(r'\b(large.format|billboard|building.signage)\b', text):
            requirements['scalability_needs'] = 'extreme'
        
        return requirements
    
    def _detect_brand_personality(self, text: str, industry: str) -> List[str]:
        """Detect brand personality traits"""
        personality_traits = []
        
        # Personality keywords mapping
        personality_keywords = {
            'professional': r'\b(professional|corporate|business|formal)\b',
            'creative': r'\b(creative|artistic|innovative|unique)\b',
            'friendly': r'\b(friendly|approachable|warm|welcoming)\b',
            'trustworthy': r'\b(trustworthy|reliable|dependable|honest)\b',
            'modern': r'\b(modern|contemporary|cutting.edge|progressive)\b',
            'elegant': r'\b(elegant|sophisticated|refined|premium)\b',
            'energetic': r'\b(energetic|dynamic|active|vibrant)\b',
            'stable': r'\b(stable|established|solid|consistent)\b'
        }
        
        for trait, pattern in personality_keywords.items():
            if re.search(pattern, text):
                personality_traits.append(trait)
        
        # Add industry-default personality traits if none detected
        if not personality_traits:
            industry_defaults = self.industry_guidelines.get(industry, {}).get('brand_personality', [])
            personality_traits.extend(industry_defaults[:2])  # Take first 2 defaults
        
        return personality_traits or ['professional', 'modern']  # Fallback defaults
    
    def _identify_target_audience(self, text: str, industry: str) -> Dict[str, Any]:
        """Identify target audience characteristics"""
        audience = {
            'demographics': [],
            'psychographics': [],
            'professional_level': 'mixed'
        }
        
        # Demographic detection
        if re.search(r'\b(young|millennial|gen.z|youth)\b', text):
            audience['demographics'].append('young_adults')
        if re.search(r'\b(professional|business|corporate|executive)\b', text):
            audience['demographics'].append('professionals')
        if re.search(r'\b(consumer|customer|general.public)\b', text):
            audience['demographics'].append('general_consumers')
        
        # Professional level detection
        if re.search(r'\b(executive|c.level|leadership|senior)\b', text):
            audience['professional_level'] = 'executive'
        elif re.search(r'\b(technical|expert|specialist|professional)\b', text):
            audience['professional_level'] = 'professional'
        elif re.search(r'\b(general|consumer|everyday|mass.market)\b', text):
            audience['professional_level'] = 'general'
        
        return audience
    
    # Logo creation helper methods (simplified implementations)
    def _define_brand_positioning(self, requirements: Dict[str, Any], industry_guidelines: Dict[str, Any]) -> Dict[str, Any]:
        """Define brand positioning strategy"""
        return {
            'market_position': 'premium' if 'elegant' in requirements.get('brand_personality', []) else 'mainstream',
            'differentiation_factors': requirements.get('brand_personality', []),
            'competitive_advantage': 'design_excellence'
        }
    
    def _establish_visual_hierarchy(self, specification: LogoSpecification) -> Dict[str, Any]:
        """Establish visual hierarchy"""
        return {
            'primary_element': 'brand_name' if specification.logo_type == 'wordmark' else 'symbol',
            'secondary_elements': ['tagline', 'supporting_graphics'],
            'visual_weight_distribution': 'balanced'
        }
    
    def _define_brand_attributes(self, requirements: Dict[str, Any]) -> List[str]:
        """Define core brand attributes"""
        return requirements.get('brand_personality', ['professional', 'modern'])
    
    def _create_differentiation_strategy(self, requirements: Dict[str, Any], specification: LogoSpecification) -> Dict[str, Any]:
        """Create differentiation strategy"""
        return {
            'unique_elements': ['custom_typography', 'distinctive_symbol'],
            'competitive_differentiation': 'visual_sophistication',
            'brand_recognition_factors': ['color_system', 'typography_choice']
        }
    
    def _create_scalability_plan(self, specification: LogoSpecification) -> Dict[str, Any]:
        """Create scalability plan"""
        return {
            'minimum_size': '16px',
            'maximum_size': 'unlimited',
            'scalability_approach': 'vector_based',
            'detail_reduction_strategy': 'progressive_simplification'
        }
    
    def _plan_logo_applications(self, requirements: Dict[str, Any]) -> List[str]:
        """Plan logo applications"""
        return requirements.get('usage_requirements', {}).get('primary_applications', ['digital', 'print'])
    
    def _create_primary_logo_concept(self, specification: LogoSpecification, brand_strategy: Dict[str, Any]) -> Dict[str, Any]:
        """Create primary logo concept"""
        return {
            'type': 'primary_logo',
            'logo_type': specification.logo_type,
            'design_approach': specification.style,
            'conceptual_foundation': brand_strategy.get('brand_positioning', {}),
            'visual_elements': self._define_visual_elements(specification)
        }
    
    def _create_text_elements(self, specification: LogoSpecification, brand_strategy: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create text elements"""
        text_elements = []
        
        if specification.logo_type in ['wordmark', 'combination', 'emblem']:
            primary_text = {
                'type': 'primary_text',
                'content': 'Brand Name',
                'typography_style': specification.typography,
                'hierarchy_level': 'primary',
                'treatment': 'custom_lettering' if specification.style == 'unique' else 'font_based'
            }
            text_elements.append(primary_text)
        
        return text_elements
    
    def _create_symbolic_elements(self, specification: LogoSpecification, brand_strategy: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create symbolic elements"""
        symbolic_elements = []
        
        if specification.logo_type in ['symbol', 'combination', 'emblem']:
            primary_symbol = {
                'type': 'primary_symbol',
                'design_approach': specification.style,
                'industry_relevance': specification.industry,
                'symbolic_meaning': self._define_symbolic_meaning(specification),
                'geometric_foundation': self._define_geometric_foundation(specification)
            }
            symbolic_elements.append(primary_symbol)
        
        return symbolic_elements
    
    def _design_layout_composition(self, logo_elements: LogoElements, specification: LogoSpecification) -> Dict[str, Any]:
        """Design layout composition"""
        return {
            'composition_type': self._determine_composition_type(specification.logo_type),
            'element_relationships': self._define_element_relationships(logo_elements),
            'visual_balance': 'centered',
            'proportional_system': 'golden_ratio',
            'spacing_system': 'geometric_progression'
        }
    
    def _create_typography_style(self, text_element: Dict[str, Any], typography_config: Dict[str, Any], specification: LogoSpecification) -> Dict[str, Any]:
        """Create typography style"""
        return {
            'font_family': self._select_font_family(specification.typography, specification.industry),
            'font_weight': self._determine_font_weight(specification.style),
            'letter_spacing': self._calculate_letter_spacing(specification.style),
            'character_modifications': self._define_character_modifications(specification),
            'custom_elements': self._identify_custom_typography_elements(specification)
        }
    
    def _create_color_palette(self, specification: LogoSpecification) -> List[Dict[str, Any]]:
        """Create comprehensive color palette"""
        color_palette = []
        
        if specification.color_scheme == 'monochrome':
            color_palette.extend([
                {'name': 'primary_black', 'hex': '#000000', 'usage': 'primary'},
                {'name': 'secondary_gray', 'hex': '#666666', 'usage': 'secondary'},
                {'name': 'light_gray', 'hex': '#CCCCCC', 'usage': 'background'}
            ])
        elif specification.color_scheme == 'two_color':
            primary_color = self._select_primary_color(specification.industry, specification.style)
            color_palette.extend([
                {'name': 'primary_color', 'hex': primary_color, 'usage': 'primary'},
                {'name': 'secondary_black', 'hex': '#000000', 'usage': 'secondary'}
            ])
        else:  # full_color
            colors = self._create_full_color_palette(specification.industry, specification.style)
            color_palette.extend(colors)
        
        return color_palette
    
    def _apply_colors_to_elements(self, elements: LogoElements, color_palette: List[Dict[str, Any]]) -> LogoElements:
        """Apply colors to logo elements"""
        enhanced_elements = elements
        
        # Apply colors based on element hierarchy
        primary_color = next((c for c in color_palette if c['usage'] == 'primary'), color_palette[0])
        
        for element in enhanced_elements.graphic_elements:
            element['color'] = primary_color['hex']
        
        for element in enhanced_elements.text_elements:
            element['color'] = primary_color['hex']
        
        return enhanced_elements
    
    # Additional helper methods would continue here...
    # Due to length constraints, I'm showing the core structure and key methods
    
    def _define_visual_elements(self, specification: LogoSpecification) -> List[str]:
        """Define visual elements for the logo"""
        style_config = self.design_styles.get(specification.style, {})
        return style_config.get('visual_elements', ['geometric_shapes', 'clean_lines'])
    
    def _define_symbolic_meaning(self, specification: LogoSpecification) -> str:
        """Define symbolic meaning for the logo"""
        industry_guidelines = self.industry_guidelines.get(specification.industry, {})
        return f"Represents {specification.industry} industry values and brand personality"
    
    def _define_geometric_foundation(self, specification: LogoSpecification) -> str:
        """Define geometric foundation"""
        if specification.style == 'modern':
            return 'geometric_precision'
        elif specification.style == 'organic':
            return 'natural_curves'
        else:
            return 'balanced_proportions'
    
    def _determine_composition_type(self, logo_type: str) -> str:
        """Determine composition type"""
        composition_mapping = {
            'wordmark': 'horizontal_text',
            'symbol': 'centered_icon',
            'combination': 'text_and_symbol',
            'emblem': 'enclosed_composition',
            'monogram': 'letter_based'
        }
        return composition_mapping.get(logo_type, 'balanced')
    
    def _define_element_relationships(self, logo_elements: LogoElements) -> Dict[str, str]:
        """Define relationships between logo elements"""
        return {
            'text_to_symbol': 'complementary',
            'visual_hierarchy': 'balanced',
            'spatial_relationship': 'proportional'
        }
    
    def _select_font_family(self, typography_type: str, industry: str) -> str:
        """Select appropriate font family"""
        font_mapping = {
            'sans_serif': 'Modern Sans Serif',
            'serif': 'Classic Serif',
            'script': 'Elegant Script',
            'display': 'Custom Display'
        }
        return font_mapping.get(typography_type, 'Modern Sans Serif')
    
    def _determine_font_weight(self, style: str) -> str:
        """Determine font weight based on style"""
        weight_mapping = {
            'bold': 'heavy',
            'elegant': 'light',
            'modern': 'medium',
            'classic': 'regular'
        }
        return weight_mapping.get(style, 'medium')
    
    def _calculate_letter_spacing(self, style: str) -> str:
        """Calculate letter spacing"""
        spacing_mapping = {
            'minimalist': 'wide',
            'bold': 'tight',
            'elegant': 'normal',
            'modern': 'slight'
        }
        return spacing_mapping.get(style, 'normal')
    
    def _define_character_modifications(self, specification: LogoSpecification) -> List[str]:
        """Define character modifications"""
        if specification.style == 'custom':
            return ['custom_letterforms', 'unique_connections', 'stylized_characters']
        return ['standard_letterforms']
    
    def _identify_custom_typography_elements(self, specification: LogoSpecification) -> List[str]:
        """Identify custom typography elements"""
        if specification.complexity == 'complex':
            return ['custom_ligatures', 'decorative_elements', 'unique_character_treatments']
        return ['standard_typography']
    
    # Color selection methods
    def _select_primary_color(self, industry: str, style: str) -> str:
        """Select primary color based on industry and style"""
        industry_colors = {
            'technology': '#0066CC',
            'healthcare': '#00AA44',
            'finance': '#003366',
            'creative': '#FF6600',
            'retail': '#CC0066'
        }
        return industry_colors.get(industry, '#000000')
    
    def _create_full_color_palette(self, industry: str, style: str) -> List[Dict[str, Any]]:
        """Create full color palette"""
        return [
            {'name': 'primary', 'hex': self._select_primary_color(industry, style), 'usage': 'primary'},
            {'name': 'secondary', 'hex': '#666666', 'usage': 'secondary'},
            {'name': 'accent', 'hex': '#FF6600', 'usage': 'accent'}
        ]
    
    # Brand guidelines helper methods
    def _define_minimum_sizes(self, specification: LogoSpecification) -> Dict[str, str]:
        """Define minimum logo sizes"""
        return {
            'print': '0.5 inches',
            'digital': '32px',
            'favicon': '16px'
        }
    
    def _define_clear_space_requirements(self) -> Dict[str, str]:
        """Define clear space requirements"""
        return {
            'minimum_clear_space': '1x logo height',
            'preferred_clear_space': '2x logo height',
            'critical_applications': '3x logo height'
        }
    
    def _create_placement_guidelines(self) -> List[str]:
        """Create placement guidelines"""
        return [
            'Always maintain clear space',
            'Avoid busy backgrounds',
            'Ensure adequate contrast',
            'Maintain proportional scaling'
        ]
    
    def _create_usage_examples(self) -> List[Dict[str, str]]:
        """Create usage examples"""
        return [
            {'application': 'business_card', 'specifications': 'Minimum 0.5 inch width'},
            {'application': 'website_header', 'specifications': 'Minimum 120px width'},
            {'application': 'letterhead', 'specifications': 'Top left or center placement'}
        ]
    
    def _extract_primary_colors(self, colors: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Extract primary colors"""
        return [c for c in colors if c.get('usage') == 'primary']
    
    def _extract_secondary_colors(self, colors: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Extract secondary colors"""
        return [c for c in colors if c.get('usage') == 'secondary']
    
    def _generate_color_codes(self, colors: List[Dict[str, Any]]) -> Dict[str, Dict[str, str]]:
        """Generate comprehensive color codes"""
        color_codes = {}
        for color in colors:
            color_codes[color['name']] = {
                'hex': color['hex'],
                'rgb': self._hex_to_rgb(color['hex']),
                'cmyk': self._hex_to_cmyk(color['hex']),
                'pantone': f"PMS {color['name']}"  # Simplified
            }
        return color_codes
    
    def _create_color_usage_rules(self) -> List[str]:
        """Create color usage rules"""
        return [
            'Use primary color for main brand elements',
            'Use secondary colors for supporting elements',
            'Ensure sufficient contrast for readability',
            'Test colors across different media'
        ]
    
    # Utility methods
    def _hex_to_rgb(self, hex_color: str) -> str:
        """Convert hex to RGB"""
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        return f"rgb({r}, {g}, {b})"
    
    def _hex_to_cmyk(self, hex_color: str) -> str:
        """Convert hex to CMYK (simplified)"""
        return "CMYK conversion required"  # Simplified
    
    def _calculate_scalability_score(self, logo_elements: LogoElements) -> float:
        """Calculate scalability score"""
        base_score = 0.8
        if len(logo_elements.graphic_elements) < 3:  # Simpler designs scale better
            base_score += 0.1
        if len(logo_elements.text_elements) == 1:  # Single text element scales better
            base_score += 0.1
        return min(1.0, base_score)
    
    # Format generation methods (simplified)
    def _generate_svg_version(self, logo_elements: LogoElements, specification: LogoSpecification) -> str:
        """Generate SVG version of the logo"""
        return f'''<?xml version="1.0" encoding="UTF-8"?>
<svg width="200" height="100" xmlns="http://www.w3.org/2000/svg">
  <title>{specification.logo_type.title()} Logo</title>
  <rect x="10" y="10" width="180" height="80" fill="none" stroke="black" stroke-width="2"/>
  <text x="100" y="55" text-anchor="middle" font-size="18" font-family="Arial">LOGO</text>
</svg>'''
    
    def _generate_png_specifications(self, logo_elements: LogoElements) -> Dict[str, str]:
        """Generate PNG specifications"""
        return {
            'high_resolution': '300 DPI, 2400x1200px',
            'web_resolution': '72 DPI, 400x200px',
            'social_media': '72 DPI, 500x500px'
        }
    
    def _generate_eps_specifications(self, logo_elements: LogoElements) -> Dict[str, str]:
        """Generate EPS specifications"""
        return {
            'vector_format': 'Scalable vector format',
            'color_mode': 'CMYK for print',
            'compatibility': 'Adobe Illustrator compatible'
        }
    
    def _generate_pdf_specifications(self, logo_elements: LogoElements) -> Dict[str, str]:
        """Generate PDF specifications"""
        return {
            'format': 'PDF/X-1a for print',
            'color_profile': 'CMYK',
            'resolution': 'Vector-based, infinite scalability'
        }
    
    # Variation creation methods (simplified implementations)
    def _create_large_format_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create large format version"""
        return {'format': 'large_format', 'optimizations': ['high_detail', 'full_complexity']}
    
    def _create_medium_format_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create medium format version"""
        return {'format': 'medium_format', 'optimizations': ['balanced_detail', 'versatile_usage']}
    
    def _create_small_format_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create small format version"""
        return {'format': 'small_format', 'optimizations': ['simplified_details', 'enhanced_readability']}
    
    def _create_favicon_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create favicon version"""
        return {'format': 'favicon', 'optimizations': ['maximum_simplification', 'icon_only']}
    
    def _create_full_color_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create full color version"""
        return {'version': 'full_color', 'colors': 'all_brand_colors'}
    
    def _create_two_color_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create two color version"""
        return {'version': 'two_color', 'colors': 'primary_and_black'}
    
    def _create_single_color_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create single color version"""
        return {'version': 'single_color', 'colors': 'black_only'}
    
    def _create_reversed_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create reversed version"""
        return {'version': 'reversed', 'colors': 'white_on_dark'}
    
    # Application-specific methods
    def _create_business_card_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create business card optimized version"""
        return {'application': 'business_card', 'specifications': 'Small format optimized'}
    
    def _create_letterhead_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create letterhead version"""
        return {'application': 'letterhead', 'specifications': 'Header placement optimized'}
    
    def _create_website_header_version(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create website header version"""
        return {'application': 'website_header', 'specifications': 'Horizontal format optimized'}
    
    def _create_social_media_versions(self, logo_elements: LogoElements) -> Dict[str, Any]:
        """Create social media versions"""
        return {
            'facebook': {'format': 'square', 'size': '500x500px'},
            'twitter': {'format': 'square', 'size': '400x400px'},
            'instagram': {'format': 'square', 'size': '500x500px'},
            'linkedin': {'format': 'square', 'size': '300x300px'}
        }
    
    # Final package methods
    def _create_application_examples(self, logo_variations: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create application examples"""
        return [
            {'application': 'Business Card', 'description': 'Professional business card implementation'},
            {'application': 'Website Header', 'description': 'Digital header implementation'},
            {'application': 'Letterhead', 'description': 'Corporate stationery implementation'}
        ]
    
    def _create_brand_asset_library(self, logo_variations: Dict[str, Any], brand_guidelines: Dict[str, Any]) -> Dict[str, Any]:
        """Create brand asset library"""
        return {
            'logo_files': logo_variations['format_variations'],
            'color_swatches': brand_guidelines['color_specifications'],
            'typography_files': brand_guidelines['typography_guidelines'],
            'template_files': ['business_card_template', 'letterhead_template', 'presentation_template']
        }
    
    def _create_implementation_guide(self, brand_guidelines: Dict[str, Any]) -> List[str]:
        """Create implementation guide"""
        return [
            'Review brand guidelines thoroughly',
            'Use provided logo files for all applications',
            'Maintain consistent color usage',
            'Follow typography specifications',
            'Ensure proper logo placement and sizing'
        ]
    
    def _create_quality_checklist(self) -> List[str]:
        """Create quality checklist"""
        return [
            'Logo scalability tested at various sizes',
            'Color variations created and tested',
            'Typography legibility confirmed',
            'Brand guidelines documentation complete',
            'File formats optimized for intended use'
        ]
    
    def _create_trademark_guidance(self) -> Dict[str, Any]:
        """Create trademark guidance"""
        return {
            'trademark_search': 'Conduct thorough trademark search before use',
            'registration_advice': 'Consider trademark registration for brand protection',
            'usage_monitoring': 'Monitor for unauthorized usage',
            'legal_considerations': 'Consult legal counsel for trademark matters'
        }