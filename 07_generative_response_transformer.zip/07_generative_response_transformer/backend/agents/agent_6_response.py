# 🗣️ Form raw textual response

from .base_agent import BaseAgent
from typing import Dict, Any

class ResponseAgent(BaseAgent):
    """Agent 6: Form raw textual response"""
    
    def __init__(self):
        super().__init__(
            name="ResponseAgent", 
            description="Form raw textual response"
        )
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        user_input = pipeline_data.get('current_response', '')
        intent_data = pipeline_data.get('stage_results', {}).get(3, {}).get('metadata', {})
        structure_data = pipeline_data.get('stage_results', {}).get(5, {}).get('metadata', {})
        
        self._log_processing(user_input)
        
        # Generate raw response based on intent and structure
        raw_response = self._generate_raw_response(user_input, intent_data, structure_data)
        
        return self._create_result(
            output=raw_response,
            metadata={
                'response_generated': True,
                'response_type': intent_data.get('user_intent', 'general'),
                'word_count': len(raw_response.split())
            }
        )
    
    def _generate_raw_response(self, user_input: str, intent_data: Dict[str, Any], structure_data: Dict[str, Any]) -> str:
        """Generate raw textual response"""
        user_intent = intent_data.get('user_intent', 'general')
        
        if user_intent == 'greeting':
            return self._greeting_response(user_input)
        elif user_intent == 'question':
            return self._question_response(user_input)
        elif user_intent == 'creation':
            return self._creation_response(user_input)
        elif user_intent == 'assistance':
            return self._assistance_response(user_input)
        else:
            return self._general_response(user_input)
    
    def _greeting_response(self, user_input: str) -> str:
        return "Hello! I'm the Generative Response Transformer, a sophisticated 37-agent AI system. I'm here to help you with intelligent conversations, creative tasks, and problem-solving. What can I assist you with today?"
    
    def _question_response(self, user_input: str) -> str:
        return f"I understand you're asking about: '{user_input}'. Let me analyze this and provide you with a comprehensive answer based on my 37-agent processing pipeline."
    
    def _creation_response(self, user_input: str) -> str:
        return f"I'd be happy to help create what you're looking for: '{user_input}'. My generative capabilities can assist with content creation, problem-solving, and innovative solutions."
    
    def _assistance_response(self, user_input: str) -> str:
        return f"I'm here to help with: '{user_input}'. My 37-agent system provides comprehensive assistance across multiple domains and capabilities."
    
    def _general_response(self, user_input: str) -> str:
        return f"Thank you for your input: '{user_input}'. I'm processing this through my advanced multi-agent system to provide you with the most helpful response."