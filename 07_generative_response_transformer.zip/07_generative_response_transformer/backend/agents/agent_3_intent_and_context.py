# 🎯 Classify user intent + context setup

from .base_agent import BaseAgent
from typing import Dict, Any

class IntentContextAgent(BaseAgent):
    """Agent 3: Classify user intent + context setup"""
    
    def __init__(self):
        super().__init__(
            name="IntentContextAgent",
            description="Classify user intent + context setup"
        )
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        user_input = pipeline_data.get('current_response', '')
        self._log_processing(user_input)
        
        # Classify intent and set up context
        intent = self._classify_intent(user_input)
        context = self._setup_context(user_input, intent)
        
        return self._create_result(
            output=user_input,
            metadata={
                'user_intent': intent,
                'context_setup': context,
                'intent_confidence': self._calculate_confidence(user_input, intent)
            }
        )
    
    def _classify_intent(self, text: str) -> str:
        """Classify the user's intent"""
        text_lower = text.lower()
        
        if any(word in text_lower for word in ['hello', 'hi', 'hey', 'good morning']):
            return 'greeting'
        elif any(word in text_lower for word in ['create', 'make', 'build', 'generate']):
            return 'creation'
        elif any(word in text_lower for word in ['?', 'what', 'how', 'why', 'when', 'where']):
            return 'question'
        elif any(word in text_lower for word in ['help', 'assist', 'support']):
            return 'assistance'
        elif any(word in text_lower for word in ['explain', 'tell me', 'describe']):
            return 'information'
        else:
            return 'general'
    
    def _setup_context(self, text: str, intent: str) -> Dict[str, Any]:
        """Setup context based on intent"""
        return {
            'intent_type': intent,
            'requires_creation': intent == 'creation',
            'requires_explanation': intent in ['question', 'information'],
            'is_conversational': intent in ['greeting', 'general'],
            'complexity': 'high' if intent == 'creation' else 'medium'
        }
    
    def _calculate_confidence(self, text: str, intent: str) -> float:
        """Calculate confidence in intent classification"""
        # Simple confidence calculation
        return 0.85  # Placeholder