# ⚙️ Process response flow structure

from .base_agent import BaseAgent
from typing import Dict, Any

class ProcessingAgent(BaseAgent):
    """Agent 5: Process response flow structure"""
    
    def __init__(self):
        super().__init__(
            name="ProcessingAgent",
            description="Process response flow structure"
        )
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        user_input = pipeline_data.get('current_response', '')
        intent_data = pipeline_data.get('stage_results', {}).get(3, {}).get('metadata', {})
        
        self._log_processing(user_input)
        
        # Structure the response flow
        response_structure = self._create_response_structure(user_input, intent_data)
        
        return self._create_result(
            output=user_input,
            metadata={
                'response_structure': response_structure,
                'flow_type': self._determine_flow_type(intent_data),
                'processing_complete': True
            }
        )
    
    def _create_response_structure(self, text: str, intent_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create structured response flow"""
        user_intent = intent_data.get('user_intent', 'general')
        
        if user_intent == 'greeting':
            return {
                'opening': 'greeting_response',
                'body': 'capability_introduction',
                'closing': 'offer_help'
            }
        elif user_intent == 'question':
            return {
                'opening': 'acknowledge_question',
                'body': 'provide_answer',
                'closing': 'offer_clarification'
            }
        elif user_intent == 'creation':
            return {
                'opening': 'acknowledge_request',
                'body': 'creation_process',
                'closing': 'present_result'
            }
        else:
            return {
                'opening': 'acknowledge_input',
                'body': 'provide_response',
                'closing': 'continue_conversation'
            }
    
    def _determine_flow_type(self, intent_data: Dict[str, Any]) -> str:
        """Determine the type of response flow needed"""
        user_intent = intent_data.get('user_intent', 'general')
        
        flow_mapping = {
            'greeting': 'conversational',
            'question': 'informative',
            'creation': 'generative',
            'assistance': 'supportive',
            'information': 'explanatory'
        }
        
        return flow_mapping.get(user_intent, 'standard')