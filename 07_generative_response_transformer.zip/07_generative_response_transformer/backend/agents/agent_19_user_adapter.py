# 🧍 Adapts tone for user profile

from .base_agent import BaseAgent
from typing import Dict, Any

class UserAdapterAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="UserAdapterAgent", description="Adapts tone for user profile")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        user_id = pipeline_data.get('user_id', 'anonymous')
        self._log_processing(current_response)
        
        adapted_response = self._adapt_for_user(current_response, user_id)
        
        return self._create_result(
            output=adapted_response,
            metadata={'user_adaptation_applied': True, 'user_profile': 'default'}
        )
    
    def _adapt_for_user(self, response: str, user_id: str) -> str:
        # Basic user adaptation - could be enhanced with user profiles
        return response
# 🎯 Advanced User Adapter - Personalizes responses and adapts to user preferences

from .base_agent import BaseAgent
from typing import Dict, Any, List, Tuple, Optional, Union
import json
import re
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from collections import defaultdict

@dataclass
class UserProfile:
    """Comprehensive user profile and preferences"""
    user_id: str = "anonymous"
    communication_style: str = "balanced"  # formal, casual, balanced, technical, creative
    expertise_level: str = "intermediate"  # beginner, intermediate, advanced, expert
    preferred_language: str = "en"
    interaction_history: List[Dict[str, Any]] = field(default_factory=list)
    learning_preferences: Dict[str, Any] = field(default_factory=dict)
    response_preferences: Dict[str, Any] = field(default_factory=dict)
    accessibility_needs: Dict[str, Any] = field(default_factory=dict)
    context_memory: Dict[str, Any] = field(default_factory=dict)

@dataclass
class AdaptationStrategy:
    """User adaptation strategy configuration"""
    personalization_level: str = "high"  # none, basic, moderate, high, maximum
    learning_adaptation: bool = True
    style_adaptation: bool = True
    complexity_adaptation: bool = True
    cultural_adaptation: bool = True
    temporal_adaptation: bool = True  # Time-based adaptation
    contextual_adaptation: bool = True

class UserAdapterAgent(BaseAgent):
    """Agent 19: Advanced user adaptation with deep personalization and learning capabilities"""
    
    def __init__(self):
        super().__init__(
            name="UserAdapterAgent",
            description="Advanced user adaptation with deep personalization, learning preferences, and dynamic response customization",
            priority=8
        )
        
        # User adaptation capabilities
        self.adaptation_capabilities = [
            'communication_style_adaptation', 'expertise_level_adjustment', 'response_personalization',
            'learning_preference_integration', 'cultural_sensitivity_adaptation', 'accessibility_optimization',
            'context_memory_management', 'interaction_pattern_analysis', 'preference_learning',
            'dynamic_complexity_adjustment', 'temporal_behavior_adaptation', 'engagement_optimization'
        ]
        
        # Communication style templates
        self.communication_styles = {
            'formal': {
                'tone': 'professional and respectful',
                'structure': 'well-organized with clear sections',
                'language': 'precise and technical terminology',
                'examples': 'industry-standard examples and references'
            },
            'casual': {
                'tone': 'friendly and conversational',
                'structure': 'natural flow with informal transitions',
                'language': 'everyday language with minimal jargon',
                'examples': 'relatable analogies and common scenarios'
            },
            'balanced': {
                'tone': 'professional yet approachable',
                'structure': 'clear organization with smooth flow',
                'language': 'accessible technical terms with explanations',
                'examples': 'practical examples with clear explanations'
            },
            'technical': {
                'tone': 'precise and analytical',
                'structure': 'detailed and systematic presentation',
                'language': 'technical terminology and specifications',
                'examples': 'technical documentation and code examples'
            },
            'creative': {
                'tone': 'inspiring and imaginative',
                'structure': 'engaging narrative with creative elements',
                'language': 'expressive and metaphorical language',
                'examples': 'innovative approaches and creative solutions'
            }
        }
        
        # Expertise level configurations
        self.expertise_levels = {
            'beginner': {
                'complexity': 'simple and straightforward',
                'detail_level': 'high explanation detail',
                'terminology': 'basic terms with definitions',
                'examples': 'step-by-step tutorials',
                'support': 'extensive guidance and encouragement'
            },
            'intermediate': {
                'complexity': 'moderate with some advanced concepts',
                'detail_level': 'balanced explanation depth',
                'terminology': 'standard terms with context',
                'examples': 'practical applications and use cases',
                'support': 'structured guidance with independence'
            },
            'advanced': {
                'complexity': 'sophisticated concepts and connections',
                'detail_level': 'focused on key insights',
                'terminology': 'advanced technical vocabulary',
                'examples': 'complex scenarios and edge cases',
                'support': 'minimal guidance, maximum insight'
            },
            'expert': {
                'complexity': 'cutting-edge and nuanced analysis',
                'detail_level': 'deep technical specifics',
                'terminology': 'specialized expert terminology',
                'examples': 'industry best practices and innovations',
                'support': 'peer-level collaboration and discussion'
            }
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Advanced user adaptation processing"""
        current_input = pipeline_data.get('current_response', '')
        user_input = pipeline_data.get('user_input', '')
        
        context_metadata = pipeline_data.get('stage_results', {})
        intent_data = context_metadata.get('agent_3_intent_and_context_advanced', {})
        
        self._log_processing(current_input)
        
        # Stage 1: Analyze user profile and preferences
        user_analysis = self._analyze_user_profile(user_input, intent_data, pipeline_data)
        
        # Stage 2: Determine adaptation strategy
        adaptation_strategy = self._determine_adaptation_strategy(user_analysis, pipeline_data)
        
        # Stage 3: Apply communication style adaptation
        style_adapted_response = self._apply_communication_style_adaptation(current_input, user_analysis, adaptation_strategy)
        
        # Stage 4: Adjust expertise level and complexity
        complexity_adapted_response = self._apply_complexity_adaptation(style_adapted_response, user_analysis, adaptation_strategy)
        
        # Stage 5: Personalize content and examples
        personalized_response = self._apply_content_personalization(complexity_adapted_response, user_analysis, adaptation_strategy)
        
        # Stage 6: Optimize for accessibility and preferences
        accessibility_optimized_response = self._apply_accessibility_optimization(personalized_response, user_analysis, adaptation_strategy)
        
        # Stage 7: Integrate contextual memory and learning
        context_integrated_response = self._integrate_contextual_memory(accessibility_optimized_response, user_analysis, adaptation_strategy)
        
        # Stage 8: Finalize adaptive response with engagement optimization
        final_adaptive_response = self._finalize_adaptive_response(context_integrated_response, user_analysis, adaptation_strategy)
        
        return {
            'current_response': final_adaptive_response,
            'user_adaptation_metadata': {
                'user_profile': user_analysis,
                'adaptation_strategy': adaptation_strategy,
                'applied_adaptations': self._get_applied_adaptations(),
                'personalization_score': self._calculate_personalization_score(user_analysis),
                'adaptation_confidence': self._calculate_adaptation_confidence(user_analysis, adaptation_strategy),
                'learning_insights': self._extract_learning_insights(user_analysis, pipeline_data),
                'engagement_optimization': self._get_engagement_optimization_data(),
                'accessibility_features': self._get_accessibility_features(user_analysis)
            }
        }
    
    def _analyze_user_profile(self, user_input: str, intent_data: Dict[str, Any], pipeline_data: Dict[str, Any]) -> UserProfile:
        """Analyze and build comprehensive user profile"""
        user_id = pipeline_data.get('user_id', 'anonymous')
        
        # Detect communication style preferences
        communication_style = self._detect_communication_style(user_input, intent_data)
        
        # Assess expertise level from input complexity
        expertise_level = self._assess_expertise_level(user_input, intent_data)
        
        # Detect language and cultural preferences
        language_preferences = self._detect_language_preferences(user_input, intent_data)
        
        # Analyze learning preferences from interaction patterns
        learning_preferences = self._analyze_learning_preferences(user_input, intent_data, pipeline_data)
        
        # Extract accessibility needs
        accessibility_needs = self._extract_accessibility_needs(user_input, intent_data)
        
        # Build interaction history context
        interaction_history = self._build_interaction_history(pipeline_data)
        
        return UserProfile(
            user_id=user_id,
            communication_style=communication_style,
            expertise_level=expertise_level,
            preferred_language=language_preferences.get('primary_language', 'en'),
            interaction_history=interaction_history,
            learning_preferences=learning_preferences,
            response_preferences=self._extract_response_preferences(user_input, intent_data),
            accessibility_needs=accessibility_needs,
            context_memory=self._build_context_memory(pipeline_data)
        )
    
    def _detect_communication_style(self, user_input: str, intent_data: Dict[str, Any]) -> str:
        """Detect user's preferred communication style"""
        formal_indicators = ['please', 'could you', 'would you', 'thank you', 'sir', 'madam']
        casual_indicators = ['hey', 'hi', 'thanks', 'cool', 'awesome', 'yeah']
        technical_indicators = ['implement', 'optimize', 'configure', 'debug', 'algorithm', 'architecture']
        creative_indicators = ['create', 'design', 'innovative', 'artistic', 'creative', 'imagine']
        
        user_lower = user_input.lower()
        
        formal_score = sum(1 for indicator in formal_indicators if indicator in user_lower)
        casual_score = sum(1 for indicator in casual_indicators if indicator in user_lower)
        technical_score = sum(1 for indicator in technical_indicators if indicator in user_lower)
        creative_score = sum(1 for indicator in creative_indicators if indicator in user_lower)
        
        scores = {
            'formal': formal_score,
            'casual': casual_score,
            'technical': technical_score,
            'creative': creative_score
        }
        
        max_style = max(scores, key=scores.get)
        return max_style if scores[max_style] > 0 else 'balanced'
    
    def _assess_expertise_level(self, user_input: str, intent_data: Dict[str, Any]) -> str:
        """Assess user's expertise level from input complexity"""
        beginner_indicators = ['how to', 'what is', 'explain', 'tutorial', 'guide', 'help me understand']
        intermediate_indicators = ['implement', 'use', 'apply', 'configure', 'setup']
        advanced_indicators = ['optimize', 'customize', 'integrate', 'advanced', 'complex']
        expert_indicators = ['architecture', 'design patterns', 'best practices', 'performance', 'scalability']
        
        user_lower = user_input.lower()
        
        beginner_score = sum(1 for indicator in beginner_indicators if indicator in user_lower)
        intermediate_score = sum(1 for indicator in intermediate_indicators if indicator in user_lower)
        advanced_score = sum(1 for indicator in advanced_indicators if indicator in user_lower)
        expert_score = sum(1 for indicator in expert_indicators if indicator in user_lower)
        
        # Weight by input complexity
        input_complexity = len(user_input.split()) + len([w for w in user_input.split() if len(w) > 8])
        
        if expert_score > 0 or input_complexity > 50:
            return 'expert'
        elif advanced_score > 0 or input_complexity > 30:
            return 'advanced'
        elif intermediate_score > 0 or input_complexity > 15:
            return 'intermediate'
        else:
            return 'beginner'
    
    def _detect_language_preferences(self, user_input: str, intent_data: Dict[str, Any]) -> Dict[str, Any]:
        """Detect language and cultural preferences"""
        # Simple language detection (can be enhanced with proper language detection library)
        language_indicators = {
            'es': ['hola', 'gracias', 'por favor', 'español'],
            'fr': ['bonjour', 'merci', 's\'il vous plaît', 'français'],
            'de': ['hallo', 'danke', 'bitte', 'deutsch'],
            'it': ['ciao', 'grazie', 'prego', 'italiano'],
            'pt': ['olá', 'obrigado', 'por favor', 'português'],
            'ru': ['привет', 'спасибо', 'пожалуйста'],
            'zh': ['你好', '谢谢', '请'],
            'ja': ['こんにちは', 'ありがとう', 'お願いします'],
            'ko': ['안녕하세요', '감사합니다', '부탁드립니다']
        }
        
        user_lower = user_input.lower()
        detected_language = 'en'  # Default to English
        
        for lang_code, indicators in language_indicators.items():
            if any(indicator in user_lower for indicator in indicators):
                detected_language = lang_code
                break
        
        return {
            'primary_language': detected_language,
            'multilingual_preference': len([lang for lang, indicators in language_indicators.items() 
                                          if any(indicator in user_lower for indicator in indicators)]) > 1
        }
    
    def _analyze_learning_preferences(self, user_input: str, intent_data: Dict[str, Any], pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze user's learning preferences and patterns"""
        visual_indicators = ['show', 'see', 'diagram', 'chart', 'image', 'visual']
        hands_on_indicators = ['example', 'demo', 'practice', 'try', 'test', 'implement']
        theoretical_indicators = ['explain', 'theory', 'concept', 'principle', 'understand']
        step_by_step_indicators = ['step', 'guide', 'tutorial', 'process', 'procedure']
        
        user_lower = user_input.lower()
        
        return {
            'visual_learner': any(indicator in user_lower for indicator in visual_indicators),
            'hands_on_learner': any(indicator in user_lower for indicator in hands_on_indicators),
            'theoretical_learner': any(indicator in user_lower for indicator in theoretical_indicators),
            'structured_learner': any(indicator in user_lower for indicator in step_by_step_indicators),
            'preferred_example_types': self._determine_preferred_examples(user_input),
            'learning_pace': self._assess_learning_pace(user_input, intent_data)
        }
    
    def _determine_adaptation_strategy(self, user_profile: UserProfile, pipeline_data: Dict[str, Any]) -> AdaptationStrategy:
        """Determine optimal adaptation strategy for user"""
        # Base strategy on user profile and context
        personalization_level = "high"  # Default high personalization
        
        # Adjust based on user's interaction history
        if len(user_profile.interaction_history) < 3:
            personalization_level = "moderate"  # Lower for new users
        
        return AdaptationStrategy(
            personalization_level=personalization_level,
            learning_adaptation=user_profile.learning_preferences.get('visual_learner', False) or 
                               user_profile.learning_preferences.get('hands_on_learner', False),
            style_adaptation=user_profile.communication_style != 'balanced',
            complexity_adaptation=user_profile.expertise_level in ['beginner', 'expert'],
            cultural_adaptation=user_profile.preferred_language != 'en',
            temporal_adaptation=len(user_profile.interaction_history) > 5,
            contextual_adaptation=bool(user_profile.context_memory)
        )
    
    def _apply_communication_style_adaptation(self, response: str, user_profile: UserProfile, strategy: AdaptationStrategy) -> str:
        """Apply communication style adaptation to response"""
        if not strategy.style_adaptation:
            return response
        
        style_config = self.communication_styles.get(user_profile.communication_style, self.communication_styles['balanced'])
        
        # Apply tone adaptation
        if user_profile.communication_style == 'formal':
            response = self._formalize_tone(response)
        elif user_profile.communication_style == 'casual':
            response = self._casualize_tone(response)
        elif user_profile.communication_style == 'technical':
            response = self._technicalize_tone(response)
        elif user_profile.communication_style == 'creative':
            response = self._creativize_tone(response)
        
        return response
    
    def _apply_complexity_adaptation(self, response: str, user_profile: UserProfile, strategy: AdaptationStrategy) -> str:
        """Apply expertise level and complexity adaptation"""
        if not strategy.complexity_adaptation:
            return response
        
        level_config = self.expertise_levels.get(user_profile.expertise_level, self.expertise_levels['intermediate'])
        
        if user_profile.expertise_level == 'beginner':
            response = self._simplify_for_beginners(response)
        elif user_profile.expertise_level == 'expert':
            response = self._enhance_for_experts(response)
        
        return response
    
    def _apply_content_personalization(self, response: str, user_profile: UserProfile, strategy: AdaptationStrategy) -> str:
        """Apply content personalization based on user preferences"""
        # Add personalized examples based on learning preferences
        if user_profile.learning_preferences.get('visual_learner'):
            response = self._add_visual_elements(response)
        
        if user_profile.learning_preferences.get('hands_on_learner'):
            response = self._add_practical_examples(response)
        
        if user_profile.learning_preferences.get('structured_learner'):
            response = self._add_structured_format(response)
        
        return response
    
    def _apply_accessibility_optimization(self, response: str, user_profile: UserProfile, strategy: AdaptationStrategy) -> str:
        """Apply accessibility optimizations"""
        accessibility_needs = user_profile.accessibility_needs
        
        # Apply accessibility enhancements
        if accessibility_needs.get('screen_reader_friendly'):
            response = self._optimize_for_screen_readers(response)
        
        if accessibility_needs.get('cognitive_accessibility'):
            response = self._optimize_for_cognitive_accessibility(response)
        
        return response
    
    def _integrate_contextual_memory(self, response: str, user_profile: UserProfile, strategy: AdaptationStrategy) -> str:
        """Integrate contextual memory and previous interactions"""
        if not strategy.contextual_adaptation:
            return response
        
        # Reference previous context when relevant
        if user_profile.context_memory:
            response = self._add_contextual_references(response, user_profile.context_memory)
        
        return response
    
    def _finalize_adaptive_response(self, response: str, user_profile: UserProfile, strategy: AdaptationStrategy) -> str:
        """Finalize adaptive response with engagement optimization"""
        # Add engagement elements based on user profile
        if user_profile.communication_style == 'creative':
            response = self._add_creative_engagement(response)
        elif user_profile.expertise_level == 'beginner':
            response = self._add_encouraging_elements(response)
        
        # Add personalized closing
        response = self._add_personalized_closing(response, user_profile)
        
        return response
    
    # Helper methods for specific adaptations
    def _formalize_tone(self, response: str) -> str:
        """Apply formal tone to response"""
        # Replace casual language with formal equivalents
        replacements = {
            "hey": "Hello",
            "yeah": "Yes",
            "cool": "excellent",
            "awesome": "outstanding",
            "gonna": "going to",
            "wanna": "want to"
        }
        
        for casual, formal in replacements.items():
            response = re.sub(r'\b' + casual + r'\b', formal, response, flags=re.IGNORECASE)
        
        return response
    
    def _casualize_tone(self, response: str) -> str:
        """Apply casual tone to response"""
        # Add casual expressions and contractions
        response = response.replace("you are", "you're")
        response = response.replace("it is", "it's")
        response = response.replace("cannot", "can't")
        
        return response
    
    def _simplify_for_beginners(self, response: str) -> str:
        """Simplify response for beginners"""
        # Add explanations for technical terms
        # Break down complex sentences
        # Add encouragement
        if "technical" in response.lower() or "complex" in response.lower():
            response += "\n\n💡 **Beginner Tip**: Don't worry if this seems complex at first - we'll break it down step by step!"
        
        return response
    
    def _enhance_for_experts(self, response: str) -> str:
        """Enhance response for experts"""
        # Add advanced considerations
        # Include performance implications
        # Reference best practices
        response += "\n\n🔧 **Expert Considerations**: Consider the performance implications and scalability factors when implementing this solution."
        
        return response
    
    def _add_visual_elements(self, response: str) -> str:
        """Add visual elements for visual learners"""
        # Add diagrams, charts, or visual representations
        response += "\n\n📊 **Visual Aid**: A diagram or flowchart would help visualize this concept."
        
        return response
    
    def _add_practical_examples(self, response: str) -> str:
        """Add practical examples for hands-on learners"""
        response += "\n\n🛠️ **Hands-on Example**: Try implementing this step-by-step to better understand the concept."
        
        return response
    
    def _add_structured_format(self, response: str) -> str:
        """Add structured format for structured learners"""
        # Ensure clear steps and organization
        if "1." not in response and "step" in response.lower():
            response = "**Step-by-Step Approach:**\n" + response
        
        return response
    
    # Additional helper methods
    def _extract_accessibility_needs(self, user_input: str, intent_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract accessibility needs from user input"""
        return {
            'screen_reader_friendly': 'screen reader' in user_input.lower(),
            'cognitive_accessibility': any(word in user_input.lower() for word in ['simple', 'easy', 'clear']),
            'visual_impairment': 'vision' in user_input.lower() or 'blind' in user_input.lower()
        }
    
    def _extract_response_preferences(self, user_input: str, intent_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract response format preferences"""
        return {
            'prefers_lists': 'list' in user_input.lower() or 'bullet' in user_input.lower(),
            'prefers_examples': 'example' in user_input.lower(),
            'prefers_code': 'code' in user_input.lower() or 'implementation' in user_input.lower(),
            'prefers_explanations': 'explain' in user_input.lower() or 'why' in user_input.lower()
        }
    
    def _build_interaction_history(self, pipeline_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Build interaction history from pipeline data"""
        # This would typically come from a database or session storage
        return pipeline_data.get('interaction_history', [])
    
    def _build_context_memory(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Build context memory from previous interactions"""
        return pipeline_data.get('context_memory', {})
    
    def _determine_preferred_examples(self, user_input: str) -> List[str]:
        """Determine what types of examples user prefers"""
        preferences = []
        
        if 'code' in user_input.lower():
            preferences.append('code_examples')
        if 'real' in user_input.lower() or 'practical' in user_input.lower():
            preferences.append('real_world_examples')
        if 'simple' in user_input.lower():
            preferences.append('simple_examples')
        
        return preferences if preferences else ['general_examples']
    
    def _assess_learning_pace(self, user_input: str, intent_data: Dict[str, Any]) -> str:
        """Assess user's preferred learning pace"""
        if 'quick' in user_input.lower() or 'fast' in user_input.lower():
            return 'fast'
        elif 'slow' in user_input.lower() or 'careful' in user_input.lower():
            return 'slow'
        else:
            return 'moderate'
    
    def _get_applied_adaptations(self) -> List[str]:
        """Get list of applied adaptations"""
        return [
            'communication_style_adaptation',
            'expertise_level_adjustment',
            'content_personalization',
            'accessibility_optimization'
        ]
    
    def _calculate_personalization_score(self, user_profile: UserProfile) -> float:
        """Calculate personalization score based on available user data"""
        score = 0.0
        
        # Add points for each known preference
        if user_profile.communication_style != 'balanced':
            score += 0.2
        if user_profile.expertise_level != 'intermediate':
            score += 0.2
        if user_profile.learning_preferences:
            score += 0.2
        if user_profile.context_memory:
            score += 0.2
        if len(user_profile.interaction_history) > 0:
            score += 0.2
        
        return min(1.0, score)
    
    def _calculate_adaptation_confidence(self, user_profile: UserProfile, strategy: AdaptationStrategy) -> float:
        """Calculate confidence in adaptation decisions"""
        confidence = 0.7  # Base confidence
        
        # Increase confidence with more interaction history
        if len(user_profile.interaction_history) > 5:
            confidence += 0.1
        if len(user_profile.interaction_history) > 10:
            confidence += 0.1
        
        # Increase confidence with clear preferences
        if user_profile.communication_style in ['formal', 'technical']:
            confidence += 0.05
        
        return min(1.0, confidence)
    
    def _extract_learning_insights(self, user_profile: UserProfile, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract insights about user's learning patterns"""
        return {
            'preferred_communication_style': user_profile.communication_style,
            'expertise_progression': user_profile.expertise_level,
            'learning_pattern': user_profile.learning_preferences,
            'engagement_level': 'high' if len(user_profile.interaction_history) > 3 else 'moderate'
        }
    
    def _get_engagement_optimization_data(self) -> Dict[str, Any]:
        """Get engagement optimization data"""
        return {
            'interactive_elements_added': True,
            'personalization_applied': True,
            'accessibility_enhanced': True,
            'learning_optimized': True
        }
    
    def _get_accessibility_features(self, user_profile: UserProfile) -> List[str]:
        """Get list of accessibility features applied"""
        features = []
        
        if user_profile.accessibility_needs.get('screen_reader_friendly'):
            features.append('screen_reader_optimization')
        if user_profile.accessibility_needs.get('cognitive_accessibility'):
            features.append('cognitive_accessibility_enhancement')
        
        return features
    
    def _optimize_for_screen_readers(self, response: str) -> str:
        """Optimize response for screen readers"""
        # Add alt text descriptions, proper heading structure
        return response
    
    def _optimize_for_cognitive_accessibility(self, response: str) -> str:
        """Optimize for cognitive accessibility"""
        # Simplify language, add clear structure
        return response
    
    def _add_contextual_references(self, response: str, context_memory: Dict[str, Any]) -> str:
        """Add contextual references from memory"""
        if context_memory.get('previous_topic'):
            response = f"Building on our previous discussion about {context_memory['previous_topic']}, " + response
        
        return response
    
    def _add_creative_engagement(self, response: str) -> str:
        """Add creative engagement elements"""
        response += "\n\n✨ **Creative Insight**: Think of this as building with digital LEGO blocks - each component fits together to create something amazing!"
        
        return response
    
    def _add_encouraging_elements(self, response: str) -> str:
        """Add encouraging elements for beginners"""
        response += "\n\n🌟 **You've got this!** Every expert was once a beginner. Take it one step at a time."
        
        return response
    
    def _add_personalized_closing(self, response: str, user_profile: UserProfile) -> str:
        """Add personalized closing based on user profile"""
        closings = {
            'formal': "\n\nI hope this information proves helpful for your needs.",
            'casual': "\n\nHope this helps! Let me know if you need anything else! 😊",
            'technical': "\n\nRefer to the documentation for additional implementation details.",
            'creative': "\n\nNow go forth and create something amazing! 🚀",
            'balanced': "\n\nFeel free to ask if you need any clarification or have questions!"
        }
        
        closing = closings.get(user_profile.communication_style, closings['balanced'])
        return response + closing
