"""
GRT Agents Module
Registry and factory for all 37 specialized agents
"""

from .base_agent import BaseAgent
from typing import Dict, Type, List
import logging

logger = logging.getLogger(__name__)

# Agent registry mapping agent IDs to implementations
AGENT_REGISTRY: Dict[str, Type[BaseAgent]] = {}

def register_agent(agent_id: str, agent_class: Type[BaseAgent]):
    """Register an agent implementation"""
    AGENT_REGISTRY[agent_id] = agent_class
    logger.info(f"🔧 Registered agent: {agent_id}")

def get_agent(agent_id: str, capabilities: List[str] = None) -> BaseAgent:
    """Get agent instance by ID - only real implementations allowed"""
    if agent_id in AGENT_REGISTRY:
        return AGENT_REGISTRY[agent_id](agent_id, capabilities)
    else:
        # No mock agents - fail if not found
        raise RuntimeError(f"❌ Agent {agent_id} not found in registry. Only real implementations allowed.")

def get_all_agents() -> Dict[str, BaseAgent]:
    """Get all registered agents"""
    return {agent_id: get_agent(agent_id) for agent_id in AGENT_REGISTRY.keys()}

# Define agent capabilities mapping
AGENT_CAPABILITIES = {
    'agent_1_input': ['input_processing', 'multilingual_support'],
    'agent_2_thinking': ['thinking', 'reasoning', 'advanced_analysis'],
    'agent_3_intent_and_context': ['intent_detection', 'context_analysis'],
    'agent_4_thinking': ['deep_thinking', 'problem_solving'],
    'agent_5_processing': ['data_processing', 'pipeline_coordination'],
    'agent_6_response': ['response_generation', 'output_formatting'],
    'agent_7_multilanguage': ['multilanguage_support', 'translation'],
    'agent_8_response_enhancement': ['response_enhancement', 'quality_improvement'],
    'agent_9_personality_engine': ['personality_engine', 'emotional_intelligence'],
    'agent_10_conversation_memory': ['conversation_memory', 'context_retention'],
    'agent_11_dialog_flow_agent': ['dialog_flow', 'conversation_management'],
    'agent_12_fact_checker': ['fact_checking', 'verification'],
    'agent_13_code_interpreter': ['code_interpretation', 'programming_assistance'],
    'agent_14_math_solver': ['math_solving', 'computational_analysis'],
    'agent_15_cad_generator': ['cad_generation', '3d_modeling', 'file_reading'],
    'agent_16_visualizer': ['drawing_generation', 'logo_design', 'visualization'],
    'agent_17_logic_bridge': ['logic_bridge', 'reasoning_connections'],
    'agent_18_emotion_detector': ['emotion_detection', 'image_generation'],
    'agent_19_user_adapter': ['animation_direction', 'user_adaptation'],
    'agent_20_summary_agent': ['summary_generation', 'ui_ux_design'],
    'agent_21_command_agent': ['command_processing', 'pdf_generation'],
    'agent_22_planner': ['excel_creation', 'planning'],
    'agent_23_qa_agent': ['qa_processing', 'word_building'],
    'agent_24_inference_optimizer': ['inference_optimization', 'powerpoint_creation'],
    'agent_25_feedback_handler': ['feedback_handling', 'improvement_processing'],
    'agent_26_history_lookup': ['history_lookup', 'data_retrieval'],
    'agent_27_topic_tracker': ['gif_animation', 'topic_tracking'],
    'agent_28_grammar_polisher': ['grammar_polishing', 'image_analysis'],
    'agent_29_context_repair': ['3d_video_making', 'context_repair'],
    'agent_30_hallucination_filter': ['hallucination_filtering', 'accuracy_control'],
    'agent_31_confidence_estimator': ['confidence_estimation', 'reliability_assessment'],
    'agent_32_prompt_enricher': ['prompt_enrichment', 'input_enhancement'],
    'agent_33_security_filter': ['security_filtering', 'safety_control'],
    'agent_34_task_decomposer': ['task_decomposition', 'workflow_breaking'],
    'agent_35_logic_critic': ['logic_criticism', 'reasoning_validation'],
    'agent_36_delivery_agent': ['delivery_optimization', 'output_coordination'],
    'agent_37_content_creation_agent': ['content_creation', 'creative_generation']
}

# Register all available agents (existing implementations)
def _register_available_agents():
    """Register all available agent implementations"""
    
    # Import and register all completed agents
    agent_imports = [
        ('agent_1_input', 'Agent1Input'),
        ('agent_2_thinking', 'Agent2Thinking'),
        ('agent_3_intent_and_context', 'Agent3IntentAndContext'),
        ('agent_10_conversation_memory', 'Agent10ConversationMemory'),
        ('agent_12_fact_checker', 'Agent12FactChecker'),
        ('agent_13_code_interpreter', 'Agent13CodeInterpreter'),
        ('agent_14_math_solver', 'Agent14MathSolver'),
        ('agent_15_cad_generator', 'Agent15CadGenerator'),
        ('agent_15_file_reader', 'Agent15FileReader'),
        ('agent_16_visualizer', 'Agent16Visualizer'),
        ('agent_17_logic_bridge', 'Agent17LogicBridge'),
        ('agent_18_emotion_detector', 'Agent18EmotionDetector'),
        ('agent_19_user_adapter', 'Agent19UserAdapter'),
        ('agent_20_summary_agent', 'Agent20SummaryAgent'),
        ('agent_21_command_agent', 'Agent21CommandAgent'),
        ('agent_22_planner', 'Agent22Planner'),
        ('agent_23_qa_agent', 'Agent23QAAgent'),
        ('agent_24_inference_optimizer', 'Agent24InferenceOptimizer'),
        ('agent_25_feedback_handler', 'Agent25FeedbackHandler'),
        ('agent_26_history_lookup', 'Agent26HistoryLookup'),
        ('agent_27_topic_tracker', 'Agent27TopicTracker'),
        ('agent_28_grammar_polisher', 'Agent28GrammarPolisher'),
        ('agent_29_context_repair', 'Agent29ContextRepair'),
        ('agent_30_hallucination_filter', 'Agent30HallucinationFilter'),
        ('agent_31_confidence_estimator', 'Agent31ConfidenceEstimator'),
        ('agent_32_prompt_enricher', 'Agent32PromptEnricher'),
        ('agent_33_security_filter', 'Agent33SecurityFilter'),
        ('agent_34_task_decomposer', 'Agent34TaskDecomposer'),
        ('agent_35_logic_critic', 'Agent35LogicCritic'),
        ('agent_36_delivery_agent', 'Agent36DeliveryAgent'),
        ('agent_37_content_creation_agent', 'Agent37ContentCreationAgent'),
    ]
    
    registered_count = 0
    for module_name, class_name in agent_imports:
        try:
            module = __import__(f'.{module_name}', package=__name__, level=1)
            agent_class = getattr(module, class_name)
            register_agent(module_name, agent_class)
            registered_count += 1
        except (ImportError, AttributeError) as e:
            logger.error(f"❌ Could not import {class_name} from {module_name}: {e}")
            # No mock implementations - real agents only
    
    logger.info(f"✅ Successfully registered {registered_count} real agents out of {len(agent_imports)} total")

# Initialize registry
_register_available_agents()

logger.info(f"🚀 GRT Agents initialized with {len(AGENT_REGISTRY)} registered agents")