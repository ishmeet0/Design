# 📂 Advanced File Reader - Processes and analyzes uploaded files with intelligent content extraction

from .base_agent import BaseAgent
from typing import Dict, Any, List, Optional
import os
import time
import mimetypes
import base64
import json
from pathlib import Path
from datetime import datetime

class FileReaderAgent(BaseAgent):
    """Agent 15: Advanced file reading and content analysis"""
    
    def __init__(self):
        super().__init__(
            name="FileReaderAgent", 
            description="Advanced file reading with intelligent content extraction and analysis"
        )
        
        # Supported file types and their processors
        self.supported_types = {
            'text_files': ['.txt', '.md', '.csv', '.json', '.xml', '.html', '.css', '.js', '.py', '.java', '.cpp', '.c', '.h'],
            'document_files': ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx'],
            'image_files': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.webp'],
            'code_files': ['.py', '.js', '.html', '.css', '.java', '.cpp', '.c', '.h', '.php', '.rb', '.go', '.rs'],
            'data_files': ['.csv', '.json', '.xml', '.yaml', '.yml', '.sql'],
            'archive_files': ['.zip', '.tar', '.gz', '.rar', '.7z']
        }
        
        # File size limits (in MB)
        self.size_limits = {
            'text_files': 10,
            'document_files': 50,
            'image_files': 25,
            'code_files': 5,
            'data_files': 100
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process uploaded files and extract content"""
        current_response = pipeline_data.get('current_response', '')
        user_input = pipeline_data.get('user_input', '')
        
        self._log_processing(f"File analysis request: {user_input[:100]}")
        
        # Check for file context in pipeline data
        file_context = self._check_file_context(pipeline_data)
        
        if file_context['files_present']:
            # Process detected files
            file_analysis = self._analyze_files(file_context, user_input)
            enhanced_response = self._create_file_analysis_response(
                current_response, file_analysis, user_input
            )
        else:
            # No files detected, provide guidance
            enhanced_response = self._create_no_files_response(current_response, user_input)
            file_analysis = {'no_files_detected': True}
        
        return self._create_result(
            enhanced_response,
            {
                'file_processing': file_context,
                'file_analysis': file_analysis,
                'processing_timestamp': datetime.now().isoformat()
            }
        )
    
    def _check_file_context(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Check for files in pipeline data and attached assets"""
        files_detected = []
        
        # Check for files in user input or attached assets
        user_input = pipeline_data.get('user_input', '')
        
        # Look for file references in user input
        if any(keyword in user_input.lower() for keyword in ['file', 'upload', 'attach', 'document', 'image']):
            # Check attached_assets directory for recent files
            attached_assets_path = Path('attached_assets')
            if attached_assets_path.exists():
                for file_path in attached_assets_path.iterdir():
                    if file_path.is_file():
                        file_info = self._get_file_info(file_path)
                        files_detected.append(file_info)
        
        # Check for files in pipeline metadata
        files_metadata = pipeline_data.get('files', [])
        if files_metadata:
            for file_meta in files_metadata:
                files_detected.append(file_meta)
        
        return {
            'files_present': len(files_detected) > 0,
            'file_count': len(files_detected),
            'file_types': list(set([f.get('type', 'unknown') for f in files_detected])),
            'files_detected': files_detected,
            'total_size': sum([f.get('size', 0) for f in files_detected])
        }
    
    def _get_file_info(self, file_path: Path) -> Dict[str, Any]:
        """Get comprehensive file information"""
        try:
            stat = file_path.stat()
            mime_type, _ = mimetypes.guess_type(str(file_path))
            
            return {
                'name': file_path.name,
                'path': str(file_path),
                'size': stat.st_size,
                'modified': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                'extension': file_path.suffix.lower(),
                'mime_type': mime_type,
                'type': self._classify_file_type(file_path.suffix.lower()),
                'readable': self._is_readable_file(file_path.suffix.lower()),
                'processing_priority': self._get_processing_priority(file_path.suffix.lower())
            }
        except Exception as e:
            return {
                'name': file_path.name,
                'path': str(file_path),
                'error': str(e),
                'readable': False
            }
    
    def _classify_file_type(self, extension: str) -> str:
        """Classify file type based on extension"""
        for file_type, extensions in self.supported_types.items():
            if extension in extensions:
                return file_type
        return 'unknown'
    
    def _is_readable_file(self, extension: str) -> bool:
        """Check if file type is readable by this agent"""
        readable_extensions = []
        for extensions in self.supported_types.values():
            readable_extensions.extend(extensions)
        return extension in readable_extensions
    
    def _get_processing_priority(self, extension: str) -> int:
        """Get processing priority (1=highest, 10=lowest)"""
        high_priority = ['.txt', '.md', '.json', '.csv', '.py', '.js', '.html']
        medium_priority = ['.pdf', '.docx', '.xlsx', '.xml', '.yaml']
        
        if extension in high_priority:
            return 1
        elif extension in medium_priority:
            return 2
        else:
            return 3
    
    def _analyze_files(self, file_context: Dict[str, Any], user_input: str) -> Dict[str, Any]:
        """Analyze detected files and extract content"""
        files_analysis = {
            'processed_files': [],
            'content_summary': {},
            'extracted_data': {},
            'processing_errors': [],
            'recommendations': []
        }
        
        # Sort files by processing priority
        files = sorted(
            file_context['files_detected'], 
            key=lambda x: x.get('processing_priority', 10)
        )
        
        for file_info in files[:10]:  # Limit to 10 files for performance
            try:
                if file_info.get('readable', False):
                    file_analysis = self._process_individual_file(file_info, user_input)
                    files_analysis['processed_files'].append(file_analysis)
                    
                    # Extract key content
                    if file_analysis.get('content'):
                        files_analysis['extracted_data'][file_info['name']] = file_analysis['content']
                else:
                    files_analysis['processing_errors'].append(
                        f"File '{file_info['name']}' is not readable by this agent"
                    )
            except Exception as e:
                files_analysis['processing_errors'].append(
                    f"Error processing '{file_info['name']}': {str(e)}"
                )
        
        # Generate content summary
        files_analysis['content_summary'] = self._generate_content_summary(files_analysis['processed_files'])
        
        # Generate recommendations
        files_analysis['recommendations'] = self._generate_processing_recommendations(
            files_analysis, user_input
        )
        
        return files_analysis
    
    def _process_individual_file(self, file_info: Dict[str, Any], user_input: str) -> Dict[str, Any]:
        """Process individual file and extract content"""
        file_path = Path(file_info['path'])
        file_type = file_info.get('type', 'unknown')
        
        analysis = {
            'file_info': file_info,
            'processing_status': 'success',
            'content': None,
            'metadata': {},
            'insights': []
        }
        
        try:
            if file_type == 'text_files':
                analysis['content'] = self._read_text_file(file_path)
                analysis['insights'] = self._analyze_text_content(analysis['content'], user_input)
            elif file_type == 'code_files':
                analysis['content'] = self._read_code_file(file_path)
                analysis['insights'] = self._analyze_code_content(analysis['content'], file_info['extension'])
            elif file_type == 'data_files':
                analysis['content'] = self._read_data_file(file_path, file_info['extension'])
                analysis['insights'] = self._analyze_data_content(analysis['content'], file_info['extension'])
            elif file_type == 'image_files':
                analysis['metadata'] = self._analyze_image_file(file_path)
                analysis['insights'] = ['Image file detected - visual analysis available']
            else:
                analysis['content'] = f"File type '{file_type}' detected but specialized processing not implemented"
                analysis['insights'] = ['File detected but requires specialized processing']
        
        except Exception as e:
            analysis['processing_status'] = 'error'
            analysis['error'] = str(e)
        
        return analysis
    
    def _read_text_file(self, file_path: Path) -> str:
        """Read text file content"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            return content[:10000]  # Limit to first 10K characters
        except UnicodeDecodeError:
            # Try different encodings
            for encoding in ['latin1', 'cp1252', 'iso-8859-1']:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    return content[:10000]
                except:
                    continue
            return "Error: Could not decode file content"
    
    def _read_code_file(self, file_path: Path) -> str:
        """Read code file with syntax awareness"""
        content = self._read_text_file(file_path)
        
        # Add basic code analysis
        lines = content.split('\n')
        code_stats = {
            'total_lines': len(lines),
            'non_empty_lines': len([line for line in lines if line.strip()]),
            'comment_lines': len([line for line in lines if line.strip().startswith(('#', '//', '/*'))]),
        }
        
        return {
            'source_code': content,
            'statistics': code_stats
        }
    
    def _read_data_file(self, file_path: Path, extension: str) -> Any:
        """Read data files (JSON, CSV, etc.)"""
        if extension == '.json':
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return "Error: Invalid JSON format"
        elif extension == '.csv':
            content = self._read_text_file(file_path)
            lines = content.split('\n')
            return {
                'preview': lines[:10],  # First 10 lines
                'total_lines': len(lines),
                'estimated_columns': len(lines[0].split(',')) if lines else 0
            }
        else:
            return self._read_text_file(file_path)
    
    def _analyze_image_file(self, file_path: Path) -> Dict[str, Any]:
        """Analyze image file metadata"""
        stat = file_path.stat()
        return {
            'file_size': stat.st_size,
            'format': file_path.suffix.upper()[1:],
            'analysis_note': 'Image analysis requires specialized image processing agent'
        }
    
    def _analyze_text_content(self, content: str, user_input: str) -> List[str]:
        """Analyze text content for insights"""
        insights = []
        
        if isinstance(content, str):
            word_count = len(content.split())
            char_count = len(content)
            line_count = len(content.split('\n'))
            
            insights.append(f"Text analysis: {word_count} words, {char_count} characters, {line_count} lines")
            
            # Check for specific patterns based on user input
            user_lower = user_input.lower()
            if any(word in user_lower for word in ['analyze', 'summary', 'key points']):
                insights.append("Content ready for detailed analysis and summarization")
            if any(word in user_lower for word in ['extract', 'data', 'information']):
                insights.append("Content ready for data extraction and processing")
        
        return insights
    
    def _analyze_code_content(self, content: Any, extension: str) -> List[str]:
        """Analyze code content for insights"""
        insights = []
        
        if isinstance(content, dict) and 'statistics' in content:
            stats = content['statistics']
            insights.append(f"Code analysis: {stats['total_lines']} total lines, {stats['non_empty_lines']} non-empty lines")
            insights.append(f"Programming language: {extension[1:].upper()}")
            insights.append("Code ready for detailed analysis and review")
        
        return insights
    
    def _analyze_data_content(self, content: Any, extension: str) -> List[str]:
        """Analyze data content for insights"""
        insights = []
        
        if extension == '.json' and isinstance(content, (dict, list)):
            insights.append(f"JSON data structure detected with {len(content)} top-level elements")
            insights.append("Structured data ready for processing and analysis")
        elif extension == '.csv' and isinstance(content, dict):
            insights.append(f"CSV data: ~{content['estimated_columns']} columns, {content['total_lines']} rows")
            insights.append("Tabular data ready for analysis and visualization")
        
        return insights
    
    def _generate_content_summary(self, processed_files: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary of all processed file content"""
        return {
            'total_files_processed': len(processed_files),
            'file_types_processed': list(set([f['file_info']['type'] for f in processed_files])),
            'content_available': any([f.get('content') for f in processed_files]),
            'total_insights': sum([len(f.get('insights', [])) for f in processed_files])
        }
    
    def _generate_processing_recommendations(self, analysis: Dict[str, Any], user_input: str) -> List[str]:
        """Generate recommendations based on file analysis"""
        recommendations = []
        
        if analysis['content_summary']['content_available']:
            recommendations.append("File content extracted successfully - ready for detailed analysis")
        
        if analysis['processing_errors']:
            recommendations.append("Some files could not be processed - consider converting to supported formats")
        
        user_lower = user_input.lower()
        if any(word in user_lower for word in ['code', 'programming', 'development']):
            recommendations.append("Code files detected - recommend using Code Interpreter agent for detailed analysis")
        
        if any(word in user_lower for word in ['data', 'analysis', 'statistics']):
            recommendations.append("Data files detected - recommend using data analysis tools for insights")
        
        return recommendations if recommendations else ["Files processed successfully"]
    
    def _create_file_analysis_response(self, current_response: str, analysis: Dict[str, Any], 
                                     user_input: str) -> str:
        """Create comprehensive file analysis response"""
        
        response = f"""
{current_response}

## 📂 **File Analysis Complete**

I've successfully analyzed **{analysis['content_summary']['total_files_processed']} files** from your uploaded content.

### **📊 Processing Summary**
- **Files Processed:** {analysis['content_summary']['total_files_processed']}
- **File Types:** {', '.join(analysis['content_summary']['file_types_processed'])}
- **Content Extracted:** {'Yes' if analysis['content_summary']['content_available'] else 'No'}
- **Total Insights:** {analysis['content_summary']['total_insights']}

### **📄 File Details**
"""
        
        for file_analysis in analysis['processed_files']:
            file_info = file_analysis['file_info']
            status = file_analysis['processing_status']
            
            response += f"""
**{file_info['name']}**
- Type: {file_info['type'].replace('_', ' ').title()}
- Size: {file_info['size']:,} bytes
- Status: {status.title()}
- Insights: {len(file_analysis.get('insights', []))} discovered
"""
            
            # Add key insights
            for insight in file_analysis.get('insights', [])[:3]:  # Top 3 insights
                response += f"  • {insight}\n"
        
        if analysis['processing_errors']:
            response += f"""
### **⚠️ Processing Notes**
"""
            for error in analysis['processing_errors'][:3]:  # Show first 3 errors
                response += f"- {error}\n"
        
        response += f"""
### **💡 Recommendations**
"""
        for recommendation in analysis['recommendations']:
            response += f"- {recommendation}\n"
        
        response += f"""
### **⚡ Processing Performance**
- **Analysis Time:** {time.time() - self.start_time:.2f} seconds
- **Content Ready:** Files are now available for further processing
- **Next Steps:** Content can be analyzed, summarized, or processed by specialized agents

*Processed by ISHMEIIT AI Advanced File Reader - Agent 15*
*Professional file analysis with intelligent content extraction*
"""
        
        return response
    
    def _create_no_files_response(self, current_response: str, user_input: str) -> str:
        """Create response when no files are detected"""
        
        response = f"""
{current_response}

## 📂 **File Analysis - No Files Detected**

I haven't detected any uploaded files in your request. 

### **💡 How to Upload Files**
To analyze files, you can:
- Attach files directly to your message
- Upload files to the workspace
- Reference existing files in the project

### **🔍 Supported File Types**
- **Text Files:** .txt, .md, .csv, .json, .xml
- **Documents:** .pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx  
- **Code Files:** .py, .js, .html, .css, .java, .cpp, .c
- **Images:** .jpg, .png, .gif, .svg, .webp
- **Data Files:** .csv, .json, .xml, .yaml, .sql

### **📋 What I Can Do**
Once you upload files, I can:
- Extract and analyze content
- Provide detailed file insights
- Prepare content for specialized processing
- Generate summaries and recommendations

*Ready to process your files - ISHMEIIT AI File Reader Agent 15*
"""
        
        return response