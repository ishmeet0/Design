
"""
🎬 Agent 27: GIF Animation Agent - Creates animated GIFs, motion graphics, and interactive animations
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List, Tuple, Optional
import json
import time
from datetime import datetime
from dataclasses import dataclass, field

@dataclass
class GIFAnimationSpec:
    """Comprehensive GIF animation specification"""
    animation_type: str = "motion_graphics"  # motion_graphics, character_animation, logo_reveal, transitions
    style: str = "smooth"  # smooth, bouncy, elastic, linear, custom
    duration: float = 3.0  # Duration in seconds
    frame_rate: int = 24  # FPS for smooth animation
    dimensions: str = "720x720"  # Square format popular for social media
    loop_count: int = 0  # 0 = infinite loop
    optimization: str = "web"  # web, high_quality, small_size

@dataclass
class AnimationElements:
    """Animation elements and keyframes"""
    keyframes: List[Dict[str, Any]] = field(default_factory=list)
    transitions: List[Dict[str, Any]] = field(default_factory=list)
    effects: List[str] = field(default_factory=list)
    easing_functions: List[str] = field(default_factory=list)

class Agent27GIFAnimationAgent(BaseAgent):
    """Agent 27: Advanced GIF Animation Agent with motion graphics and interactive storytelling"""
    
    def __init__(self):
        super().__init__(
            name="Agent27GIFAnimationAgent",
            description="Advanced GIF animation creation with motion graphics, character animation, and interactive storytelling",
            priority=8
        )
        
        # Animation type systems
        self.animation_types = {
            'motion_graphics': {
                'characteristics': ['clean_transitions', 'geometric_shapes', 'text_animations'],
                'typical_elements': ['logo_reveals', 'infographic_animations', 'data_visualization'],
                'timing_approach': 'precise',
                'style_focus': 'professional'
            },
            'character_animation': {
                'characteristics': ['personality_expression', 'storytelling', 'emotional_connection'],
                'typical_elements': ['walk_cycles', 'facial_expressions', 'gesture_sequences'],
                'timing_approach': 'organic',
                'style_focus': 'character_driven'
            },
            'logo_reveal': {
                'characteristics': ['brand_identity', 'memorable_impact', 'professional_presentation'],
                'typical_elements': ['logo_build_up', 'brand_colors', 'tagline_animation'],
                'timing_approach': 'impactful',
                'style_focus': 'brand_consistent'
            },
            'transitions': {
                'characteristics': ['smooth_flow', 'seamless_change', 'visual_continuity'],
                'typical_elements': ['scene_transitions', 'morph_effects', 'fade_sequences'],
                'timing_approach': 'fluid',
                'style_focus': 'seamless'
            }
        }
        
        # Animation techniques and effects
        self.animation_techniques = {
            'easing_functions': ['ease_in', 'ease_out', 'ease_in_out', 'bounce', 'elastic', 'back'],
            'movement_patterns': ['linear', 'circular', 'wave', 'spiral', 'zigzag', 'pendulum'],
            'effects': ['fade', 'scale', 'rotate', 'translate', 'skew', 'morph', 'particle'],
            'transitions': ['slide', 'wipe', 'dissolve', 'zoom', 'flip', 'reveal']
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process GIF animation creation request"""
        try:
            current_response = pipeline_data.get('current_response', '')
            user_input = pipeline_data.get('user_input', '')
            
            self._log_processing(f"GIF Animation Request: {user_input[:100]}")
            
            # Analyze animation requirements
            animation_analysis = self._analyze_animation_requirements(user_input, current_response)
            
            # Generate animation specification
            gif_spec = self._generate_animation_specification(animation_analysis)
            
            # Create animation storyboard
            storyboard = self._create_animation_storyboard(gif_spec, animation_analysis)
            
            # Generate animation timeline
            timeline = self._generate_animation_timeline(gif_spec, storyboard)
            
            # Create technical specifications
            technical_specs = self._create_technical_specifications(gif_spec, timeline)
            
            # Generate animation code/instructions
            animation_instructions = self._generate_animation_instructions(technical_specs)
            
            # Create comprehensive response
            enhanced_response = self._create_gif_animation_response(
                current_response, animation_analysis, gif_spec, 
                storyboard, timeline, animation_instructions
            )
            
            return self._create_result(
                enhanced_response,
                {
                    'gif_specification': gif_spec.__dict__,
                    'animation_storyboard': storyboard,
                    'animation_timeline': timeline,
                    'technical_specs': technical_specs,
                    'animation_type': animation_analysis.get('primary_type'),
                    'complexity_level': animation_analysis.get('complexity', 'medium'),
                    'estimated_file_size': self._estimate_file_size(gif_spec),
                    'optimization_suggestions': self._get_optimization_suggestions(gif_spec)
                }
            )
            
        except Exception as e:
            return self._create_result(
                current_response,
                {'error': f'GIF animation processing failed: {str(e)}', 'fallback_applied': True}
            )
    
    def _analyze_animation_requirements(self, user_input: str, current_response: str) -> Dict[str, Any]:
        """Analyze what type of GIF animation is needed"""
        user_lower = user_input.lower()
        
        # Detect animation type
        primary_type = 'motion_graphics'
        if any(word in user_lower for word in ['character', 'mascot', 'person', 'avatar']):
            primary_type = 'character_animation'
        elif any(word in user_lower for word in ['logo', 'brand', 'company', 'reveal']):
            primary_type = 'logo_reveal'
        elif any(word in user_lower for word in ['transition', 'scene', 'change', 'morph']):
            primary_type = 'transitions'
        
        # Detect complexity
        complexity = 'medium'
        if any(word in user_lower for word in ['simple', 'basic', 'minimal', 'clean']):
            complexity = 'simple'
        elif any(word in user_lower for word in ['complex', 'detailed', 'advanced', 'intricate']):
            complexity = 'complex'
        
        # Detect style preferences
        style_indicators = {
            'smooth': ['smooth', 'fluid', 'seamless', 'gentle'],
            'bouncy': ['bouncy', 'playful', 'energetic', 'fun'],
            'elastic': ['elastic', 'stretchy', 'flexible', 'organic'],
            'linear': ['linear', 'straight', 'direct', 'mechanical']
        }
        
        detected_style = 'smooth'
        for style, keywords in style_indicators.items():
            if any(keyword in user_lower for keyword in keywords):
                detected_style = style
                break
        
        # Detect duration preferences
        duration = 3.0
        if any(word in user_lower for word in ['quick', 'fast', 'short', 'brief']):
            duration = 2.0
        elif any(word in user_lower for word in ['long', 'extended', 'detailed', 'slow']):
            duration = 5.0
        
        # Detect specific elements
        elements = []
        element_keywords = {
            'text_animation': ['text', 'title', 'words', 'typography'],
            'shape_morphing': ['shape', 'morph', 'transform', 'geometry'],
            'color_transitions': ['color', 'gradient', 'fade', 'blend'],
            'particle_effects': ['particles', 'sparkle', 'explosion', 'scatter'],
            'loading_animation': ['loading', 'progress', 'spinner', 'loader']
        }
        
        for element, keywords in element_keywords.items():
            if any(keyword in user_lower for keyword in keywords):
                elements.append(element)
        
        return {
            'primary_type': primary_type,
            'complexity': complexity,
            'style': detected_style,
            'duration': duration,
            'elements': elements,
            'user_intent': self._extract_user_intent(user_input),
            'technical_requirements': self._extract_technical_requirements(user_input)
        }
    
    def _generate_animation_specification(self, analysis: Dict[str, Any]) -> GIFAnimationSpec:
        """Generate detailed animation specification"""
        return GIFAnimationSpec(
            animation_type=analysis['primary_type'],
            style=analysis['style'],
            duration=analysis['duration'],
            frame_rate=24 if analysis['complexity'] == 'complex' else 20,
            dimensions=self._determine_optimal_dimensions(analysis),
            loop_count=0,  # Infinite loop for GIFs
            optimization='web'
        )
    
    def _create_animation_storyboard(self, spec: GIFAnimationSpec, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Create detailed animation storyboard"""
        total_frames = int(spec.duration * spec.frame_rate)
        
        # Create keyframe breakdowns
        keyframes = []
        
        if spec.animation_type == 'motion_graphics':
            keyframes = self._create_motion_graphics_keyframes(total_frames, analysis)
        elif spec.animation_type == 'character_animation':
            keyframes = self._create_character_animation_keyframes(total_frames, analysis)
        elif spec.animation_type == 'logo_reveal':
            keyframes = self._create_logo_reveal_keyframes(total_frames, analysis)
        else:
            keyframes = self._create_transition_keyframes(total_frames, analysis)
        
        return {
            'total_frames': total_frames,
            'keyframes': keyframes,
            'scene_breakdown': self._create_scene_breakdown(keyframes),
            'timing_chart': self._create_timing_chart(keyframes, spec.frame_rate),
            'visual_elements': self._identify_visual_elements(analysis)
        }
    
    def _create_motion_graphics_keyframes(self, total_frames: int, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create keyframes for motion graphics animation"""
        keyframes = []
        
        # Opening keyframe (0%)
        keyframes.append({
            'frame': 0,
            'percentage': 0,
            'description': 'Initial state - elements positioned off-screen or transparent',
            'elements': {
                'main_elements': 'hidden',
                'background': 'solid_color_or_gradient',
                'opacity': 0
            },
            'transitions': ['fade_in', 'slide_in']
        })
        
        # Build-up keyframes (25%)
        keyframes.append({
            'frame': total_frames // 4,
            'percentage': 25,
            'description': 'Elements begin to appear with smooth transitions',
            'elements': {
                'main_elements': 'partially_visible',
                'text_elements': 'animating_in',
                'opacity': 0.7
            },
            'transitions': ['ease_in_out', 'scale_up']
        })
        
        # Peak keyframes (50-75%)
        keyframes.append({
            'frame': total_frames // 2,
            'percentage': 50,
            'description': 'All elements fully visible and animated',
            'elements': {
                'main_elements': 'fully_visible',
                'secondary_animations': 'active',
                'opacity': 1.0
            },
            'transitions': ['continuous_motion', 'color_shifts']
        })
        
        # Ending keyframes (100%)
        keyframes.append({
            'frame': total_frames - 1,
            'percentage': 100,
            'description': 'Loop preparation - smooth transition back to start',
            'elements': {
                'main_elements': 'transition_to_loop',
                'background': 'consistent_with_start',
                'opacity': 1.0
            },
            'transitions': ['seamless_loop', 'fade_to_start']
        })
        
        return keyframes
    
    def _generate_animation_timeline(self, spec: GIFAnimationSpec, storyboard: Dict[str, Any]) -> Dict[str, Any]:
        """Generate detailed animation timeline"""
        timeline = {
            'total_duration': spec.duration,
            'frame_rate': spec.frame_rate,
            'total_frames': storyboard['total_frames'],
            'timing_segments': []
        }
        
        # Create timing segments
        for i, keyframe in enumerate(storyboard['keyframes']):
            if i < len(storyboard['keyframes']) - 1:
                next_keyframe = storyboard['keyframes'][i + 1]
                segment_duration = (next_keyframe['frame'] - keyframe['frame']) / spec.frame_rate
                
                timeline['timing_segments'].append({
                    'segment': i + 1,
                    'start_frame': keyframe['frame'],
                    'end_frame': next_keyframe['frame'],
                    'duration': segment_duration,
                    'easing_function': self._select_easing_function(spec.style),
                    'primary_animation': keyframe.get('transitions', []),
                    'description': keyframe['description']
                })
        
        return timeline
    
    def _create_technical_specifications(self, spec: GIFAnimationSpec, timeline: Dict[str, Any]) -> Dict[str, Any]:
        """Create comprehensive technical specifications"""
        return {
            'file_format': 'GIF',
            'dimensions': spec.dimensions,
            'frame_rate': spec.frame_rate,
            'duration': spec.duration,
            'color_palette': self._generate_optimal_color_palette(spec),
            'compression_settings': {
                'optimization_level': 'high',
                'dithering': 'floyd_steinberg',
                'color_reduction': 'adaptive'
            },
            'loop_settings': {
                'loop_count': spec.loop_count,
                'loop_delay': 0
            },
            'estimated_file_size': self._estimate_file_size(spec),
            'performance_optimization': {
                'frame_disposal': 'background',
                'transparency_optimization': True,
                'frame_optimization': True
            }
        }
    
    def _generate_animation_instructions(self, technical_specs: Dict[str, Any]) -> Dict[str, Any]:
        """Generate detailed animation creation instructions"""
        return {
            'setup_instructions': [
                f"Create new project with dimensions {technical_specs['dimensions']}",
                f"Set frame rate to {technical_specs['frame_rate']} FPS",
                f"Configure color palette with {len(technical_specs['color_palette'])} colors",
                "Enable transparency support for smooth edges"
            ],
            'animation_code': self._generate_css_animation_code(technical_specs),
            'keyframe_code': self._generate_keyframe_css(technical_specs),
            'javascript_controls': self._generate_js_animation_controls(technical_specs),
            'optimization_steps': [
                "Use adaptive color reduction to minimize file size",
                "Apply Floyd-Steinberg dithering for smooth gradients",
                "Optimize frame disposal for efficient looping",
                "Remove unnecessary metadata"
            ],
            'export_settings': {
                'format': 'GIF',
                'quality': 'web_optimized',
                'loop': 'infinite',
                'compression': 'adaptive'
            }
        }
    
    def _create_gif_animation_response(self, current_response: str, analysis: Dict[str, Any], 
                                     spec: GIFAnimationSpec, storyboard: Dict[str, Any], 
                                     timeline: Dict[str, Any], instructions: Dict[str, Any]) -> str:
        """Create comprehensive GIF animation response"""
        
        animation_description = f"""
🎬 **GIF Animation Specification Created**

**Animation Type:** {spec.animation_type.replace('_', ' ').title()}
**Style:** {spec.style.replace('_', ' ').title()}
**Duration:** {spec.duration} seconds
**Dimensions:** {spec.dimensions}
**Frame Rate:** {spec.frame_rate} FPS

**🎯 Animation Concept:**
{self._describe_animation_concept(analysis, spec)}

**⏱️ Animation Timeline:**
{self._format_timeline_description(timeline)}

**🎨 Visual Elements:**
{self._format_visual_elements(storyboard)}

**💻 Technical Specifications:**
- **File Format:** GIF with infinite loop
- **Estimated Size:** {self._estimate_file_size(spec)}
- **Optimization:** Web-optimized with adaptive color palette
- **Compatibility:** Universal browser and platform support

**🛠️ Implementation Ready:**
The animation specification includes complete keyframe definitions, timing charts, and optimization settings for immediate production.
"""
        
        if current_response and current_response.strip():
            return f"{current_response}\n\n{animation_description}"
        return animation_description
    
    def _describe_animation_concept(self, analysis: Dict[str, Any], spec: GIFAnimationSpec) -> str:
        """Create engaging description of the animation concept"""
        type_descriptions = {
            'motion_graphics': 'Sleek, professional motion graphics with smooth geometric transitions and clean typography animations',
            'character_animation': 'Expressive character animation with personality-driven movements and emotional storytelling',
            'logo_reveal': 'Impactful brand presentation with memorable logo build-up and professional reveal sequence',
            'transitions': 'Seamless scene transitions with fluid morphing effects and visual continuity'
        }
        
        return type_descriptions.get(spec.animation_type, 'Custom animation sequence with engaging visual flow')
    
    def _format_timeline_description(self, timeline: Dict[str, Any]) -> str:
        """Format timeline for user-friendly description"""
        descriptions = []
        for segment in timeline['timing_segments']:
            descriptions.append(f"• **Segment {segment['segment']}** ({segment['duration']:.1f}s): {segment['description']}")
        
        return '\n'.join(descriptions)
    
    def _format_visual_elements(self, storyboard: Dict[str, Any]) -> str:
        """Format visual elements description"""
        elements = storyboard.get('visual_elements', [])
        if not elements:
            elements = ['Dynamic shapes', 'Smooth transitions', 'Engaging motion']
        
        return '\n'.join([f"• {element}" for element in elements])
    
    def _estimate_file_size(self, spec: GIFAnimationSpec) -> str:
        """Estimate GIF file size based on specifications"""
        width, height = map(int, spec.dimensions.split('x'))
        pixels = width * height
        frames = int(spec.duration * spec.frame_rate)
        
        # Rough estimation: pixels * frames * compression_factor
        estimated_kb = (pixels * frames * 0.5) / 1024  # Assuming good compression
        
        if estimated_kb < 1024:
            return f"~{estimated_kb:.0f} KB"
        else:
            return f"~{estimated_kb/1024:.1f} MB"
    
    def _determine_optimal_dimensions(self, analysis: Dict[str, Any]) -> str:
        """Determine optimal dimensions based on use case"""
        if analysis.get('technical_requirements', {}).get('social_media'):
            return "720x720"  # Square format for social media
        elif analysis.get('technical_requirements', {}).get('banner'):
            return "1200x400"  # Banner format
        elif analysis.get('technical_requirements', {}).get('icon'):
            return "256x256"  # Icon format
        else:
            return "800x600"  # Standard format
    
    def _generate_optimal_color_palette(self, spec: GIFAnimationSpec) -> List[str]:
        """Generate optimal color palette for the animation"""
        palettes = {
            'motion_graphics': ['#2196F3', '#4CAF50', '#FF9800', '#9C27B0', '#F44336'],
            'character_animation': ['#FFB74D', '#64B5F6', '#81C784', '#F06292', '#A1887F'],
            'logo_reveal': ['#1976D2', '#388E3C', '#F57C00', '#7B1FA2', '#D32F2F'],
            'transitions': ['#3F51B5', '#009688', '#FF5722', '#E91E63', '#795548']
        }
        
        return palettes.get(spec.animation_type, palettes['motion_graphics'])
    
    def _select_easing_function(self, style: str) -> str:
        """Select appropriate easing function based on style"""
        easing_map = {
            'smooth': 'ease-in-out',
            'bouncy': 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
            'elastic': 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
            'linear': 'linear'
        }
        return easing_map.get(style, 'ease-in-out')
    
    def _generate_css_animation_code(self, specs: Dict[str, Any]) -> str:
        """Generate CSS animation code"""
        return f"""
@keyframes gifAnimation {{
  0% {{ opacity: 0; transform: scale(0.8); }}
  25% {{ opacity: 0.7; transform: scale(1.1); }}
  50% {{ opacity: 1; transform: scale(1); }}
  75% {{ opacity: 1; transform: scale(1.05); }}
  100% {{ opacity: 1; transform: scale(1); }}
}}

.gif-animation {{
  width: {specs['dimensions'].split('x')[0]}px;
  height: {specs['dimensions'].split('x')[1]}px;
  animation: gifAnimation {specs['duration']}s infinite;
}}
"""
    
    def _generate_keyframe_css(self, specs: Dict[str, Any]) -> str:
        """Generate detailed keyframe CSS"""
        return """
/* Detailed keyframe animations */
@keyframes elementFadeIn { 0% { opacity: 0; } 100% { opacity: 1; } }
@keyframes elementSlideIn { 0% { transform: translateX(-100%); } 100% { transform: translateX(0); } }
@keyframes elementScaleUp { 0% { transform: scale(0); } 100% { transform: scale(1); } }
"""
    
    def _generate_js_animation_controls(self, specs: Dict[str, Any]) -> str:
        """Generate JavaScript animation controls"""
        return """
// GIF Animation Controls
const gifAnimation = {
  play: () => document.querySelector('.gif-animation').style.animationPlayState = 'running',
  pause: () => document.querySelector('.gif-animation').style.animationPlayState = 'paused',
  restart: () => {
    const element = document.querySelector('.gif-animation');
    element.style.animation = 'none';
    setTimeout(() => element.style.animation = '', 10);
  }
};
"""
    
    def _extract_user_intent(self, user_input: str) -> str:
        """Extract the primary intent from user input"""
        user_lower = user_input.lower()
        
        if any(word in user_lower for word in ['marketing', 'promotion', 'brand']):
            return 'marketing_content'
        elif any(word in user_lower for word in ['social', 'instagram', 'twitter']):
            return 'social_media'
        elif any(word in user_lower for word in ['presentation', 'slide', 'demo']):
            return 'presentation'
        elif any(word in user_lower for word in ['website', 'web', 'landing']):
            return 'web_content'
        else:
            return 'general_animation'
    
    def _extract_technical_requirements(self, user_input: str) -> Dict[str, bool]:
        """Extract technical requirements from user input"""
        user_lower = user_input.lower()
        
        return {
            'social_media': any(word in user_lower for word in ['social', 'instagram', 'twitter', 'facebook']),
            'banner': any(word in user_lower for word in ['banner', 'header', 'top']),
            'icon': any(word in user_lower for word in ['icon', 'small', 'button']),
            'high_quality': any(word in user_lower for word in ['high', 'quality', 'professional']),
            'small_size': any(word in user_lower for word in ['small', 'compressed', 'lightweight'])
        }
    
    def _create_scene_breakdown(self, keyframes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Create scene breakdown from keyframes"""
        scenes = []
        for i, keyframe in enumerate(keyframes):
            scenes.append({
                'scene': i + 1,
                'frame_start': keyframe['frame'],
                'description': keyframe['description'],
                'key_elements': keyframe.get('elements', {}),
                'transitions': keyframe.get('transitions', [])
            })
        return scenes
    
    def _create_timing_chart(self, keyframes: List[Dict[str, Any]], frame_rate: int) -> Dict[str, Any]:
        """Create detailed timing chart"""
        timing_chart = {
            'frame_rate': frame_rate,
            'keyframe_times': []
        }
        
        for keyframe in keyframes:
            time_seconds = keyframe['frame'] / frame_rate
            timing_chart['keyframe_times'].append({
                'frame': keyframe['frame'],
                'time': f"{time_seconds:.2f}s",
                'percentage': keyframe['percentage'],
                'description': keyframe['description']
            })
        
        return timing_chart
    
    def _identify_visual_elements(self, analysis: Dict[str, Any]) -> List[str]:
        """Identify key visual elements for the animation"""
        elements = []
        
        # Add elements based on detected requirements
        if 'text_animation' in analysis.get('elements', []):
            elements.append('Animated typography with smooth letter reveals')
        
        if 'shape_morphing' in analysis.get('elements', []):
            elements.append('Morphing geometric shapes with fluid transitions')
        
        if 'color_transitions' in analysis.get('elements', []):
            elements.append('Dynamic color gradients and smooth color shifts')
        
        if 'particle_effects' in analysis.get('elements', []):
            elements.append('Particle systems with engaging visual effects')
        
        if 'loading_animation' in analysis.get('elements', []):
            elements.append('Progress indicators with smooth loading sequences')
        
        # Default elements if none detected
        if not elements:
            elements = [
                'Smooth entrance animations',
                'Engaging visual flow',
                'Professional motion graphics',
                'Seamless loop transitions'
            ]
        
        return elements
    
    def _get_optimization_suggestions(self, spec: GIFAnimationSpec) -> List[str]:
        """Get optimization suggestions for the GIF"""
        suggestions = [
            f"Use adaptive color palette to reduce file size while maintaining quality",
            f"Optimize frame rate ({spec.frame_rate} FPS) for smooth motion without bloat",
            f"Apply compression techniques for {spec.optimization} optimization",
            "Use transparency optimization for smooth edges and backgrounds"
        ]
        
        if spec.duration > 4.0:
            suggestions.append("Consider reducing duration for smaller file size")
        
        if 'x' in spec.dimensions:
            width, height = map(int, spec.dimensions.split('x'))
            if width * height > 720 * 720:
                suggestions.append("Consider smaller dimensions for web optimization")
        
        return suggestions
    
    def _create_character_animation_keyframes(self, total_frames: int, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create keyframes for character animation"""
        return [
            {
                'frame': 0,
                'percentage': 0,
                'description': 'Character in rest position',
                'elements': {'character': 'idle_pose', 'expression': 'neutral'},
                'transitions': ['character_entrance']
            },
            {
                'frame': total_frames // 3,
                'percentage': 33,
                'description': 'Character begins main action',
                'elements': {'character': 'action_start', 'expression': 'engaged'},
                'transitions': ['movement_buildup']
            },
            {
                'frame': 2 * total_frames // 3,
                'percentage': 67,
                'description': 'Character peak action',
                'elements': {'character': 'peak_action', 'expression': 'excited'},
                'transitions': ['peak_performance']
            },
            {
                'frame': total_frames - 1,
                'percentage': 100,
                'description': 'Character returns to loop position',
                'elements': {'character': 'loop_return', 'expression': 'satisfied'},
                'transitions': ['seamless_loop']
            }
        ]
    
    def _create_logo_reveal_keyframes(self, total_frames: int, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create keyframes for logo reveal animation"""
        return [
            {
                'frame': 0,
                'percentage': 0,
                'description': 'Logo elements hidden or fragmented',
                'elements': {'logo_parts': 'scattered', 'background': 'brand_color'},
                'transitions': ['dramatic_entrance']
            },
            {
                'frame': total_frames // 4,
                'percentage': 25,
                'description': 'Logo elements begin to assemble',
                'elements': {'logo_parts': 'converging', 'glow_effect': 'building'},
                'transitions': ['magnetic_assembly']
            },
            {
                'frame': total_frames // 2,
                'percentage': 50,
                'description': 'Logo fully formed with impact',
                'elements': {'logo': 'complete', 'impact_effect': 'active'},
                'transitions': ['powerful_reveal']
            },
            {
                'frame': total_frames - 1,
                'percentage': 100,
                'description': 'Logo settled with subtle loop animation',
                'elements': {'logo': 'stable', 'subtle_glow': 'pulsing'},
                'transitions': ['confident_presence']
            }
        ]
    
    def _create_transition_keyframes(self, total_frames: int, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create keyframes for transition animations"""
        return [
            {
                'frame': 0,
                'percentage': 0,
                'description': 'Initial scene/state established',
                'elements': {'scene_a': 'visible', 'transition_element': 'prepared'},
                'transitions': ['scene_establishment']
            },
            {
                'frame': total_frames // 3,
                'percentage': 33,
                'description': 'Transition effect begins',
                'elements': {'transition_effect': 'active', 'scene_blend': 'starting'},
                'transitions': ['transition_initiation']
            },
            {
                'frame': 2 * total_frames // 3,
                'percentage': 67,
                'description': 'Transition at peak effect',
                'elements': {'transition_effect': 'peak', 'scene_blend': 'maximum'},
                'transitions': ['transition_climax']
            },
            {
                'frame': total_frames - 1,
                'percentage': 100,
                'description': 'New scene/state established',
                'elements': {'scene_b': 'visible', 'transition_complete': 'settled'},
                'transitions': ['transition_completion']
            }
        ]
