# 💭 Advanced Conversation Memory - Intelligent context retention and conversation state management

from .base_agent import BaseAgent
from typing import Dict, Any, List, Optional, Tuple
import time
import json
import hashlib
from datetime import datetime, timedelta
from collections import defaultdict, deque

class ConversationMemoryAgent(BaseAgent):
    """Agent 10: Advanced conversation memory with intelligent context management"""
    
    def __init__(self):
        super().__init__(
            name="ConversationMemoryAgent", 
            description="Advanced conversation memory with intelligent context retention and state management"
        )
        
        # Memory configurations
        self.memory_config = {
            'short_term_capacity': 50,  # Last 50 exchanges
            'medium_term_capacity': 200,  # Last 200 important points
            'long_term_capacity': 1000,  # Persistent important information
            'context_window': 10,  # Active context window
            'memory_decay_threshold': 0.3,  # Importance threshold for retention
            'topic_coherence_threshold': 0.7  # Topic consistency threshold
        }
        
        # Memory storage structures
        self.short_term_memory = deque(maxlen=self.memory_config['short_term_capacity'])
        self.medium_term_memory = deque(maxlen=self.memory_config['medium_term_capacity'])
        self.long_term_memory = {}
        self.topic_memory = defaultdict(list)
        self.conversation_state = {
            'current_topic': None,
            'topic_transitions': [],
            'conversation_depth': 0,
            'engagement_level': 0.5,
            'conversation_flow': 'building'
        }
        
        # Memory analysis patterns
        self.importance_indicators = {
            'high_importance': [
                'important', 'crucial', 'critical', 'essential', 'key', 'significant',
                'remember', 'note', 'don\'t forget', 'keep in mind', 'pay attention'
            ],
            'topic_markers': [
                'about', 'regarding', 'concerning', 'topic', 'subject', 'discuss',
                'talk about', 'focus on', 'working on', 'dealing with'
            ],
            'state_changes': [
                'decided', 'concluded', 'agreed', 'changed mind', 'updated',
                'modified', 'revised', 'corrected', 'clarified'
            ],
            'emotional_markers': [
                'feel', 'think', 'believe', 'prefer', 'like', 'dislike',
                'excited', 'concerned', 'worried', 'happy', 'frustrated'
            ]
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process conversation memory with intelligent context management"""
        current_response = pipeline_data.get('current_response', '')
        user_input = pipeline_data.get('user_input', '')
        
        self._log_processing(f"Memory processing: {user_input[:100]}")
        
        # Analyze current conversation exchange
        conversation_analysis = self._analyze_conversation_exchange(user_input, current_response, pipeline_data)
        
        # Update memory structures
        memory_updates = self._update_conversation_memory(conversation_analysis, pipeline_data)
        
        # Retrieve relevant context
        context_retrieval = self._retrieve_relevant_context(user_input, pipeline_data)
        
        # Update conversation state
        state_updates = self._update_conversation_state(conversation_analysis, context_retrieval)
        
        # Generate memory-enhanced response
        enhanced_response = self._create_memory_enhanced_response(
            current_response, conversation_analysis, context_retrieval, state_updates
        )
        
        return self._create_result(
            enhanced_response,
            {
                'conversation_memory': {
                    'memory_updates': memory_updates,
                    'context_retrieved': context_retrieval,
                    'state_updates': state_updates,
                    'conversation_analysis': conversation_analysis,
                    'memory_stats': self._get_memory_statistics(),
                    'processing_timestamp': datetime.now().isoformat()
                }
            }
        )
    
    def _analyze_conversation_exchange(self, user_input: str, response: str, 
                                     pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze the current conversation exchange for memory relevance"""
        
        analysis = {
            'exchange_id': self._generate_exchange_id(user_input, response),
            'timestamp': datetime.now().isoformat(),
            'user_input_analysis': self._analyze_user_input(user_input),
            'response_analysis': self._analyze_response(response),
            'importance_score': 0.5,
            'topic_coherence': 0.5,
            'emotional_tone': 'neutral',
            'memory_triggers': [],
            'context_dependencies': []
        }
        
        # Calculate importance score
        analysis['importance_score'] = self._calculate_importance_score(user_input, response)
        
        # Analyze topic coherence
        analysis['topic_coherence'] = self._calculate_topic_coherence(user_input, response)
        
        # Detect emotional tone
        analysis['emotional_tone'] = self._detect_emotional_tone(user_input, response)
        
        # Identify memory triggers
        analysis['memory_triggers'] = self._identify_memory_triggers(user_input, response)
        
        # Find context dependencies
        analysis['context_dependencies'] = self._find_context_dependencies(user_input, pipeline_data)
        
        return analysis
    
    def _analyze_user_input(self, user_input: str) -> Dict[str, Any]:
        """Analyze user input for memory-relevant information"""
        user_lower = user_input.lower()
        
        analysis = {
            'length': len(user_input),
            'word_count': len(user_input.split()),
            'question_detected': '?' in user_input,
            'command_detected': any(word in user_lower for word in ['create', 'make', 'build', 'generate']),
            'reference_detected': any(word in user_lower for word in ['remember', 'recall', 'previous', 'earlier']),
            'topic_shift_detected': any(word in user_lower for word in ['now', 'next', 'instead', 'different']),
            'importance_indicators': self._count_importance_indicators(user_input),
            'entities_mentioned': self._extract_entities(user_input)
        }
        
        return analysis
    
    def _analyze_response(self, response: str) -> Dict[str, Any]:
        """Analyze response for memory-relevant information"""
        
        analysis = {
            'length': len(response),
            'word_count': len(response.split()),
            'structured_content': '###' in response or '##' in response,
            'code_content': '```' in response,
            'list_content': '•' in response or '-' in response,
            'technical_content': self._detect_technical_content(response),
            'actionable_content': self._detect_actionable_content(response),
            'informational_density': self._calculate_informational_density(response)
        }
        
        return analysis
    
    def _calculate_importance_score(self, user_input: str, response: str) -> float:
        """Calculate importance score for memory retention"""
        score = 0.3  # Base score
        
        # User input importance factors
        user_lower = user_input.lower()
        for indicator in self.importance_indicators['high_importance']:
            if indicator in user_lower:
                score += 0.1
        
        # Response length and structure factor
        if len(response) > 500:
            score += 0.1
        if '###' in response or '##' in response:
            score += 0.1
        
        # Technical content factor
        if any(word in response.lower() for word in ['create', 'build', 'implement', 'design']):
            score += 0.2
        
        # Question complexity factor
        if '?' in user_input and len(user_input.split()) > 5:
            score += 0.1
        
        return min(1.0, score)
    
    def _calculate_topic_coherence(self, user_input: str, response: str) -> float:
        """Calculate topic coherence with current conversation"""
        if not self.conversation_state['current_topic']:
            return 0.8  # High coherence for new conversations
        
        # Simple topic coherence based on keyword overlap
        current_topic_words = set(self.conversation_state['current_topic'].lower().split())
        input_words = set(user_input.lower().split())
        response_words = set(response.lower().split())
        
        input_overlap = len(current_topic_words.intersection(input_words))
        response_overlap = len(current_topic_words.intersection(response_words))
        
        total_words = len(current_topic_words)
        if total_words == 0:
            return 0.8
        
        coherence = (input_overlap + response_overlap) / (total_words * 2)
        return min(1.0, coherence)
    
    def _detect_emotional_tone(self, user_input: str, response: str) -> str:
        """Detect emotional tone of the conversation"""
        emotional_indicators = {
            'positive': ['great', 'excellent', 'amazing', 'perfect', 'wonderful', 'fantastic', 'love'],
            'negative': ['problem', 'issue', 'error', 'wrong', 'bad', 'terrible', 'hate'],
            'neutral': ['okay', 'fine', 'normal', 'standard', 'regular'],
            'excited': ['excited', 'eager', 'looking forward', 'can\'t wait'],
            'concerned': ['worried', 'concerned', 'anxious', 'nervous', 'uncertain']
        }
        
        combined_text = (user_input + ' ' + response).lower()
        
        for tone, indicators in emotional_indicators.items():
            if any(indicator in combined_text for indicator in indicators):
                return tone
        
        return 'neutral'
    
    def _identify_memory_triggers(self, user_input: str, response: str) -> List[str]:
        """Identify triggers that should be remembered"""
        triggers = []
        
        combined_text = user_input + ' ' + response
        
        # Look for explicit memory requests
        if any(word in user_input.lower() for word in ['remember', 'save', 'note', 'keep']):
            triggers.append('explicit_memory_request')
        
        # Look for decisions or preferences
        if any(word in combined_text.lower() for word in ['decided', 'prefer', 'choose', 'selected']):
            triggers.append('decision_made')
        
        # Look for important information
        if any(word in combined_text.lower() for word in ['important', 'crucial', 'key']):
            triggers.append('important_information')
        
        # Look for personal information
        if any(word in user_input.lower() for word in ['my', 'i am', 'i have', 'i work', 'i like']):
            triggers.append('personal_information')
        
        return triggers
    
    def _find_context_dependencies(self, user_input: str, pipeline_data: Dict[str, Any]) -> List[str]:
        """Find dependencies on previous context"""
        dependencies = []
        
        # Look for references to previous content
        reference_words = ['this', 'that', 'it', 'them', 'they', 'previous', 'earlier', 'above']
        user_lower = user_input.lower()
        
        for word in reference_words:
            if word in user_lower:
                dependencies.append(f'reference_to_{word}')
        
        # Look for continuation indicators
        continuation_words = ['also', 'additionally', 'furthermore', 'moreover', 'continue']
        for word in continuation_words:
            if word in user_lower:
                dependencies.append('continuation_of_topic')
        
        return dependencies
    
    def _update_conversation_memory(self, analysis: Dict[str, Any], 
                                  pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Update conversation memory structures"""
        
        memory_entry = {
            'exchange_id': analysis['exchange_id'],
            'timestamp': analysis['timestamp'],
            'user_input': pipeline_data.get('user_input', ''),
            'response': pipeline_data.get('current_response', ''),
            'importance_score': analysis['importance_score'],
            'topic_coherence': analysis['topic_coherence'],
            'emotional_tone': analysis['emotional_tone'],
            'memory_triggers': analysis['memory_triggers'],
            'context_dependencies': analysis['context_dependencies']
        }
        
        # Add to short-term memory
        self.short_term_memory.append(memory_entry)
        
        # Add to medium-term memory if important enough
        if analysis['importance_score'] > self.memory_config['memory_decay_threshold']:
            self.medium_term_memory.append(memory_entry)
        
        # Add to long-term memory if very important
        if analysis['importance_score'] > 0.7:
            topic = self._extract_main_topic(pipeline_data.get('user_input', ''))
            if topic:
                if topic not in self.long_term_memory:
                    self.long_term_memory[topic] = []
                self.long_term_memory[topic].append(memory_entry)
        
        # Update topic memory
        current_topic = self._extract_main_topic(pipeline_data.get('user_input', ''))
        if current_topic:
            self.topic_memory[current_topic].append(memory_entry)
        
        return {
            'entries_added': 1,
            'short_term_entries': len(self.short_term_memory),
            'medium_term_entries': len(self.medium_term_memory),
            'long_term_topics': len(self.long_term_memory),
            'current_topic': current_topic
        }
    
    def _retrieve_relevant_context(self, user_input: str, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Retrieve relevant context from memory"""
        
        context = {
            'recent_context': [],
            'topic_context': [],
            'related_memories': [],
            'conversation_history_summary': '',
            'relevance_score': 0.0
        }
        
        # Get recent context from short-term memory
        context['recent_context'] = list(self.short_term_memory)[-self.memory_config['context_window']:]
        
        # Get topic-specific context
        current_topic = self._extract_main_topic(user_input)
        if current_topic and current_topic in self.topic_memory:
            context['topic_context'] = self.topic_memory[current_topic][-5:]  # Last 5 entries for topic
        
        # Find related memories based on keyword similarity
        context['related_memories'] = self._find_related_memories(user_input)
        
        # Generate conversation history summary
        context['conversation_history_summary'] = self._generate_conversation_summary()
        
        # Calculate overall relevance score
        context['relevance_score'] = self._calculate_context_relevance(user_input, context)
        
        return context
    
    def _update_conversation_state(self, analysis: Dict[str, Any], 
                                 context: Dict[str, Any]) -> Dict[str, Any]:
        """Update conversation state based on analysis and context"""
        
        # Update current topic
        new_topic = self._extract_main_topic(analysis.get('user_input_analysis', {}).get('entities_mentioned', []))
        if new_topic and new_topic != self.conversation_state['current_topic']:
            self.conversation_state['topic_transitions'].append({
                'from_topic': self.conversation_state['current_topic'],
                'to_topic': new_topic,
                'timestamp': datetime.now().isoformat()
            })
            self.conversation_state['current_topic'] = new_topic
        
        # Update conversation depth
        if analysis['importance_score'] > 0.7:
            self.conversation_state['conversation_depth'] += 1
        
        # Update engagement level
        engagement_factors = {
            'question_complexity': 0.1 if analysis.get('user_input_analysis', {}).get('question_detected') else 0,
            'response_detail': 0.1 if analysis.get('response_analysis', {}).get('structured_content') else 0,
            'topic_coherence': analysis['topic_coherence'] * 0.2,
            'emotional_engagement': 0.1 if analysis['emotional_tone'] != 'neutral' else 0
        }
        
        engagement_change = sum(engagement_factors.values())
        self.conversation_state['engagement_level'] = min(1.0, 
            self.conversation_state['engagement_level'] + engagement_change)
        
        # Update conversation flow
        if len(context['recent_context']) > 3:
            self.conversation_state['conversation_flow'] = 'flowing'
        elif analysis['topic_coherence'] > 0.8:
            self.conversation_state['conversation_flow'] = 'focused'
        else:
            self.conversation_state['conversation_flow'] = 'exploring'
        
        return {
            'state_updated': True,
            'current_topic': self.conversation_state['current_topic'],
            'conversation_depth': self.conversation_state['conversation_depth'],
            'engagement_level': self.conversation_state['engagement_level'],
            'conversation_flow': self.conversation_state['conversation_flow'],
            'topic_transitions_count': len(self.conversation_state['topic_transitions'])
        }
    
    def _create_memory_enhanced_response(self, current_response: str, analysis: Dict[str, Any],
                                       context: Dict[str, Any], state: Dict[str, Any]) -> str:
        """Create response enhanced with memory context"""
        
        response = f"""
{current_response}

## 💭 **Conversation Memory Analysis**

I'm tracking our conversation with intelligent memory management, maintaining context across our entire interaction.

### **🧠 Memory Integration**
- **Context Retention:** {len(context['recent_context'])} recent exchanges actively maintained
- **Topic Coherence:** {analysis['topic_coherence']:.1%} coherence with current conversation thread
- **Importance Score:** {analysis['importance_score']:.1%} significance level for long-term retention
- **Related Memories:** {len(context['related_memories'])} relevant past conversations identified

### **🎯 Conversation State**
- **Current Topic:** {state['current_topic'] or 'General Discussion'}
- **Conversation Depth:** Level {state['conversation_depth']} (building complexity)
- **Engagement Level:** {state['engagement_level']:.1%} active engagement
- **Flow State:** {state['conversation_flow'].title()} conversation pattern
- **Emotional Tone:** {analysis['emotional_tone'].title()} detected

### **📚 Memory Statistics**
- **Short-term Memory:** {len(self.short_term_memory)} recent exchanges
- **Medium-term Memory:** {len(self.medium_term_memory)} important points retained
- **Long-term Topics:** {len(self.long_term_memory)} topic areas with persistent context
- **Topic Transitions:** {state['topic_transitions_count']} conversation shifts tracked

### **🔗 Context Integration**
"""
        
        if context['topic_context']:
            response += f"- **Topic History:** {len(context['topic_context'])} related exchanges on this topic\n"
        
        if analysis['memory_triggers']:
            response += f"- **Memory Triggers:** {', '.join(analysis['memory_triggers'])}\n"
        
        if analysis['context_dependencies']:
            response += f"- **Context Dependencies:** References to previous content detected\n"
        
        if context['conversation_history_summary']:
            response += f"""
### **📝 Conversation Summary**
{context['conversation_history_summary']}
"""
        
        response += f"""
### **⚡ Memory Performance**
- **Processing Time:** {time.time() - self.start_time:.2f} seconds
- **Context Relevance:** {context['relevance_score']:.1%} match with current query
- **Memory Efficiency:** Optimized retention with intelligent decay

*Enhanced by ISHMEIIT AI Conversation Memory Agent - Agent 10*
*Intelligent context retention and conversation state management*
"""
        
        return response
    
    # Helper methods for memory operations
    def _generate_exchange_id(self, user_input: str, response: str) -> str:
        """Generate unique ID for conversation exchange"""
        content = f"{user_input}:{response}:{datetime.now().isoformat()}"
        return hashlib.md5(content.encode()).hexdigest()[:8]
    
    def _count_importance_indicators(self, text: str) -> int:
        """Count importance indicators in text"""
        count = 0
        text_lower = text.lower()
        for indicator in self.importance_indicators['high_importance']:
            if indicator in text_lower:
                count += 1
        return count
    
    def _extract_entities(self, text: str) -> List[str]:
        """Simple entity extraction"""
        import re
        # Extract capitalized words as potential entities
        entities = re.findall(r'\b[A-Z][a-z]+\b', text)
        return entities[:10]  # Limit to first 10
    
    def _detect_technical_content(self, text: str) -> bool:
        """Detect if content is technical"""
        technical_indicators = ['API', 'database', 'algorithm', 'function', 'code', 'implementation']
        return any(indicator in text for indicator in technical_indicators)
    
    def _detect_actionable_content(self, text: str) -> bool:
        """Detect if content contains actionable items"""
        action_words = ['create', 'build', 'implement', 'design', 'develop', 'make']
        return any(word in text.lower() for word in action_words)
    
    def _calculate_informational_density(self, text: str) -> float:
        """Calculate informational density of text"""
        if not text:
            return 0.0
        
        # Simple metric based on unique words vs total words
        words = text.lower().split()
        unique_words = set(words)
        return len(unique_words) / len(words) if words else 0.0
    
    def _extract_main_topic(self, text: Any) -> Optional[str]:
        """Extract main topic from text or entity list"""
        if isinstance(text, list) and text:
            return text[0]  # First entity as topic
        elif isinstance(text, str):
            # Simple topic extraction - first noun or important word
            important_words = ['project', 'system', 'application', 'website', 'design', 'code']
            text_lower = text.lower()
            for word in important_words:
                if word in text_lower:
                    return word
            
            # Fall back to first capitalized word
            import re
            capitalized = re.findall(r'\b[A-Z][a-z]+\b', text)
            return capitalized[0] if capitalized else None
        return None
    
    def _find_related_memories(self, user_input: str) -> List[Dict[str, Any]]:
        """Find memories related to current input"""
        related = []
        user_words = set(user_input.lower().split())
        
        # Search through medium-term memory for keyword overlap
        for memory in self.medium_term_memory:
            memory_words = set((memory['user_input'] + ' ' + memory['response']).lower().split())
            overlap = len(user_words.intersection(memory_words))
            if overlap > 2:  # Minimum 2 word overlap
                related.append(memory)
        
        return related[-5:]  # Return last 5 related memories
    
    def _generate_conversation_summary(self) -> str:
        """Generate a brief summary of the conversation"""
        if not self.short_term_memory:
            return "New conversation beginning"
        
        # Count topics and identify main themes
        topics = []
        for memory in self.short_term_memory:
            if memory.get('user_input'):
                topic = self._extract_main_topic(memory['user_input'])
                if topic:
                    topics.append(topic)
        
        if topics:
            main_topics = list(set(topics))[:3]  # Top 3 unique topics
            return f"Discussion covering: {', '.join(main_topics)}"
        else:
            return f"Ongoing conversation with {len(self.short_term_memory)} exchanges"
    
    def _calculate_context_relevance(self, user_input: str, context: Dict[str, Any]) -> float:
        """Calculate relevance of retrieved context"""
        if not context['recent_context'] and not context['topic_context']:
            return 0.0
        
        relevance_factors = []
        
        # Recent context relevance
        if context['recent_context']:
            relevance_factors.append(0.7)  # Recent context is generally relevant
        
        # Topic context relevance
        if context['topic_context']:
            relevance_factors.append(0.8)  # Topic-specific context is highly relevant
        
        # Related memories relevance
        if context['related_memories']:
            relevance_factors.append(0.6)  # Related memories are moderately relevant
        
        return sum(relevance_factors) / len(relevance_factors) if relevance_factors else 0.0
    
    def _get_memory_statistics(self) -> Dict[str, Any]:
        """Get current memory statistics"""
        return {
            'short_term_count': len(self.short_term_memory),
            'medium_term_count': len(self.medium_term_memory),
            'long_term_topics': len(self.long_term_memory),
            'total_topic_memories': sum(len(memories) for memories in self.topic_memory.values()),
            'memory_utilization': {
                'short_term': f"{len(self.short_term_memory)}/{self.memory_config['short_term_capacity']}",
                'medium_term': f"{len(self.medium_term_memory)}/{self.memory_config['medium_term_capacity']}"
            },
            'conversation_state': self.conversation_state.copy()
        }