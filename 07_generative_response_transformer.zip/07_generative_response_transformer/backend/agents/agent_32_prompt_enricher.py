# 🔍 Enriches user query
from .base_agent import BaseAgent
from typing import Dict, Any

class PromptEnricherAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="PromptEnricherAgent", description="Enriches user query")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        return self._create_result(output=current_response, metadata={'prompt_enriched': True})
"""
🔍 Agent 32: Prompt Enricher - Advanced prompt enhancement and context enrichment
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List, Tuple
import json
import re
from datetime import datetime

class Agent32PromptEnricher(BaseAgent):
    """Agent 32: Advanced prompt enhancement and context enrichment system"""
    
    def __init__(self):
        super().__init__(
            name="Agent32PromptEnricher",
            description="Advanced prompt enhancement, context enrichment, and query optimization",
            priority=7
        )
        
        # Prompt enhancement patterns
        self.enhancement_strategies = {
            'clarification_prompts': [
                "Could you provide more specific details about {topic}?",
                "What particular aspect of {topic} interests you most?",
                "Are you looking for {option1} or {option2} information?",
                "What is your experience level with {topic}?"
            ],
            'context_enrichment': [
                "To provide the most relevant answer, I should consider:",
                "This topic relates to several areas including:",
                "Key factors that might influence this are:",
                "Important context for this question includes:"
            ],
            'scope_expansion': [
                "This question touches on several related areas:",
                "You might also be interested in:",
                "Related topics that could be helpful:",
                "This connects to broader concepts like:"
            ]
        }
        
        # Domain-specific enrichment patterns
        self.domain_enrichers = {
            'technical': {
                'keywords': ['code', 'programming', 'software', 'algorithm', 'debug', 'API'],
                'enrichments': [
                    "What programming language or technology stack are you using?",
                    "What is your experience level with this technology?",
                    "Are you looking for a specific implementation or general concept?",
                    "Do you need code examples or theoretical explanation?"
                ]
            },
            'creative': {
                'keywords': ['design', 'art', 'creative', 'style', 'aesthetic', 'visual'],
                'enrichments': [
                    "What style or aesthetic are you aiming for?",
                    "Who is your target audience?",
                    "What medium or format are you working with?",
                    "Are there any constraints or requirements?"
                ]
            },
            'business': {
                'keywords': ['business', 'marketing', 'strategy', 'revenue', 'customer', 'market'],
                'enrichments': [
                    "What type and size of business are you working with?",
                    "What is your target market or customer segment?",
                    "What are your key business objectives?",
                    "What resources and constraints do you have?"
                ]
            },
            'educational': {
                'keywords': ['learn', 'study', 'teach', 'explain', 'understand', 'education'],
                'enrichments': [
                    "What is your current knowledge level on this topic?",
                    "Are you preparing for a specific exam or project?",
                    "Do you prefer detailed explanations or quick summaries?",
                    "Would examples and practical applications be helpful?"
                ]
            }
        }
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process prompt through enrichment system"""
        try:
            current_response = pipeline_data.get('current_response', '')
            user_input = pipeline_data.get('user_input', '')
            context = pipeline_data.get('context', {})
            
            self._log_processing(f"Prompt Enrichment: '{user_input[:50]}...'")
            
            # Analyze the original prompt
            prompt_analysis = self._analyze_prompt(user_input)
            
            # Identify enrichment opportunities
            enrichment_opportunities = self._identify_enrichment_opportunities(user_input, context)
            
            # Generate context enrichments
            context_enrichments = self._generate_context_enrichments(user_input, prompt_analysis)
            
            # Create follow-up questions
            follow_up_questions = self._generate_follow_up_questions(user_input, prompt_analysis)
            
            # Generate enhanced prompt variations
            prompt_variations = self._generate_prompt_variations(user_input, enrichment_opportunities)
            
            # Enhance the current response with enrichments
            enriched_response = self._enhance_response(
                current_response, enrichment_opportunities, context_enrichments, follow_up_questions
            )
            
            return self._create_result(
                enriched_response,
                {
                    'prompt_analysis': prompt_analysis,
                    'enrichment_opportunities': enrichment_opportunities,
                    'context_enrichments': context_enrichments,
                    'follow_up_questions': follow_up_questions,
                    'prompt_variations': prompt_variations,
                    'enrichment_applied': len(enrichment_opportunities) > 0
                }
            )
            
        except Exception as e:
            return self._create_result(
                current_response,
                {'error': f'Prompt enrichment failed: {str(e)}', 'fallback_applied': True}
            )
    
    def _analyze_prompt(self, user_input: str) -> Dict[str, Any]:
        """Analyze the user prompt for structure and content"""
        
        # Basic metrics
        word_count = len(user_input.split())
        sentence_count = len([s for s in user_input.split('.') if s.strip()])
        question_count = user_input.count('?')
        
        # Specificity indicators
        specific_numbers = len(re.findall(r'\b\d+\b', user_input))
        proper_nouns = len(re.findall(r'\b[A-Z][a-z]+\b', user_input))
        technical_terms = len(re.findall(r'\b\w{8,}\b', user_input))  # Long words often technical
        
        # Intent indicators
        action_verbs = len(re.findall(r'\b(?:create|make|build|design|analyze|explain|solve|fix)\b', 
                                     user_input.lower()))
        question_words = len(re.findall(r'\b(?:what|how|why|when|where|which|who)\b', 
                                       user_input.lower()))
        
        # Vagueness indicators
        vague_terms = len(re.findall(r'\b(?:thing|stuff|some|any|something|anything)\b', 
                                    user_input.lower()))
        ambiguous_pronouns = len(re.findall(r'\b(?:it|this|that|they)\b', user_input.lower()))
        
        # Calculate scores
        specificity_score = min(1.0, (specific_numbers + proper_nouns + technical_terms) / 10)
        clarity_score = max(0.1, 1.0 - (vague_terms + ambiguous_pronouns) / 10)
        completeness_score = min(1.0, word_count / 20)  # 20 words = complete
        
        return {
            'metrics': {
                'word_count': word_count,
                'sentence_count': sentence_count,
                'question_count': question_count
            },
            'specificity_indicators': {
                'specific_numbers': specific_numbers,
                'proper_nouns': proper_nouns,
                'technical_terms': technical_terms
            },
            'intent_indicators': {
                'action_verbs': action_verbs,
                'question_words': question_words
            },
            'vagueness_indicators': {
                'vague_terms': vague_terms,
                'ambiguous_pronouns': ambiguous_pronouns
            },
            'scores': {
                'specificity': specificity_score,
                'clarity': clarity_score,
                'completeness': completeness_score,
                'overall': (specificity_score + clarity_score + completeness_score) / 3
            }
        }
    
    def _identify_enrichment_opportunities(self, user_input: str, context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Identify specific opportunities to enrich the prompt"""
        opportunities = []
        user_lower = user_input.lower()
        
        # Check for domain-specific enrichment
        for domain, config in self.domain_enrichers.items():
            if any(keyword in user_lower for keyword in config['keywords']):
                opportunities.append({
                    'type': 'domain_specific',
                    'domain': domain,
                    'priority': 'high',
                    'description': f'This appears to be a {domain} question that could benefit from domain-specific context'
                })
        
        # Check for vague language
        vague_patterns = [
            (r'\b(?:something|anything|some\s+\w+)\b', 'vague_objects'),
            (r'\b(?:good|best|better)\b(?!\s+(?:practice|example))', 'vague_qualifiers'),
            (r'\b(?:help|assist)\b(?!\s+with\s+\w+)', 'vague_actions'),
            (r'\b(?:it|this|that)\b(?!\s+\w+)', 'unclear_references')
        ]
        
        for pattern, issue_type in vague_patterns:
            if re.search(pattern, user_lower):
                opportunities.append({
                    'type': 'clarification_needed',
                    'issue': issue_type,
                    'priority': 'medium',
                    'description': f'The prompt contains {issue_type.replace("_", " ")} that could be clarified'
                })
        
        # Check for incomplete specifications
        incomplete_patterns = [
            (r'\bfor\s+\w+\s*$', 'incomplete_purpose'),
            (r'\bhow\s+to\b(?!\s+\w+)', 'incomplete_method'),
            (r'\bwhat\s+is\b(?!\s+\w+)', 'incomplete_subject')
        ]
        
        for pattern, issue_type in incomplete_patterns:
            if re.search(pattern, user_input):
                opportunities.append({
                    'type': 'completion_needed',
                    'issue': issue_type,
                    'priority': 'high',
                    'description': f'The prompt appears to have {issue_type.replace("_", " ")}'
                })
        
        # Check for context opportunities
        if len(user_input.split()) < 10:
            opportunities.append({
                'type': 'context_expansion',
                'issue': 'brief_prompt',
                'priority': 'medium',
                'description': 'The prompt is brief and could benefit from additional context'
            })
        
        return opportunities
    
    def _generate_context_enrichments(self, user_input: str, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate context enrichments based on the prompt analysis"""
        enrichments = []
        
        # Add domain context if needed
        user_lower = user_input.lower()
        for domain, config in self.domain_enrichers.items():
            if any(keyword in user_lower for keyword in config['keywords']):
                enrichments.append({
                    'type': 'domain_context',
                    'domain': domain,
                    'context': f"This question relates to {domain}, which involves considerations such as:",
                    'details': config['enrichments'][:2]  # First 2 enrichments
                })
        
        # Add complexity context if the prompt seems advanced
        if analysis['scores']['specificity'] > 0.7:
            enrichments.append({
                'type': 'complexity_context',
                'context': "This appears to be an advanced topic. Here are some key considerations:",
                'details': [
                    "Prerequisites and foundational knowledge",
                    "Common challenges and pitfalls",
                    "Best practices and recommendations",
                    "Related advanced concepts"
                ]
            })
        
        # Add beginner context if the prompt seems basic
        elif analysis['scores']['specificity'] < 0.3:
            enrichments.append({
                'type': 'beginner_context',
                'context': "For a comprehensive understanding, it's helpful to consider:",
                'details': [
                    "Basic concepts and definitions",
                    "Step-by-step approach",
                    "Common examples and use cases",
                    "Next steps for learning"
                ]
            })
        
        return enrichments
    
    def _generate_follow_up_questions(self, user_input: str, analysis: Dict[str, Any]) -> List[str]:
        """Generate relevant follow-up questions to enrich understanding"""
        questions = []
        user_lower = user_input.lower()
        
        # Questions based on specificity score
        if analysis['scores']['specificity'] < 0.5:
            questions.extend([
                "Could you provide more specific details about what you're trying to achieve?",
                "What is the context or situation where this would be applied?",
                "Are there any specific constraints or requirements I should know about?"
            ])
        
        # Questions based on domain detection
        for domain, config in self.domain_enrichers.items():
            if any(keyword in user_lower for keyword in config['keywords']):
                questions.extend(config['enrichments'][:2])  # Add first 2 domain questions
                break
        
        # Questions based on intent
        if any(word in user_lower for word in ['create', 'make', 'build', 'design']):
            questions.extend([
                "What is the intended purpose or goal of what you want to create?",
                "Who is the target audience or user?",
                "Are there any design preferences or style requirements?"
            ])
        
        elif any(word in user_lower for word in ['problem', 'issue', 'error', 'fix', 'solve']):
            questions.extend([
                "Can you describe the specific problem or error you're encountering?",
                "What have you already tried to resolve this?",
                "When did this issue first occur?"
            ])
        
        elif any(word in user_lower for word in ['learn', 'understand', 'explain']):
            questions.extend([
                "What is your current knowledge level on this topic?",
                "Are you looking for a theoretical explanation or practical guidance?",
                "Would examples and real-world applications be helpful?"
            ])
        
        # Limit to most relevant questions
        return questions[:4]
    
    def _generate_prompt_variations(self, user_input: str, opportunities: List[Dict[str, Any]]) -> List[str]:
        """Generate enhanced variations of the original prompt"""
        variations = []
        
        # Create a more specific version
        if any(opp['type'] == 'clarification_needed' for opp in opportunities):
            specific_version = f"{user_input}\n\nTo provide the most helpful response, please consider including:\n"
            specific_version += "- Specific context or use case\n"
            specific_version += "- Your experience level or background\n"
            specific_version += "- Any constraints or requirements\n"
            specific_version += "- Your ultimate goal or desired outcome"
            variations.append({
                'type': 'specific_version',
                'prompt': specific_version
            })
        
        # Create a more comprehensive version
        if any(opp['type'] == 'context_expansion' for opp in opportunities):
            comprehensive_version = f"Comprehensive question: {user_input}\n\n"
            comprehensive_version += "Please provide a thorough response that covers:\n"
            comprehensive_version += "- Main concepts and principles\n"
            comprehensive_version += "- Practical examples and applications\n"
            comprehensive_version += "- Common challenges and solutions\n"
            comprehensive_version += "- Next steps or further learning resources"
            variations.append({
                'type': 'comprehensive_version',
                'prompt': comprehensive_version
            })
        
        # Create a domain-specific version
        for domain, config in self.domain_enrichers.items():
            if any(keyword in user_input.lower() for keyword in config['keywords']):
                domain_version = f"{user_input}\n\n{domain.title()} context considerations:\n"
                for enrichment in config['enrichments'][:3]:
                    domain_version += f"- {enrichment}\n"
                variations.append({
                    'type': f'{domain}_specific',
                    'prompt': domain_version
                })
                break
        
        return variations
    
    def _enhance_response(self, response: str, opportunities: List[Dict[str, Any]], 
                         enrichments: List[Dict[str, Any]], follow_up_questions: List[str]) -> str:
        """Enhance the response with enrichment information"""
        
        if not opportunities and not enrichments and not follow_up_questions:
            return response
        
        enhanced_response = response
        
        # Add context enrichments if available
        if enrichments:
            context_section = "\n\n**Additional Context:**\n"
            for enrichment in enrichments[:2]:  # Limit to 2 most relevant
                context_section += f"\n*{enrichment['context']}*\n"
                for detail in enrichment['details'][:3]:  # Limit to 3 details
                    context_section += f"• {detail}\n"
            enhanced_response += context_section
        
        # Add follow-up questions if the response could be more specific
        high_priority_opportunities = [opp for opp in opportunities if opp['priority'] == 'high']
        if high_priority_opportunities and follow_up_questions:
            questions_section = "\n\n**To provide more targeted help, consider:**\n"
            for question in follow_up_questions[:3]:  # Limit to 3 questions
                questions_section += f"• {question}\n"
            enhanced_response += questions_section
        
        # Add enrichment opportunities note for vague prompts
        if len([opp for opp in opportunities if opp['type'] == 'clarification_needed']) > 2:
            clarity_note = ("\n\n**Note**: For more precise assistance, consider providing "
                           "additional details about your specific use case and requirements.")
            enhanced_response += clarity_note
        
        return enhanced_response
