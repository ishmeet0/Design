# 🧵 Keeps track of topics
from .base_agent import BaseAgent
from typing import Dict, Any

class TopicTrackerAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="TopicTrackerAgent", description="Keeps track of topics")
    
    def process(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        current_response = pipeline_data.get('current_response', '')
        self._log_processing(current_response)
        
        return self._create_result(output=current_response, metadata={'topic_tracking': True})