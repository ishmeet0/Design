# 🧠 Neural Router - Micro neural networking for intelligent agent selection

import numpy as np
import json
import asyncio
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from collections import defaultdict, deque
import math
import logging

@dataclass
class MicroNeuralNode:
    """Micro neural network node for agent routing decisions"""
    node_id: str
    agent_type: str
    input_weights: Dict[str, float] = field(default_factory=dict)
    bias: float = 0.0
    activation_function: str = "sigmoid"
    learning_rate: float = 0.01
    momentum: float = 0.9
    
    # Performance tracking
    success_rate: float = 0.5
    response_time: float = 1.0
    quality_score: float = 0.5
    usage_frequency: int = 0
    
    # Learning history
    gradient_history: deque = field(default_factory=lambda: deque(maxlen=100))
    performance_history: deque = field(default_factory=lambda: deque(maxlen=1000))
    
    def __post_init__(self):
        if not self.input_weights:
            self.input_weights = {
                'complexity': 0.3,
                'domain_match': 0.4,
                'context_relevance': 0.2,
                'user_preference': 0.1
            }

class NeuralRouter:
    """Advanced neural router for intelligent agent selection and orchestration"""
    
    def __init__(self):
        self.neural_nodes: Dict[str, MicroNeuralNode] = {}
        self.routing_history: deque = deque(maxlen=10000)
        self.performance_metrics: Dict[str, Any] = {}
        self.learning_enabled: bool = True
        
        # Initialize micro neural network
        self._initialize_neural_network()
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        
        # Performance tracking
        self.routing_success_rate = 0.75
        self.average_response_time = 2.5
        self.total_requests_processed = 0
    
    def _initialize_neural_network(self):
        """Initialize micro neural network with specialized nodes"""
        
        # Core processing agents with specialized characteristics
        core_agents = [
            ("agent_1_input_processing", "input_analysis", {"complexity": 0.4, "domain_match": 0.3, "context_relevance": 0.2, "user_preference": 0.1}),
            ("agent_2_reasoning_engine", "logical_reasoning", {"complexity": 0.5, "domain_match": 0.2, "context_relevance": 0.2, "user_preference": 0.1}),
            ("agent_3_intent_context", "context_understanding", {"complexity": 0.3, "domain_match": 0.3, "context_relevance": 0.3, "user_preference": 0.1}),
            ("agent_6_response_generator", "content_generation", {"complexity": 0.3, "domain_match": 0.2, "context_relevance": 0.3, "user_preference": 0.2}),
            ("agent_9_personality_engine", "personality_adaptation", {"complexity": 0.2, "domain_match": 0.2, "context_relevance": 0.2, "user_preference": 0.4})
        ]
        
        # Visual creation agents with creative focus
        visual_agents = [
            ("agent_15_cad_generator", "technical_creation", {"complexity": 0.6, "domain_match": 0.3, "context_relevance": 0.1}),
            ("agent_16_drawing_generator", "artistic_creation", {"complexity": 0.4, "domain_match": 0.4, "context_relevance": 0.2}),
            ("agent_17_logo_designer", "brand_creation", {"complexity": 0.4, "domain_match": 0.4, "context_relevance": 0.2}),
            ("agent_18_image_generator", "visual_creation", {"complexity": 0.5, "domain_match": 0.3, "context_relevance": 0.2}),
            ("agent_19_animation_director", "motion_creation", {"complexity": 0.6, "domain_match": 0.3, "context_relevance": 0.1}),
            ("agent_20_ui_ux_designer", "interface_creation", {"complexity": 0.5, "domain_match": 0.3, "context_relevance": 0.2})
        ]
        
        # Document creation agents with productivity focus
        document_agents = [
            ("agent_21_pdf_generator", "document_creation", {"complexity": 0.4, "domain_match": 0.4, "context_relevance": 0.2}),
            ("agent_22_excel_creator", "spreadsheet_creation", {"complexity": 0.5, "domain_match": 0.4, "context_relevance": 0.1}),
            ("agent_23_word_builder", "text_document_creation", {"complexity": 0.4, "domain_match": 0.4, "context_relevance": 0.2}),
            ("agent_24_powerpoint_creator", "presentation_creation", {"complexity": 0.5, "domain_match": 0.3, "context_relevance": 0.2})
        ]
        
        # Create neural nodes for all agents
        all_agents = core_agents + visual_agents + document_agents
        
        for agent_id, agent_type, weights in all_agents:
            self.neural_nodes[agent_id] = MicroNeuralNode(
                node_id=agent_id,
                agent_type=agent_type,
                input_weights=weights,
                bias=np.random.normal(0, 0.1),  # Small random bias
                learning_rate=0.01 if 'core' in agent_type else 0.005  # Core agents learn faster
            )
    
    async def route_request(self, user_input: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Intelligently route request using micro neural network"""
        
        context = context or {}
        
        # Extract features from input
        input_features = await self._extract_input_features(user_input, context)
        
        # Calculate neural activations for all nodes
        node_activations = {}
        for node_id, node in self.neural_nodes.items():
            activation = self._calculate_node_activation(node, input_features)
            node_activations[node_id] = activation
        
        # Select optimal agents based on activations
        selected_agents = self._select_agents_from_activations(node_activations, input_features)
        
        # Determine processing strategy
        processing_strategy = self._determine_processing_strategy(selected_agents, input_features)
        
        # Record routing decision
        routing_decision = {
            "timestamp": datetime.now().isoformat(),
            "user_input": user_input[:200] + "..." if len(user_input) > 200 else user_input,
            "input_features": input_features,
            "node_activations": node_activations,
            "selected_agents": selected_agents,
            "processing_strategy": processing_strategy,
            "confidence": self._calculate_routing_confidence(node_activations, selected_agents)
        }
        
        self.routing_history.append(routing_decision)
        self.total_requests_processed += 1
        
        return routing_decision
    
    async def _extract_input_features(self, user_input: str, context: Dict[str, Any]) -> Dict[str, float]:
        """Extract neural network features from user input"""
        
        text_lower = user_input.lower()
        
        # Complexity analysis
        complexity_features = self._analyze_complexity(user_input)
        
        # Domain matching
        domain_features = self._analyze_domain_relevance(text_lower)
        
        # Context relevance
        context_features = self._analyze_context_relevance(user_input, context)
        
        # User preference (from history if available)
        user_preference_features = self._analyze_user_preferences(context)
        
        return {
            "complexity": complexity_features["overall_complexity"],
            "technical_complexity": complexity_features["technical_complexity"],
            "creative_complexity": complexity_features["creative_complexity"],
            
            "domain_visual_creation": domain_features["visual_creation"],
            "domain_document_creation": domain_features["document_creation"],
            "domain_data_analysis": domain_features["data_analysis"],
            "domain_general_processing": domain_features["general_processing"],
            
            "context_relevance": context_features["relevance_score"],
            "context_urgency": context_features["urgency_score"],
            
            "user_preference_visual": user_preference_features["visual_preference"],
            "user_preference_analytical": user_preference_features["analytical_preference"],
            "user_preference_creative": user_preference_features["creative_preference"]
        }
    
    def _analyze_complexity(self, user_input: str) -> Dict[str, float]:
        """Analyze input complexity across multiple dimensions"""
        
        # Text complexity metrics
        word_count = len(user_input.split())
        sentence_count = user_input.count('.') + user_input.count('!') + user_input.count('?')
        avg_word_length = np.mean([len(word) for word in user_input.split()]) if user_input.split() else 0
        
        # Technical indicators
        technical_terms = sum(1 for term in ['formula', 'calculate', 'analyze', 'data', 'chart', 'graph', 'code', 'function'] if term in user_input.lower())
        
        # Creative indicators  
        creative_terms = sum(1 for term in ['design', 'create', 'draw', 'logo', 'visual', 'art', 'style', 'color'] if term in user_input.lower())
        
        # Normalize complexity scores
        overall_complexity = min((word_count / 100 + sentence_count / 10 + avg_word_length / 10) / 3, 1.0)
        technical_complexity = min(technical_terms / 5, 1.0)
        creative_complexity = min(creative_terms / 5, 1.0)
        
        return {
            "overall_complexity": overall_complexity,
            "technical_complexity": technical_complexity,
            "creative_complexity": creative_complexity
        }
    
    def _analyze_domain_relevance(self, text_lower: str) -> Dict[str, float]:
        """Analyze domain relevance for different agent categories"""
        
        # Visual creation domain
        visual_keywords = ['design', 'create', 'draw', 'logo', 'image', 'graphic', 'visual', 'art', 'ui', 'interface', 'animation', 'cad']
        visual_score = sum(1 for keyword in visual_keywords if keyword in text_lower) / len(visual_keywords)
        
        # Document creation domain
        doc_keywords = ['document', 'pdf', 'excel', 'word', 'powerpoint', 'presentation', 'spreadsheet', 'report', 'letter', 'contract']
        doc_score = sum(1 for keyword in doc_keywords if keyword in text_lower) / len(doc_keywords)
        
        # Data analysis domain
        data_keywords = ['analyze', 'data', 'statistics', 'chart', 'graph', 'calculation', 'formula', 'pivot', 'dashboard']
        data_score = sum(1 for keyword in data_keywords if keyword in text_lower) / len(data_keywords)
        
        # General processing (always has baseline)
        general_score = 0.3 + (0.7 * (1 - max(visual_score, doc_score, data_score)))
        
        return {
            "visual_creation": min(visual_score * 2, 1.0),  # Amplify domain-specific scores
            "document_creation": min(doc_score * 2, 1.0),
            "data_analysis": min(data_score * 2, 1.0),
            "general_processing": general_score
        }
    
    def _analyze_context_relevance(self, user_input: str, context: Dict[str, Any]) -> Dict[str, float]:
        """Analyze context relevance and urgency"""
        
        # Urgency indicators
        urgency_keywords = ['urgent', 'asap', 'immediately', 'quick', 'fast', 'now', 'deadline']
        urgency_score = min(sum(1 for keyword in urgency_keywords if keyword in user_input.lower()) / 3, 1.0)
        
        # Context relevance from previous interactions
        relevance_score = 0.5  # Default
        if context.get('previous_agents'):
            # Boost relevance if similar agents were used recently
            relevance_score = 0.7
        
        return {
            "relevance_score": relevance_score,
            "urgency_score": urgency_score
        }
    
    def _analyze_user_preferences(self, context: Dict[str, Any]) -> Dict[str, float]:
        """Analyze user preferences from context and history"""
        
        # Default preferences
        preferences = {
            "visual_preference": 0.33,
            "analytical_preference": 0.33,
            "creative_preference": 0.33
        }
        
        # Adjust based on usage history (if available in context)
        if context.get('user_history'):
            history = context['user_history']
            
            # Count agent type usage
            visual_usage = sum(1 for agent in history if any(x in agent for x in ['cad', 'drawing', 'logo', 'image', 'animation', 'ui']))
            doc_usage = sum(1 for agent in history if any(x in agent for x in ['pdf', 'excel', 'word', 'powerpoint']))
            total_usage = len(history)
            
            if total_usage > 0:
                preferences["visual_preference"] = visual_usage / total_usage
                preferences["analytical_preference"] = doc_usage / total_usage
                preferences["creative_preference"] = 1 - (preferences["visual_preference"] + preferences["analytical_preference"])
        
        return preferences
    
    def _calculate_node_activation(self, node: MicroNeuralNode, features: Dict[str, float]) -> float:
        """Calculate neural node activation using weighted inputs"""
        
        # Calculate weighted sum of inputs
        weighted_sum = node.bias
        
        for feature_name, weight in node.input_weights.items():
            if feature_name == 'complexity':
                feature_value = features.get('complexity', 0)
            elif feature_name == 'domain_match':
                # Get best domain match for this node
                feature_value = self._get_best_domain_match(node, features)
            elif feature_name == 'context_relevance':
                feature_value = features.get('context_relevance', 0.5)
            elif feature_name == 'user_preference':
                feature_value = self._get_user_preference_for_node(node, features)
            else:
                feature_value = features.get(feature_name, 0)
            
            weighted_sum += weight * feature_value
        
        # Apply activation function
        if node.activation_function == "sigmoid":
            return 1 / (1 + math.exp(-weighted_sum))
        elif node.activation_function == "relu":
            return max(0, weighted_sum)
        elif node.activation_function == "tanh":
            return math.tanh(weighted_sum)
        else:
            return weighted_sum  # Linear activation
    
    def _get_best_domain_match(self, node: MicroNeuralNode, features: Dict[str, float]) -> float:
        """Get best domain match score for a specific node"""
        
        agent_type = node.agent_type
        
        if any(x in agent_type for x in ['creation', 'visual', 'artistic', 'brand', 'interface', 'motion']):
            return features.get('domain_visual_creation', 0)
        elif any(x in agent_type for x in ['document', 'spreadsheet', 'text', 'presentation']):
            return features.get('domain_document_creation', 0)
        elif any(x in agent_type for x in ['analysis', 'reasoning', 'logical']):
            return features.get('domain_data_analysis', 0)
        else:
            return features.get('domain_general_processing', 0.5)
    
    def _get_user_preference_for_node(self, node: MicroNeuralNode, features: Dict[str, float]) -> float:
        """Get user preference score for a specific node"""
        
        agent_type = node.agent_type
        
        if any(x in agent_type for x in ['creation', 'visual', 'artistic']):
            return features.get('user_preference_creative', 0.33)
        elif any(x in agent_type for x in ['analysis', 'reasoning']):
            return features.get('user_preference_analytical', 0.33)
        else:
            return features.get('user_preference_visual', 0.33)
    
    def _select_agents_from_activations(self, activations: Dict[str, float], features: Dict[str, float]) -> List[str]:
        """Select optimal agents based on neural activations"""
        
        # Always include core processing agents
        selected_agents = ['agent_1_input_processing']
        
        # Sort agents by activation score
        sorted_agents = sorted(activations.items(), key=lambda x: x[1], reverse=True)
        
        # Select high-activation agents
        activation_threshold = 0.6
        high_activation_agents = [agent_id for agent_id, score in sorted_agents if score > activation_threshold]
        
        # Ensure we have domain-specific agents based on features
        domain_agents = self._select_domain_specific_agents(features)
        
        # Combine selections
        all_selected = set(selected_agents + high_activation_agents + domain_agents)
        
        # Limit total agents to prevent over-processing
        max_agents = 8
        if len(all_selected) > max_agents:
            # Keep highest activation agents
            prioritized = sorted([(agent, activations.get(agent, 0)) for agent in all_selected], 
                               key=lambda x: x[1], reverse=True)
            all_selected = [agent for agent, _ in prioritized[:max_agents]]
        
        # Always ensure response generation
        if 'agent_6_response_generator' not in all_selected:
            all_selected.append('agent_6_response_generator')
        
        return list(all_selected)
    
    def _select_domain_specific_agents(self, features: Dict[str, float]) -> List[str]:
        """Select domain-specific agents based on feature analysis"""
        
        domain_agents = []
        
        # Visual creation domain
        if features.get('domain_visual_creation', 0) > 0.4:
            domain_agents.extend(['agent_17_logo_designer', 'agent_18_image_generator'])
        
        # Document creation domain
        if features.get('domain_document_creation', 0) > 0.4:
            domain_agents.extend(['agent_21_pdf_generator', 'agent_22_excel_creator'])
        
        # Data analysis domain
        if features.get('domain_data_analysis', 0) > 0.4:
            domain_agents.extend(['agent_2_reasoning_engine', 'agent_22_excel_creator'])
        
        return domain_agents
    
    def _determine_processing_strategy(self, selected_agents: List[str], features: Dict[str, float]) -> Dict[str, Any]:
        """Determine optimal processing strategy"""
        
        complexity = features.get('complexity', 0.5)
        urgency = features.get('context_urgency', 0.5)
        
        if len(selected_agents) <= 3:
            strategy = "sequential"
        elif urgency > 0.7:
            strategy = "parallel_fast"
        elif complexity > 0.8:
            strategy = "parallel_comprehensive"
        else:
            strategy = "adaptive_parallel"
        
        return {
            "strategy": strategy,
            "agent_count": len(selected_agents),
            "estimated_time": self._estimate_processing_time(selected_agents, strategy),
            "resource_usage": "high" if len(selected_agents) > 5 else "medium"
        }
    
    def _calculate_routing_confidence(self, activations: Dict[str, float], selected_agents: List[str]) -> float:
        """Calculate confidence in routing decision"""
        
        if not selected_agents or not activations:
            return 0.5
        
        # Calculate average activation of selected agents
        selected_activations = [activations.get(agent, 0) for agent in selected_agents]
        avg_activation = np.mean(selected_activations)
        
        # Factor in selection diversity
        activation_std = np.std(selected_activations) if len(selected_activations) > 1 else 0
        diversity_bonus = min(activation_std * 0.5, 0.2)
        
        # Factor in historical performance
        historical_performance = self.routing_success_rate
        
        confidence = (avg_activation * 0.6 + diversity_bonus + historical_performance * 0.4)
        return min(confidence, 1.0)
    
    def _estimate_processing_time(self, selected_agents: List[str], strategy: str) -> float:
        """Estimate processing time based on agents and strategy"""
        
        base_time_per_agent = 1.5  # seconds
        
        if strategy == "sequential":
            return len(selected_agents) * base_time_per_agent
        elif strategy == "parallel_fast":
            return base_time_per_agent * 1.2  # Slight overhead for coordination
        elif strategy == "parallel_comprehensive":
            return base_time_per_agent * 2.0  # More thorough processing
        else:  # adaptive_parallel
            return base_time_per_agent * 1.5
    
    def update_performance(self, routing_id: str, success: bool, response_time: float, quality_score: float):
        """Update neural network performance based on routing results"""
        
        if not self.learning_enabled:
            return
        
        # Find the routing decision
        routing_decision = None
        for decision in reversed(self.routing_history):
            if decision.get('routing_id') == routing_id:
                routing_decision = decision
                break
        
        if not routing_decision:
            return
        
        # Update performance metrics
        selected_agents = routing_decision['selected_agents']
        
        for agent_id in selected_agents:
            if agent_id in self.neural_nodes:
                node = self.neural_nodes[agent_id]
                
                # Update success rate
                node.success_rate = node.success_rate * 0.9 + (1.0 if success else 0.0) * 0.1
                
                # Update response time
                node.response_time = node.response_time * 0.9 + response_time * 0.1
                
                # Update quality score
                node.quality_score = node.quality_score * 0.9 + quality_score * 0.1
                
                # Update usage frequency
                node.usage_frequency += 1
                
                # Record performance
                node.performance_history.append({
                    'timestamp': datetime.now().isoformat(),
                    'success': success,
                    'response_time': response_time,
                    'quality_score': quality_score
                })
        
        # Update global metrics
        self.routing_success_rate = self.routing_success_rate * 0.95 + (1.0 if success else 0.0) * 0.05
        self.average_response_time = self.average_response_time * 0.95 + response_time * 0.05
    
    def get_network_status(self) -> Dict[str, Any]:
        """Get current neural network status and performance"""
        
        return {
            "network_overview": {
                "total_nodes": len(self.neural_nodes),
                "total_requests_processed": self.total_requests_processed,
                "overall_success_rate": self.routing_success_rate,
                "average_response_time": self.average_response_time
            },
            "node_performance": {
                node_id: {
                    "success_rate": node.success_rate,
                    "average_response_time": node.response_time,
                    "quality_score": node.quality_score,
                    "usage_frequency": node.usage_frequency,
                    "recent_performance": list(node.performance_history)[-5:] if node.performance_history else []
                }
                for node_id, node in self.neural_nodes.items()
            },
            "routing_statistics": {
                "recent_routing_decisions": len(self.routing_history),
                "learning_enabled": self.learning_enabled,
                "most_used_agents": self._get_most_used_agents(),
                "performance_trends": self._get_performance_trends()
            }
        }
    
    def _get_most_used_agents(self) -> List[Tuple[str, int]]:
        """Get most frequently used agents"""
        usage_counts = [(node_id, node.usage_frequency) for node_id, node in self.neural_nodes.items()]
        return sorted(usage_counts, key=lambda x: x[1], reverse=True)[:10]
    
    def _get_performance_trends(self) -> Dict[str, Any]:
        """Get performance trends over time"""
        if len(self.routing_history) < 10:
            return {"insufficient_data": True}
        
        recent_decisions = list(self.routing_history)[-100:]  # Last 100 decisions
        
        avg_confidence = np.mean([d.get('confidence', 0.5) for d in recent_decisions])
        avg_agents_selected = np.mean([len(d.get('selected_agents', [])) for d in recent_decisions])
        
        return {
            "average_routing_confidence": avg_confidence,
            "average_agents_per_request": avg_agents_selected,
            "trend_direction": "improving" if avg_confidence > 0.7 else "stable"
        }

# Global neural router instance
neural_router = NeuralRouter()