
"""
Integrated GRT System
Brings together all components of the enhanced pipeline with LLRR Engine and Meta-Agent Layer
"""

import logging
import asyncio
import time
from typing import Dict, Any, List, Optional
from datetime import datetime

from .enhanced_pipeline_orchestrator import EnhancedPipelineOrchestrator, PipelineContext
from .webscraper_integration import WebScraperEngine, KnowledgeAssessor, KnowledgeRequest
from .memory.enhanced_memory_store import EnhancedMemoryStore, WebDataMemory, AgentCommunicationMemory
from .communication_bus import CommunicationBus, AgentBusInterface, LLRRBusInterface, MemoryBusInterface, MetaAgentBusInterface, LoggingBusInterface
from .agent_controller import AgentController

logger = logging.getLogger(__name__)

class IntegratedGRTSystem:
    """
    Integrated Generative Response Transformer System
    Implements the complete enhanced pipeline with all components
    """
    
    def __init__(self):
        # Core components
        self.pipeline_orchestrator = EnhancedPipelineOrchestrator()
        self.webscraper_engine = WebScraperEngine()
        self.knowledge_assessor = KnowledgeAssessor()
        self.memory_store = EnhancedMemoryStore()
        self.communication_bus = CommunicationBus()
        self.agent_controller = AgentController()
        
        # Bus interfaces
        self.llrr_bus = None
        self.memory_bus = None
        self.meta_agent_bus = None
        self.logging_bus = None
        
        # System state
        self.initialized = False
        self.processing_sessions = {}
        
        # Performance metrics
        self.metrics = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'average_processing_time': 0.0,
            'external_knowledge_requests': 0,
            'llrr_iterations_total': 0
        }
    
    async def initialize(self):
        """Initialize the complete GRT system"""
        logger.info("🚀 Initializing Integrated GRT System...")
        
        try:
            # Initialize core components
            await self.communication_bus.initialize()
            await self.memory_store.initialize()
            await self.webscraper_engine.initialize()
            
            # Initialize bus interfaces
            self.llrr_bus = LLRRBusInterface(self.communication_bus)
            self.memory_bus = MemoryBusInterface(self.communication_bus)
            self.meta_agent_bus = MetaAgentBusInterface(self.communication_bus)
            self.logging_bus = LoggingBusInterface(self.communication_bus)
            
            # Initialize agent bus interfaces
            for i in range(1, 38):  # 37 agents
                agent_bus = AgentBusInterface(i, self.communication_bus)
            
            self.initialized = True
            logger.info("✅ Integrated GRT System initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize GRT system: {e}")
            raise
    
    async def shutdown(self):
        """Shutdown the GRT system"""
        logger.info("🔽 Shutting down Integrated GRT System...")
        
        try:
            await self.communication_bus.shutdown()
            await self.memory_store.close()
            await self.webscraper_engine.close()
            
            self.initialized = False
            logger.info("✅ GRT System shutdown complete")
            
        except Exception as e:
            logger.error(f"❌ Error during shutdown: {e}")
    
    async def process_user_input(self, user_input: str, session_id: str, 
                               user_id: str) -> Dict[str, Any]:
        """
        Process user input through the complete enhanced pipeline
        
        Flow:
        User Input → [Input Agent] → [Intent & Context Agent] → [Knowledge Assessment] 
        → [WebScraper Engine if needed] → [37 Specialized Agents] 
        → [LLRR Engine] → [Meta-Agent Layer] → [Final Enhanced Output]
        """
        
        if not self.initialized:
            raise RuntimeError("GRT System not initialized")
        
        start_time = time.time()
        session_data = {
            'session_id': session_id,
            'user_id': user_id,
            'start_time': start_time,
            'status': 'processing'
        }
        
        self.processing_sessions[session_id] = session_data
        self.metrics['total_requests'] += 1
        
        try:
            logger.info(f"🎯 Processing user input: {user_input[:100]}...")
            
            # Step 1: Knowledge Assessment
            logger.info("📚 Step 1: Knowledge Assessment")
            knowledge_request = await self.knowledge_assessor.assess_knowledge_needs(
                user_input, {'session_id': session_id, 'user_id': user_id}
            )
            
            # Step 2: External Knowledge Acquisition (if needed)
            web_data_memory = None
            if knowledge_request:
                logger.info("🌐 Step 2: External Knowledge Acquisition")
                scraped_knowledge = await self.webscraper_engine.acquire_knowledge(knowledge_request)
                
                # Store web data in memory
                if scraped_knowledge:
                    self.metrics['external_knowledge_requests'] += 1
                    
                    web_data_memory = WebDataMemory(
                        entry_id=self.memory_store.generate_entry_id(user_input, 'web_data'),
                        entry_type='web_data',
                        content={'scraped_knowledge': [knowledge.__dict__ for knowledge in scraped_knowledge]},
                        created_at=datetime.now(),
                        updated_at=datetime.now(),
                        source_url=knowledge_request.query,
                        knowledge_domains=knowledge_request.domains,
                        validation_status='validated'
                    )
                    
                    await self.memory_store.store_web_data(web_data_memory)
                    
                    # Notify via communication bus
                    await self.memory_bus.store_data('web_data', web_data_memory.__dict__)
            
            # Step 3: Enhanced Pipeline Processing
            logger.info("🤖 Step 3: Enhanced Pipeline Processing")
            pipeline_result = await self.pipeline_orchestrator.process_complete_pipeline(
                user_input, session_id, user_id
            )
            
            # Update metrics
            self.metrics['llrr_iterations_total'] += pipeline_result.get('processing_metadata', {}).get('llrr_iterations', 0)
            
            # Step 4: Store results in memory
            logger.info("💾 Step 4: Storing Results")
            await self._store_processing_results(session_id, user_id, user_input, pipeline_result)
            
            # Step 5: Update session data
            session_data['status'] = 'completed'
            session_data['processing_time'] = time.time() - start_time
            session_data['result'] = pipeline_result
            
            # Update performance metrics
            self.metrics['successful_requests'] += 1
            self._update_average_processing_time(session_data['processing_time'])
            
            logger.info(f"✅ Processing completed in {session_data['processing_time']:.2f}s")
            
            # Return enhanced result
            return {
                'success': True,
                'final_output': pipeline_result['final_output'],
                'justification': pipeline_result['justification'],
                'sources': pipeline_result['sources'],
                'processing_metadata': {
                    **pipeline_result['processing_metadata'],
                    'session_id': session_id,
                    'external_knowledge_used': knowledge_request is not None,
                    'web_sources': len(scraped_knowledge) if knowledge_request else 0,
                    'system_metrics': self.get_system_metrics()
                },
                'session_data': session_data
            }
            
        except Exception as e:
            logger.error(f"❌ Error processing user input: {e}")
            
            # Update error metrics
            self.metrics['failed_requests'] += 1
            session_data['status'] = 'error'
            session_data['error'] = str(e)
            
            return {
                'success': False,
                'error': str(e),
                'final_output': f"I apologize, but I encountered an error while processing your request: {str(e)}",
                'justification': "Error occurred during processing",
                'sources': [],
                'processing_metadata': {
                    'error': str(e),
                    'processing_time': time.time() - start_time,
                    'session_id': session_id
                }
            }
        
        finally:
            # Clean up session data
            if session_id in self.processing_sessions:
                del self.processing_sessions[session_id]
    
    async def _store_processing_results(self, session_id: str, user_id: str, 
                                       user_input: str, pipeline_result: Dict[str, Any]):
        """Store processing results in memory"""
        try:
            # Store conversation turn
            await self.memory_store.store_conversation_turn(
                session_id=session_id,
                user_id=user_id,
                turn_number=await self._get_next_turn_number(session_id),
                user_input=user_input,
                agent_outputs=pipeline_result.get('context', {}).agent_outputs if hasattr(pipeline_result.get('context', {}), 'agent_outputs') else {},
                final_response=pipeline_result['final_output'],
                processing_metadata=pipeline_result['processing_metadata']
            )
            
            # Store LLRR results if available
            if 'llrr_result' in pipeline_result:
                from .memory.enhanced_memory_store import LLRRMemory
                
                llrr_memory = LLRRMemory(
                    entry_id=self.memory_store.generate_entry_id(user_input, 'llrr'),
                    entry_type='llrr',
                    content=pipeline_result['llrr_result'].__dict__,
                    created_at=datetime.now(),
                    updated_at=datetime.now(),
                    iteration_number=pipeline_result['llrr_result'].iterations_completed,
                    reasoning_layers=pipeline_result['llrr_result'].reasoning_layers,
                    logical_errors=[],
                    harmony_score=pipeline_result['llrr_result'].confidence_score
                )
                
                await self.memory_store.store_llrr_memory(llrr_memory)
            
            # Store meta-analysis results if available
            if 'meta_result' in pipeline_result:
                from .memory.enhanced_memory_store import MetaAnalysisMemory
                
                meta_memory = MetaAnalysisMemory(
                    entry_id=self.memory_store.generate_entry_id(user_input, 'meta_analysis'),
                    entry_type='meta_analysis',
                    content=pipeline_result['meta_result'],
                    created_at=datetime.now(),
                    updated_at=datetime.now(),
                    analysis_type='final',
                    confidence_assessment=pipeline_result['meta_result'].get('meta_reasoning', {}).get('confidence_assessment', 0.0),
                    optimization_results=pipeline_result['meta_result'].get('global_optimization', {}),
                    justification=pipeline_result['justification']
                )
                
                await self.memory_store.store_meta_analysis(meta_memory)
            
        except Exception as e:
            logger.error(f"Failed to store processing results: {e}")
    
    async def _get_next_turn_number(self, session_id: str) -> int:
        """Get the next turn number for a session"""
        try:
            history = await self.memory_store.retrieve_conversation_history(session_id, limit=1)
            if history:
                return history[0]['turn_number'] + 1
            else:
                return 1
        except Exception:
            return 1
    
    def _update_average_processing_time(self, processing_time: float):
        """Update average processing time metric"""
        successful_requests = self.metrics['successful_requests']
        if successful_requests > 0:
            current_avg = self.metrics['average_processing_time']
            new_avg = ((current_avg * (successful_requests - 1)) + processing_time) / successful_requests
            self.metrics['average_processing_time'] = new_avg
    
    def get_system_metrics(self) -> Dict[str, Any]:
        """Get current system metrics"""
        return {
            **self.metrics.copy(),
            'active_sessions': len(self.processing_sessions),
            'memory_stats': asyncio.create_task(self.memory_store.get_memory_statistics()),
            'bus_stats': self.communication_bus.get_bus_statistics(),
            'system_status': 'healthy' if self.initialized else 'not_initialized',
            'timestamp': datetime.now().isoformat()
        }
    
    def get_session_status(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get status of a processing session"""
        return self.processing_sessions.get(session_id)
    
    def get_active_sessions(self) -> List[Dict[str, Any]]:
        """Get all active processing sessions"""
        return list(self.processing_sessions.values())
    
    async def get_conversation_history(self, session_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get conversation history for a session"""
        return await self.memory_store.retrieve_conversation_history(session_id, limit)
    
    async def search_knowledge(self, query: str, domains: List[str] = None) -> List[Dict[str, Any]]:
        """Search stored knowledge"""
        web_data = await self.memory_store.retrieve_web_data(domains=domains, limit=10)
        
        results = []
        for data in web_data:
            if query.lower() in str(data.content).lower():
                results.append({
                    'entry_id': data.entry_id,
                    'source_url': data.source_url,
                    'content_summary': str(data.content)[:200],
                    'relevance_score': data.relevance_score,
                    'knowledge_domains': data.knowledge_domains,
                    'created_at': data.created_at.isoformat()
                })
        
        return results
    
    async def cleanup_old_data(self, days_old: int = 30):
        """Clean up old data from memory store"""
        await self.memory_store.cleanup_old_entries(days_old)
        logger.info(f"Cleaned up data older than {days_old} days")
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform system health check"""
        health_status = {
            'system_initialized': self.initialized,
            'components': {
                'communication_bus': self.communication_bus.running,
                'memory_store': self.memory_store.connection is not None,
                'webscraper_engine': self.webscraper_engine.session is not None,
            },
            'metrics': self.get_system_metrics(),
            'timestamp': datetime.now().isoformat()
        }
        
        # Check component health
        component_status = self.communication_bus.get_all_component_status()
        health_status['component_details'] = {
            comp_id: {
                'status': state.status,
                'last_activity': state.last_activity.isoformat(),
                'message_count': state.message_count,
                'error_count': state.error_count
            }
            for comp_id, state in component_status.items()
        }
        
        # Overall health assessment
        all_healthy = all([
            health_status['system_initialized'],
            health_status['components']['communication_bus'],
            health_status['components']['memory_store'],
            health_status['components']['webscraper_engine']
        ])
        
        health_status['overall_health'] = 'healthy' if all_healthy else 'degraded'
        
        return health_status

# Global system instance
grt_system = None

async def get_grt_system() -> IntegratedGRTSystem:
    """Get or create the global GRT system instance"""
    global grt_system
    
    if grt_system is None:
        grt_system = IntegratedGRTSystem()
        await grt_system.initialize()
    
    return grt_system

async def shutdown_grt_system():
    """Shutdown the global GRT system instance"""
    global grt_system
    
    if grt_system is not None:
        await grt_system.shutdown()
        grt_system = None
