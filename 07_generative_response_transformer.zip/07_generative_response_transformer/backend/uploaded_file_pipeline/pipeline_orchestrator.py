# 🎯 Manages full flow of file processing

import logging
from typing import Dict, Any, List
import os

logger = logging.getLogger(__name__)

class PipelineOrchestrator:
    """Orchestrates the full file processing pipeline"""
    
    def __init__(self):
        self.supported_formats = ['.txt', '.pdf', '.py', '.js', '.html', '.css', '.md', '.json']
        self.upload_directory = './uploads'
        self._ensure_upload_directory()
        logger.info("🎯 Pipeline Orchestrator initialized")
    
    def _ensure_upload_directory(self):
        """Ensure upload directory exists"""
        if not os.path.exists(self.upload_directory):
            os.makedirs(self.upload_directory)
    
    def process_uploaded_file(self, file_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process an uploaded file through the pipeline"""
        filename = file_data.get('filename', '')
        file_content = file_data.get('content', '')
        file_type = self._detect_file_type(filename)
        
        logger.info(f"Processing uploaded file: {filename}")
        
        # Route to appropriate parser
        parsed_data = self._route_to_parser(file_content, file_type)
        
        # Analyze content
        analysis_result = self._analyze_content(parsed_data, file_type)
        
        # Route to appropriate agent
        agent_routing = self._route_to_agent(analysis_result, file_type)
        
        return {
            'filename': filename,
            'file_type': file_type,
            'parsed_data': parsed_data,
            'analysis': analysis_result,
            'agent_routing': agent_routing,
            'processing_complete': True
        }
    
    def _detect_file_type(self, filename: str) -> str:
        """Detect file type from filename"""
        _, ext = os.path.splitext(filename.lower())
        return ext if ext in self.supported_formats else 'unknown'
    
    def _route_to_parser(self, content: str, file_type: str) -> Dict[str, Any]:
        """Route file to appropriate parser"""
        if file_type in ['.py', '.js']:
            return {'type': 'code', 'content': content, 'language': file_type[1:]}
        elif file_type in ['.txt', '.md']:
            return {'type': 'text', 'content': content}
        elif file_type == '.json':
            return {'type': 'structured', 'content': content}
        else:
            return {'type': 'generic', 'content': content}
    
    def _analyze_content(self, parsed_data: Dict[str, Any], file_type: str) -> Dict[str, Any]:
        """Analyze parsed content"""
        content = parsed_data.get('content', '')
        
        return {
            'word_count': len(content.split()),
            'character_count': len(content),
            'file_size_category': 'small' if len(content) < 1000 else 'large',
            'complexity': 'basic'
        }
    
    def _route_to_agent(self, analysis: Dict[str, Any], file_type: str) -> Dict[str, str]:
        """Determine which agent should handle this file"""
        if file_type in ['.py', '.js']:
            return {'recommended_agent': 'agent_13_code_interpreter', 'priority': 'high'}
        elif file_type in ['.txt', '.md']:
            return {'recommended_agent': 'agent_6_response', 'priority': 'medium'}
        else:
            return {'recommended_agent': 'agent_15_file_reader', 'priority': 'low'}