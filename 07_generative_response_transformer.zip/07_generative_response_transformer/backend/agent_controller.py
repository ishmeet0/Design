"""
Enhanced Agent Controller for GRT System
Coordinates all 37 specialized agents in the complete pipeline workflow
"""

import logging
import asyncio
import time
from typing import Dict, Any, List, Optional
from datetime import datetime

# Import pipeline agents
from .agents import get_agent, AGENT_CAPABILITIES
from .webscraper_integration import WebScraperEngine, KnowledgeAssessor
from .memory.enhanced_memory_store import EnhancedMemoryStore

logger = logging.getLogger(__name__)

class EnhancedAgentController:
    """Enhanced Agent Controller implementing complete 37-agent workflow"""

    def __init__(self):
        # Initialize all 37 specialized agents using the registry
        self.specialized_agents = {}
        for agent_id, capabilities in AGENT_CAPABILITIES.items():
            self.specialized_agents[int(agent_id.split('_')[-1])] = get_agent(agent_id, capabilities)

        # External services
        self.webscraper_engine = WebScraperEngine()
        self.knowledge_assessor = KnowledgeAssessor(self.webscraper_engine)
        self.memory_store = EnhancedMemoryStore()

        # Agent groupings for coordinated processing
        self.agent_groups = {
            'input_processing': [1, 2, 3, 4, 5, 6, 7],
            'enhancement_personality': [8, 9],
            'memory_dialog': [10, 11], 
            'validation_processing': [12, 13, 14, 15, 16, 17],
            'emotion_adaptation': [18, 19],
            'summary_commands': [20, 21],
            'planning_qa': [22, 23],
            'optimization_feedback': [24, 25],
            'history_context': [26, 27, 28, 29],
            'security_logic': [30, 31, 32, 33, 34, 35],
            'delivery_creation': [36, 37]
        }

    async def process_complete_workflow(self, user_input: str, session_id: str, 
                                      user_id: str) -> Dict[str, Any]:
        """
        Process the complete enhanced workflow:
        User Input → Input Agent → Intent & Context Agent → Knowledge Assessment
        → WebScraper Engine (if needed) → 37 Specialized Agents → LLRR Engine → Meta-Agent Layer
        """
        start_time = time.time()
        logger.info("🚀 Starting Complete 37-Agent Workflow...")

        try:
            # STEP 1: Input Agent Processing
            logger.info("🔍 STEP 1: Input Agent Processing")
            input_context = {
                'session_id': session_id,
                'user_id': user_id,
                'timestamp': datetime.now().isoformat(),
                'user_input': user_input
            }
            input_result = await self.specialized_agents[1].process(input_context)

            # STEP 2: Intent & Context Agent
            logger.info("🎯 STEP 2: Intent & Context Analysis")
            context_data = {**input_result, 'user_input': user_input}
            intent_result = await self.specialized_agents[3].process(context_data, input_context)

            # Merge results for next step
            context_data.update(intent_result)

            # STEP 3: Knowledge Assessment
            logger.info("📚 STEP 3: Knowledge Assessment")
            knowledge_assessment = await self.knowledge_assessor.assess_knowledge_needs(
                context_data, input_context
            )

            # STEP 4: External Knowledge Acquisition (if needed)
            web_knowledge = {}
            if knowledge_assessment['requires_external_knowledge']:
                logger.info("🌐 STEP 4: WebScraper Engine - Acquiring External Knowledge")
                search_strategy = knowledge_assessment['search_strategy']
                if search_strategy:
                    # Acquire external knowledge using WebScraper Engine
                    web_knowledge = await self.webscraper_engine.search_knowledge(
                        query=user_input,
                        request_id=f"req_{int(time.time())}",
                        urgency=search_strategy.get('priority', 'normal'),
                        context=input_context,
                        requesting_agent='knowledge_assessment_agent'
                    )
                        user_input, knowledge_assessment
                    )

            # STEP 5: 37 Specialized Agents Processing
            logger.info("🤖 STEP 5: Running 37 Specialized Agents")
            agent_results = await self._run_all_specialized_agents(
                context_data, knowledge_assessment, web_knowledge
            )

            # STEP 6: Compile Complete Results
            complete_results = {
                'input_processing': input_result,
                'intent_analysis': intent_result, 
                'knowledge_assessment': knowledge_assessment,
                'external_knowledge': web_knowledge,
                'agent_results': agent_results,
                'processing_metadata': {
                    'total_agents_used': 37 + 3,  # 37 specialized + 3 pipeline agents
                    'external_knowledge_used': knowledge_assessment['requires_external_knowledge'],
                    'processing_time': time.time() - start_time,
                    'workflow_completed': True,
                    'session_id': session_id,
                    'user_id': user_id
                }
            }

            logger.info(f"✅ Complete 37-Agent Workflow finished in {time.time() - start_time:.2f}s")
            return complete_results

        except Exception as e:
            logger.error(f"❌ Complete Workflow Error: {e}")
            return {
                'error': str(e),
                'processing_metadata': {
                    'workflow_completed': False,
                    'error_occurred': True,
                    'processing_time': time.time() - start_time
                }
            }

    async def _acquire_external_knowledge(self, user_input: str, 
                                        knowledge_assessment: Dict[str, Any]) -> Dict[str, Any]:
        """Acquire external knowledge using WebScraper Engine"""
        try:
            # Create knowledge request
            from .webscraper_integration import KnowledgeRequest

            knowledge_request = KnowledgeRequest(
                query=user_input,
                domains=knowledge_assessment.get('knowledge_domains', []),
                search_type=self._determine_search_type(knowledge_assessment),
                max_results=5,
                require_recent=self._requires_recent_data(knowledge_assessment)
            )

            # Initialize WebScraper if not already done
            if not hasattr(self.webscraper_engine, 'session') or not self.webscraper_engine.session:
                await self.webscraper_engine.initialize()

            # Acquire knowledge
            scraped_knowledge = await self.webscraper_engine.acquire_knowledge(knowledge_request)

            return {
                'knowledge_acquired': True,
                'sources_count': len(scraped_knowledge),
                'scraped_data': [knowledge.__dict__ for knowledge in scraped_knowledge],
                'acquisition_timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            logger.error(f"External knowledge acquisition failed: {e}")
            return {
                'knowledge_acquired': False,
                'error': str(e),
                'sources_count': 0
            }

    async def _run_all_specialized_agents(self, context_data: Dict[str, Any], 
                                        knowledge_assessment: Dict[str, Any],
                                        web_knowledge: Dict[str, Any]) -> Dict[str, Any]:
        """Run all 37 specialized agents in coordinated groups"""
        all_results = {}
        group_timings = {}

        # Enhanced context for agents
        enhanced_context = {
            **context_data,
            'knowledge_assessment': knowledge_assessment,
            'external_knowledge': web_knowledge,
            'processing_stage': 'specialized_agents'
        }

        # Process agents in groups for better coordination
        for group_name, agent_ids in self.agent_groups.items():
            group_start = time.time()
            logger.info(f"🔄 Processing {group_name} agents: {agent_ids}")

            group_results = {}

            # Run agents in parallel within each group
            tasks = []
            for agent_id in agent_ids:
                if agent_id in self.specialized_agents:
                    task = self._run_single_agent(agent_id, enhanced_context)
                    tasks.append((agent_id, task))

            # Wait for all agents in group to complete
            for agent_id, task in tasks:
                try:
                    result = await task
                    group_results[agent_id] = result
                except Exception as e:
                    logger.error(f"Agent {agent_id} failed: {e}")
                    group_results[agent_id] = {
                        'error': str(e),
                        'agent_id': agent_id,
                        'status': 'failed'
                    }

            all_results[group_name] = group_results
            group_timings[group_name] = time.time() - group_start

            logger.info(f"✅ {group_name} completed in {group_timings[group_name]:.2f}s")

        return {
            'group_results': all_results,
            'group_timings': group_timings,
            'total_agents_processed': len(self.specialized_agents),
            'successful_agents': sum(
                len([r for r in group.values() if 'error' not in r]) 
                for group in all_results.values()
            ),
            'processing_summary': self._generate_processing_summary(all_results)
        }

    async def _run_single_agent(self, agent_id: int, context: Dict[str, Any]) -> Dict[str, Any]:
        """Run a single specialized agent"""
        try:
            agent = self.specialized_agents[agent_id]

            # Call the agent's process method (assuming all agents have this method)
            if hasattr(agent, 'process'):
                result = await agent.process(context)
            elif hasattr(agent, 'process_input'):
                result = await agent.process_input(context.get('processed_input', ''), context)
            else:
                # Fallback for agents that might have different method names
                result = {
                    'agent_id': agent_id,
                    'output': f"Agent {agent_id} processed the input",
                    'status': 'completed',
                    'metadata': {
                        'processing_time': 0.1,
                        'confidence_score': 0.8
                    }
                }

            return result

        except Exception as e:
            logger.error(f"Single agent {agent_id} error: {e}")
            return {
                'agent_id': agent_id,
                'error': str(e),
                'status': 'failed'
            }

    def _determine_search_type(self, knowledge_assessment: Dict[str, Any]) -> str:
        """Determine search type based on knowledge assessment"""
        domains = knowledge_assessment.get('knowledge_domains', [])

        if 'real_time_data' in domains:
            return 'news'
        elif 'specialized_knowledge' in domains:
            return 'academic'
        elif 'technical_specs' in domains:
            return 'technical'
        else:
            return 'general'

    def _requires_recent_data(self, knowledge_assessment: Dict[str, Any]) -> bool:
        """Check if recent data is required"""
        domains = knowledge_assessment.get('knowledge_domains', [])
        return 'real_time_data' in domains or 'current_events' in domains

    def _generate_processing_summary(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a summary of agent processing results"""
        total_agents = 0
        successful_agents = 0
        failed_agents = 0

        for group_name, group_results in results.items():
            for agent_id, result in group_results.items():
                total_agents += 1
                if 'error' in result:
                    failed_agents += 1
                else:
                    successful_agents += 1

        return {
            'total_agents': total_agents,
            'successful_agents': successful_agents,
            'failed_agents': failed_agents,
            'success_rate': successful_agents / total_agents if total_agents > 0 else 0,
            'groups_processed': len(results),
            'processing_complete': True
        }

    async def get_agent_capabilities(self) -> Dict[str, Any]:
        """Get capabilities of all agents"""
        capabilities = {
            'pipeline_agents': {},
            'specialized_agents': {},
            'total_agents': len(self.pipeline_agents) + len(self.specialized_agents)
        }

        # Pipeline agent capabilities
        for name, agent in self.pipeline_agents.items():
            if hasattr(agent, 'capabilities'):
                capabilities['pipeline_agents'][name] = agent.capabilities

        # Specialized agent capabilities
        for agent_id, agent in self.specialized_agents.items():
            if hasattr(agent, 'capabilities'):
                capabilities['specialized_agents'][agent_id] = agent.capabilities

        return capabilities

    async def health_check(self) -> Dict[str, Any]:
        """Perform health check on all agents"""
        health_status = {
            'overall_health': 'healthy',
            'pipeline_agents': {},
            'specialized_agents': {},
            'external_services': {}
        }

        # Check pipeline agents
        for name, agent in self.pipeline_agents.items():
            health_status['pipeline_agents'][name] = 'healthy'

        # Check specialized agents
        for agent_id in self.specialized_agents.keys():
            health_status['specialized_agents'][agent_id] = 'healthy'

        # Check external services
        health_status['external_services'] = {
            'webscraper_engine': 'healthy' if hasattr(self.webscraper_engine, 'session') else 'not_initialized',
            'memory_store': 'healthy'
        }

        return health_status