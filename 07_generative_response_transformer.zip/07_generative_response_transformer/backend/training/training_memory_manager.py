# 🧪 Save user feedback

import sqlite3
import logging
from datetime import datetime
from typing import Dict, Any

logger = logging.getLogger(__name__)

class TrainingMemoryManager:
    """Manages training memory and user feedback"""
    
    def __init__(self, db_path: str = "training_memory.db"):
        self.db_path = db_path
        self._init_database()
        logger.info("🧪 Training Memory Manager initialized")
    
    def _init_database(self):
        """Initialize training database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT,
                session_id TEXT,
                feedback_type TEXT,
                rating INTEGER,
                comments TEXT,
                response_data TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def save_feedback(self, feedback_data: Dict[str, Any]):
        """Save user feedback"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO feedback (user_id, session_id, feedback_type, rating, comments, response_data)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            feedback_data.get('user_id'),
            feedback_data.get('session_id'),
            feedback_data.get('type'),
            feedback_data.get('rating'),
            feedback_data.get('comments'),
            str(feedback_data.get('response_data', {}))
        ))
        
        conn.commit()
        conn.close()
        logger.info(f"Feedback saved for user {feedback_data.get('user_id')}")
    
    def get_feedback_stats(self) -> Dict[str, Any]:
        """Get feedback statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT AVG(rating), COUNT(*) FROM feedback WHERE rating IS NOT NULL')
        avg_rating, total_count = cursor.fetchone()
        
        conn.close()
        
        return {
            'average_rating': avg_rating or 0,
            'total_feedback': total_count or 0
        }