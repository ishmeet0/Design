# Review agent chain quality

import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class ConversationAnalyzer:
    """Analyzes conversation quality and agent performance"""
    
    def __init__(self):
        self.analysis_metrics = {
            'response_quality': [],
            'agent_performance': {},
            'user_satisfaction': []
        }
        logger.info("Conversation Analyzer initialized")
    
    def analyze_conversation(self, conversation_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a complete conversation"""
        pipeline_data = conversation_data.get('pipeline_data', {})
        stage_results = pipeline_data.get('stage_results', {})
        
        quality_score = self._calculate_quality_score(stage_results)
        agent_scores = self._analyze_agent_performance(stage_results)
        
        analysis_result = {
            'overall_quality': quality_score,
            'agent_performance': agent_scores,
            'processing_time': conversation_data.get('metadata', {}).get('total_processing_time', 0),
            'stages_completed': len(stage_results),
            'success': conversation_data.get('success', False)
        }
        
        self._update_metrics(analysis_result)
        return analysis_result
    
    def _calculate_quality_score(self, stage_results: Dict[str, Any]) -> float:
        """Calculate overall quality score"""
        if not stage_results:
            return 0.0
        
        # Simple quality scoring based on stages completed
        completed_stages = len(stage_results)
        max_stages = 37
        
        return min(1.0, completed_stages / max_stages)
    
    def _analyze_agent_performance(self, stage_results: Dict[str, Any]) -> Dict[str, float]:
        """Analyze individual agent performance"""
        agent_scores = {}
        
        for stage_id, result in stage_results.items():
            agent_name = result.get('agent', f'Agent_{stage_id}')
            # Simple performance scoring
            agent_scores[agent_name] = 1.0 if result.get('output') else 0.5
        
        return agent_scores
    
    def _update_metrics(self, analysis_result: Dict[str, Any]):
        """Update overall metrics"""
        self.analysis_metrics['response_quality'].append(analysis_result['overall_quality'])
        
        # Keep only last 100 entries
        if len(self.analysis_metrics['response_quality']) > 100:
            self.analysis_metrics['response_quality'] = self.analysis_metrics['response_quality'][-100:]
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance summary"""
        quality_scores = self.analysis_metrics['response_quality']
        
        if not quality_scores:
            return {'average_quality': 0, 'total_analyzed': 0}
        
        return {
            'average_quality': sum(quality_scores) / len(quality_scores),
            'total_analyzed': len(quality_scores),
            'latest_quality': quality_scores[-1] if quality_scores else 0
        }