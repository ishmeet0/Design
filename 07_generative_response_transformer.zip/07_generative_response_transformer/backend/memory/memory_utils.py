# Helpers: prune, search, index

from typing import Dict, Any, List
import re

def prune_memory(memory_data: List[Dict[str, Any]], max_entries: int = 50) -> List[Dict[str, Any]]:
    """Prune memory to keep only recent entries"""
    if len(memory_data) > max_entries:
        return memory_data[-max_entries:]
    return memory_data

def search_memory(memory_data: List[Dict[str, Any]], query: str) -> List[Dict[str, Any]]:
    """Search memory for relevant entries"""
    results = []
    query_lower = query.lower()
    
    for entry in memory_data:
        content = entry.get('content', '').lower()
        if query_lower in content:
            results.append(entry)
    
    return results

def index_memory(memory_data: List[Dict[str, Any]]) -> Dict[str, List[int]]:
    """Create index of memory entries"""
    index = {}
    
    for i, entry in enumerate(memory_data):
        content = entry.get('content', '')
        words = re.findall(r'\w+', content.lower())
        
        for word in words:
            if word not in index:
                index[word] = []
            index[word].append(i)
    
    return index