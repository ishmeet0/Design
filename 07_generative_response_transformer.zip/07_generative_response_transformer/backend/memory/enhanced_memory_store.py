"""
Enhanced Memory Store for GRT System
Manages conversation memory and context persistence
"""

import json
import logging
import time
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from collections import defaultdict, deque

logger = logging.getLogger(__name__)

class EnhancedMemoryStore:
    """Enhanced memory management for conversation context"""
    
    def __init__(self, max_memory_size: int = 1000):
        self.max_memory_size = max_memory_size
        self.conversations = {}
        self.user_profiles = {}
        self.context_cache = defaultdict(lambda: deque(maxlen=50))
        self.knowledge_cache = {}
        
        logger.info("🧠 Enhanced Memory Store initialized")
    
    async def store_conversation(self, session_id: str, user_id: str, 
                               conversation_data: Dict[str, Any]) -> bool:
        """Store conversation data"""
        try:
            if session_id not in self.conversations:
                self.conversations[session_id] = {
                    'session_id': session_id,
                    'user_id': user_id,
                    'created': datetime.now().isoformat(),
                    'messages': [],
                    'context': {},
                    'metadata': {}
                }
            
            # Store the conversation message
            self.conversations[session_id]['messages'].append({
                'timestamp': datetime.now().isoformat(),
                'data': conversation_data
            })
            
            # Update context cache
            self.context_cache[session_id].append(conversation_data)
            
            # Clean up old conversations if needed
            await self._cleanup_old_conversations()
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to store conversation: {e}")
            return False
    
    async def retrieve_conversation_context(self, session_id: str, 
                                          messages_limit: int = 10) -> Dict[str, Any]:
        """Retrieve conversation context"""
        try:
            if session_id in self.conversations:
                conversation = self.conversations[session_id]
                recent_messages = list(self.context_cache[session_id])[-messages_limit:]
                
                return {
                    'session_id': session_id,
                    'user_id': conversation['user_id'],
                    'recent_messages': recent_messages,
                    'context': conversation.get('context', {}),
                    'message_count': len(conversation['messages']),
                    'session_age': self._calculate_session_age(conversation['created'])
                }
            else:
                return {
                    'session_id': session_id,
                    'user_id': None,
                    'recent_messages': [],
                    'context': {},
                    'message_count': 0,
                    'session_age': 0
                }
                
        except Exception as e:
            logger.error(f"Failed to retrieve conversation context: {e}")
            return {'error': str(e)}
    
    async def update_user_profile(self, user_id: str, profile_data: Dict[str, Any]) -> bool:
        """Update user profile information"""
        try:
            if user_id not in self.user_profiles:
                self.user_profiles[user_id] = {
                    'user_id': user_id,
                    'created': datetime.now().isoformat(),
                    'preferences': {},
                    'interaction_history': [],
                    'learned_patterns': {}
                }
            
            # Update profile
            self.user_profiles[user_id].update(profile_data)
            self.user_profiles[user_id]['last_updated'] = datetime.now().isoformat()
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to update user profile: {e}")
            return False
    
    async def get_user_profile(self, user_id: str) -> Dict[str, Any]:
        """Get user profile information"""
        return self.user_profiles.get(user_id, {
            'user_id': user_id,
            'preferences': {},
            'interaction_history': [],
            'learned_patterns': {}
        })
    
    async def store_knowledge_cache(self, query: str, knowledge_data: Dict[str, Any]) -> bool:
        """Store knowledge data in cache"""
        try:
            cache_key = self._generate_cache_key(query)
            self.knowledge_cache[cache_key] = {
                'query': query,
                'data': knowledge_data,
                'cached_at': datetime.now().isoformat(),
                'access_count': 0
            }
            return True
            
        except Exception as e:
            logger.error(f"Failed to store knowledge cache: {e}")
            return False
    
    async def retrieve_knowledge_cache(self, query: str) -> Optional[Dict[str, Any]]:
        """Retrieve cached knowledge data"""
        try:
            cache_key = self._generate_cache_key(query)
            if cache_key in self.knowledge_cache:
                cached_item = self.knowledge_cache[cache_key]
                cached_item['access_count'] += 1
                cached_item['last_accessed'] = datetime.now().isoformat()
                
                # Check if cache is still valid (24 hours)
                cached_time = datetime.fromisoformat(cached_item['cached_at'])
                if datetime.now() - cached_time < timedelta(hours=24):
                    return cached_item['data']
                else:
                    # Remove expired cache
                    del self.knowledge_cache[cache_key]
            
            return None
            
        except Exception as e:
            logger.error(f"Failed to retrieve knowledge cache: {e}")
            return None
    
    async def get_memory_stats(self) -> Dict[str, Any]:
        """Get memory store statistics"""
        return {
            'total_conversations': len(self.conversations),
            'total_users': len(self.user_profiles),
            'cache_size': len(self.knowledge_cache),
            'memory_usage': self._calculate_memory_usage(),
            'oldest_conversation': self._get_oldest_conversation_date(),
            'most_active_user': self._get_most_active_user()
        }
    
    def _generate_cache_key(self, query: str) -> str:
        """Generate cache key from query"""
        return f"knowledge_{hash(query.lower().strip())}"
    
    def _calculate_session_age(self, created_time: str) -> float:
        """Calculate session age in minutes"""
        try:
            created = datetime.fromisoformat(created_time)
            return (datetime.now() - created).total_seconds() / 60
        except:
            return 0
    
    def _calculate_memory_usage(self) -> Dict[str, int]:
        """Calculate memory usage statistics"""
        return {
            'conversations_mb': len(str(self.conversations)) / (1024 * 1024),
            'profiles_mb': len(str(self.user_profiles)) / (1024 * 1024), 
            'cache_mb': len(str(self.knowledge_cache)) / (1024 * 1024)
        }
    
    def _get_oldest_conversation_date(self) -> Optional[str]:
        """Get the oldest conversation date"""
        if not self.conversations:
            return None
        
        oldest = min(self.conversations.values(), key=lambda x: x['created'])
        return oldest['created']
    
    def _get_most_active_user(self) -> Optional[str]:
        """Get the most active user ID"""
        if not self.conversations:
            return None
        
        user_activity = defaultdict(int)
        for conv in self.conversations.values():
            user_activity[conv['user_id']] += len(conv['messages'])
        
        return max(user_activity.items(), key=lambda x: x[1])[0] if user_activity else None
    
    async def _cleanup_old_conversations(self):
        """Clean up old conversations to manage memory"""
        if len(self.conversations) > self.max_memory_size:
            # Remove oldest conversations
            sorted_conversations = sorted(
                self.conversations.items(),
                key=lambda x: x[1]['created']
            )
            
            # Keep newest 80% of conversations
            keep_count = int(self.max_memory_size * 0.8)
            conversations_to_remove = sorted_conversations[:-keep_count]
            
            for session_id, _ in conversations_to_remove:
                del self.conversations[session_id]
                if session_id in self.context_cache:
                    del self.context_cache[session_id]
                    
            logger.info(f"🧹 Cleaned up {len(conversations_to_remove)} old conversations")