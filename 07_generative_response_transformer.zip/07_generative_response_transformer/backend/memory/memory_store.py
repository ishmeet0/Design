# 🧠 Store/retrieve memory

import logging
from typing import Dict, Any, List
from datetime import datetime

logger = logging.getLogger(__name__)

class MemoryStore:
    """Memory storage and retrieval system"""
    
    def __init__(self):
        self.short_term_memory = {}
        self.long_term_memory = {}
        logger.info("🧠 Memory Store initialized")
    
    def store_conversation(self, user_id: str, session_id: str, conversation_data: Dict[str, Any]):
        """Store conversation in memory"""
        key = f"{user_id}_{session_id}"
        
        if key not in self.short_term_memory:
            self.short_term_memory[key] = []
        
        self.short_term_memory[key].append({
            **conversation_data,
            'timestamp': datetime.now().isoformat()
        })
    
    def retrieve_conversation(self, user_id: str, session_id: str) -> List[Dict[str, Any]]:
        """Retrieve conversation from memory"""
        key = f"{user_id}_{session_id}"
        return self.short_term_memory.get(key, [])
    
    def clear_session(self, user_id: str, session_id: str):
        """Clear session memory"""
        key = f"{user_id}_{session_id}"
        if key in self.short_term_memory:
            del self.short_term_memory[key]