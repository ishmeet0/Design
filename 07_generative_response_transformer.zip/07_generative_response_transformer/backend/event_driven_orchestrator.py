
#!/usr/bin/env python3
"""
Enhanced Event-Driven Orchestrator
Implements the 9-point event flow architecture with comprehensive error handling
"""

import asyncio
import logging
import json
import time
import traceback
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime
from dataclasses import dataclass, asdict
from enum import Enum
import threading
import queue

logger = logging.getLogger(__name__)

class EventType(Enum):
    """Event types in the 9-point flow"""
    USER_INPUT = "user.input"
    INTENT_DETECTED = "intent.detected"
    KNOWLEDGE_ASSESSMENT = "knowledge.assessment"
    WEBSCRAPER_RESULT = "webscraper.result"
    AGENT_OUTPUT_PARTIAL = "agent.output.partial"
    LLRR_REVIEW_CYCLE = "llrr.review.cycle"
    LLRR_FINAL_OUTPUT = "llrr.final.output"
    METAAGENT_OPTIMIZED_OUTPUT = "metaagent.optimized.output"
    OUTPUT_FINAL_DELIVER = "output.final.deliver"

@dataclass
class Event:
    """Event data structure"""
    event_type: str
    data: Dict[str, Any]
    timestamp: str
    event_id: str
    session_id: str
    metadata: Dict[str, Any] = None

class EventSubscriber:
    """Base class for event subscribers"""
    
    def __init__(self, name: str):
        self.name = name
        self.processed_events = 0
        self.last_activity = datetime.now()
    
    def process_event(self, event: Event) -> Dict[str, Any]:
        """Process an event and return result"""
        try:
            self.processed_events += 1
            self.last_activity = datetime.now()
            return self._handle_event(event)
        except Exception as e:
            logger.error(f"Event processing error in {self.name}: {str(e)}")
            return {'error': str(e), 'success': False}
    
    def _handle_event(self, event: Event) -> Dict[str, Any]:
        """Override this method in subclasses"""
        return {'success': True, 'response': f"Processed by {self.name}"}

class InputAgent(EventSubscriber):
    """Input processing agent"""
    
    def _handle_event(self, event: Event) -> Dict[str, Any]:
        try:
            user_input = event.data.get('message', '')
            
            # Enhanced input analysis
            analysis = {
                'text_length': len(user_input),
                'word_count': len(user_input.split()),
                'language_detected': 'en',  # Basic detection
                'complexity_score': min(len(user_input) / 100, 1.0),
                'requires_processing': len(user_input.strip()) > 0
            }
            
            return {
                'success': True,
                'analysis': analysis,
                'processed_input': user_input.strip(),
                'next_event': EventType.INTENT_DETECTED.value
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

class IntentContextAgent(EventSubscriber):
    """Intent and context detection agent"""
    
    def _handle_event(self, event: Event) -> Dict[str, Any]:
        try:
            processed_input = event.data.get('processed_input', '')
            
            # Enhanced intent analysis
            intent_keywords = {
                'question': ['what', 'how', 'why', 'when', 'where', 'who', '?'],
                'request': ['please', 'can you', 'could you', 'help me'],
                'command': ['create', 'make', 'build', 'generate', 'design'],
                'analysis': ['analyze', 'explain', 'compare', 'evaluate']
            }
            
            detected_intent = 'general'
            confidence = 0.5
            
            for intent, keywords in intent_keywords.items():
                if any(keyword in processed_input.lower() for keyword in keywords):
                    detected_intent = intent
                    confidence = 0.8
                    break
            
            context = {
                'intent': detected_intent,
                'confidence': confidence,
                'entities': [],  # Could be enhanced with NER
                'sentiment': 'neutral',
                'urgency': 'normal'
            }
            
            return {
                'success': True,
                'context': context,
                'next_event': EventType.KNOWLEDGE_ASSESSMENT.value
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

class KnowledgeAssessmentAgent(EventSubscriber):
    """Knowledge assessment and routing agent"""
    
    def _handle_event(self, event: Event) -> Dict[str, Any]:
        try:
            context = event.data.get('context', {})
            intent = context.get('intent', 'general')
            
            # Determine processing route
            processing_routes = {
                'question': {'needs_web_data': False, 'agents_required': ['reasoning', 'knowledge']},
                'request': {'needs_web_data': False, 'agents_required': ['task', 'planning']},
                'command': {'needs_web_data': False, 'agents_required': ['creation', 'validation']},
                'analysis': {'needs_web_data': True, 'agents_required': ['analysis', 'research', 'synthesis']}
            }
            
            route = processing_routes.get(intent, processing_routes['question'])
            
            assessment = {
                'processing_route': route,
                'complexity_level': 'medium',
                'estimated_time': '2-5 seconds',
                'parallel_processing': True
            }
            
            # Determine next event based on assessment
            next_event = (EventType.WEBSCRAPER_RESULT.value if route['needs_web_data'] 
                         else EventType.AGENT_OUTPUT_PARTIAL.value)
            
            return {
                'success': True,
                'assessment': assessment,
                'next_event': next_event
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

class EnhancedEventDrivenOrchestrator:
    """
    Enhanced Event-Driven Orchestrator
    Implements the complete 9-point event flow with robust error handling
    """
    
    def __init__(self):
        self.subscribers = {}
        self.event_history = []
        self.processing_stats = {
            'events_processed': 0,
            'errors_handled': 0,
            'average_processing_time': 0.0
        }
        
        # Initialize event processing queue
        self.event_queue = queue.Queue()
        self.processing_thread = None
        self.is_running = False
        
        # Register default subscribers
        self._register_default_subscribers()
        
        logger.info("Enhanced Event-Driven Orchestrator initialized")
    
    def _register_default_subscribers(self):
        """Register default event subscribers"""
        # Event 1: user.input subscribers
        self.subscribe(EventType.USER_INPUT.value, [
            InputAgent("Input Agent"),
            EventSubscriber("Logger"),
            EventSubscriber("ProactiveNeedPredictor")
        ])
        
        # Event 2: intent.detected subscribers
        self.subscribe(EventType.INTENT_DETECTED.value, [
            IntentContextAgent("Intent & Context Agent"),
            EventSubscriber("Memory Manager"),
            EventSubscriber("ParallelContextAugmentor")
        ])
        
        # Event 3: knowledge.assessment subscribers
        self.subscribe(EventType.KNOWLEDGE_ASSESSMENT.value, [
            KnowledgeAssessmentAgent("Knowledge Assessment Agent")
        ])
        
        # Additional event subscribers can be added here
        logger.info("Default event subscribers registered")
    
    def subscribe(self, event_type: str, subscribers: List[EventSubscriber]):
        """Subscribe agents to specific events"""
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        
        self.subscribers[event_type].extend(subscribers)
        logger.info(f"Registered {len(subscribers)} subscribers for {event_type}")
    
    def publish_event(self, event_type: str, data: Dict[str, Any], session_id: str = None) -> str:
        """Publish an event to the system"""
        try:
            event_id = f"evt_{int(time.time() * 1000)}"
            session_id = session_id or f"session_{int(time.time())}"
            
            event = Event(
                event_type=event_type,
                data=data,
                timestamp=datetime.now().isoformat(),
                event_id=event_id,
                session_id=session_id,
                metadata={'source': 'orchestrator'}
            )
            
            # Add to processing queue
            self.event_queue.put(event)
            
            # Add to history
            self.event_history.append(event)
            
            # Keep history manageable
            if len(self.event_history) > 1000:
                self.event_history = self.event_history[-500:]
            
            logger.info(f"Event published: {event_type} (ID: {event_id})")
            return event_id
            
        except Exception as e:
            logger.error(f"Error publishing event: {str(e)}")
            raise
    
    def process_event(self, event_type: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Process an event synchronously and return results"""
        start_time = time.time()
        
        try:
            # Create event
            event_id = f"evt_{int(time.time() * 1000)}"
            session_id = data.get('session_id', f"session_{int(time.time())}")
            
            event = Event(
                event_type=event_type,
                data=data,
                timestamp=datetime.now().isoformat(),
                event_id=event_id,
                session_id=session_id
            )
            
            # Process event
            results = self._process_event_sync(event)
            
            # Update stats
            processing_time = time.time() - start_time
            self._update_stats(processing_time)
            
            return {
                'success': True,
                'event_id': event_id,
                'results': results,
                'processing_time': processing_time,
                'response': self._extract_response(results)
            }
            
        except Exception as e:
            logger.error(f"Event processing error: {str(e)}\n{traceback.format_exc()}")
            self.processing_stats['errors_handled'] += 1
            
            return {
                'success': False,
                'error': str(e),
                'event_type': event_type
            }
    
    def _process_event_sync(self, event: Event) -> List[Dict[str, Any]]:
        """Process event synchronously with all subscribers"""
        results = []
        
        # Get subscribers for this event type
        event_subscribers = self.subscribers.get(event.event_type, [])
        
        if not event_subscribers:
            logger.warning(f"No subscribers found for event type: {event.event_type}")
            return [{'warning': 'No subscribers available'}]
        
        # Process with each subscriber
        for subscriber in event_subscribers:
            try:
                result = subscriber.process_event(event)
                result['subscriber'] = subscriber.name
                results.append(result)
                
                # Check if this result triggers a new event
                if 'next_event' in result and result.get('success'):
                    next_event_type = result['next_event']
                    next_data = {**event.data, **result}
                    
                    # Recursively process next event
                    next_results = self.process_event(next_event_type, next_data)
                    if next_results.get('success'):
                        results.extend(next_results.get('results', []))
                
            except Exception as e:
                logger.error(f"Subscriber error ({subscriber.name}): {str(e)}")
                results.append({
                    'subscriber': subscriber.name,
                    'success': False,
                    'error': str(e)
                })
        
        return results
    
    def _extract_response(self, results: List[Dict[str, Any]]) -> str:
        """Extract the best response from processing results"""
        try:
            # Find successful results with responses
            valid_responses = []
            
            for result in results:
                if result.get('success') and 'response' in result:
                    valid_responses.append(result['response'])
                elif result.get('success') and 'processed_input' in result:
                    # Use processed input as fallback
                    processed = result.get('processed_input', '')
                    if processed:
                        valid_responses.append(f"I understand you said: {processed}")
            
            if valid_responses:
                # Return the most comprehensive response
                return max(valid_responses, key=len)
            else:
                # Generate fallback response
                return "I've processed your request through the event-driven system. The agents are working to provide you with a comprehensive response."
                
        except Exception as e:
            logger.error(f"Response extraction error: {str(e)}")
            return "I apologize, but I encountered an issue while processing your request."
    
    def _update_stats(self, processing_time: float):
        """Update processing statistics"""
        self.processing_stats['events_processed'] += 1
        
        # Update average processing time
        current_avg = self.processing_stats['average_processing_time']
        event_count = self.processing_stats['events_processed']
        
        self.processing_stats['average_processing_time'] = (
            (current_avg * (event_count - 1) + processing_time) / event_count
        )
    
    def get_stats(self) -> Dict[str, Any]:
        """Get orchestrator statistics"""
        return {
            'processing_stats': self.processing_stats,
            'subscriber_stats': {
                event_type: [
                    {
                        'name': sub.name,
                        'processed_events': sub.processed_events,
                        'last_activity': sub.last_activity.isoformat()
                    }
                    for sub in subscribers
                ]
                for event_type, subscribers in self.subscribers.items()
            },
            'recent_events': len(self.event_history),
            'system_health': 'operational'
        }
    
    def start_async_processing(self):
        """Start asynchronous event processing"""
        if self.is_running:
            return
        
        self.is_running = True
        self.processing_thread = threading.Thread(target=self._async_event_processor)
        self.processing_thread.daemon = True
        self.processing_thread.start()
        
        logger.info("Async event processing started")
    
    def stop_async_processing(self):
        """Stop asynchronous event processing"""
        self.is_running = False
        if self.processing_thread:
            self.processing_thread.join(timeout=5)
        
        logger.info("Async event processing stopped")
    
    def _async_event_processor(self):
        """Asynchronous event processor"""
        while self.is_running:
            try:
                # Get event from queue with timeout
                event = self.event_queue.get(timeout=1)
                
                # Process event
                self._process_event_sync(event)
                
                # Mark task as done
                self.event_queue.task_done()
                
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Async processing error: {str(e)}")

# Create global instance
EventDrivenOrchestrator = EnhancedEventDrivenOrchestrator

def main():
    """Test the enhanced event-driven orchestrator"""
    orchestrator = EnhancedEventDrivenOrchestrator()
    
    # Test event processing
    test_data = {
        'message': 'Hello, how can you help me create a web application?',
        'session_id': 'test_session_001'
    }
    
    result = orchestrator.process_event(EventType.USER_INPUT.value, test_data)
    
    print("Test Result:")
    print(json.dumps(result, indent=2, default=str))
    
    print("\nOrchestrator Stats:")
    print(json.dumps(orchestrator.get_stats(), indent=2, default=str))

if __name__ == '__main__':
    main()
