#!/usr/bin/env python3
"""
GRT Co-op Backend Server
Provides API endpoints for the collaborative frontend interface
"""

import os
import sys
import time
import json
import logging
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room, leave_room

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('GRT-Coop-Server')

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET', 'grt-coop-secret-key')

# Enable CORS for all routes
CORS(app, origins=['http://localhost:5107', 'http://0.0.0.0:5107'])

# Initialize SocketIO for real-time collaboration
socketio = SocketIO(app, cors_allowed_origins=['http://localhost:5107', 'http://0.0.0.0:5107'])

# In-memory storage for demo purposes
active_sessions = {}
collaborators = {}
projects = {}
agent_status = {
    'total_agents': 37,
    'active_agents': 35,
    'available_agents': [
        'reasoning', 'creative', 'technical', 'research', 
        'collaboration', 'planning', 'quality', 'communication',
        'analysis', 'synthesis', 'optimization', 'validation'
    ],
    'system_health': 'optimal',
    'last_update': datetime.now().isoformat()
}

# Mock 37-Agent Pipeline Simulator
class MockAgentPipeline:
    def __init__(self):
        self.agents = {
            'input_processor': {'status': 'active', 'load': 15},
            'intent_analyzer': {'status': 'active', 'load': 22},
            'context_manager': {'status': 'active', 'load': 18},
            'reasoning_engine': {'status': 'active', 'load': 35},
            'knowledge_retriever': {'status': 'active', 'load': 28},
            'creative_synthesizer': {'status': 'active', 'load': 12},
            'technical_specialist': {'status': 'active', 'load': 41},
            'quality_validator': {'status': 'active', 'load': 19},
            'response_formatter': {'status': 'active', 'load': 8},
            'output_optimizer': {'status': 'active', 'load': 16}
        }
    
    def process_message(self, message, selected_agents=None, session_id=None):
        """Simulate 37-agent pipeline processing"""
        start_time = time.time()
        
        # Simulate agent selection and processing
        if not selected_agents or 'auto' in selected_agents:
            # Auto-select optimal agents based on message analysis
            involved_agents = self._auto_select_agents(message)
        else:
            involved_agents = selected_agents
        
        # Simulate processing delay based on complexity
        processing_time = max(0.5, len(message) * 0.01 + len(involved_agents) * 0.1)
        time.sleep(min(processing_time, 2.0))  # Cap at 2 seconds for demo
        
        # Generate response based on message content
        response = self._generate_response(message, involved_agents)
        
        end_time = time.time()
        
        return {
            'response': response,
            'confidence': round(0.85 + (len(involved_agents) * 0.02), 2),
            'processing_time': round(end_time - start_time, 2),
            'agents_used': involved_agents,
            'primary_agent': involved_agents[0] if involved_agents else 'auto-selector',
            'sources': self._get_mock_sources(message),
            'metadata': {
                'session_id': session_id,
                'timestamp': datetime.now().isoformat(),
                'model': 'GRT-37-Agent-Pipeline',
                'agent_count': len(involved_agents)
            }
        }
    
    def _auto_select_agents(self, message):
        """Simulate intelligent agent selection"""
        message_lower = message.lower()
        agents = []
        
        # Basic keyword-based selection
        if any(word in message_lower for word in ['code', 'programming', 'debug', 'implement']):
            agents.extend(['technical_specialist', 'quality_validator'])
        
        if any(word in message_lower for word in ['creative', 'design', 'idea', 'brainstorm']):
            agents.extend(['creative_synthesizer', 'reasoning_engine'])
        
        if any(word in message_lower for word in ['research', 'find', 'information', 'learn']):
            agents.extend(['knowledge_retriever', 'research_specialist'])
        
        if any(word in message_lower for word in ['collaborate', 'team', 'together', 'share']):
            agents.extend(['collaboration_manager', 'communication_enhancer'])
        
        # Always include core agents
        core_agents = ['input_processor', 'intent_analyzer', 'response_formatter']
        agents.extend(core_agents)
        
        # Remove duplicates and return
        return list(set(agents))[:8]  # Limit to 8 agents for efficiency
    
    def _generate_response(self, message, agents):
        """Generate contextual response based on message and agents"""
        message_lower = message.lower()
        
        # Collaborative responses
        if any(word in message_lower for word in ['collaborate', 'team', 'together']):
            return f"""I'm ready to collaborate with you! As a 37-agent system, I can coordinate multiple AI specialists to work on your project.

**How I can help with collaboration:**
• **Real-time coordination**: Multiple agents can work simultaneously on different aspects
• **Specialized expertise**: Each agent brings unique capabilities (technical, creative, research, etc.)
• **Intelligent task distribution**: I automatically assign the best agents for each subtask
• **Seamless integration**: All agent outputs are synthesized into coherent responses

The agents currently involved are: {', '.join(agents)}

What would you like us to work on together?"""
        
        # Technical requests
        elif any(word in message_lower for word in ['code', 'programming', 'debug']):
            return f"""I'll engage my technical specialists to help you with your programming needs.

**Technical agents activated:**
• **Code Generator**: Creates optimized, production-ready code
• **Debug Specialist**: Identifies and fixes issues systematically  
• **Quality Validator**: Ensures best practices and standards
• **Performance Optimizer**: Improves efficiency and scalability

**My approach:**
1. Analyze your specific requirements
2. Design the optimal solution architecture
3. Generate clean, documented code
4. Test and validate functionality
5. Provide optimization recommendations

Agents processing your request: {', '.join(agents)}

What technical challenge can I help you solve?"""
        
        # Creative requests
        elif any(word in message_lower for word in ['creative', 'design', 'idea']):
            return f"""Creative mode activated! I'm engaging multiple creative and analytical agents to generate innovative solutions.

**Creative pipeline engaged:**
• **Ideation Engine**: Generates diverse creative concepts
• **Design Synthesizer**: Combines ideas into cohesive designs
• **Innovation Catalyst**: Pushes boundaries and explores new approaches
• **Aesthetic Optimizer**: Ensures visual and functional harmony

**Process:**
1. Divergent thinking - exploring multiple creative directions
2. Concept development - refining promising ideas
3. Design integration - creating unified solutions
4. Iterative refinement - perfecting the final output

Active creative agents: {', '.join(agents)}

What creative challenge would you like to explore?"""
        
        # Research requests
        elif any(word in message_lower for word in ['research', 'information', 'learn']):
            return f"""Research mode initiated! I'm deploying specialized research and analysis agents to gather comprehensive information.

**Research capabilities:**
• **Information Retrieval**: Accessing diverse knowledge sources
• **Data Analysis**: Processing and synthesizing findings
• **Fact Verification**: Ensuring accuracy and reliability
• **Insight Generation**: Identifying patterns and connections

**Research methodology:**
1. Query analysis and scope definition
2. Multi-source information gathering
3. Critical evaluation and validation
4. Synthesis and insight extraction
5. Structured presentation of findings

Research agents deployed: {', '.join(agents)}

What research question would you like me to investigate?"""
        
        # General greeting or conversation
        else:
            return f"""Hello! I'm the GRT (Generative Response Transformer) Co-op Assistant, powered by a sophisticated 37-agent neural pipeline designed for collaborative intelligence.

**Current system status:**
• **Active agents**: {len(agents)} specialized agents processing your request
• **Processing mode**: Collaborative multi-agent coordination
• **Response confidence**: High (optimized agent selection)
• **System health**: All core systems operational

**I can help you with:**
• Complex problem solving and analysis
• Creative ideation and design work
• Technical development and debugging  
• Research and information synthesis
• Project planning and coordination
• Real-time collaboration with team members

**Engaged agents**: {', '.join(agents)}

How would you like to collaborate today? I can adapt my approach based on your specific needs."""

    def _get_mock_sources(self, message):
        """Generate mock sources based on message content"""
        sources = []
        message_lower = message.lower()
        
        if any(word in message_lower for word in ['research', 'information', 'data']):
            sources.extend([
                'Internal Knowledge Base',
                'Technical Documentation',
                'Research Papers Database'
            ])
        
        if any(word in message_lower for word in ['code', 'programming']):
            sources.extend([
                'Code Repository Analysis',
                'Best Practices Database',
                'Technical Standards'
            ])
        
        return sources[:3]  # Limit to 3 sources

# Initialize the pipeline
agent_pipeline = MockAgentPipeline()

# Health Check Endpoint
@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint for frontend connectivity"""
    return jsonify({
        'status': 'healthy',
        'service': 'GRT Co-op Backend',
        'version': '2.0.1',
        'agents_available': agent_status['total_agents'],
        'active_agents': agent_status['active_agents'],
        'uptime': '2h 15m',
        'timestamp': datetime.now().isoformat()
    })

# Chat API Endpoint
@app.route('/api/chat', methods=['POST'])
def chat_api():
    """Main chat endpoint for AI interactions"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required'}), 400
        
        message = data['message']
        session_id = data.get('session_id', f'session_{int(time.time())}')
        selected_agents = data.get('selected_agents', ['auto'])
        user_id = data.get('user_id', 'anonymous')
        
        logger.info(f"Processing chat request - Session: {session_id}, User: {user_id}")
        
        # Process message through agent pipeline
        result = agent_pipeline.process_message(
            message=message,
            selected_agents=selected_agents,
            session_id=session_id
        )
        
        # Store session data
        if session_id not in active_sessions:
            active_sessions[session_id] = {
                'created': datetime.now().isoformat(),
                'messages': [],
                'user_id': user_id
            }
        
        # Add to session history
        active_sessions[session_id]['messages'].append({
            'type': 'user',
            'content': message,
            'timestamp': datetime.now().isoformat()
        })
        
        active_sessions[session_id]['messages'].append({
            'type': 'assistant',
            'content': result['response'],
            'metadata': result['metadata'],
            'timestamp': datetime.now().isoformat()
        })
        
        # Emit to collaborators if any
        socketio.emit('new_message', {
            'session_id': session_id,
            'message': result,
            'user_id': user_id
        }, room=session_id)
        
        logger.info(f"Successfully processed message - Response length: {len(result['response'])}")
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error processing chat request: {str(e)}")
        return jsonify({
            'error': 'Internal server error',
            'message': 'Failed to process your request. Please try again.'
        }), 500

# Agent Status Endpoint
@app.route('/api/agents/status', methods=['GET'])
def agents_status():
    """Get current agent system status"""
    return jsonify(agent_status)

# Session Management
@app.route('/api/sessions', methods=['GET'])
def get_sessions():
    """Get all active sessions"""
    return jsonify({
        'active_sessions': len(active_sessions),
        'sessions': list(active_sessions.keys())
    })

@app.route('/api/sessions/<session_id>', methods=['GET'])
def get_session(session_id):
    """Get specific session data"""
    if session_id not in active_sessions:
        return jsonify({'error': 'Session not found'}), 404
    
    return jsonify(active_sessions[session_id])

# WebSocket Events for Real-time Collaboration
@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    logger.info(f"Client connected: {request.sid}")
    emit('connection_established', {
        'status': 'connected',
        'session_id': request.sid,
        'server_time': datetime.now().isoformat()
    })

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    logger.info(f"Client disconnected: {request.sid}")

@socketio.on('join_session')
def handle_join_session(data):
    """Handle joining a collaboration session"""
    session_id = data.get('session_id')
    user_info = data.get('user_info', {})
    
    if session_id:
        join_room(session_id)
        
        # Add to collaborators
        collaborators[request.sid] = {
            'user_id': user_info.get('user_id', 'anonymous'),
            'name': user_info.get('name', 'Anonymous User'),
            'session_id': session_id,
            'joined_at': datetime.now().isoformat(),
            'color': user_info.get('color', '#667eea'),
            'status': 'active'
        }
        
        # Notify other collaborators
        emit('collaborator_joined', {
            'collaborator': collaborators[request.sid]
        }, room=session_id, include_self=False)
        
        logger.info(f"User joined session {session_id}: {user_info.get('name', 'Anonymous')}")

@socketio.on('leave_session')
def handle_leave_session(data):
    """Handle leaving a collaboration session"""
    session_id = data.get('session_id')
    
    if session_id and request.sid in collaborators:
        leave_room(session_id)
        
        # Notify other collaborators
        emit('collaborator_left', {
            'collaborator_id': request.sid
        }, room=session_id)
        
        # Remove from collaborators
        del collaborators[request.sid]
        
        logger.info(f"User left session {session_id}")

@socketio.on('chat_message')
def handle_chat_message(data):
    """Handle real-time chat messages"""
    try:
        message = data.get('message')
        session_id = data.get('session_id')
        selected_agents = data.get('selected_agents', ['auto'])
        
        if not message or not session_id:
            emit('error', {'message': 'Invalid message data'})
            return
        
        # Process through agent pipeline
        result = agent_pipeline.process_message(
            message=message,
            selected_agents=selected_agents,
            session_id=session_id
        )
        
        # Emit response to all session participants
        emit('agent_response', {
            'type': 'agent_response',
            'session_id': session_id,
            'response': result,
            'timestamp': datetime.now().isoformat()
        }, room=session_id)
        
        logger.info(f"Real-time message processed for session {session_id}")
        
    except Exception as e:
        logger.error(f"Error handling chat message: {str(e)}")
        emit('error', {'message': 'Failed to process message'})

if __name__ == '__main__':
    print("🚀 Starting GRT Co-op Backend Server...")
    print(f"📡 Server will be available at http://0.0.0.0:6003")
    print(f"🔌 WebSocket support enabled for real-time collaboration")
    print(f"🤖 37-Agent Pipeline initialized and ready")
    print(f"💡 Health check: http://0.0.0.0:6003/health")
    print("="*60)
    
    # Run with SocketIO support
    socketio.run(
        app,
        host='0.0.0.0',
        port=6003,
        debug=False,
        allow_unsafe_werkzeug=True
    )