
#!/usr/bin/env python3
"""
GRT Frontend Launcher
Starts the React frontend development server for the GRT system
"""

import subprocess
import os
import sys
import time
import requests
from pathlib import Path

def check_port(port):
    """Check if a port is responding"""
    try:
        response = requests.get(f"http://0.0.0.0:{port}", timeout=3)
        return response.status_code == 200
    except:
        return False

def start_frontend():
    """Start the GRT frontend development server"""
    frontend_path = Path(__file__).parent / "frontend"
    
    if not frontend_path.exists():
        print("❌ Frontend directory not found")
        return False
    
    os.chdir(frontend_path)
    
    # Check if node_modules exists
    if not Path("node_modules").exists():
        print("📦 Installing frontend dependencies...")
        try:
            subprocess.run(["npm", "install"], check=True)
        except subprocess.CalledProcessError:
            print("❌ Failed to install dependencies")
            return False
    
    print("🌐 Starting GRT Frontend on port 5107...")
    try:
        # Start the development server
        process = subprocess.Popen(
            ["npm", "run", "dev", "--", "--host", "0.0.0.0", "--port", "5107"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # Wait for server to start
        for i in range(30):  # Wait up to 30 seconds
            if check_port(5107):
                print("✅ GRT Frontend is running on http://0.0.0.0:5107")
                return True
            time.sleep(1)
            print(f"⏳ Waiting for frontend to start... ({i+1}/30)")
        
        print("❌ Frontend failed to start within 30 seconds")
        process.terminate()
        return False
        
    except Exception as e:
        print(f"❌ Error starting frontend: {e}")
        return False

if __name__ == "__main__":
    print("🚀 GRT Frontend Launcher")
    print("=" * 50)
    
    # Check if backend is running
    backend_ports = [6001, 5007]  # Check both possible backend ports
    backend_found = False
    
    for port in backend_ports:
        if check_port(port):
            print(f"✅ GRT Backend detected on port {port}")
            backend_found = True
            break
    
    if not backend_found:
        print("⚠️ GRT Backend not detected on ports 6001 or 5007")
        print("💡 Make sure to start the backend first with 'Start Event-Driven GRT System' workflow")
    
    if start_frontend():
        print("\n🎯 GRT Frontend is ready!")
        print("🌐 Frontend: http://0.0.0.0:5107")
        print("🧠 Backend: http://0.0.0.0:6001")
        print("\nPress Ctrl+C to stop")
        
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n👋 Shutting down GRT Frontend...")
            sys.exit(0)
    else:
        print("\n❌ Failed to start GRT Frontend")
        sys.exit(1)
