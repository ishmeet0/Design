
#!/usr/bin/env python3
"""
GRT Startup Script
Simple one-command startup for GRT system
"""

import sys
import subprocess
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)

def main():
    """Main startup function"""
    logger.info("🧠 GRT - Generative Response Transformer")
    logger.info("🚀 37-Agent Collaborative Intelligence System")
    logger.info("=" * 50)
    
    grt_path = Path(__file__).parent
    
    # Check if we should install dependencies first
    try:
        import flask, requests
        logger.info("✅ Dependencies available")
    except ImportError:
        logger.info("📦 Installing dependencies...")
        installer = grt_path / "install_dependencies.py" 
        if installer.exists():
            subprocess.run([sys.executable, str(installer)])
        else:
            logger.error("❌ Dependency installer not found!")
            return
    
    # Start the system
    logger.info("🚀 Starting GRT System...")
    
    # Try standalone runner first
    standalone_runner = grt_path / "standalone_runner.py"
    if standalone_runner.exists():
        logger.info("🔧 Using standalone runner...")
        subprocess.run([sys.executable, str(standalone_runner)])
    else:
        # Fallback to just frontend
        logger.info("🌐 Starting frontend only...")
        app_script = grt_path / "app.py"
        if app_script.exists():
            subprocess.run([sys.executable, str(app_script)])
        else:
            logger.error("❌ No startup scripts found!")
            logger.info("💡 Please ensure all GRT files are properly installed.")

if __name__ == "__main__":
    main()
