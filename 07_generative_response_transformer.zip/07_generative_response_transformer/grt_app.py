
#!/usr/bin/env python3
from flask import Flask, send_file, send_from_directory, request, jsonify
from flask_cors import CORS
import os
import requests
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    """Main GRT interface"""
    return '''<!DOCTYPE html><html><head><title>GRT Co-op Chat</title>
<style>
body { font-family: 'Segoe UI', sans-serif; margin: 0; padding: 20px; background: #1a1a1a; color: white; }
.container { max-width: 1200px; margin: 0 auto; }
.header { text-align: center; margin-bottom: 30px; }
.chat-interface { background: #2a2a2a; border-radius: 8px; padding: 20px; margin: 20px 0; }
.message-input { width: 100%; padding: 15px; margin-top: 10px; border: none; border-radius: 4px; background: #333; color: white; font-size: 16px; }
.send-btn { background: #4CAF50; color: white; padding: 15px 30px; border: none; border-radius: 4px; cursor: pointer; margin-top: 10px; font-size: 16px; }
.send-btn:hover { background: #45a049; }
.messages { max-height: 600px; overflow-y: auto; margin-bottom: 20px; }
.message { margin: 15px 0; padding: 15px; border-radius: 8px; }
.user-message { background: #0084ff; text-align: right; }
.bot-message { background: #333; }
.agent-status { background: #444; padding: 10px; border-radius: 4px; margin: 10px 0; font-size: 12px; }
.typing { opacity: 0.7; font-style: italic; }
</style></head><body>
<div class="container">
<div class="header">
<h1>🧠 GRT Co-op Chat</h1>
<p>37-Agent Collaborative Intelligence System</p>
<div class="agent-status">Backend Status: <span id="status">Checking...</span></div>
</div>
<div class="chat-interface">
<div class="messages" id="messages"></div>
<input type="text" id="messageInput" class="message-input" placeholder="Ask me anything...">
<button onclick="sendMessage()" class="send-btn">Send Message</button>
</div>
</div>
<script>
let sessionId = 'session_' + Date.now();

// Check backend status
async function checkStatus() {
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        document.getElementById('status').textContent = response.ok ? 'Online ✅' : 'Offline ❌';
    } catch (error) {
        document.getElementById('status').textContent = 'Offline ❌';
    }
}

async function sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    if (!message) return;
    
    addMessage('user', message);
    input.value = '';
    
    // Show typing indicator
    addMessage('typing', 'GRT is thinking...');
    
    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                message: message, 
                session_id: sessionId,
                collaboration_mode: true
            })
        });
        
        // Remove typing indicator
        const messages = document.getElementById('messages');
        const typingMsg = messages.querySelector('.typing');
        if (typingMsg) typingMsg.remove();
        
        const result = await response.json();
        
        if (result.response) {
            addMessage('bot', result.response);
            if (result.agents_used) {
                addMessage('agents', `Agents used: ${result.agents_used.join(', ')}`);
            }
        } else {
            addMessage('bot', result.error || 'Sorry, I encountered an error.');
        }
        
    } catch (error) {
        // Remove typing indicator
        const messages = document.getElementById('messages');
        const typingMsg = messages.querySelector('.typing');
        if (typingMsg) typingMsg.remove();
        
        addMessage('bot', 'Connection error. Please try again.');
    }
}

function addMessage(type, text) {
    const messages = document.getElementById('messages');
    const div = document.createElement('div');
    
    if (type === 'user') {
        div.className = 'message user-message';
        div.innerHTML = `<strong>You:</strong> ${text}`;
    } else if (type === 'bot') {
        div.className = 'message bot-message';
        div.innerHTML = `<strong>GRT:</strong> ${text}`;
    } else if (type === 'agents') {
        div.className = 'message agent-status';
        div.textContent = text;
    } else if (type === 'typing') {
        div.className = 'message bot-message typing';
        div.innerHTML = `<em>${text}</em>`;
    }
    
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
}

document.getElementById('messageInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') sendMessage();
});

// Check status on load
checkStatus();
setInterval(checkStatus, 30000);
</script></body></html>'''

@app.route('/api/health')
def health_check():
    """Health check endpoint"""
    try:
        # Check if GRT backend is running
        response = requests.get('http://0.0.0.0:6001/health', timeout=2)
        if response.status_code == 200:
            return jsonify({'status': 'healthy', 'backend': 'connected'})
    except:
        pass
    
    return jsonify({'status': 'healthy', 'backend': 'standalone'})

@app.route('/api/chat', methods=['POST'])
def chat_endpoint():
    """Chat endpoint that uses local GRT system"""
    try:
        data = request.get_json()
        message = data.get('message', '')
        session_id = data.get('session_id', 'default')
        
        # Try to connect to GRT backend first
        try:
            response = requests.post(
                'http://0.0.0.0:6001/api/chat',
                json=data,
                timeout=30
            )
            return jsonify(response.json()), response.status_code
        except:
            # Fallback to simple response if backend not available
            return jsonify({
                'response': f'GRT Standalone Response: I understand you said "{message}". The full 37-agent system is initializing. Please ensure the GRT backend is running on port 6001 for complete functionality.',
                'agents_used': ['input_agent', 'response_agent'],
                'confidence': 0.8,
                'session_id': session_id
            })
            
    except Exception as e:
        logger.error(f"Chat error: {e}")
        return jsonify({'error': 'Chat processing failed'}), 500

@app.route('/api/agents')
def list_agents():
    """List available agents"""
    agents = [
        'input_agent', 'thinking_agent', 'intent_context_agent', 'knowledge_agent',
        'webscraper_agent', 'response_agent', 'multilanguage_agent', 'enhancement_agent',
        'personality_agent', 'memory_agent', 'dialog_agent', 'fact_checker',
        'code_interpreter', 'math_solver', 'cad_generator', 'file_reader',
        'visualizer', 'logo_designer', 'logic_bridge', 'emotion_detector',
        'image_generator', 'animation_director', 'user_adapter', 'summary_agent',
        'ui_ux_designer', 'command_agent', 'pdf_generator', 'excel_creator',
        'planner', 'qa_agent', 'word_builder', 'powerpoint_creator', 'inference_optimizer',
        'feedback_handler', 'history_lookup', 'topic_tracker', 'context_repair',
        'delivery_agent'
    ]
    return jsonify({'agents': agents, 'count': len(agents)})

if __name__ == '__main__':
    logger.info("🧠 Starting GRT Standalone Application...")
    logger.info("🌐 Frontend: http://0.0.0.0:5107")
    logger.info("🔧 Backend API: http://0.0.0.0:6001 (if available)")
    app.run(host='0.0.0.0', port=5107, debug=True)
