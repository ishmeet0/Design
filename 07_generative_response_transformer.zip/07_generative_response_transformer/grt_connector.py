# Main connector service for Generative Response Transformer

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'backend'))

from backend.app import app
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

if __name__ == '__main__':
    logger.info("🚀 Starting Generative Response Transformer on port 5007...")
    app.run(host='0.0.0.0', port=5007, debug=True)