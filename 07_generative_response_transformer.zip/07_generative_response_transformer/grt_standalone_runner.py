
#!/usr/bin/env python3
"""
GRT Standalone Runner
Runs both backend and frontend in one process
"""

import subprocess
import sys
import time
import threading
import requests
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class GRTStandaloneRunner:
    def __init__(self):
        self.backend_process = None
        self.frontend_process = None
        self.grt_path = Path(__file__).parent
        
    def check_backend_health(self):
        """Check if backend is running"""
        try:
            response = requests.get("http://0.0.0.0:6001/health", timeout=3)
            return response.status_code == 200
        except:
            return False
    
    def start_backend(self):
        """Start GRT backend"""
        try:
            logger.info("🧠 Starting GRT Backend on port 6001...")
            backend_script = self.grt_path / "run_standalone.py"
            
            if backend_script.exists():
                self.backend_process = subprocess.Popen([
                    sys.executable, str(backend_script)
                ], cwd=str(self.grt_path))
            else:
                logger.warning("⚠️ Backend script not found, using simple backend...")
                # Start simple backend
                simple_backend = self.grt_path / "backend" / "main.py"
                if simple_backend.exists():
                    self.backend_process = subprocess.Popen([
                        sys.executable, str(simple_backend)
                    ], cwd=str(self.grt_path / "backend"))
        except Exception as e:
            logger.error(f"❌ Failed to start backend: {e}")
    
    def start_frontend(self):
        """Start GRT frontend"""
        try:
            logger.info("🌐 Starting GRT Frontend on port 5107...")
            frontend_script = self.grt_path / "app.py"
            
            if frontend_script.exists():
                self.frontend_process = subprocess.Popen([
                    sys.executable, str(frontend_script)
                ], cwd=str(self.grt_path))
            else:
                logger.error("❌ Frontend app.py not found!")
        except Exception as e:
            logger.error(f"❌ Failed to start frontend: {e}")
    
    def wait_for_backend(self, timeout=30):
        """Wait for backend to be ready"""
        logger.info("⏳ Waiting for GRT backend to start...")
        for i in range(timeout):
            if self.check_backend_health():
                logger.info("✅ GRT backend is ready!")
                return True
            time.sleep(1)
            if i % 5 == 0:
                logger.info(f"   Waiting... ({i}/{timeout})")
        
        logger.warning("⚠️ Backend not responding, continuing anyway...")
        return False
    
    def run(self):
        """Run GRT standalone system"""
        try:
            logger.info("🚀 Starting GRT Standalone System...")
            logger.info("=" * 50)
            
            # Start backend
            self.start_backend()
            
            # Wait for backend
            self.wait_for_backend()
            
            # Start frontend
            self.start_frontend()
            
            logger.info("✅ GRT Standalone System Started!")
            logger.info("")
            logger.info("🎯 Access Points:")
            logger.info("   Frontend UI: http://0.0.0.0:5107")
            logger.info("   Backend API: http://0.0.0.0:6001")
            logger.info("")
            logger.info("Press Ctrl+C to stop...")
            
            # Keep running
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                logger.info("🛑 Shutting down GRT system...")
                
                if self.backend_process:
                    self.backend_process.terminate()
                    self.backend_process.wait()
                
                if self.frontend_process:
                    self.frontend_process.terminate()
                    self.frontend_process.wait()
                
                logger.info("✅ GRT system shutdown complete")
                
        except Exception as e:
            logger.error(f"❌ Error running GRT system: {e}")

if __name__ == "__main__":
    runner = GRTStandaloneRunner()
    runner.run()
