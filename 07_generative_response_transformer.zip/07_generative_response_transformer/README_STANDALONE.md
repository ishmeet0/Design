
# Standalone Generative Response Transformer

A complete, self-contained AI response generation system powered by 37 specialized agents.

## 🚀 Features

- **37 Specialized AI Agents** working in concert for optimal responses
- **Web Interface** for easy interaction
- **REST API** for programmatic access
- **Memory Storage** for conversation history
- **Training Feedback** system for continuous improvement
- **Real-time Processing** with detailed agent chain visualization

## 🎯 Key Capabilities

- Intelligent conversation and reasoning
- Code generation and analysis
- Creative design and visualization  
- Document and presentation creation
- Problem-solving and strategic planning
- Multi-language support
- Intent detection and context analysis

## 🔧 Quick Start

### Method 1: Direct Launch
```bash
cd i_ishmeiit_ai/07_generative_response_transformer
python run_standalone.py
```

### Method 2: Direct Backend Launch
```bash
cd i_ishmeiit_ai/07_generative_response_transformer/backend
python standalone_app.py
```

## 🌐 Access

Once running, access the application at:

- **Web Interface**: http://0.0.0.0:5007/
- **API Base**: http://0.0.0.0:5007/api/
- **Health Check**: http://0.0.0.0:5007/health
- **Status**: http://0.0.0.0:5007/api/status

## 📡 API Endpoints

### Main Processing
- `POST /api/process` - Process input through 37-agent pipeline
- `GET /api/agents` - Get information about all agents
- `GET|POST /api/memory` - Memory operations
- `POST /api/training` - Submit training feedback

### System
- `GET /api/info` - API information
- `GET /api/status` - Detailed system status
- `GET /health` - Health check

## 🔍 Example API Usage

### Process a Message
```bash
curl -X POST http://0.0.0.0:5007/api/process \
  -H "Content-Type: application/json" \
  -d '{
    "input": "Hello! Can you help me with coding?",
    "user_id": "test_user",
    "session_id": "session_123"
  }'
```

### Get Agent Information
```bash
curl http://0.0.0.0:5007/api/agents
```

### Check System Status
```bash
curl http://0.0.0.0:5007/api/status
```

## 🧠 Agent Pipeline

The system processes each input through multiple specialized agents:

1. **Input Agent** - Sanitizes and parses input
2. **Intent Agent** - Detects user intent
3. **Context Agent** - Analyzes conversation context
4. **Response Agent** - Generates base response
5. **Enhancement Agent** - Applies improvements
6. **QA Agent** - Quality validation
7. **+ 31 More Specialized Agents**

## 💾 Data Storage

The standalone version uses in-memory storage for:
- Conversation history
- Training feedback
- Agent processing logs

## 🎨 Web Interface Features

- **Real-time Chat** with AI agents
- **Agent Visualization** showing active agents
- **Processing Statistics** including response times
- **Processing Chain** visualization
- **Responsive Design** for all devices

## 🔧 Configuration

Edit `config.json` to customize:
- Server host and port
- Logging settings
- Agent configuration
- Feature toggles

## 🚦 System Requirements

- Python 3.7+
- Flask and dependencies
- 512MB+ RAM recommended
- Modern web browser for interface

## 📊 Monitoring

The application provides comprehensive monitoring:
- Real-time agent processing chains
- Response time statistics
- Memory usage tracking
- Error logging and reporting

## 🔒 Security

- Input sanitization
- CORS configuration
- Error handling
- Request validation

## 📈 Performance

- Multi-threaded processing
- Efficient agent coordination
- Optimized response generation
- Memory management

## 🆘 Troubleshooting

### Common Issues

1. **Port 5007 already in use**
   - Change port in config.json or standalone_app.py
   
2. **Import errors**
   - Ensure you're in the correct directory
   - Check Python path configuration

3. **Agent initialization fails**
   - Check logs in standalone_grt.log
   - Verify system resources

### Debug Mode

Enable debug mode by setting `debug=True` in standalone_app.py for detailed error information.

## 🎯 Use Cases

- **Customer Support** - Intelligent response generation
- **Content Creation** - Automated content and code generation
- **Research Assistant** - Information processing and analysis
- **Development Tool** - Code analysis and generation
- **Creative Projects** - Design and visualization assistance

## 🔄 Continuous Improvement

The system includes training feedback mechanisms to continuously improve:
- User rating system
- Response quality tracking
- Agent performance monitoring
- Automatic learning adaptation

---

**Note**: This is a standalone version that runs independently without external dependencies on other ISHMEIIT AI components.
# GRT - Generative Response Transformer (Standalone)

🧠 **Complete 37-Agent Collaborative Intelligence System**

## Overview

GRT is a sophisticated AI system featuring 37 specialized agents working together to provide intelligent responses. This standalone version contains everything needed to run GRT independently.

## Quick Start

### 1. Install Dependencies
```bash
cd i_ishmeiit_ai/07_generative_response_transformer
python install_dependencies.py
```

### 2. Run Standalone System
```bash
python standalone_runner.py
```

### 3. Access the Interface
- **Frontend UI**: http://0.0.0.0:5107
- **Backend API**: http://0.0.0.0:6001

## Alternative Running Methods

### Method 1: Full System
```bash
python standalone_runner.py
```

### Method 2: Frontend Only
```bash
python app.py
```

### Method 3: Backend Only
```bash
python run_standalone.py
```

## System Architecture

### 37-Agent Pipeline
1. **Input Processing** (Agents 1-5)
   - Input Agent, Thinking Agent, Intent & Context Agent
   - Knowledge Assessment Agent, Processing Agent

2. **Content Generation** (Agents 6-20)
   - Response Agent, Multilanguage Agent, Enhancement Agent
   - Personality Agent, Memory Agent, Dialog Agent
   - Fact Checker, Code Interpreter, Math Solver
   - CAD Generator, File Reader, Visualizer, Logo Designer
   - Logic Bridge, Emotion Detector

3. **Media & Documents** (Agents 21-30)
   - Image Generator, Animation Director, User Adapter
   - Summary Agent, UI/UX Designer, Command Agent
   - PDF Generator, Excel Creator, Planner, QA Agent

4. **Advanced Processing** (Agents 31-37)
   - Word Builder, PowerPoint Creator, Inference Optimizer
   - Feedback Handler, History Lookup, Topic Tracker
   - Context Repair, Delivery Agent

### Event-Driven Architecture
- **Event 1**: User Input Processing
- **Event 2**: Intent Detection & Context Analysis
- **Event 3**: Knowledge Assessment & Routing
- **Event 4**: Web Scraping & Data Collection
- **Event 5**: Agent Collaboration & Processing
- **Event 6**: Review & Refinement (LLRR Engine)
- **Event 7**: Meta-Agent Optimization
- **Event 8**: Output Delivery & Learning
- **Event 9**: Final Response & Analytics

## API Endpoints

### Chat API
```bash
POST /api/chat
{
    "message": "Your question here",
    "session_id": "optional_session_id",
    "collaboration_mode": true
}
```

### Health Check
```bash
GET /api/health
```

### Agent List
```bash
GET /api/agents
```

## Features

- ✅ **37 Specialized Agents** - Each with unique capabilities
- ✅ **Event-Driven Architecture** - 9-point event flow system
- ✅ **Real-time Chat Interface** - Interactive web UI
- ✅ **Memory Management** - Conversation history and context
- ✅ **Multi-language Support** - Global language processing
- ✅ **Code Generation** - Programming assistance
- ✅ **Document Creation** - PDF, Excel, Word, PowerPoint
- ✅ **Image Analysis** - Visual content processing
- ✅ **Web Scraping** - Real-time information gathering
- ✅ **Quality Assurance** - LLRR review system

## Directory Structure

```
07_generative_response_transformer/
├── app.py                    # Frontend application
├── standalone_runner.py      # Complete system runner  
├── install_dependencies.py   # Dependency installer
├── run_standalone.py         # Backend runner
├── requirements_standalone.txt # All dependencies
├── backend/                  # Core backend system
│   ├── agents/              # 37 specialized agents
│   ├── memory/              # Memory management
│   └── main.py              # Backend entry point
├── frontend/                # React frontend (optional)
└── README_STANDALONE.md     # This file
```

## Troubleshooting

### Backend Not Starting
1. Check if port 6001 is available
2. Install missing dependencies: `python install_dependencies.py`
3. Try running backend separately: `python run_standalone.py`

### Frontend Issues
1. Check if port 5107 is available
2. Try running frontend separately: `python app.py`
3. Access directly via browser: http://0.0.0.0:5107

### Performance Issues
1. Ensure adequate system resources (4GB+ RAM recommended)
2. Check Python version (3.8+ required)
3. Close unnecessary applications

## Support

For issues or questions:
1. Check the logs in the terminal
2. Verify all dependencies are installed
3. Ensure ports 5107 and 6001 are available

---

**GRT - Generative Response Transformer**  
*37-Agent Collaborative Intelligence System*
