
#!/usr/bin/env python3
"""
GRT Dependency Installer
Installs all required dependencies for standalone operation
"""

import subprocess
import sys
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def install_dependencies():
    """Install all required dependencies"""
    try:
        requirements_file = Path(__file__).parent / "requirements_standalone.txt"
        
        if not requirements_file.exists():
            logger.error("❌ requirements_standalone.txt not found!")
            return False
        
        logger.info("📦 Installing GRT dependencies...")
        logger.info("🔧 This may take a few minutes...")
        
        result = subprocess.run([
            sys.executable, "-m", "pip", "install", "-r", str(requirements_file)
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            logger.info("✅ All dependencies installed successfully!")
            return True
        else:
            logger.error(f"❌ Installation failed: {result.stderr}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Error installing dependencies: {e}")
        return False

def check_dependencies():
    """Check if key dependencies are available"""
    try:
        import flask
        import requests
        import numpy
        logger.info("✅ Key dependencies are available")
        return True
    except ImportError as e:
        logger.warning(f"⚠️ Missing dependency: {e}")
        return False

if __name__ == "__main__":
    logger.info("🧠 GRT Dependency Installer")
    logger.info("=" * 40)
    
    if check_dependencies():
        logger.info("✅ Dependencies already satisfied!")
    else:
        if install_dependencies():
            logger.info("🚀 Ready to run GRT!")
        else:
            logger.error("❌ Installation failed. Please check your Python environment.")
