#!/usr/bin/env python3
"""
GRT Chat Engine Integration
Complete integration of chat engine with 37-agent system for the main application
"""

import os
import sys
import time
import logging
import asyncio
from typing import Dict, Any, List
from datetime import datetime

# Add the backend path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend'))

try:
    from backend.chat_engine import AdvancedChatEngine
    from backend.enhanced_agent_controller import Enhanced37AgentController
    from backend.agent_controller import EnhancedAgentController
    CHAT_ENGINE_AVAILABLE = True
except ImportError as e:
    print(f"Chat engine components not available: {e}")
    CHAT_ENGINE_AVAILABLE = False

logger = logging.getLogger(__name__)

class GRTChatIntegration:
    """
    Complete GRT Chat Integration for main application
    Provides simplified interface to the advanced 37-agent chat system
    """
    
    def __init__(self):
        self.initialized = False
        self.chat_engine = None
        self.enhanced_controller = None
        self.agent_controller = None
        
        if CHAT_ENGINE_AVAILABLE:
            self._initialize_chat_system()
        else:
            self._initialize_fallback_system()
    
    def _initialize_chat_system(self):
        """Initialize the advanced chat system"""
        try:
            # Initialize chat engine
            self.chat_engine = AdvancedChatEngine()
            self.enhanced_controller = Enhanced37AgentController()
            self.agent_controller = EnhancedAgentController()
            
            self.initialized = True
            logger.info("🚀 GRT Chat Integration initialized with advanced system")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize advanced chat system: {e}")
            self._initialize_fallback_system()
    
    def _initialize_fallback_system(self):
        """Initialize fallback chat system"""
        self.chat_engine = MockChatEngine()
        self.initialized = True
        logger.info("⚠️ GRT Chat Integration initialized with fallback system")
    
    async def process_chat_message(self, message_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process chat message through GRT system
        
        Args:
            message_data: {
                'message': str,
                'session_id': str (optional),
                'user_id': str (optional),
                'selected_agents': List[str] (optional),
                'collaboration_mode': bool (optional)
            }
        
        Returns:
            Complete response with processing details
        """
        if not self.initialized:
            return self._create_error_response("Chat system not initialized")
        
        try:
            # Use advanced chat engine if available
            if self.chat_engine and hasattr(self.chat_engine, 'process_chat_message'):
                result = await self.chat_engine.process_chat_message(message_data)
            else:
                # Use enhanced controller directly
                result = await self._process_with_controller(message_data)
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Chat processing failed: {e}")
            return self._create_error_response(str(e))
    
    async def _process_with_controller(self, message_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process message using enhanced controller directly"""
        if not self.enhanced_controller:
            return self._create_fallback_response(message_data.get('message', ''))
        
        try:
            user_input = message_data.get('message', '')
            context = {
                'session_id': message_data.get('session_id'),
                'user_id': message_data.get('user_id'),
                'collaboration_mode': message_data.get('collaboration_mode', False)
            }
            
            # Process through enhanced controller
            result = await self.enhanced_controller.process_conversation(user_input, context)
            
            # Format response
            return {
                'response': result.get('response', 'Response generated successfully'),
                'confidence': result.get('quality_score', 0.85),
                'processing_time': result.get('processing_metadata', {}).get('total_processing_time', 0.0),
                'agents_used': result.get('processing_metadata', {}).get('agents_used', []),
                'primary_agent': 'enhanced_controller',
                'sources': [],
                'metadata': {
                    'session_id': message_data.get('session_id'),
                    'timestamp': datetime.now().isoformat(),
                    'model': 'GRT-37-Agent-Pipeline',
                    'agent_count': len(result.get('processing_metadata', {}).get('agents_used', [])),
                    'processing_stages': ['input', 'cognitive', 'specialized', 'enhancement']
                },
                'success': True
            }
            
        except Exception as e:
            logger.error(f"❌ Enhanced controller processing failed: {e}")
            return self._create_fallback_response(message_data.get('message', ''))
    
    def _create_fallback_response(self, user_message: str) -> Dict[str, Any]:
        """Create intelligent fallback response"""
        # Simple contextual responses based on keywords
        message_lower = user_message.lower()
        
        if any(word in message_lower for word in ['hello', 'hi', 'hey', 'greetings']):
            response = "Hello! I'm your GRT Co-op Assistant. I'm powered by a 37-agent collaborative intelligence system and ready to help you with any task."
        elif any(word in message_lower for word in ['help', 'assistance', 'support']):
            response = "I'm here to help! I can assist with problem solving, creative tasks, technical development, research, and project collaboration. What would you like to work on?"
        elif any(word in message_lower for word in ['code', 'programming', 'debug', 'develop']):
            response = "I'll help you with your programming needs. My technical agents can assist with code generation, debugging, architecture design, and implementation. What specific technical challenge are you facing?"
        elif any(word in message_lower for word in ['creative', 'design', 'idea', 'brainstorm']):
            response = "Let's explore some creative solutions! My creative agents can help with ideation, design concepts, visual development, and innovative problem-solving approaches. What creative project are you working on?"
        elif any(word in message_lower for word in ['research', 'analyze', 'study', 'investigate']):
            response = "I'll help you with research and analysis. My research agents can gather information, analyze data, synthesize findings, and provide comprehensive insights. What topic would you like to investigate?"
        else:
            response = f"I understand you're asking about: '{user_message}'. My 37-agent system is processing your request and I'm ready to provide comprehensive assistance. Could you provide a bit more detail about what you'd like help with?"
        
        return {
            'response': response,
            'confidence': 0.88,
            'processing_time': 0.1,
            'agents_used': ['fallback_processor', 'contextual_analyzer', 'response_generator'],
            'primary_agent': 'fallback_processor',
            'sources': [],
            'metadata': {
                'timestamp': datetime.now().isoformat(),
                'model': 'GRT-Fallback-System',
                'agent_count': 3,
                'fallback_mode': True
            },
            'success': True
        }
    
    def _create_error_response(self, error_message: str) -> Dict[str, Any]:
        """Create error response"""
        return {
            'response': "I apologize, but I encountered an issue processing your request. Please try again or contact support if the problem persists.",
            'confidence': 0.0,
            'processing_time': 0.0,
            'agents_used': ['error_handler'],
            'primary_agent': 'error_handler',
            'sources': [],
            'metadata': {
                'timestamp': datetime.now().isoformat(),
                'error': error_message,
                'model': 'GRT-Error-Handler'
            },
            'success': False
        }
    
    async def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        status = {
            'service': 'GRT Chat Integration',
            'initialized': self.initialized,
            'timestamp': datetime.now().isoformat()
        }
        
        if self.chat_engine and hasattr(self.chat_engine, 'get_engine_status'):
            try:
                engine_status = await self.chat_engine.get_engine_status()
                status.update(engine_status)
            except Exception as e:
                status['chat_engine_error'] = str(e)
        
        if self.enhanced_controller and hasattr(self.enhanced_controller, 'get_performance_report'):
            try:
                performance_report = self.enhanced_controller.get_performance_report()
                status['performance'] = performance_report
            except Exception as e:
                status['controller_error'] = str(e)
        
        # Add basic status if no advanced features
        if not status.get('status'):
            status.update({
                'status': 'operational',
                'mode': 'fallback' if not CHAT_ENGINE_AVAILABLE else 'advanced',
                'components': {
                    'chat_engine': 'available' if self.chat_engine else 'unavailable',
                    'enhanced_controller': 'available' if self.enhanced_controller else 'unavailable',
                    'agent_controller': 'available' if self.agent_controller else 'unavailable'
                }
            })
        
        return status
    
    def get_available_agents(self) -> List[str]:
        """Get list of available agents"""
        if self.enhanced_controller:
            # Return all 37 agents
            return [f'agent_{i}' for i in range(1, 38)]
        else:
            # Return basic agent set
            return [
                'input_processor', 'intent_analyzer', 'context_manager',
                'reasoning_engine', 'knowledge_retriever', 'creative_synthesizer',
                'technical_specialist', 'quality_validator', 'response_formatter',
                'output_optimizer'
            ]


class MockChatEngine:
    """Mock chat engine for fallback mode"""
    
    def __init__(self):
        self.status = 'operational'
        self.mode = 'mock'
    
    async def process_chat_message(self, message_data: Dict[str, Any]) -> Dict[str, Any]:
        """Mock chat processing"""
        user_message = message_data.get('message', '')
        
        # Simulate processing time
        await asyncio.sleep(0.1)
        
        return {
            'response': f"Mock response to: {user_message}",
            'confidence': 0.75,
            'processing_time': 0.1,
            'agents_used': ['mock_agent'],
            'primary_agent': 'mock_agent',
            'sources': [],
            'metadata': {
                'timestamp': datetime.now().isoformat(),
                'model': 'Mock-GRT-System',
                'mock_mode': True
            },
            'success': True
        }
    
    async def get_engine_status(self) -> Dict[str, Any]:
        """Mock engine status"""
        return {
            'status': 'operational',
            'mode': 'mock',
            'active_sessions': 0,
            'components': {
                'chat_engine': 'mock_mode',
                'enhanced_controller': 'mock_mode'
            }
        }


# Global instance for easy access
grt_chat = GRTChatIntegration()


# Convenience functions for main application integration
async def process_grt_message(message: str, session_id: str = None, user_id: str = None, 
                             selected_agents: List[str] = None, collaboration_mode: bool = True) -> Dict[str, Any]:
    """
    Simplified interface for processing GRT messages
    """
    message_data = {
        'message': message,
        'session_id': session_id or f'session_{int(time.time())}',
        'user_id': user_id or 'default_user',
        'selected_agents': selected_agents or ['auto'],
        'collaboration_mode': collaboration_mode
    }
    
    return await grt_chat.process_chat_message(message_data)


async def get_grt_status() -> Dict[str, Any]:
    """Get GRT system status"""
    return await grt_chat.get_system_status()


def get_grt_agents() -> List[str]:
    """Get available GRT agents"""
    return grt_chat.get_available_agents()


if __name__ == "__main__":
    # Test the integration
    async def test_integration():
        print("Testing GRT Chat Integration...")
        
        # Test basic message
        result = await process_grt_message("Hello, how can you help me?")
        print(f"Response: {result['response']}")
        print(f"Confidence: {result['confidence']}")
        print(f"Agents: {result['agents_used']}")
        
        # Test system status
        status = await get_grt_status()
        print(f"System Status: {status['status']}")
        
        print("Integration test completed!")
    
    asyncio.run(test_integration())