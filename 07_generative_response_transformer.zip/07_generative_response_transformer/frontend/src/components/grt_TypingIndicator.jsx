import React from 'react'
import { Bot, Brain } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import './TypingIndicator.css'

function TypingIndicator({ agents = [] }) {
  return (
    <motion.div
      className="typing-indicator"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <div className="typing-avatar">
        <Brain size={16} className="brain-icon" />
      </div>
      
      <div className="typing-content">
        <div className="typing-header">
          <span className="typing-sender">GRT Assistant</span>
          <span className="typing-status">is thinking...</span>
        </div>
        
        <div className="typing-bubble">
          <div className="typing-animation">
            <span></span>
            <span></span>
            <span></span>
          </div>
          
          {agents.length > 0 && (
            <div className="active-agents-display">
              <div className="agents-working">
                <span className="agents-count">{agents.length}</span>
                <span className="agents-text">
                  agent{agents.length > 1 ? 's' : ''} working
                </span>
              </div>
              
              <AnimatePresence mode="wait">
                <motion.div 
                  className="current-agents"
                  key={agents.join(',')}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  {agents.slice(0, 3).map((agent, index) => (
                    <span key={agent} className="agent-name">
                      {agent.replace('_', ' ')}
                      {index < Math.min(agents.length, 3) - 1 && ', '}
                    </span>
                  ))}
                  {agents.length > 3 && (
                    <span className="agent-more">
                      +{agents.length - 3} more
                    </span>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>
          )}
        </div>
        
        <div className="neural-activity">
          <div className="activity-dots">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
          </div>
          <span className="activity-text">Neural pipeline processing</span>
        </div>
      </div>
    </motion.div>
  )
}

export default TypingIndicator