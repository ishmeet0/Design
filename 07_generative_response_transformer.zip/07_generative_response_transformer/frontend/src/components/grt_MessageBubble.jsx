import React, { useState } from 'react'
import { Copy, ThumbsUp, ThumbsDown, RefreshCw, User, Bot } from 'lucide-react'
import { motion } from 'framer-motion'
import { formatDistanceToNow } from 'date-fns'
import toast from 'react-hot-toast'
import './MessageBubble.css'

function MessageBubble({ message, isLatest }) {
  const [copied, setCopied] = useState(false)
  const isUser = message.role === 'user'
  const isTyping = message.isTyping
  
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content)
      setCopied(true)
      toast.success('Copied to clipboard')
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      toast.error('Failed to copy')
    }
  }
  
  const handleThumbsUp = () => {
    toast.success('Feedback recorded')
  }
  
  const handleThumbsDown = () => {
    toast.success('Feedback recorded')
  }
  
  const handleRegenerate = () => {
    toast.success('Regenerating response...')
  }
  
  return (
    <motion.div
      className={`message-bubble ${isUser ? 'user' : 'assistant'}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="message-avatar">
        {isUser ? (
          <User size={16} />
        ) : (
          <Bot size={16} />
        )}
      </div>
      
      <div className="message-content-wrapper">
        <div className="message-header">
          <span className="message-sender">
            {isUser ? 'You' : 'GRT Assistant'}
          </span>
          {message.timestamp && (
            <span className="message-time">
              {formatDistanceToNow(new Date(message.timestamp), { addSuffix: true })}
            </span>
          )}
        </div>
        
        <div className="message-content">
          {isTyping ? (
            <div className="typing-animation">
              <span></span>
              <span></span>
              <span></span>
            </div>
          ) : (
            <div className="message-text">
              {message.content.split('\n').map((line, index) => (
                <p key={index}>{line}</p>
              ))}
            </div>
          )}
        </div>
        
        {/* Agent Information */}
        {!isUser && message.agents && message.agents.length > 0 && (
          <div className="agents-used">
            <span className="agents-label">Agents involved:</span>
            <div className="agents-list">
              {message.agents.map((agent, index) => (
                <span key={index} className="agent-tag">
                  {agent.replace('_', ' ')}
                </span>
              ))}
            </div>
          </div>
        )}
        
        {/* Processing Time */}
        {!isUser && message.processingTime && (
          <div className="processing-info">
            <span className="processing-time">
              Processed in {message.processingTime}ms
            </span>
          </div>
        )}
        
        {/* Sources */}
        {!isUser && message.sources && message.sources.length > 0 && (
          <div className="sources">
            <span className="sources-label">Sources:</span>
            <div className="sources-list">
              {message.sources.map((source, index) => (
                <a 
                  key={index} 
                  href={source.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="source-link"
                >
                  {source.title || source.url}
                </a>
              ))}
            </div>
          </div>
        )}
        
        {/* Message Actions */}
        {!isTyping && (
          <div className="message-actions">
            <button
              className="action-button"
              onClick={handleCopy}
              title="Copy message"
            >
              <Copy size={14} />
              {copied && <span className="action-feedback">Copied!</span>}
            </button>
            
            {!isUser && (
              <>
                <button
                  className="action-button"
                  onClick={handleThumbsUp}
                  title="Good response"
                >
                  <ThumbsUp size={14} />
                </button>
                
                <button
                  className="action-button"
                  onClick={handleThumbsDown}
                  title="Poor response"
                >
                  <ThumbsDown size={14} />
                </button>
                
                {isLatest && (
                  <button
                    className="action-button"
                    onClick={handleRegenerate}
                    title="Regenerate response"
                  >
                    <RefreshCw size={14} />
                  </button>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </motion.div>
  )
}

export default MessageBubble