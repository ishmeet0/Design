import React, { useState } from 'react'
import { Activity, Cpu, Database, Globe, Zap, Eye, EyeOff } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAgents } from '../contexts/AgentContext'
import './AgentStatus.css'

function AgentStatus() {
  const { 
    agents, 
    systemStatus, 
    activeAgents, 
    totalAgents, 
    connectedAgents, 
    processingQueue, 
    metrics 
  } = useAgents()
  
  const [expandedAgent, setExpandedAgent] = useState(null)
  const [showInactiveAgents, setShowInactiveAgents] = useState(false)
  
  const agentList = Object.values(agents)
  const activeAgentsList = agentList.filter(agent => activeAgents.includes(agent.id))
  const inactiveAgentsList = agentList.filter(agent => !activeAgents.includes(agent.id))
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return '#22c55e'
      case 'processing': return '#3b82f6'
      case 'idle': return '#64748b'
      case 'error': return '#ef4444'
      case 'disconnected': return '#f59e0b'
      default: return '#64748b'
    }
  }
  
  const getSystemStatusIcon = (component) => {
    const status = systemStatus[component]
    switch (component) {
      case 'llrr_engine': return <Cpu size={16} />
      case 'meta_agent': return <Zap size={16} />
      case 'webscraper': return <Globe size={16} />
      case 'communication_bus': return <Database size={16} />
      default: return <Activity size={16} />
    }
  }
  
  return (
    <div className="agent-status">
      <div className="agent-status-header">
        <h2 className="panel-title">Agent Status</h2>
        <div className="status-summary">
          <div className="summary-item">
            <span className="summary-value">{activeAgents.length}</span>
            <span className="summary-label">Active</span>
          </div>
          <div className="summary-divider"></div>
          <div className="summary-item">
            <span className="summary-value">{connectedAgents}</span>
            <span className="summary-label">Connected</span>
          </div>
        </div>
      </div>
      
      {/* System Status */}
      <div className="system-status-section">
        <h3 className="section-title">System Components</h3>
        <div className="system-components">
          {Object.entries(systemStatus).map(([component, status]) => (
            <div key={component} className="system-component">
              <div className="component-icon">
                {getSystemStatusIcon(component)}
              </div>
              <div className="component-info">
                <span className="component-name">
                  {component.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </span>
                <div className="component-status">
                  <div 
                    className="status-dot"
                    style={{ backgroundColor: getStatusColor(status) }}
                  ></div>
                  <span className="status-text">{status}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Metrics */}
      <div className="metrics-section">
        <h3 className="section-title">Performance Metrics</h3>
        <div className="metrics-grid">
          <div className="metric-item">
            <span className="metric-value">{metrics.totalRequests}</span>
            <span className="metric-label">Total Requests</span>
          </div>
          <div className="metric-item">
            <span className="metric-value">{metrics.avgResponseTime}ms</span>
            <span className="metric-label">Avg Response</span>
          </div>
          <div className="metric-item">
            <span className="metric-value">{metrics.successRate}%</span>
            <span className="metric-label">Success Rate</span>
          </div>
        </div>
      </div>
      
      {/* Processing Queue */}
      {processingQueue.length > 0 && (
        <div className="processing-section">
          <h3 className="section-title">Processing Queue</h3>
          <div className="processing-queue">
            {processingQueue.map((task, index) => (
              <div key={task.id || index} className="queue-item">
                <div className="queue-icon">
                  <div className="processing-spinner"></div>
                </div>
                <div className="queue-info">
                  <span className="queue-task">{task.type || 'Processing'}</span>
                  <span className="queue-time">
                    {task.startTime && `${Date.now() - task.startTime}ms`}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Active Agents */}
      {activeAgentsList.length > 0 && (
        <div className="agents-section">
          <h3 className="section-title">Active Agents</h3>
          <div className="agents-list">
            <AnimatePresence>
              {activeAgentsList.map(agent => (
                <motion.div
                  key={agent.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className={`agent-item ${expandedAgent === agent.id ? 'expanded' : ''}`}
                  onClick={() => setExpandedAgent(
                    expandedAgent === agent.id ? null : agent.id
                  )}
                >
                  <div className="agent-header">
                    <div className="agent-basic-info">
                      <div 
                        className="agent-status-dot"
                        style={{ backgroundColor: getStatusColor(agent.status) }}
                      ></div>
                      <span className="agent-name">{agent.name}</span>
                    </div>
                    <div className="agent-activity">
                      <span className="activity-indicator"></span>
                    </div>
                  </div>
                  
                  <AnimatePresence>
                    {expandedAgent === agent.id && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="agent-details"
                      >
                        <div className="agent-specialization">
                          {agent.specialization}
                        </div>
                        <div className="agent-stats">
                          <span>Requests: {agent.requests || 0}</span>
                          <span>Avg Time: {agent.avgResponseTime || 0}ms</span>
                        </div>
                        {agent.capabilities && (
                          <div className="agent-capabilities">
                            {agent.capabilities.map((capability, index) => (
                              <span key={index} className="capability-tag">
                                {capability}
                              </span>
                            ))}
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}
      
      {/* Inactive Agents Toggle */}
      <div className="inactive-agents-section">
        <button
          className="toggle-inactive-button"
          onClick={() => setShowInactiveAgents(!showInactiveAgents)}
        >
          {showInactiveAgents ? <EyeOff size={16} /> : <Eye size={16} />}
          <span>
            {showInactiveAgents ? 'Hide' : 'Show'} Inactive Agents ({inactiveAgentsList.length})
          </span>
        </button>
        
        <AnimatePresence>
          {showInactiveAgents && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="inactive-agents-list"
            >
              {inactiveAgentsList.map(agent => (
                <div key={agent.id} className="inactive-agent-item">
                  <div 
                    className="agent-status-dot inactive"
                    style={{ backgroundColor: getStatusColor(agent.status) }}
                  ></div>
                  <span className="agent-name">{agent.name}</span>
                  <span className="agent-status-text">{agent.status}</span>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

export default AgentStatus