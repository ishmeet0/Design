import React from 'react'
import { Menu, X, Brain, Users, Activity } from 'lucide-react'
import { motion } from 'framer-motion'
import './Header.css'

function Header({ sidebarOpen, setSidebarOpen, agentPanelOpen, setAgentPanelOpen }) {
  return (
    <motion.header 
      className="header"
      initial={{ y: -60 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="header-left">
        <button
          className="header-button"
          onClick={() => setSidebarOpen(!sidebarOpen)}
          title={sidebarOpen ? 'Hide Sidebar' : 'Show Sidebar'}
        >
          {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        
        <div className="header-logo">
          <Brain className="logo-icon" size={24} />
          <h1 className="logo-text">GRT Co-op Assistant</h1>
          <span className="logo-subtitle">37-Agent Intelligence</span>
        </div>
      </div>
      
      <div className="header-center">
        <div className="status-indicator">
          <div className="status-dot active"></div>
          <span>Neural Pipeline Active</span>
        </div>
      </div>
      
      <div className="header-right">
        <button
          className="header-button"
          onClick={() => setAgentPanelOpen(!agentPanelOpen)}
          title={agentPanelOpen ? 'Hide Agent Panel' : 'Show Agent Panel'}
        >
          <Activity size={20} />
          <span className="button-text">Agents</span>
        </button>
        
        <button className="header-button" title="Team Collaboration">
          <Users size={20} />
          <span className="button-text">Team</span>
        </button>
      </div>
    </motion.header>
  )
}

export default Header