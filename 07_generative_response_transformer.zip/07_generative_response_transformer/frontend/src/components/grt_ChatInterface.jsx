import React, { useState, useEffect, useRef } from 'react'
import { Send, Loader2, AlertCircle } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { useChat } from '../contexts/ChatContext'
import { useAgents } from '../contexts/AgentContext'
import MessageBubble from './MessageBubble'
import TypingIndicator from './TypingIndicator'
import './ChatInterface.css'

function ChatInterface() {
  const { 
    sessions, 
    currentSessionId, 
    isLoading, 
    error, 
    sendMessage 
  } = useChat()
  
  const { activeAgents } = useAgents()
  
  const [inputValue, setInputValue] = useState('')
  const [inputRows, setInputRows] = useState(1)
  const messagesEndRef = useRef(null)
  const textareaRef = useRef(null)
  
  const currentSession = currentSessionId ? sessions[currentSessionId] : null
  const messages = currentSession?.messages || []
  
  useEffect(() => {
    scrollToBottom()
  }, [messages])
  
  useEffect(() => {
    adjustTextareaHeight()
  }, [inputValue])
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }
  
  const adjustTextareaHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      const scrollHeight = textareaRef.current.scrollHeight
      const maxHeight = 200 // max height in pixels
      const lineHeight = 24
      const lines = Math.min(Math.ceil(scrollHeight / lineHeight), Math.floor(maxHeight / lineHeight))
      
      textareaRef.current.style.height = `${Math.max(lineHeight, Math.min(scrollHeight, maxHeight))}px`
      setInputRows(lines)
    }
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!inputValue.trim() || isLoading) return
    
    const message = inputValue.trim()
    setInputValue('')
    
    try {
      await sendMessage(message)
    } catch (error) {
      console.error('Failed to send message:', error)
    }
  }
  
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e)
    }
  }
  
  const handleInputChange = (e) => {
    setInputValue(e.target.value)
  }
  
  return (
    <div className="chat-interface">
      {!currentSession ? (
        <div className="welcome-screen">
          <motion.div 
            className="welcome-content"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="welcome-logo">🧠</div>
            <h1 className="welcome-title">Welcome to GRT Co-op Assistant</h1>
            <p className="welcome-description">
              Your advanced 37-agent collaborative intelligence platform. 
              Start a conversation to experience the power of multi-agent AI.
            </p>
            <div className="welcome-features">
              <div className="feature-item">
                <span className="feature-icon">⚡</span>
                <span>Real-time neural processing</span>
              </div>
              <div className="feature-item">
                <span className="feature-icon">🤝</span>
                <span>37 specialized agents</span>
              </div>
              <div className="feature-item">
                <span className="feature-icon">🧩</span>
                <span>Collaborative intelligence</span>
              </div>
            </div>
          </motion.div>
        </div>
      ) : (
        <>
          <div className="messages-container">
            <div className="messages-list">
              <AnimatePresence>
                {messages.map((message, index) => (
                  <MessageBubble
                    key={message.id || index}
                    message={message}
                    isLatest={index === messages.length - 1}
                  />
                ))}
              </AnimatePresence>
              
              {isLoading && activeAgents.length > 0 && (
                <TypingIndicator agents={activeAgents} />
              )}
              
              <div ref={messagesEndRef} />
            </div>
          </div>
          
          {error && (
            <motion.div 
              className="error-banner"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
            >
              <AlertCircle size={16} />
              <span>{error}</span>
            </motion.div>
          )}
        </>
      )}
      
      <div className="input-container">
        <form onSubmit={handleSubmit} className="input-form">
          <div className="input-wrapper">
            <textarea
              ref={textareaRef}
              value={inputValue}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Message GRT Co-op Assistant..."
              className="message-input"
              disabled={isLoading}
              rows={inputRows}
            />
            
            <button
              type="submit"
              className={`send-button ${inputValue.trim() && !isLoading ? 'active' : ''}`}
              disabled={!inputValue.trim() || isLoading}
            >
              {isLoading ? (
                <Loader2 size={18} className="spinning" />
              ) : (
                <Send size={18} />
              )}
            </button>
          </div>
          
          <div className="input-footer">
            <span className="input-hint">
              Press Enter to send, Shift+Enter for new line
            </span>
            {activeAgents.length > 0 && (
              <span className="active-agents">
                {activeAgents.length} agent{activeAgents.length > 1 ? 's' : ''} active
              </span>
            )}
          </div>
        </form>
      </div>
    </div>
  )
}

export default ChatInterface