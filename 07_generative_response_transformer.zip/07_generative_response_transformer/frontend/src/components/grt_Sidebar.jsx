import React, { useState } from 'react'
import { Plus, MessageSquare, Trash2, Edit3, Search } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { useChat } from '../contexts/ChatContext'
import { formatDistanceToNow } from 'date-fns'
import './Sidebar.css'

function Sidebar() {
  const { 
    sessions, 
    currentSessionId, 
    createSession, 
    setCurrentSession, 
    deleteSession,
    updateSessionTitle 
  } = useChat()
  
  const [searchTerm, setSearchTerm] = useState('')
  const [editingSessionId, setEditingSessionId] = useState(null)
  const [editingTitle, setEditingTitle] = useState('')
  
  const sessionList = Object.values(sessions).sort((a, b) => b.timestamp - a.timestamp)
  
  const filteredSessions = sessionList.filter(session =>
    session.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    session.messages.some(msg => 
      msg.content.toLowerCase().includes(searchTerm.toLowerCase())
    )
  )
  
  const handleCreateNew = () => {
    createSession()
  }
  
  const handleSessionClick = (sessionId) => {
    setCurrentSession(sessionId)
  }
  
  const handleDeleteSession = (e, sessionId) => {
    e.stopPropagation()
    if (window.confirm('Are you sure you want to delete this chat?')) {
      deleteSession(sessionId)
    }
  }
  
  const handleEditTitle = (e, session) => {
    e.stopPropagation()
    setEditingSessionId(session.id)
    setEditingTitle(session.title)
  }
  
  const handleSaveTitle = () => {
    if (editingTitle.trim() && editingSessionId) {
      updateSessionTitle(editingSessionId, editingTitle.trim())
    }
    setEditingSessionId(null)
    setEditingTitle('')
  }
  
  const handleCancelEdit = () => {
    setEditingSessionId(null)
    setEditingTitle('')
  }
  
  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <motion.button
          className="new-chat-button"
          onClick={handleCreateNew}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Plus size={18} />
          <span>New Chat</span>
        </motion.button>
        
        <div className="search-container">
          <Search size={16} className="search-icon" />
          <input
            type="text"
            placeholder="Search chats..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
      </div>
      
      <div className="sessions-container">
        <AnimatePresence>
          {filteredSessions.map(session => (
            <motion.div
              key={session.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className={`session-item ${session.id === currentSessionId ? 'active' : ''}`}
              onClick={() => handleSessionClick(session.id)}
            >
              <div className="session-content">
                <MessageSquare size={16} className="session-icon" />
                
                <div className="session-info">
                  {editingSessionId === session.id ? (
                    <input
                      type="text"
                      value={editingTitle}
                      onChange={(e) => setEditingTitle(e.target.value)}
                      onBlur={handleSaveTitle}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleSaveTitle()
                        if (e.key === 'Escape') handleCancelEdit()
                      }}
                      className="title-edit-input"
                      autoFocus
                      onClick={(e) => e.stopPropagation()}
                    />
                  ) : (
                    <div className="session-title">{session.title}</div>
                  )}
                  
                  <div className="session-meta">
                    <span className="message-count">
                      {session.messages.length} messages
                    </span>
                    <span className="session-time">
                      {formatDistanceToNow(new Date(session.timestamp), { addSuffix: true })}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="session-actions">
                <button
                  className="action-button"
                  onClick={(e) => handleEditTitle(e, session)}
                  title="Rename chat"
                >
                  <Edit3 size={14} />
                </button>
                
                <button
                  className="action-button delete"
                  onClick={(e) => handleDeleteSession(e, session.id)}
                  title="Delete chat"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {filteredSessions.length === 0 && (
          <div className="empty-state">
            <MessageSquare size={32} className="empty-icon" />
            <p>No chats found</p>
            {searchTerm && (
              <button 
                className="clear-search"
                onClick={() => setSearchTerm('')}
              >
                Clear search
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

export default Sidebar