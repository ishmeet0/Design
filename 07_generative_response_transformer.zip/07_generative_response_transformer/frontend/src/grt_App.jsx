import React, { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { motion } from 'framer-motion'
import ChatInterface from './components/ChatInterface'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import AgentStatus from './components/AgentStatus'
import { ChatProvider } from './contexts/ChatContext'
import { AgentProvider } from './contexts/AgentContext'
import './grt_App.css'

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [agentPanelOpen, setAgentPanelOpen] = useState(false)

  return (
    <AgentProvider>
      <ChatProvider>
        <div className="app">
          <Header 
            sidebarOpen={sidebarOpen}
            setSidebarOpen={setSidebarOpen}
            agentPanelOpen={agentPanelOpen}
            setAgentPanelOpen={setAgentPanelOpen}
          />
          
          <div className="app-main">
            <motion.div
              className={`sidebar-container ${sidebarOpen ? 'open' : 'closed'}`}
              animate={{ 
                width: sidebarOpen ? '280px' : '0px',
                opacity: sidebarOpen ? 1 : 0 
              }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
            >
              <Sidebar />
            </motion.div>
            
            <div className="main-content">
              <Routes>
                <Route path="/" element={<ChatInterface />} />
                <Route path="/chat/:sessionId" element={<ChatInterface />} />
              </Routes>
            </div>
            
            <motion.div
              className={`agent-panel-container ${agentPanelOpen ? 'open' : 'closed'}`}
              animate={{ 
                width: agentPanelOpen ? '320px' : '0px',
                opacity: agentPanelOpen ? 1 : 0 
              }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
            >
              <AgentStatus />
            </motion.div>
          </div>
        </div>
      </ChatProvider>
    </AgentProvider>
  )
}

export default App