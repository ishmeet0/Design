import React, { createContext, useContext, useReducer, useEffect } from 'react'
import io from 'socket.io-client'

const AgentContext = createContext()

const initialState = {
  agents: {},
  systemStatus: {
    llrr_engine: 'idle',
    meta_agent: 'idle',
    webscraper: 'idle',
    communication_bus: 'active'
  },
  activeAgents: [],
  totalAgents: 37,
  connectedAgents: 0,
  processingQueue: [],
  metrics: {
    totalRequests: 0,
    avgResponseTime: 0,
    successRate: 100
  }
}

const agentTypes = [
  'input_agent', 'intent_agent', 'context_agent', 'knowledge_agent', 'web_scraper',
  'code_agent', 'design_agent', 'analysis_agent', 'creative_agent', 'logic_agent',
  'math_agent', 'research_agent', 'writing_agent', 'translation_agent', 'summarization_agent',
  'classification_agent', 'extraction_agent', 'validation_agent', 'optimization_agent', 'debugging_agent',
  'testing_agent', 'deployment_agent', 'monitoring_agent', 'security_agent', 'performance_agent',
  'ui_agent', 'ux_agent', 'mobile_agent', 'web_agent', 'api_agent',
  'database_agent', 'ml_agent', 'ai_agent', 'nlp_agent', 'vision_agent',
  'audio_agent', 'integration_agent'
]

function agentReducer(state, action) {
  switch (action.type) {
    case 'INITIALIZE_AGENTS':
      const initialAgents = {}
      agentTypes.forEach((type, index) => {
        initialAgents[type] = {
          id: type,
          name: type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()),
          status: 'idle',
          lastActive: null,
          requests: 0,
          avgResponseTime: 0,
          specialization: getAgentSpecialization(type),
          capabilities: getAgentCapabilities(type)
        }
      })
      return {
        ...state,
        agents: initialAgents,
        connectedAgents: agentTypes.length
      }
      
    case 'UPDATE_AGENT_STATUS':
      const { agentId, status, metadata } = action.payload
      return {
        ...state,
        agents: {
          ...state.agents,
          [agentId]: {
            ...state.agents[agentId],
            status,
            lastActive: status === 'active' ? Date.now() : state.agents[agentId]?.lastActive,
            ...(metadata || {})
          }
        },
        activeAgents: status === 'active' 
          ? [...state.activeAgents.filter(id => id !== agentId), agentId]
          : state.activeAgents.filter(id => id !== agentId)
      }
      
    case 'UPDATE_SYSTEM_STATUS':
      return {
        ...state,
        systemStatus: {
          ...state.systemStatus,
          ...action.payload
        }
      }
      
    case 'ADD_TO_PROCESSING_QUEUE':
      return {
        ...state,
        processingQueue: [...state.processingQueue, action.payload]
      }
      
    case 'REMOVE_FROM_PROCESSING_QUEUE':
      return {
        ...state,
        processingQueue: state.processingQueue.filter(item => item.id !== action.payload)
      }
      
    case 'UPDATE_METRICS':
      return {
        ...state,
        metrics: {
          ...state.metrics,
          ...action.payload
        }
      }
      
    default:
      return state
  }
}

function getAgentSpecialization(type) {
  const specializations = {
    input_agent: 'Input Processing & Validation',
    intent_agent: 'Intent Recognition & Classification',
    context_agent: 'Context Analysis & Understanding',
    knowledge_agent: 'Knowledge Base Management',
    web_scraper: 'Web Data Extraction',
    code_agent: 'Code Generation & Analysis',
    design_agent: 'UI/UX Design & Prototyping',
    analysis_agent: 'Data Analysis & Insights',
    creative_agent: 'Creative Content Generation',
    logic_agent: 'Logical Reasoning & Problem Solving',
    math_agent: 'Mathematical Computations',
    research_agent: 'Research & Information Gathering',
    writing_agent: 'Content Writing & Editing',
    translation_agent: 'Language Translation',
    summarization_agent: 'Content Summarization',
    classification_agent: 'Data Classification',
    extraction_agent: 'Information Extraction',
    validation_agent: 'Data Validation & Verification',
    optimization_agent: 'Performance Optimization',
    debugging_agent: 'Bug Detection & Fixing',
    testing_agent: 'Quality Assurance & Testing',
    deployment_agent: 'Deployment & DevOps',
    monitoring_agent: 'System Monitoring',
    security_agent: 'Security Analysis',
    performance_agent: 'Performance Analysis',
    ui_agent: 'User Interface Development',
    ux_agent: 'User Experience Design',
    mobile_agent: 'Mobile App Development',
    web_agent: 'Web Development',
    api_agent: 'API Design & Integration',
    database_agent: 'Database Management',
    ml_agent: 'Machine Learning',
    ai_agent: 'AI Model Integration',
    nlp_agent: 'Natural Language Processing',
    vision_agent: 'Computer Vision',
    audio_agent: 'Audio Processing',
    integration_agent: 'System Integration'
  }
  return specializations[type] || 'General Purpose Agent'
}

function getAgentCapabilities(type) {
  // Return array of capabilities for each agent type
  const capabilities = {
    input_agent: ['Input Validation', 'Sanitization', 'Format Detection'],
    intent_agent: ['Intent Classification', 'Confidence Scoring', 'Context Mapping'],
    context_agent: ['Context Building', 'Relevance Analysis', 'Memory Integration'],
    // ... add more as needed
  }
  return capabilities[type] || ['General Processing']
}

export function AgentProvider({ children }) {
  const [state, dispatch] = useReducer(agentReducer, initialState)
  
  useEffect(() => {
    // Initialize agents
    dispatch({ type: 'INITIALIZE_AGENTS' })
    
    // Connect to WebSocket for real-time updates
    const socket = io('ws://localhost:6001', {
      transports: ['websocket']
    })
    
    socket.on('connect', () => {
      dispatch({ 
        type: 'UPDATE_SYSTEM_STATUS', 
        payload: { communication_bus: 'active' }
      })
    })
    
    socket.on('agent_status', (data) => {
      dispatch({
        type: 'UPDATE_AGENT_STATUS',
        payload: data
      })
    })
    
    socket.on('system_status', (data) => {
      dispatch({
        type: 'UPDATE_SYSTEM_STATUS',
        payload: data
      })
    })
    
    socket.on('processing_update', (data) => {
      if (data.action === 'add') {
        dispatch({
          type: 'ADD_TO_PROCESSING_QUEUE',
          payload: data.task
        })
      } else if (data.action === 'remove') {
        dispatch({
          type: 'REMOVE_FROM_PROCESSING_QUEUE',
          payload: data.taskId
        })
      }
    })
    
    socket.on('metrics_update', (data) => {
      dispatch({
        type: 'UPDATE_METRICS',
        payload: data
      })
    })
    
    socket.on('disconnect', () => {
      dispatch({ 
        type: 'UPDATE_SYSTEM_STATUS', 
        payload: { communication_bus: 'disconnected' }
      })
    })
    
    return () => {
      socket.disconnect()
    }
  }, [])
  
  const value = {
    ...state,
    updateAgentStatus: (agentId, status, metadata) => {
      dispatch({
        type: 'UPDATE_AGENT_STATUS',
        payload: { agentId, status, metadata }
      })
    },
    updateSystemStatus: (status) => {
      dispatch({
        type: 'UPDATE_SYSTEM_STATUS',
        payload: status
      })
    }
  }
  
  return (
    <AgentContext.Provider value={value}>
      {children}
    </AgentContext.Provider>
  )
}

export function useAgents() {
  const context = useContext(AgentContext)
  if (!context) {
    throw new Error('useAgents must be used within an AgentProvider')
  }
  return context
}