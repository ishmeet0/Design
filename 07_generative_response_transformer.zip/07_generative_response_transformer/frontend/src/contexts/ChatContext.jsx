import React, { createContext, useContext, useReducer, useEffect } from 'react'
import { v4 as uuidv4 } from 'uuid'
import toast from 'react-hot-toast'

const ChatContext = createContext()

const initialState = {
  sessions: {},
  currentSessionId: null,
  isLoading: false,
  error: null,
  connectionStatus: 'disconnected'
}

function chatReducer(state, action) {
  switch (action.type) {
    case 'CREATE_SESSION':
      const newSessionId = uuidv4()
      return {
        ...state,
        sessions: {
          ...state.sessions,
          [newSessionId]: {
            id: newSessionId,
            title: 'New Chat',
            messages: [],
            timestamp: Date.now(),
            agentsUsed: []
          }
        },
        currentSessionId: newSessionId
      }
      
    case 'SET_CURRENT_SESSION':
      return {
        ...state,
        currentSessionId: action.payload
      }
      
    case 'ADD_MESSAGE':
      const { sessionId, message } = action.payload
      return {
        ...state,
        sessions: {
          ...state.sessions,
          [sessionId]: {
            ...state.sessions[sessionId],
            messages: [...state.sessions[sessionId].messages, message],
            timestamp: Date.now()
          }
        }
      }
      
    case 'UPDATE_MESSAGE':
      const { sessionId: updateSessionId, messageId, updates } = action.payload
      return {
        ...state,
        sessions: {
          ...state.sessions,
          [updateSessionId]: {
            ...state.sessions[updateSessionId],
            messages: state.sessions[updateSessionId].messages.map(msg =>
              msg.id === messageId ? { ...msg, ...updates } : msg
            )
          }
        }
      }
      
    case 'UPDATE_SESSION_TITLE':
      const { sessionId: titleSessionId, title } = action.payload
      return {
        ...state,
        sessions: {
          ...state.sessions,
          [titleSessionId]: {
            ...state.sessions[titleSessionId],
            title
          }
        }
      }
      
    case 'DELETE_SESSION':
      const { [action.payload]: deletedSession, ...remainingSessions } = state.sessions
      const newCurrentSessionId = state.currentSessionId === action.payload 
        ? Object.keys(remainingSessions)[0] || null 
        : state.currentSessionId
      return {
        ...state,
        sessions: remainingSessions,
        currentSessionId: newCurrentSessionId
      }
      
    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload
      }
      
    case 'SET_ERROR':
      return {
        ...state,
        error: action.payload,
        isLoading: false
      }
      
    case 'SET_CONNECTION_STATUS':
      return {
        ...state,
        connectionStatus: action.payload
      }
      
    case 'CLEAR_ERROR':
      return {
        ...state,
        error: null
      }
      
    default:
      return state
  }
}

export function ChatProvider({ children }) {
  const [state, dispatch] = useReducer(chatReducer, initialState)
  
  // Create initial session
  useEffect(() => {
    if (Object.keys(state.sessions).length === 0) {
      dispatch({ type: 'CREATE_SESSION' })
    }
  }, [state.sessions])
  
  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('grt-chat-sessions', JSON.stringify(state.sessions))
  }, [state.sessions])
  
  // Load from localStorage on mount
  useEffect(() => {
    try {
      const savedSessions = localStorage.getItem('grt-chat-sessions')
      if (savedSessions) {
        const sessions = JSON.parse(savedSessions)
        Object.keys(sessions).forEach(sessionId => {
          dispatch({ 
            type: 'CREATE_SESSION', 
            payload: { id: sessionId, ...sessions[sessionId] }
          })
        })
      }
    } catch (error) {
      console.error('Failed to load chat sessions:', error)
    }
  }, [])
  
  const createSession = () => {
    dispatch({ type: 'CREATE_SESSION' })
  }
  
  const setCurrentSession = (sessionId) => {
    dispatch({ type: 'SET_CURRENT_SESSION', payload: sessionId })
  }
  
  const addMessage = (sessionId, message) => {
    const messageWithId = {
      ...message,
      id: uuidv4(),
      timestamp: Date.now()
    }
    dispatch({ 
      type: 'ADD_MESSAGE', 
      payload: { sessionId, message: messageWithId }
    })
    return messageWithId.id
  }
  
  const updateMessage = (sessionId, messageId, updates) => {
    dispatch({
      type: 'UPDATE_MESSAGE',
      payload: { sessionId, messageId, updates }
    })
  }
  
  const updateSessionTitle = (sessionId, title) => {
    dispatch({
      type: 'UPDATE_SESSION_TITLE',
      payload: { sessionId, title }
    })
  }
  
  const deleteSession = (sessionId) => {
    dispatch({ type: 'DELETE_SESSION', payload: sessionId })
    toast.success('Chat deleted')
  }
  
  const sendMessage = async (content) => {
    if (!state.currentSessionId) return
    
    try {
      dispatch({ type: 'SET_LOADING', payload: true })
      dispatch({ type: 'CLEAR_ERROR' })
      
      // Add user message
      const userMessage = {
        role: 'user',
        content,
        timestamp: Date.now()
      }
      const userMessageId = addMessage(state.currentSessionId, userMessage)
      
      // Add assistant message placeholder
      const assistantMessage = {
        role: 'assistant',
        content: '',
        isTyping: true,
        agents: [],
        reasoning: null
      }
      const assistantMessageId = addMessage(state.currentSessionId, assistantMessage)
      
      // Send to backend
      const response = await fetch('/api/grt/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: content,
          session_id: state.currentSessionId,
          conversation_history: state.sessions[state.currentSessionId].messages.slice(-10)
        })
      })
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }
      
      const data = await response.json()
      
      // Update assistant message with response
      updateMessage(state.currentSessionId, assistantMessageId, {
        content: data.response || data.message || 'No response received',
        isTyping: false,
        agents: data.agents_used || [],
        reasoning: data.reasoning || null,
        sources: data.sources || [],
        processingTime: data.processing_time || null
      })
      
      // Update session title if it's the first message
      if (state.sessions[state.currentSessionId].messages.length <= 2) {
        const title = content.slice(0, 30) + (content.length > 30 ? '...' : '')
        updateSessionTitle(state.currentSessionId, title)
      }
      
    } catch (error) {
      console.error('Failed to send message:', error)
      dispatch({ type: 'SET_ERROR', payload: error.message })
      toast.error('Failed to send message: ' + error.message)
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false })
    }
  }
  
  const value = {
    ...state,
    createSession,
    setCurrentSession,
    addMessage,
    updateMessage,
    updateSessionTitle,
    deleteSession,
    sendMessage
  }
  
  return (
    <ChatContext.Provider value={value}>
      {children}
    </ChatContext.Provider>
  )
}

export function useChat() {
  const context = useContext(ChatContext)
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider')
  }
  return context
}