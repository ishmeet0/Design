
#!/usr/bin/env python3
"""
Standalone GRT System Launcher
Runs the complete 37-agent pipeline system
"""

import os
import sys
import subprocess
import signal
import time
import threading
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Get the current directory (GRT root)
GRT_ROOT = Path(__file__).parent
BACKEND_PATH = GRT_ROOT / "backend" / "grtmain.py"

# Add backend to Python path
sys.path.insert(0, str(GRT_ROOT / "backend"))

class GRTLauncher:
    def __init__(self):
        self.backend_process = None
        self.running = False
    
    def start_backend(self):
        """Start the GRT backend service"""
        try:
            logger.info("🚀 Starting GRT Backend Service...")
            
            # Change to backend directory
            backend_dir = BACKEND_PATH.parent
            
            # Start the backend process
            self.backend_process = subprocess.Popen([
                sys.executable, str(BACKEND_PATH)
            ], cwd=str(backend_dir))
            
            # Wait a moment for startup
            time.sleep(3)
            
            if self.backend_process.poll() is None:
                logger.info("✅ GRT Backend started successfully on port 6001")
                logger.info("🌐 Access at: http://0.0.0.0:6001")
                return True
            else:
                logger.error("❌ GRT Backend failed to start")
                return False
                
        except Exception as e:
            logger.error(f"Error starting GRT backend: {e}")
            return False
    
    def stop_services(self):
        """Stop all GRT services"""
        self.running = False
        
        if self.backend_process and self.backend_process.poll() is None:
            logger.info("Stopping GRT Backend...")
            self.backend_process.terminate()
            
            # Wait for graceful shutdown
            try:
                self.backend_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                logger.warning("Backend didn't stop gracefully, force killing...")
                self.backend_process.kill()
        
        logger.info("GRT services stopped")
    
    def run(self):
        """Run the complete GRT system"""
        def signal_handler(signum, frame):
            logger.info("Shutdown signal received...")
            self.stop_services()
            sys.exit(0)
        
        # Register signal handlers
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        try:
            logger.info("🧠 Starting Complete GRT System...")
            logger.info("=" * 50)
            
            # Start backend
            if not self.start_backend():
                logger.error("Failed to start GRT system")
                return False
            
            self.running = True
            
            logger.info("🎯 GRT System is running!")
            logger.info("📋 System Status:")
            logger.info("   • Backend: http://0.0.0.0:6001")
            logger.info("   • Health Check: http://0.0.0.0:6001/health")
            logger.info("   • API: http://0.0.0.0:6001/api/chat")
            logger.info("")
            logger.info("Press Ctrl+C to stop the system")
            
            # Keep the launcher running
            while self.running:
                time.sleep(1)
                
                # Check if backend is still running
                if self.backend_process.poll() is not None:
                    logger.error("Backend process died, restarting...")
                    if not self.start_backend():
                        logger.error("Failed to restart backend, exiting...")
                        break
            
        except KeyboardInterrupt:
            logger.info("Shutdown requested by user...")
        except Exception as e:
            logger.error(f"Error running GRT system: {e}")
        finally:
            self.stop_services()

if __name__ == '__main__':
    launcher = GRTLauncher()
    launcher.run()
